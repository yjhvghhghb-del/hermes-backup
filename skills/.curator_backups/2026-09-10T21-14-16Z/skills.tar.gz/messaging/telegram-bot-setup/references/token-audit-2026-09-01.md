# Telegram Bot Token Audit — 2026-09-01

## 结论
**全部3个bot已被删除，token全部失效（404 Not Found）**。

| Profile | Token | Bot名 | 用途 | API状态 |
|---------|-------|-------|------|---------|
| default (root config) | `8800919754:***` | Hhvvbfgbot (黑逼毛老婆) | 主Bot | ✗ 404 (已删除) |
| geekwife | `8637317610:***` | ffdrtfcgbot | Telegram老婆bot | ✗ 404 (已删除) |
| siliconflow | `8363232963:***` | ? | SiliconFlow免费模型bot | ✗ 404 (已删除) |

## Token存放位置
- **主Bot**：Token在 `~/.hermes/.env` (`TELEGRAM_BOT_TOKEN=8800919754:***`)；config在 `~/.hermes/config.yaml` 的 `platforms.telegram` 节
- **其他Bot**：各profile的 `~/.hermes/profiles/<profile>/.env` 中的 `TELEGRAM_BOT_TOKEN`

## 验证方法（无需代理）
```bash
curl -s "https://api.telegram.org/bot<TOKEN>/getMe"
```
- 404 → bot已删除，需重建
- 401 → token无效，需换key
- 200 + `ok:true` → token有效

## 历史记录
- 2026-08-14/15：主bot token `8800919754` 正常工作（日志中有 `first_name":"黑逼毛老婆"` 记录）
- 2026-08-29：geekwife token `8637317610` 首次发现 404
- 2026-09-01：全部3个token确认为 404

---
name: telegram-bot-setup
description: 新建独立 Telegram Bot profile（独立性格+模型）
triggers:
  - 新建 Telegram Bot
  - 新建 Agent 接入电报
  - telegram bot 新 profile
---

# Telegram Bot 独立 Profile 接入

## 完整步骤

### 1. 创建 Profile
```bash
hermes profile create <profile_name>
```

### 2. 写 SOUL.md 性格设定
路径：`~/.hermes/profiles/<profile>/SOUL.md`

## config.yaml
```yaml
model:
  base_url: https://api.minimaxi.com/anthropic
  default: MiniMax-M2.7
  provider: minimax-cn

platforms:
  telegram:
    enabled: true
    dm_policy: open

streaming:
  enabled: true
  edit_interval: 0.3
  buffer_threshold: 4

_config_version: 33
```

> ⚠️ mytokk 不能直接接 Bot（指纹检测），用 MiniMax-M2.7；编程任务通过 `claude -p` 命令走 Opus-4-8

> ⚠️ **mytokk 不能直接接 Bot**：mytokk 有客户端指纹检测，非 Claude CLI 请求返回 http200 + 空 stream（EmptyStreamError）。Bot 对话直接用 `MiniMax-M2.7`，编程任务走 `claude -p` 命令调用 Opus-4-8。

### 4. 写 .env（必须！）
路径：`~/.hermes/profiles/<profile>/.env`
```
TELEGRAM_BOT_TOKEN=123456789:ABCDEFG...
ANTHROPIC_BASE_URL=https://api.mytokk.com
ANTHROPIC_AUTH_TOKEN=sk-xxxxxxxx
```

### 5. 启动
```bash
hermes -p <profile> gateway run
```

### 6. 配对
1. 用户 Telegram 搜 Bot 发消息 → 收到配对码
2. `hermes -p <profile> pairing approve telegram <CODE>`

## mytokk 配置要点

| 项 | 正确 | 错误 |
|---|---|---|
| Base URL | `https://api.mytokk.com` | 含 `/v1` 后缀 |
| 认证 | `ANTHROPIC_AUTH_TOKEN` | `ANTHROPIC_API_KEY` |

> ⚠️ **Bot 不能直接用 mytokk**：mytokk 客户端指纹检测导致 `custom` provider 返回 EmptyStreamError。Bot 只能走 MiniMax-M2.7，编程任务通过 `claude -p` 命令调用 Opus-4-8。

## 已知坑

### provider 必须是 custom
`anthropic-compatible` 不被识别 → "Unknown provider"。必须是 `custom`。

### 杀进程正确方式
- 看 PID：`hermes -p <profile> gateway status`
- 杀：`kill <PID>`
- 不要用 `hermes gateway stop`（操作 default profile）

### ⚠️ 同一 Bot Token 多个 Profile 会重复回复（核心陷阱）
**症状**：同一条消息出现两条几乎相同的回复。

**根因**：多个 Hermes profile 使用同一个 Telegram bot 的 token，都注册到 Telegram Bot API 的 updates 端点，导致每条消息每个 profile 都收到并各自回复。

**调查命令**：
```bash
# 1. 看哪些 profile 的 config 里有 telegram 配置
grep -r "telegram" ~/.hermes/profiles/*/config.yaml

# 2. 看实际在跑的 hermes 进程
ps aux | grep "hermes --profile" | grep -v grep

# 3. 看 gateway 日志每条消息是否只发一次
grep "Sending response" ~/.hermes/logs/gateway.log
```

**原则**：**一个 Telegram bot token 只允许一个 profile 接入**。如果要给不同 profile 配各自的 bot，必须用 @BotFather 申请新的 token。

**修复步骤**：
1. 确认是哪个 profile 在捣乱：`grep -r "telegram" ~/.hermes/profiles/*/config.yaml`
2. 关掉重复接入的 profile 的 Telegram：`enabled: false`
3. `kill <PID>` 重启该 profile
4. 确认只有 default profile（或其他指定唯一 profile）接 Telegram

## streaming 模式导致 Telegram 显示重复（未完全解决）

- **症状**：日志里每条消息只有一条 "Sending response"，但 Telegram 客户端显示两条几乎相同的消息
- **根因**：streaming 模式边生成边调用 `editMessageText`，Telegram 客户端把每次编辑渲染为新消息而非编辑同一条
- **尝试方案**：调大 `edit_interval`（0.3→0.8）和 `buffer_threshold`（4→10）可能减少但不能完全消除
- **老公明确要求**：「流式输出没关吧，流式输出不用关的」— streaming 不能关
- **状态**：参数调整后仍有偶发重复，继续观察

## 调查 checklist

```bash
# Step 1：扫描所有 profile 的 telegram 配置
for profile in ~/.hermes/profiles/*/; do
  name=$(basename $profile)
  tg=$(grep -A1 "^  telegram:" $profile/config.yaml 2>/dev/null | grep "enabled" | awk '{print $2}')
  echo "$name: telegram=$tg"
done

# Step 2：看实际在跑哪些 profile
ps aux | grep "hermes --profile" | grep -v grep

# Step 3：确认只有 default 接 Telegram
grep "Sending response" ~/.hermes/logs/gateway.log | grep "Telegram" | wc -l
# 每条消息应该只有一行 Sending response 到对应 chat_id
```

# Android/Termux Background Spawn Workaround (updated 2026.08.19)

## Problem
On Android/Termux, `hermes --profile <name>` exits immediately with:
```
Warning: Input is not a terminal (fd=0).
Shutting down… (finalizing session)
```
Root cause: prompt_toolkit detects no TTY on stdin and Hermes exits. This is NOT a config problem.

## Working Solution: `gateway run`

```bash
# Named profiles — --profile flag goes IMMEDIATELY after `hermes`
hermes --profile <name> gateway run

# Default profile (主bot / Telegram) — NO --profile flag
hermes gateway run
```

The `gateway run` subcommand bypasses the TUI prompt_toolkit path entirely — no TTY needed.

**⚠️ WRONG commands (avoid these):**
```bash
hermes serve --gateway              # ❌ "unrecognized arguments: --gateway"
hermes --profile <name> serve       # ❌ "unrecognized arguments: serve"
hermes --profile <name> gateway     # ❌ missing subcommand "run"
```

**⚠️ Use terminal(background=true) in Hermes agent, NOT shell &/nohup** — shell background wrappers are rejected by the terminal tool.

**Key fact confirmed 2026.08.20:** The default profile (主bot/Telegram) uses `hermes gateway run` with NO `--profile` flag. All named profiles use `hermes --profile <name> gateway run`. Using `--profile default` is wrong for the default bot — it would look for a profile directory called "default" instead of using the main `~/.hermes/` directory.
**Verified running (2026.08.19):**
- cutegirl (PID 28450) ✓
- geekwife (PID 28608) ✓
- licai (PID 28612) ✓
- siliconflow (PID 28614) ✓
- default (PID 25911) ✓

**Shell-level backgrounding (`&`/nohup) is BLOCKED by the terminal tool** — always use `terminal(background=true)` instead.

## Python One-Line Launcher (all profiles)

```python
import subprocess
profiles = ['cutegirl', 'geekwife', 'wenyu', 'libai', 'licai', 'siliconflow']
for p in profiles:
    subprocess.Popen(['bash', '-c', f'cd ~/.hermes/profiles/{p} && hermes --profile {p} gateway run'])
```

## Verified Startup Log (2026.08.20)

| Profile | Command | Result |
|---------|---------|--------|
| default | `hermes gateway run` | ✓ PID 10444 |
| geekwife | `hermes --profile geekwife gateway run` | ✓ |
| licai | `hermes --profile licai gateway run` | ✓ |
| siliconflow | `hermes --profile siliconflow gateway run` | ✓ |
| wenyu | `hermes --profile wenyu gateway run` | ✓ |
| cutegirl | `hermes --profile cutegirl gateway run` | ✗ blocked by wenyu (same app_id) |
| libai | `hermes --profile libai gateway run` | ✗ blocked by licai (same app_id) |

**Common errors from wrong commands:**
- `hermes serve --gateway` → `error: unrecognized arguments: --gateway`
- `hermes --profile X serve` → `error: unrecognized arguments: serve`
- `hermes --profile X gateway` (no `run`) → gateway starts but immediately exits

**To start all non-conflicting bots:**
```bash
# Kill stale PIDs first
pkill -f "hermes gateway" 2>/dev/null; sleep 2

# Then start each — use terminal(background=true) in Hermes agent
hermes gateway run &
hermes --profile geekwife gateway run &
hermes --profile siliconflow gateway run &
hermes --profile licai gateway run &
hermes --profile wenyu gateway run &
```

**To start a conflicting bot (e.g. cutegirl instead of wenyu):**
```bash
kill <wenyu_pid>  # stop the winner first
hermes --profile cutegirl gateway run  # start the blocked one
```

## App_id Collision Status (2026.08.20)
## App_id Collision Status (2026.08.20)

| Profile | app_id | Running? |
|---------|--------|----------|
| wenyu | `cli_aae7a3ad78b8dbe3` | ✓ (wins over cutegirl) |
| cutegirl | `cli_aae7a3ad78b8dbe3` | ✗ (blocked by wenyu) |
| licai | `cli_aafa2c6a83b85bee` | ✓ (wins over libai) |
| libai | `cli_aafa2c6a83b85bee` | ✗ (blocked by licai) |
| geekwife | (Telegram only) | ✓ |
| siliconflow | (Telegram only) | ✓ |
| default | (Telegram only) | ✓ |

Only ONE per collision group can run at a time. Group A (`cli_aafa2c6a83b85bee`): licai wins. Group B (`cli_aae7a3ad78b8dbe3`): wenyu wins.

**Confirmed 2026.08.20:** 5 bots running simultaneously — default + geekwife + licai + siliconflow + wenyu. cutegirl and libai cannot run while their collision partners are running.

## Deprecated Scripts
- `~/.hermes/scripts/run-profile.sh` — setsid approach, no longer works
- `~/.hermes/scripts/run-profile.py` — PTY approach, no longer works
Both replaced by `hermes --profile <name> gateway run`.

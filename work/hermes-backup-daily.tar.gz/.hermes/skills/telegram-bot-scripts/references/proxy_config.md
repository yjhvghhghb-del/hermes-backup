# Proxy Auto-Discovery Config

## Known Proxy IPs (as of 2026.09.23)

| IP | Ports | Status | Notes |
|---|---|---|---|
| 127.0.0.1 | 7890 | ✅ **Auto-fallback** | 本地代理，Hermes自动发现使用 |
| 192.168.110.40 | 7891 | ⚠️ DNS broken | TCP通但SOCKS DNS解析 api.telegram.org 失败 |
| 172.19.0.1 | 7890 | ✅ Backup | 备用代理 |
| 10.1.252.196 | 7891, 7890 | ❌ Broken | TCP timeout，连不上 |
| 192.168.110.225 | 7891, 7890 | ✅ Backup | 备用 |

## Critical: Proxy DNS Issue — #1 Cause of "Bot Connected But Not Replying"
**SOCKS proxy TCP port can be open (`nc -zv` succeeds) while SOCKS DNS resolution fails internally.** This is the #1 cause of bot connection failures.

Symptoms:
- `nc -zv 192.168.110.40 7891` → Connection succeeded
- `curl --socks5 192.168.110.40:7891 https://api.telegram.org/...` → "Could not resolve host: api.telegram.org"

**When this happens:**
1. Remove `TELEGRAM_PROXY` from `~/.hermes/.env` entirely — do NOT try another broken proxy
2. Restart: `kill <PID> && hermes gateway run --replace`
3. Hermes auto-discovers local `127.0.0.1:7890` proxy and uses it

**Why direct connection works**: Telegram API `https://api.telegram.org` resolves fine over direct internet from the server. Only needed when server has no direct outbound internet (Termux behind NAT).

## Local Proxy Auto-Discovery
When `TELEGRAM_PROXY` is unset, Hermes checks: `http://127.0.0.1:7890` then `http://127.0.0.1:7891`. Confirmed working: `nc -zv 127.0.0.1 7890` → Connection succeeded.

## Auto-Scan Cron Job
- Job ID: `57a86162ad9f`
- Scans: `192.168.110.0/24`, `10.1.252.0/24`
- Runs: every 5 minutes
- Best proxy selected by lowest latency

## User Preference
- Streaming: 4 chars minimum, 0.3s interval
- Streaming URL: `telegram_stream.py <chat_id> <message>`
- Sticker: `send_sticker.py <chat_id> -p <pack> -n <index>`
- 首选代理：192.168.110.40:7891（仅当DNS正常时）
- 所有profile的.env都需同步更新代理IP

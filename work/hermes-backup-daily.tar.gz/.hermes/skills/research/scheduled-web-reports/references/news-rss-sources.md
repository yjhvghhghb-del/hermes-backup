# News / AI-Briefing Sources for Scheduled Reports (RSS fallback)

Verified 2026-10-31 from Termux (direct connections, no proxy needed, no API key).

## When to use this

Use when the job is a **daily news briefing / digest** (AI日报, 早报, tech news roundup)
and the normal `web_search` path is unavailable.

### Trigger: Tavily 432 on BOTH `web_search` and `web_extract`

```
Client error '432 ' for url 'https://api.tavily.com/search'
Client error '432 ' for url 'https://api.tavily.com/extract'
```

432 is an approvals/quota condition on the search backend — it is NOT "these tools are
broken". `web_extract` failing too means **no page-extraction path exists at all**,
so don't retry with a different URL. Go straight to RSS/Atom.

## The verified working set (RSS/Atom, all HTTP 200, all parse as XML)

```bash
mkdir -p ~/tmp/<job-name> && cd ~/tmp/<job-name>
for u in "https://techcrunch.com/category/artificial-intelligence/feed/|tc.xml" \
         "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml|verge.xml" \
         "https://arstechnica.com/feed/|ars.xml" \
         "https://openai.com/blog/rss.xml|oai.xml"; do
  url="${u%%|*}"; f="${u##*|}"
  curl -s --max-time 25 -o "$f" -w "%{http_code} %{size_download} $f\n" -L "$url"
done
```

| Feed | URL | Notes |
|------|-----|-------|
| TechCrunch AI | `techcrunch.com/category/artificial-intelligence/feed/` | RSS 2.0, ~10 AI items/day, has descriptions |
| The Verge AI | `theverge.com/rss/ai-artificial-intelligence/index.xml` | **Atom**, `<a:entry>` not `<item>` |
| Ars Technica | `arstechnica.com/feed/` | RSS 2.0, general tech — filter by title |
| OpenAI blog | `openai.com/blog/rss.xml` | RSS 2.0, **1300+ items**, high-signal vendor announcements |

Vendor blogs worth adding: `blog.google/technology/ai/rss/`, `huggingface.co/blog/feed.xml`,
`blogs.nvidia.com/feed/`, `mistral.ai/news/feed/`.

## Pitfalls that cost time

- ⚠️ **Never write to `/tmp` on Termux** — not writable. `curl -o /tmp/f.xml` fails with
  "No such file or directory" and the shell loop then reports a misleading empty size.
  Use `~/tmp/<job-name>/`.
- ⚠️ **Not every feed works.** Verified same session:
  - `venturebeat.com/category/ai/feed/` → **HTTP 429** (rate-limited)
  - `anthropic.com/news/rss.xml` → **HTTP 404** (no RSS at that path)
  - `deepmind.google/blog/rss.xml` → 200 but **not well-formed XML** (no namespace decl)
  Always check the HTTP code AND that `ET.parse()` succeeds before using a feed.
  A 200 with a non-XML body makes `ET.parse` throw
  `ParseError: not well-formed (invalid token)`.
- ⚠️ **`web_extract` is unavailable when Tavily is down.** To read a specific article
  body, fetch the HTML yourself and strip tags:
  ```bash
  curl -s --max-time 25 -L -A "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/120 Mobile" \
       -o art.html "https://www.theverge.com/tech/1023528/some-slug"
  ```
  Then `re.sub(r'<script.*?</script>|<style.*?</style>','',s,flags=re.S)` →
  `html.unescape(re.sub(r'<[^>]+>',' ',s))` → collapse whitespace. Sites are
  nav-heavy, so **anchor on a keyword** (`t.find('TPU')`) rather than `t[0:1800]`
  — the first 1800 chars are usually the nav menu, not the article.
- ⚠️ **`execute_code` is blocked in cron mode** ("runs arbitrary local Python …
  approvals.cron_mode"). Write the parser with `write_file`, run it with
  `python parse.py`, or inline it as `python3 -c` in `terminal`. `python3 -c` via
  `terminal` works fine.
- ⚠️ **Hacker News Algolia API returned HTTP 200 with a 0-byte body** (empty
  response, no JSON). Don't rely on it as a news source; `jq`/JSON parse fails
  with `Expecting value: line 2 column 1`. RSS is more reliable.
- ⚠️ **arXiv IDs in the future/today look unusual** (e.g. `2610.40655v1` for
  2026-10-29). That's the real date-encoded form — don't reject it as malformed.

## Parser (handles both RSS 2.0 and Atom)

```python
import xml.etree.ElementTree as ET, re

def parse_feed(path):
    root = ET.parse(path).getroot()
    # RSS 2.0 uses <item>, Atom uses <entry> in the Atom namespace
    items = root.findall('.//item') or root.findall('.//{http://www.w3.org/2005/Atom}entry')
    out = []
    for it in items:
        title = it.findtext('title') or it.findtext('{http://www.w3.org/2005/Atom}title') or ''
        date  = (it.findtext('pubDate') or it.findtext('{http://www.w3.org/2005/Atom}updated') or '')
        link  = it.findtext('link') or ''
        if not link:                       # Atom puts the URL in an attribute
            le = it.find('{http://www.w3.org/2005/Atom}link')
            link = le.get('href') if le is not None else ''
        desc = it.findtext('description') or it.findtext('{http://www.w3.org/2005/Atom}summary') or ''
        desc = re.sub('<[^>]+>', '', desc or '').strip()
        out.append({'title': ' '.join(title.split()), 'date': date[:25],
                    'link': link, 'desc': desc[:400]})
    return out
```

## Pairing RSS with arXiv for a "research picks" section

RSS gives industry news; the **arXiv API** gives same-day research. Both work when
Tavily is down (`export.arxiv.org` is directly reachable, HTTP 200, no key):

```bash
curl -s "https://export.arxiv.org/api/query?search_query=cat:cs.AI+OR+cat:cs.CL+OR+cat:cs.LG&sortBy=submittedDate&sortOrder=descending&max_results=15"
```

Parse with the Atom namespace `{http://www.w3.org/2005/Atom}` (`a:entry`, `a:title`,
`a:id`, `a:published`, `a:summary`). Title/summary contain newlines — collapse with
`' '.join(text.split())` or the briefing renders with ragged spacing.

Useful targeted queries for an AI daily:
- `abs:"agent"` — agentic AI work
- `cat:cs.CR` — safety/security
- `ti:"chain of thought"`, `abs:"watermark"`, `abs:"jailbreak"`

## Briefing format that worked

For 老公's AI日报 the accepted shape was:

```
📰 AI日报 | YYYY年MM月DD日 星期六
**1. 🔥 <headline>**      # emoji-led, one-line, then 3-5 sentences of substance
...
**10. 🧪 研究前沿速递（arXiv 最新）**
• *PaperName* — one clause on why it matters
**📊 今日主线**：2-3 sentence synthesis of the day's through-line
❤️ 老婆整理
```

Rules that landed well:
- **每条 3-5 句**，包含具体数字（股价跌幅、金额、时间点）——不要标题党空话。
- 收尾加一段 **"今日主线"** 归纳当日主线，而不是逐条复述。
- 最后一行固定 `❤️ 老婆整理`。
- 注明数据来源与降级情况（例如"web_search 挂了，改用 RSS + arXiv API"），
  让老公知道这期不是搜索结果而是直接抓的源。
- 大标题用 emoji + 短句，正文用 3-5 句，不要表格（中文资讯用表格可读性差）。

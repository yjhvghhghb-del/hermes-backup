# Cron Session Data Sources — reading yesterday's activity from local DBs

Observed 2026-11-12, Termux (Android), during the 9am daily-review cron job.
The job's own question was "what happened yesterday?" — the answer lives in
**three local SQLite DBs**, and each has a different schema. Getting them wrong
fails *silently* (wrong row counts), not loudly.

## The three DBs and what each answers

| DB | Answers | Timestamp column |
|---|---|---|
| `~/.hermes/state.db` | conversation history (messages, roles, content) | `timestamp` — **epoch float** |
| `~/.hermes/cron/executions.db` | cron job runs + status | `started_at` — **ISO-8601 string** |
| `~/.hermes/profiles/<p>/state.db` | per-profile conversations | same as `state.db` (epoch float) |

Per-profile `state.db` files often have **zero rows** for a given day — the
conversation history for the default profile lives in the root `state.db`.
Don't conclude "no activity" from an empty profile DB; check the root one.

## ⚠️ THE SILENT-FAILURE TRAP: mixing timestamp types

Comparing an **ISO-8601 string** column to an **epoch float** does **not** raise
and does **not** return zero rows. SQLite coerces and the predicate is
effectively always-true, so the "filtered" query returns **every row in the
table**:

```python
# WRONG — executions.db: started_at is a TEXT column, so this returns all 779 rows
cur.execute("SELECT * FROM executions WHERE started_at>=? AND started_at<?",
            (epoch_start, epoch_end))

# WRONG — state.db: timestamp IS an epoch float, so string bounds match nothing
cur.execute("SELECT * FROM messages WHERE timestamp>=? AND timestamp<?",
            ("2026-11-11", "2026-11-12"))
```

The symptom is a plausible-looking but wrong answer: "779 executions since
11/11" when 3 actually ran. **Always `PRAGMA table_info(<table>)` first and
branch on the column type** — don't assume.

The robust pattern: `ORDER BY <tscol> DESC LIMIT N` and filter in Python by
parsing the string. It needs no type juggling and gives you the newest rows
first, which is usually what a briefing wants:

```python
cur.execute("SELECT * FROM executions ORDER BY started_at DESC LIMIT 30")
# then filter rows by parsing d['started_at'][:10] == '2026-11-11'
```

## Reading yesterday's conversation from `state.db`

`messages` table columns: `id, session_id, role, content, timestamp` (role is
`user` / `assistant` / `tool`).

```python
c = sqlite3.connect("file:%s?mode=ro" % db, uri=True)   # read-only, no lock contention
cur.execute("PRAGMA table_info(messages)")
cols = [r[1] for r in cur.fetchall()]
```

⭐ **Read-only URI (`file:...?mode=ro`) is worth using** — the gateway is live
and writing to these DBs; a plain `sqlite3.connect()` can hit a lock.

⭐ **Filter the cron prompt preamble out of user rows.** Cron-injected messages
begin with a long `[IMPORTANT: You are running as a scheduled cron job...]`
block. Printing them raw floods the output with boilerplate and buries the
real instruction:

```python
txt = re.sub(r"\[IMPORTANT.*?\]", "", txt, flags=re.S)
```

⭐ **`role='tool'` rows contain huge JSON blobs** — cap or skip them. Use them
only when you need raw command output; the `assistant` rows already carry the
narrative summary. Printing tool rows raw blew up the context window
(291 KB from one `session_search` read).

## `cron/executions.db` — job status schema

Columns: `id, job_id, source, process_id, pid, process_started_at, status,
claimed_at, started_at, finished_at, error`.

- `status` ∈ `completed` / `failed` / `running` / `unknown`.
- `unknown` + a long `error` string means the scheduler restarted before the
  execution reached a terminal state — **not** that the job failed.
- `started_at` / `finished_at` are ISO-8601 with a `+08:00` offset.

The **job names** live in `~/.hermes/cron/jobs.json` (a list or dict of job
objects with `id`, `name`, `enabled`, `schedule`). Join `executions.job_id` →
`jobs.json.id` to render "每日Hermes备份" instead of `eb9b2a0e46d8`.

⭐ **`jobs.json` shape varies** — it may be a top-level list, a `{"jobs": [...]}`
dict, or a dict keyed by job id. Normalise before iterating:

```python
data = json.load(open(jobs_path))
jobs = data if isinstance(data, list) else (data.get("jobs") or data)
if isinstance(jobs, dict):
    jobs = list(jobs.values())
```

## The cron output files are the finished report text

`~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md` holds each run's
**prompt + final response**. This is far cheaper to read than replaying the
session DB — the file already contains the rendered report. Use the DB for
"what happened", these files for "what did it say".

```bash
find ~/.hermes/cron/output -newermt "2026-11-12 07:00" -type f
```

## Gateway health — read the state file, not `ps`

`~/.hermes/gateway_state.json` is the authoritative health snapshot:

```json
{"pid":15015,"gateway_state":"running","platforms":{
  "qqbot":{"state":"connected"},
  "feishu":{"state":"connected"},
  "telegram":{"state":"fatal","error_code":"missing_credentials",
              "error_message":"No bot token configured"}},
 "served_profiles":["default","cutegirl","geekwife","libai","licai","siliconflow","wenyu"]}
```

⚠️ **`telegram: fatal / missing_credentials` is EXPECTED and benign** when the
default profile is the Feishu/QQ one — the Telegram bots are separate
profiles. Reporting this as an outage is a false alarm. The real check is
whether the *served profiles* are up.

⚠️ **`ps -A | grep gateway` shows nothing on Termux** even when the gateway is
running (Termux-owned processes don't surface in `ps -A`). The state file's
`pid` field is the reliable source. Same lesson as the existing
"check logs not gateway list" rule in `gateway-architecture`.

## Current system state worth including in a daily review

- `df -h $HOME` → the writable partition is `dm-62` mounted at `/data/user/0`.
  The `/` partition is Android's read-only system image — **`Avail=0` there is a
  misreport, not a full disk.** Fire alarm = writable partition at 100%.
- `du -sh` the real suspects: `~/.hermes/hermes-agent`, `~/.hermes/profiles`,
  `~/.hermes/state.db`, `~/hermes-backup/.git`.

## Scraping rule for a briefing: don't write scratch files into `/tmp`

Termux has **no writable `/tmp`**. `write_file` to `/tmp/...` fails with
`Permission denied`; `curl -o /tmp/x.json` fails with exit 23. Write scratch
scripts and artifacts to **`$HOME`** and clean them up at the end of the turn.

Working pattern for the whole job (3 tool calls, no leftovers):

1. `write_file` → `~/q_yesterday.py` (the query script)
2. `terminal` → `python3 ~/q_yesterday.py`
3. `terminal` → `cd ~ && rm -f q_yesterday.py && echo cleaned`

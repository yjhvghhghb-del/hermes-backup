# Weather Data Sources for Scheduled Reports

Verified 2026-10-30 from Termux (direct connections, no proxy needed, no API key).

## Why not `web_search`?

`web_search` for "北京今天天气" returns **template pages** from weather.com.cn /
nmc.cn — the prose is navigation chrome, not real observations. `web_extract` on the
same pages yields an 18KB page that mostly contains links. Use the APIs below.

### ⚠️ EXCEPT when the query is date-specific — then NMC IS a usable source (2026-11-03)

The blanket ban above is too broad. **中央气象台 (`nmc.cn`) carries the complete,
date-anchored 7-day forecast table**, and two paths reach it:

**(a) `web_search` with a date in the query.** A query naming the date *and* the
weather elements pulls the nmc.cn forecast page into the result description, with the
real numbers inline:

```
query: "北京 11月3日 天气 白天 最高温 最低温 晴 冷空气"
→ result description contains:
    11/03  周二  晴  东风  微风  16℃  4℃
    11/04  周三  阴  南风  微风  13℃  4℃
```

Each day renders as `MM/DD + 星期X + 中文天气 + 风向 + 风力 + 最高℃ + 最低℃` —
that is a complete, quotable forecast row. The date is **right there in the row**, so
there is no stale-cache hazard like wttr.in's.

**(b) `web_extract` on `https://www.nmc.cn/publish/forecast/ABJ/beijing.html`.**
The forecast table IS in the extracted markdown (the rest of the page is nav links).
It caches to disk, so you can `read_file` the cached copy and read the rows directly.
In the cached markdown the rows appear as separate lines:

```
11/03
周二
晴
东风
微风
16℃
4℃
```

⚠️ The page also renders a **逐 3 小时观测表** further down (timestamps like
`03日02:00`, `08:00`, `14:00` with 气温/风速/气压/湿度/云量) — that part is the
*current* day's hourly detail, and the dates there (`03日`, `04日`) are the strongest
date anchor of all.

**Why this matters:** when `curl` to wttr.in returns empty (see pitfall below), NMC
via `web_search`/`web_extract` is the working fallback that still gives real,
date-anchored Chinese weather for a Beijing briefing. Use it, don't give up on weather.

**Caveats:**
- NMC has **no feels-like / humidity / air-quality / precipitation probability**.
  For "wear a mask" (haze) advice you still need wttr.in.
- The forecast table is rendered client-side, so a raw `curl` of the HTML may show an
  empty table. `web_extract` (which renders/extracts) or `web_search` is what surfaces it.

## 1. wttr.in — richest for air quality (best for China autumn/winter)

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=j1" | python3 -c "
import sys,json
d=json.load(sys.stdin)
c=d['current_condition'][0]
w=d['weather'][0]
print('NOW:',c['temp_C']+'C',c['weatherDesc'][0]['value'],'hum',c['humidity']+'%','wind',c['windspeedKmph']+'km/h',c['winddir16Point'],'feels',c['FeelsLikeC']+'C')
print('min',w['mintempC'],'max',w['maxtempC'])
print('sunrise',w['astronomy'][0]['sunrise'],'sunset',w['astronomy'][0]['sunset'])
for h in w['hourly']:
    print(h['time'],h['tempC']+'C',h['weatherDesc'][0]['value'],'rain%',h['chanceofrain'],'wind',h['windspeedKmph'])
print('--- 3day ---')
for day in d['weather'][1:3]:
    print(day['date'],'min',day['mintempC'],'max',day['maxtempC'])
"
```

**Why this one**: it's the only source that reports **air quality as text**
(`Smoky haze`, `Smoke`). Beijing in autumn/winter is frequently hazy, and
"wear a mask" is the single most actionable weather note you can give. open-meteo's
`weather_code` has no haze category.

**Gotchas**:
- ⚠️ **There is NO `lang_zh` key.** Some examples online use `c['lang_zh'][0]['value']` —
  that raises `KeyError: 'lang_zh'`. Use `c['weatherDesc'][0]['value']` (English) and
  translate in prose yourself ("烟霾", "晴", "多云", "小雨").
- ⚠️ `hourly[].time` is a **3-hour integer** (0/300/600/900/1200/1500/1800/2100),
  not an HH:MM string. Don't `datetime.strptime` it.
- `current_condition[0]` gives **apparent temperature** (`FeelsLikeC`) — useful
  alongside `temp_C` when the wind is up.
- `hourly[].windspeedKmph` peaks around midday (observed 23 km/h at 12:00 vs
  6 km/h at 00:00) — often a better travel note than precipitation.
- `weather[1:3]` = next two days, good for a "tomorrow it'll drop to X℃" line.

### ⚠️ Key-name traps when computing max wind / precip (observed 2026-10-31)

`hourly[]` entries expose wind under **two different keys** depending on which
part of the object you read, and using the wrong one raises `KeyError`/`TypeError`:

| Want | ✅ Correct key | ❌ Wrong key |
|------|---------------|-------------|
| Wind gust | `h['Gust']` (capital G) | `h['gust']` → KeyError |
| Wind speed | `h['windspeedKmph']` | — |
| Precipitation | `h['precipMM']` | `h['precipmm']` → KeyError |

Safe pattern that never raises (observed values: `Gust` absent → 0 on calm days):

```python
max_gust = max(int(x.get('Gust') or 0) for x in hourly)
max_precip = max(float(x.get('precipMM') or 0) for x in hourly)
```

⚠️ **`Gust` is often missing entirely** on calm days (wttr.in omits it rather
than sending 0) → a naive `x['Gust']` raises `KeyError` and kills the whole parse
mid-report. Always use `.get(...) or 0`. Note the values are **km/h** for
`windspeedKmph` but `Gust` is also km/h — don't mix with the `windspeedKmph`
peak of 23 km/h observed separately.

### ⚠️ `chanceofrain` is a **string** — coerce before comparing

`hourly[].chanceofrain` comes back as `"0"` / `"13"`, not an int. Sorting or
comparing it directly against an int raises `TypeError`. Coerce with `int()`
at the boundary (same rule as star counts in `github-trending.md`).

## 2. open-meteo — max/min/sunrise/sunset/precip probability

No key, direct, clean JSON.

```bash
curl -s --max-time 25 'https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,sunrise,sunset&timezone=Asia%2FShanghai&forecast_days=1'
```

- `weather_code` is WMO: `0`=clear, `1-3`=cloud, `51-67`=rain, `71-77`=snow, `95`=thunderstorm
- `daily` gives max/min + sunrise/sunset + precipitation probability in one call
- Diurnal swing = `temperature_2m_max - temperature_2m_min`; >10℃ → advise a jacket
- Returns a **grid point** (39.89/116.36), not the city centre — fine for a report

## 3. weather.com.cn current-observation JSON — one curl, instant

```bash
curl -s --max-time 25 "https://www.weather.com.cn/data/sk/101010100.html" \
  -H "Referer: https://www.weather.com.cn/" -H "User-Agent: Mozilla/5.0"
```

Returns:
```json
{"weatherinfo":{"city":"北京","cityid":"101010100","temp":"18","WD":"东南风","WS":"1级","SD":"17%","time":"17:05","rain":"0"}}
```

- ⚠️ **The `Referer` header is required** (and a browser UA) or the request is refused.
- ⚠️ The older `data/cityinfo/101010100.html` path now returns **301** — don't use it.
- Observations only, no forecast. Use as a "right now" supplement.

### ⚠️ wttr.in `curl` can return an EMPTY body through a proxy (2026-11-03)

The primary recommendation above is `curl wttr.in`. That failed on 2026-11-03:
`curl -s -m 30 --socks5-hostname 10.1.252.196:7891 "https://wttr.in/Beijing?format=j1"`
produced **zero bytes**, and piping it into `json.load` gave
`JSONDecodeError: Expecting value: line 1 column 1 (char 0)`.

**Diagnostic tip:** the failure looks identical whether the write target is bad or the
fetch is empty. This session, `curl -o /tmp/bj.json` **and** `curl -o ~/bj.json` both
failed with the same `No such file or directory` — even though `~/` is writable —
because curl could not create the file with content. **Don't conclude "the path is
wrong" from that message alone**; check whether the *fetch* returned bytes.

**Fall back in this order** (all confirmed working on 2026-11-03):
1. `web_extract` on wttr.in → ⚠️ **returns stale dates** — always verify
   `weather[0]['date'] == $(date +%F)` before using it.
2. `web_search` with a **date-specific** query → surfaces the NMC forecast table with
   real numbers (see the NMC section above). ✅ **This is what actually worked.**
3. `web_extract` on `nmc.cn/publish/forecast/ABJ/beijing.html` → the forecast table
   rows, date-anchored. ✅ Also worked.

⚠️ **Never write "天气查不到" when a weather source is reachable.** A report section
that says "查不到" when the NMC table was sitting in a `web_search` result is a false
negative that costs the user real information.

### ⚠️ `iconv` is not runnable in Termux (2026-11-03)

`/bin/iconv: cannot execute: required file not found` — piping curl output through
`iconv -f utf-8 -t utf-8 -c` aborts the whole command. Skip iconv entirely; the
sources here are already UTF-8 and `python3 -c` handles decoding.

## Recommended combination

| Need | Source |
|------|--------|
| Current temp + feels-like + wind | wttr.in |
| **Air quality / haze** | wttr.in (`weatherDesc`) — no other source has it |
| Today's max/min, sunrise/sunset | open-meteo |
| Precipitation probability | open-meteo (`precipitation_probability_max`) |
| Next 2–3 day trend | wttr.in (`weather[1:3]`) |
| **Chinese date-anchored forecast when curl fails** | **NMC via `web_search` (date in query) or `web_extract`** |

## Writing actionable weather notes

Don't just report numbers — give the action:

- Swing >10℃ → "外套必须带，早晚凉中午暖"
- `chanceofrain` 0 → "不用带伞"
- Haze/smoke in `weatherDesc` → "空气有霾，出门戴口罩"
- Midday wind spike → "中午风大，帽子/外套会被吹跑"
- Day-over-day drop in max temp → "明天降温到 X℃，比今天冷"

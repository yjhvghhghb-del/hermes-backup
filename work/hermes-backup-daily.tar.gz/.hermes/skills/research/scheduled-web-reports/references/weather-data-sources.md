# Weather Data Sources for Scheduled Reports

Verified 2026-10-30 from Termux (direct connections, no proxy needed, no API key).

## Why not `web_search`?

`web_search` for "北京今天天气" returns **template pages** from weather.com.cn /
nmc.cn — the prose is navigation chrome, not real observations. `web_extract` on the
same pages yields an 18KB page that mostly contains links. Never report weather from
these. Use the APIs below.

## 1. wttr.in — richest for air quality (best for China autumn/winter)

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=j1" | python3 -c "
import sys,json
d=json.load(sys.stdin)
c=d['current_condition'][0]
w=d['weather'][0]
print('NOW:',c['temp_C']+'C',c['weatherDesc'][0]['value'],'hum',c['humidity']+'%','wind',c['windspeedKmph']+'km/h',c['winddir16Point'],'feels',c['FeelsLikeC']+'C')
print('min',w['mintempC'],'max',w['maxtempC'])
print('sunrise',w['astronomy'][0]['sunrise'],'sunset',w['astronomy'][0]['sunset'])
for h in w['hourly']:
    print(h['time'],h['tempC']+'C',h['weatherDesc'][0]['value'],'rain%',h['chanceofrain'],'wind',h['windspeedKmph'])
print('--- 3day ---')
for day in d['weather'][1:3]:
    print(day['date'],'min',day['mintempC'],'max',day['maxtempC'])
"
```

**Why this one**: it's the only source that reports **air quality as text**
(`Smoky haze`, `Smoke`). Beijing in autumn/winter is frequently hazy, and
"wear a mask" is the single most actionable weather note you can give. open-meteo's
`weather_code` has no haze category.

**Gotchas**:
- ⚠️ **There is NO `lang_zh` key.** Some examples online use `c['lang_zh'][0]['value']` —
  that raises `KeyError: 'lang_zh'`. Use `c['weatherDesc'][0]['value']` (English) and
  translate in prose yourself ("烟霾", "晴", "多云", "小雨").
- ⚠️ `hourly[].time` is a **3-hour integer** (0/300/600/900/1200/1500/1800/2100),
  not an HH:MM string. Don't `datetime.strptime` it.
- `current_condition[0]` gives **apparent temperature** (`FeelsLikeC`) — useful
  alongside `temp_C` when the wind is up.
- `hourly[].windspeedKmph` peaks around midday (observed 23 km/h at 12:00 vs
  6 km/h at 00:00) — often a better travel note than precipitation.
- `weather[1:3]` = next two days, good for a "tomorrow it'll drop to X℃" line.

## 2. open-meteo — max/min/sunrise/sunset/precip probability

No key, direct, clean JSON.

```bash
curl -s --max-time 25 'https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,sunrise,sunset&timezone=Asia%2FShanghai&forecast_days=1'
```

- `weather_code` is WMO: `0`=clear, `1-3`=cloud, `51-67`=rain, `71-77`=snow, `95`=thunderstorm
- `daily` gives max/min + sunrise/sunset + precipitation probability in one call
- Diurnal swing = `temperature_2m_max - temperature_2m_min`; >10℃ → advise a jacket
- Returns a **grid point** (39.89/116.36), not the city centre — fine for a report

## 3. weather.com.cn current-observation JSON — one curl, instant

```bash
curl -s --max-time 25 "https://www.weather.com.cn/data/sk/101010100.html" \
  -H "Referer: https://www.weather.com.cn/" -H "User-Agent: Mozilla/5.0"
```

Returns:
```json
{"weatherinfo":{"city":"北京","cityid":"101010100","temp":"18","WD":"东南风","WS":"1级","SD":"17%","time":"17:05","rain":"0"}}
```

- ⚠️ **The `Referer` header is required** (and a browser UA) or the request is refused.
- ⚠️ The older `data/cityinfo/101010100.html` path now returns **301** — don't use it.
- Observations only, no forecast. Use as a "right now" supplement.

## Recommended combination

| Need | Source |
|------|--------|
| Current temp + feels-like + wind | wttr.in |
| **Air quality / haze** | wttr.in (`weatherDesc`) |
| Today's max/min, sunrise/sunset | open-meteo |
| Precipitation probability | open-meteo (`precipitation_probability_max`) |
| Next 2–3 day trend | wttr.in (`weather[1:3]`) |

## Writing actionable weather notes

Don't just report numbers — give the action:

- Swing >10℃ → "外套必须带，早晚凉中午暖"
- `chanceofrain` 0 → "不用带伞"
- Haze/smoke in `weatherDesc` → "空气有霾，出门戴口罩"
- Midday wind spike → "中午风大，帽子/外套会被吹跑"
- Day-over-day drop in max temp → "明天降温到 X℃，比今天冷"

# Weather Data Sources for Scheduled Reports

Verified 2026-10-30 from Termux (direct connections, no proxy needed, no API key).

## ⚠️ 2026-11-09 修正：「直连优先」不是硬规则 —— 直连 0 字节、走代理一次成功

The pitfall below (2026-11-03) recorded that a proxy returned zero bytes while
direct curl worked. **The reverse happened on 2026-11-09**: direct curl to wttr.in
returned **0 bytes** (exit=23) while the *same URL* through
`-x socks5h://127.0.0.1:7890` **succeeded on the first try** and returned real JSON.

→ **Both paths must be in the playbook; use whichever returns real bytes.**
Measure with `wc -c`, never guess:

```bash
curl -s -m 25 "https://wttr.in/Beijing?format=j1" | wc -c                        # direct
curl -s -m 25 -x socks5h://127.0.0.1:7890 "https://wttr.in/Beijing?format=j1" | wc -c
```

A count of 0 means *that route* is dead — switch routes. Don't debug the URL and
don't conclude the path is wrong.

⚠️ **Write the artifact under `$HOME`, never `/tmp`** (Termux): `-o /tmp/wx.json`
gave exit=23 + "No such file or directory" while `-o ~/wx.json` succeeded instantly.

⚠️ **wttr.in `format=j1` has NO `localObsDateTime` key** — that's **open-meteo**'s
(`current.time`). Using it raises `KeyError` and kills the parse mid-report.
Actual `current_condition[0]` keys:
`FeelsLikeC/FeelsLikeF, cloudcover, humidity, observation_time, precipInches,
precipMM, pressure, pressureInches, temp_C, temp_F, uvIndex, visibility,
visibilityMiles, weatherCode, weatherDesc, weatherIconUrl, winddir16Point,
winddirDegree, windspeedKmph, windspeedMiles`.
wttr.in's observation moment is **`observation_time`** (UTC, e.g. `02:04 AM`).
⭐ **Print `list(c.keys())` before writing a cross-source parser** — don't rely on
remembered key names.

⚠️ **The compact format returns FAHRENHEIT**: `Beijing: Smoky haze +43°F feels +40°F`
→ 43°F ≈ 6℃. Take temperatures from open-meteo's Celsius; use wttr.in only for
apparent temp / humidity / wind / weather description.

⚠️ **The compact format's `min`/`max` format specifiers can return garbage**
(observed 2026-11-10: `min-🌑 max-1` — the specifiers were dropped/ignored).
→ **Take max/min from open-meteo, always.** Treat wttr.in's compact min/max as
unreliable and cross-check against open-meteo's `daily.temperature_2m_max/min`.

⭐⭐⭐ **Both routes work, and which one works flips day to day — measured, never assumed.**
Observed sequence on the same URL (`https://wttr.in/Beijing?format=j1`):

| Date | Direct curl | Via `socks5h://127.0.0.1:7890` | Winner |
|------|-------------|----------------------------------|--------|
| 2026-11-03 | ✅ | ❌ 0 bytes | direct |
| 2026-11-05 | ✅ | ❌ 0 bytes | direct |
| 2026-11-09 | ❌ 0 bytes | ✅ | proxy |
| 2026-11-10 | ✅ (no proxy used at all) | n/a | direct |

→ **Never encode "direct first" or "proxy first" as a rule.** Run the route that
fits the moment and **measure the byte count** (`| wc -c`); 0 bytes means *that
route* is dead — switch, don't debug the URL.

⭐⭐⭐⭐ **The single most reliable weather call for a cron briefing: both curls
in ONE `terminal` invocation, separated by `;`.** On 2026-11-10, with Tavily
`web_search` returning 432 AND `web_extract` returning "Blocked: URL targets a
private or internal network address", this one call produced the entire weather
section — no proxy, no key, no retries:

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=%25l:+%25C+%25t+feels+%25f+min-%25m+max-%25M+wind-%25w+humidity-%25h"
echo; echo "=== OPEN-METEO ==="
curl -s --max-time 25 "https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&timezone=Asia%2FShanghai&forecast_days=1"
```

wttr.in gives the **haze description** (`Smoky haze`) that open-meteo structurally
cannot; open-meteo gives **Celsius max/min** that wttr.in's compact format may garble.
⭐ **If wttr.in returns a haze/smoke description, USE it** — "出门戴口罩" is the single
most actionable note in a Beijing autumn/winter briefing. Don't drop it just because
the numbers came from the other source.

⚠️ **open-meteo self-anchors its date** (`current.time` = `2026-11-10T09:00`,
`daily.time[0]` = `2026-11-10`) → **no date cross-check needed**, unlike wttr.in.

## Why not `web_search`?

`web_search` for "北京今天天气" returns **template pages** from weather.com.cn /
nmc.cn — the prose is navigation chrome, not real observations. `web_extract` on the
same pages yields an 18KB page that mostly contains links. Use the APIs below.

### ⚠️ EXCEPT when the query is date-specific — then NMC IS a usable source (2026-11-03)

The blanket ban above is too broad. **中央气象台 (`nmc.cn`) carries the complete,
date-anchored 7-day forecast table**, and two paths reach it:

**(a) `web_search` with a date in the query.** A query naming the date *and* the
weather elements pulls the nmc.cn forecast page into the result description, with the
real numbers inline:

```
query: "北京 11月3日 天气 白天 最高温 最低温 晴 冷空气"
→ result description contains:
    11/03  周二  晴  东风  微风  16℃  4℃
    11/04  周三  阴  南风  微风  13℃  4℃
```

Each day renders as `MM/DD + 星期X + 中文天气 + 风向 + 风力 + 最高℃ + 最低℃` —
that is a complete, quotable forecast row. The date is **right there in the row**, so
there is no stale-cache hazard like wttr.in's.

**(b) `web_extract` on `https://www.nmc.cn/publish/forecast/ABJ/beijing.html`.**
The forecast table IS in the extracted markdown (the rest of the page is nav links).
It caches to disk, so you can `read_file` the cached copy and read the rows directly.
In the cached markdown the rows appear as separate lines:

```
11/03
周二
晴
东风
微风
16℃
4℃
```

⚠️ The page also renders a **逐 3 小时观测表** further down (timestamps like
`03日02:00`, `08:00`, `14:00` with 气温/风速/气压/湿度/云量) — that part is the
*current* day's hourly detail, and the dates there (`03日`, `04日`) are the strongest
date anchor of all.

**Why this matters:** when `curl` to wttr.in returns empty (see pitfall below), NMC
via `web_search`/`web_extract` is the working fallback that still gives real,
date-anchored Chinese weather for a Beijing briefing. Use it, don't give up on weather.

**Caveats:**
- NMC has **no feels-like / humidity / air-quality / precipitation probability**.
  For "wear a mask" (haze) advice you still need wttr.in.
- The forecast table is rendered client-side, so a raw `curl` of the HTML may show an
  empty table. `web_extract` (which renders/extracts) or `web_search` is what surfaces it.

## 1. wttr.in — richest for air quality (best for China autumn/winter)

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=j1" | python3 -c "
import sys,json
d=json.load(sys.stdin)
c=d['current_condition'][0]
w=d['weather'][0]
print('NOW:',c['temp_C']+'C',c['weatherDesc'][0]['value'],'hum',c['humidity']+'%','wind',c['windspeedKmph']+'km/h',c['winddir16Point'],'feels',c['FeelsLikeC']+'C')
print('min',w['mintempC'],'max',w['maxtempC'])
print('sunrise',w['astronomy'][0]['sunrise'],'sunset',w['astronomy'][0]['sunset'])
for h in w['hourly']:
    print(h['time'],h['tempC']+'C',h['weatherDesc'][0]['value'],'rain%',h['chanceofrain'],'wind',h['windspeedKmph'])
print('--- 3day ---')
for day in d['weather'][1:3]:
    print(day['date'],'min',day['mintempC'],'max',day['maxtempC'])
"
```

**Why this one**: it's the only source that reports **air quality as text**
(`Smoky haze`, `Smoke`). Beijing in autumn/winter is frequently hazy, and
"wear a mask" is the single most actionable weather note you can give. open-meteo's
`weather_code` has no haze category.

**Gotchas**:
- ⚠️ **There is NO `lang_zh` key.** Some examples online use `c['lang_zh'][0]['value']` —
  that raises `KeyError: 'lang_zh'`. Use `c['weatherDesc'][0]['value']` (English) and
  translate in prose yourself ("烟霾", "晴", "多云", "小雨").
- ⚠️ `hourly[].time` is a **3-hour integer** (0/300/600/900/1200/1500/1800/2100),
  not an HH:MM string. Don't `datetime.strptime` it.
- `current_condition[0]` gives **apparent temperature** (`FeelsLikeC`) — useful
  alongside `temp_C` when the wind is up.
- `hourly[].windspeedKmph` peaks around midday (observed 23 km/h at 12:00 vs
  6 km/h at 00:00) — often a better travel note than precipitation.
- `weather[1:3]` = next two days, good for a "tomorrow it'll drop to X℃" line.

### ⚠️ Key-name traps when computing max wind / precip (observed 2026-10-31)

`hourly[]` entries expose wind under **two different keys** depending on which
part of the object you read, and using the wrong one raises `KeyError`/`TypeError`:

| Want | ✅ Correct key | ❌ Wrong key |
|------|---------------|-------------|
| Wind gust | `h['Gust']` (capital G) | `h['gust']` → KeyError |
| Wind speed | `h['windspeedKmph']` | — |
| Precipitation | `h['precipMM']` | `h['precipmm']` → KeyError |

Safe pattern that never raises (observed values: `Gust` absent → 0 on calm days):

```python
max_gust = max(int(x.get('Gust') or 0) for x in hourly)
max_precip = max(float(x.get('precipMM') or 0) for x in hourly)
```

⚠️ **`Gust` is often missing entirely** on calm days (wttr.in omits it rather
than sending 0) → a naive `x['Gust']` raises `KeyError` and kills the whole parse
mid-report. Always use `.get(...) or 0`. Note the values are **km/h** for
`windspeedKmph` but `Gust` is also km/h — don't mix with the `windspeedKmph`
peak of 23 km/h observed separately.

### ⚠️ `chanceofrain` is a **string** — coerce before comparing

`hourly[].chanceofrain` comes back as `"0"` / `"13"`, not an int. Sorting or
comparing it directly against an int raises `TypeError`. Coerce with `int()`
at the boundary (same rule as star counts in `github-trending.md`).

## 2. open-meteo — max/min/sunrise/sunset/precip probability

No key, direct, clean JSON.

```bash
curl -s --max-time 25 'https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,sunrise,sunset&timezone=Asia%2FShanghai&forecast_days=1'
```

- `weather_code` is WMO: `0`=clear, `1-3`=cloud, `51-67`=rain, `71-77`=snow, `95`=thunderstorm
- `daily` gives max/min + sunrise/sunset + precipitation probability in one call
- Diurnal swing = `temperature_2m_max - temperature_2m_min`; >10℃ → advise a jacket
- Returns a **grid point** (39.89/116.36), not the city centre — fine for a report

## 3. weather.com.cn current-observation JSON — one curl, instant

```bash
curl -s --max-time 25 "https://www.weather.com.cn/data/sk/101010100.html" \
  -H "Referer: https://www.weather.com.cn/" -H "User-Agent: Mozilla/5.0"
```

Returns:
```json
{"weatherinfo":{"city":"北京","cityid":"101010100","temp":"18","WD":"东南风","WS":"1级","SD":"17%","time":"17:05","rain":"0"}}
```

- ⚠️ **The `Referer` header is required** (and a browser UA) or the request is refused.
- ⚠️ The older `data/cityinfo/101010100.html` path now returns **301** — don't use it.
- Observations only, no forecast. Use as a "right now" supplement.

### ⚠️ wttr.in `curl` can return an EMPTY body through a proxy (2026-11-03)

The primary recommendation above is `curl wttr.in`. That failed on 2026-11-03:
`curl -s -m 30 --socks5-hostname 10.1.252.196:7891 "https://wttr.in/Beijing?format=j1"`
produced **zero bytes**, and piping it into `json.load` gave
`JSONDecodeError: Expecting value: line 1 column 1 (char 0)`.

**Diagnostic tip:** the failure looks identical whether the write target is bad or the
fetch is empty. This session, `curl -o /tmp/bj.json` **and** `curl -o ~/bj.json` both
failed with the same `No such file or directory` — even though `~/` is writable —
because curl could not create the file with content. **Don't conclude "the path is
wrong" from that message alone**; check whether the *fetch* returned bytes.

**Fall back in this order** (all confirmed working on 2026-11-03):
1. `web_extract` on wttr.in → ⚠️ **returns stale dates** — always verify
   `weather[0]['date'] == $(date +%F)` before using it.
2. `web_search` with a **date-specific** query → surfaces the NMC forecast table with
   real numbers (see the NMC section above). ✅ **This is what actually worked.**
3. `web_extract` on `nmc.cn/publish/forecast/ABJ/beijing.html` → the forecast table
   rows, date-anchored. ✅ Also worked.

⚠️ **Never write "天气查不到" when a weather source is reachable.** A report section
that says "查不到" when the NMC table was sitting in a `web_search` result is a false
negative that costs the user real information.

### ⚠️ `iconv` is not runnable in Termux (2026-11-03)

`/bin/iconv: cannot execute: required file not found` — piping curl output through
`iconv -f utf-8 -t utf-8 -c` aborts the whole command. Skip iconv entirely; the
sources here are already UTF-8 and `python3 -c` handles decoding.

## Recommended combination

| Need | Source |
|------|--------|
| Current temp + feels-like + wind | wttr.in |
| **Air quality / haze** | wttr.in (`weatherDesc`) — no other source has it |
| Today's max/min, sunrise/sunset | open-meteo |
| Precipitation probability | open-meteo (`precipitation_probability_max`) |
| Next 2–3 day trend | wttr.in (`weather[1:3]`) |
| **Chinese date-anchored forecast when curl fails** | **NMC via `web_search` (date in query) or `web_extract`** |

## Writing actionable weather notes

Don't just report numbers — give the action:

- Swing >10℃ → "外套必须带，早晚凉中午暖"
- `chanceofrain` 0 → "不用带伞"
- Haze/smoke in `weatherDesc` → "空气有霾，出门戴口罩"
- Midday wind spike → "中午风大，帽子/外套会被吹跑"
- Day-over-day drop in max temp → "明天降温到 X℃，比今天冷"

### ⚠️ 霾会「随时段升级」—— 只读 `current_condition` 会漏掉傍晚的重度霾（2026-11-11 实测）

wttr.in 的紧凑格式 `?format=%C`（或只读 `current_condition[0].weatherDesc`）
给的是**当前**天气描述。但**同一���北京白天到夜里的描述会演变**：

```
09:00  Smoke            (烟)
12:00  Smoky haze       (霾)
15:00  Smoky haze
18:00  Smoke
21:00  Severe smog      (重度霾)  ← 只有逐时表能看见
```

本轮就是靠逐时表才发现「**晚上 21:00 会转重度霾**」，
并把它写进报告（「出门戴口罩」）。只读当前值的写法**完全看不到这条** ——
当前是 `Smoke`，写出来就是「烟」， actionable 程度差很远。

→ **天气栏要写「什么时候变差」时，必须拉逐时表**：

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=j1" | python3 -c "
import json,sys
d=json.load(sys.stdin)
for day in d['weather'][:1]:
    print(day['date'],'min',day['mintempC'],'max',day['maxtempC'])
    for h in day['hourly']:
        print('  ',h['time'],h['tempC']+'C',h['weatherDesc'][0]['value'],'rain%',h['chanceofrain'],'precip',h['precipMM'])
"
```

`hourly[].time` 是 3 小时整数（`0/300/600/900/1200/1500/1800/2100`），
直接原样打印即可，**不要 `strptime`**（见上文 key 陷阱）。

⭐ **写报告时的用法**：找出 `weatherDesc` 里出现 `Smoke` / `Smoky haze` / `Severe smog`
的时段，然后写成「白天霾，**傍晚 21 点转重度霾**，出门戴口罩」——
比只写「有霾」多了一个**具体的时间点**，老公才知道几点出门要防护。

⚠️ **`Severe smog` 只出现在 wttr.in**，open-meteo 的 `weather_code` 没有霾这一类
（`45`=fog/雾，写不了"戴口罩"）。要写这句就必须用 wttr.in 的逐时表。

# GitHub Trending — verified parser & observed output

Session-verified on Termux (Android), 2026-10-22. Page served 11 rows.

## Why the raw-HTML path is required

`web_extract("https://github.com/trending?since=daily")` returned clean prose —
repo names, descriptions, and an avatar list — but **zero star counts and zero
language labels**. Those are exactly the fields a trending report needs. Anything
built on `web_extract` alone for this page produces a table with empty columns.

The extract also returned 15 repos while the raw HTML had 11 `<article class="Box-row">`
blocks. Different rendering between the extractor and the served page.

## Fetch

```bash
mkdir -p ~/tmp/trending && cd ~/tmp/trending \
  && curl -sL --max-time 45 -A 'Mozilla/5.0' \
       'https://github.com/trending?since=daily' -o trending.html \
  && wc -c trending.html     # -> ~587 KB
```

## Parser

See `scripts/parse_github_trending.py`. Two regexes must be exactly right or the
run silently half-fails:

| Field | Working pattern | Naive pattern that silently fails |
|---|---|---|
| stars | `stargazers"[^>]*>.*?svg.*?</svg>\s*([\d,]+)` with `re.S` | `stargazers"[^>]*>\s*([\d,]+)` — count is after the `<svg>` |
| repo | scope `<h2>.*?</h2>`, filter `href` by `count("/") == 2` | `href="/([^"]+)"` over whole article — grabs avatar/`/stargazers` |

Language: `itemprop="programmingLanguage">([^<]+)<`
Daily delta: `([\d,]+)\s*stars today`
Description: `<p class="col-9[^"]*">(.*?)</p>` then strip tags + `html.unescape`.

## Verified output format

```
cloudflare/security-audit-skill || JavaScript || 36,672 || today=2,012 || A coding-agent skill for multi-phase security audits...
vllm-project/vllm || Python || 94,911 || today=441 || A high-throughput and memory-efficient inference and serving engine for LLMs
stablyai/orca || TypeScript || 101,407 || today=1,541 || Orca is the place for working with a fleet of agents...
headroomlabs-ai/headroom || Python || 77,296 || today=474 || Compress tool outputs, logs, files, and RAG chunks before they reach the LLM...
DietrichGebert/ponytail || JavaScript || 171,781 || today=2,079 || Makes your AI agent think like the laziest senior dev in the room...
Comfy-Org/ComfyUI || Python || 141,575 || today=939 || The most powerful and modular diffusion model GUI, api and backend...
supabase/supabase || TypeScript || 113,047 || today=504 || The Postgres development platform...
twentyhq/twenty || TypeScript || 59,217 || today=112 || The open alternative to Salesforce, designed for AI.
shiyu-coder/Kronos || Python || 42,867 || today=575 || Kronos: A Foundation Model for the Language of Financial Markets
akitaonrails/ai-memory || Rust || 12,377 || today=286 || Solution for long term memory for agent coding CLIs...
Graphify-Labs/graphify || Python || 131,739 || today=1,433 || Turn any codebase, with its docs, SQL schemas, configs, and PDFs, into a queryable knowledge graph...
```

Sanity check on that run: every field populated — no `?` for stars, no `-` for
language. A run with `?` in the stars column means the SVG-spanning regex broke.

## Rotation between fetches

A second fetch of the same URL minutes later dropped these AI projects that had
been in the first: `anthropics/knowledge-work-plugins`, `wshobson/agents`,
`opencode`, `sickn33/agentic-awesome-skills`, `MadsLorentzen/ai-job-search` — and
added `supabase` and `twenty`. Trending is not stable intra-day; two snapshots are
never comparable.

## AI/ML filtering

Keywords that separated real AI projects from general-repo noise in this page:
LLM, agent, Claude, Codex, RAG, diffusion, foundation model, inference, MCP,
coding-agent, vector. `supabase` and `twenty` only qualify via the "AI application
database" / "designed for AI" angle — decide explicitly whether that's in scope
rather than letting it slide through by default.
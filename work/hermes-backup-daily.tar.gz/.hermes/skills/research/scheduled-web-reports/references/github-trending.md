# GitHub Trending — verified parser & observed output

Session-verified on Termux (Android), 2026-10-22. Page served 11 rows.

## Why the raw-HTML path is required

`web_extract("https://github.com/trending?since=daily")` returned clean prose —
repo names, descriptions, and an avatar list — but **zero star counts and zero
language labels**. Those are exactly the fields a trending report needs. Anything
built on `web_extract` alone for this page produces a table with empty columns.

The extract also returned 15 repos while the raw HTML had 11 `<article class="Box-row">`
blocks. Different rendering between the extractor and the served page.

## Fetch

```bash
mkdir -p ~/tmp/trending && cd ~/tmp/trending \
  && curl -sL --max-time 45 -A 'Mozilla/5.0' \
       'https://github.com/trending?since=daily' -o trending.html \
  && wc -c trending.html     # -> ~587 KB
```

### The established pipeline lives in `~/gh_trend/` — run it, don't re-implement it

`~/gh_trend/` holds the hardened pipeline for this exact job:

| file | role |
|---|---|
| `parse.py` | scrape → `rows.json` (HTML-sourced: repo, lang, stars, daily delta, desc) |
| `api.py` | GitHub REST enrichment → `api.json` (**optional**; never drives classification) |
| `rank.py` | classify + rank → `final.json` (AI block first, sorted by daily delta) |
| `verify.py` | **the authoritative test suite** — 7 assertion groups, run it |
| `soak.sh` | wipe artifacts, re-run every stage, assert the verifier passes N times |

`verify.py` is the real test suite for this job, not a repo-root `npm test` (see the
`npm test` placeholder trap in SKILL.md — a root `package.json` whose script is
`echo "Error: no test specified" && exit 1` has nothing to do with this pipeline).

**Before editing anything, read all five files.** They encode accumulated fixes:
the exclusion list, README description backfills, the known regex traps, and the
determinism check that classifies from HTML text so a rate-limited API can't change
the report. A parallel scratch parser loses those fixes and produces results that
disagree with the shipped pipeline.

When the pipeline's own verifier fails, **treat the failure as the signal** — that is
exactly what it is for. Observed 2026-11-09: two verifier assertions had rotted
(a `> 1000` star floor and a missing exclusion-set assertion), and both were real
findings, not noise.

### Fetch failures observed 2026-10-31 (Termux)

| Symptom | Cause | Fix |
|---|---|---|
| `web_extract` + `web_search` both HTTP 432 | Tavily backend rejecting the call | fall back to `curl` through a proxy |
| `curl` direct, HTTP 000 | egress needs a proxy | try `socks5h://172.19.0.1:7890`, `socks5h://10.1.252.196:7891` |
| HTTP 200 but `SIZE:0` | compression not negotiated | add `--compressed` |
| **HTTP 200 but `SIZE:0` on github.com HTML only, persists after `--compressed` and after `--noproxy '*'`** (observed 2026-11-10 — even `robots.txt` came back 0 bytes, while `api.github.com` returned full JSON through the same proxy) | **proxy type, not compression** — the HTTP proxy drops github.com's HTML body | **switch to SOCKS5 `socks5h://172.19.0.1:7890`**; it returned the full 541 KB page immediately. Probe with `curl ... https://github.com/robots.txt -o /dev/null -w "%{size_download}\n"` before adding more curl flags. |
| `curl: (23) Failed writing received data to disk` | `/tmp` not writable on Termux | write under `$HOME` (`~/tmp/trending/`) |
| `curl: (23) client returned ERROR on write of N bytes` on a writable path | **target partition 100% full** (observed 2026-11-01: `/` dm-28 at 0 bytes free) | `df -h / /data`; retry with `-o ~/file` (different partition) and report the full disk to the user |
| `curl: Failed to open /tmp/hdr.txt` aborted the whole command | `-D` redirect target unwritable | redirect headers to a local path |

Verified working fetch (594 KB):

```bash
cd ~/tmp/trending && curl -sS --max-time 40 --compressed \
  -x socks5h://172.19.0.1:7890 \
  -A 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36' \
  'https://github.com/trending?since=daily' -o trending.html \
  -w "HTTP:%{http_code} SIZE:%{size_download}\n"
```

Use `socks5h://` (not `socks5://`) so DNS resolves at the proxy end.

## Parser

See `scripts/parse_github_trending.py`. Two regexes must be exactly right or the
run silently half-fails:

| Field | Working pattern | Naive pattern that silently fails |
|---|---|---|
| stars | `stargazers"[^>]*>.*?svg.*?</svg>\s*([\d,]+)` with `re.S` | `stargazers"[^>]*>\s*([\d,]+)` — count is after the `<svg>` |
| repo | scope `<h2>.*?</h2>`, filter `href` by `count("/") == 2` | `href="/([^"]+)"` over whole article — grabs avatar/`/stargazers` |

Language: `itemprop="programmingLanguage">([^<]+)<`
Daily delta: `([\d,]+)\s*stars today`
Description: `<p class="col-9[^"]*">(.*?)</p>` then strip tags + `html.unescape`.

### Markup detail that breaks the obvious regex

GitHub's trending `<a>` tag carries several attributes before `href`:

```html
<h2 class="h3 lh-condensed">
  <a data-hydro-click="{...}" data-hydro-click-hmac="..." href="/owner/repo" ...>
```

So `<a href="/owner/repo"` never matches. Use attribute-order-independent matching:

```python
am = re.search(r'<a\b[^>]*href="/([^"/?#]+/[^"/?#]+)"', h2.group(1), re.S)
```

The `<h2>` also carries `class="h3 lh-condensed"`, so match the class rather than assuming
`<h2>` with no attributes. Note the page also contains unrelated `<h2 class="visuallyHidden__...">`.

### Type coercion

`stars` scraped from HTML arrives as a string (`"106204"`). Cross-checked against the
GitHub REST API it arrives as an `int` (`106204`). `!=` between them is True despite equal
value — a pure type mismatch that makes every repo look like a mismatch. Parse to `int` at
the HTML boundary and compare numerically.

## Verified output format

```
cloudflare/security-audit-skill || JavaScript || 36,672 || today=2,012 || A coding-agent skill for multi-phase security audits...
vllm-project/vllm || Python || 94,911 || today=441 || A high-throughput and memory-efficient inference and serving engine for LLMs
stablyai/orca || TypeScript || 101,407 || today=1,541 || Orca is the place for working with a fleet of agents...
headroomlabs-ai/headroom || Python || 77,296 || today=474 || Compress tool outputs, logs, files, and RAG chunks before they reach the LLM...
DietrichGebert/ponytail || JavaScript || 171,781 || today=2,079 || Makes your AI agent think like the laziest senior dev in the room...
Comfy-Org/ComfyUI || Python || 141,575 || today=939 || The most powerful and modular diffusion model GUI, api and backend...
supabase/supabase || TypeScript || 113,047 || today=504 || The Postgres development platform...
twentyhq/twenty || TypeScript || 59,217 || today=112 || The open alternative to Salesforce, designed for AI.
shiyu-coder/Kronos || Python || 42,867 || today=575 || Kronos: A Foundation Model for the Language of Financial Markets
akitaonrails/ai-memory || Rust || 12,377 || today=286 || Solution for long term memory for agent coding CLIs...
Graphify-Labs/graphify || Python || 131,739 || today=1,433 || Turn any codebase, with its docs, SQL schemas, configs, and PDFs, into a queryable knowledge graph...
```

Sanity check on that run: every field populated — no `?` for stars, no `-` for
language. A run with `?` in the stars column means the SVG-spanning regex broke.

## Rotation between fetches

A second fetch of the same URL minutes later dropped these AI projects that had
been in the first: `anthropics/knowledge-work-plugins`, `wshobson/agents`,
`opencode`, `sickn33/agentic-awesome-skills`, `MadsLorentzen/ai-job-search` — and
added `supabase` and `twenty`. Trending is not stable intra-day; two snapshots are
never comparable.

## AI/ML filtering

Keywords that separated real AI projects from general-repo noise in this page:
LLM, agent, Claude, Codex, RAG, diffusion, foundation model, inference, MCP,
coding-agent, vector. `supabase` and `twenty` only qualify via the "AI application
database" / "designed for AI" angle — decide explicitly whether that's in scope
rather than letting it slide through by default.

### Keyword false-positive trap (2026-10-31)

A substring keyword match on `deep` swept in `Renhuai123/ziwei-doushu` (紫微斗数开源排盘引擎 —
a Chinese-astrology / 紫微斗数 chart engine built on 倪海厦《天纪》, topics
`chinese-astrology`, `divination`, `fortune-telling`). It is **not** AI/ML and had to be
excluded explicitly.

Guards:
- Match on word boundaries, not raw substrings (`ai` otherwise hits "email", "chair",
  "domain"; `bot` hits "robotics"; `rag` hits "fragment").
- Keep an explicit exclusion set for known non-AI repos.
- **Audit the excluded set every run.** A repo the filter drops is invisible in the final
  table — there is no signal to the reader that something was lost. The excluded set is
  the cheapest place to catch a bad drop: print each excluded repo with its description
  and read it. This caught both `colibri` and `Kronos` on 2026-11-04.
- **Assert on what the filter removes, not a total survivor count.** A suite that asserted
  exactly 14 AI + 1 non-AI died on 2026-11-01 because the page served 14 rows, not 15 —
  the assertion failed on `len(rows)` before the filter logic was ever exercised. Assert
  that the excluded set contains exactly your known non-AI repos, and that survivors are
  `>= 8` and `<= len(rows)`. Never pin `len(rows)` or `len(ai)` to a literal.

### The verifier's row-count assertion (real failure, 2026-11-01)

`~/gh_trend/verify.py` asserted `len(rows) == 15` and `len(ai) == 14`. The live page
served 14 rows, so the suite failed on its very first assertion:

```
AssertionError: 14     # expected 15
```

The pipeline itself was correct — `rank.py` produced the right report. Only the test was
wrong, and it would have broken this cron job on any day the page length differed. The
fix is to assert shape, not count (see the SKILL.md verifier section for the exact
before/after).

## Row count varies — observed counts

11, 14, and 15 rows have all been observed for `?since=daily` on the same day across
different fetches. Treat the count as an input that varies, never as a constant.

## 2026-11-01 snapshot (14 rows, 12 AI + 2 non-AI)

| repo | lang | total | today | note |
|---|---|---|---|---|
| thedotmack/claude-mem | TypeScript | 107,841 | 1,723 | agent memory + AI compression |
| pbakaus/impeccable | Rust | 98,253 | 1,338 | design vocabulary for coding agents |
| milind-soni/OpenMausBot | TypeScript | 9,590 | 1,303 | |
| pingdotgg/t3code | TypeScript | 35,508 | 1,148 | no GitHub description — README backfill |
| Orkas-AI/Orkas | JavaScript | 6,150 | 1,044 | local-first multi-agent desktop team |
| HKUDS/DeepTutor | Python | 52,787 | 1,034 | |
| lightpanda-io/browser | Zig | 39,233 | 929 | headless browser for AI |
| mattpocock/skills | Shell | 308,355 | 883 | |
| Donchitos/Claude-Code-Game-Studios | Shell | 31,149 | 742 | 49 AI agents |
| obra/superpowers | Shell | 310,046 | 665 | |
| vorssaint/vorssaint-utils | Swift | 31,887 | 501 | ← non-AI (macOS menu bar) |
| THU-MAIC/OpenMAIC | TypeScript | 42,175 | 116 | multi-agent classroom |
| Renhuai123/ziwei-doushu | TypeScript | — | — | ← excluded, not AI/ML |
| bregman-arie/devops-exercises | Python | — | — | ← excluded, not AI/ML |

`vorssaint/vorssaint-utils` passed the keyword filter via the substring `ai` in
"macOS menu bar" / "macos" — another instance of the substring trap, caught only because
the row was inspected rather than trusted.

## GitHub REST API as enrichment — rate-limit trap

Unauthenticated `api.github.com/repos/<owner>/<repo>` is ~60 req/hr per IP. Across
repeated runs on 2026-10-31 it returned **15/15, then 14/15, then 12/15** repos, with
the failures moving around (`togg53192-cmd/jailbreaks`, `anthropics/skills`,
`pingdotgg/t3code`, `Renhuai123/ziwei-doushu`).

The failure mode that matters: `OpenMausBot` lost its API entry, and because the
AI classifier read `topics` from the API, it lost its only AI keyword and **dropped out of
the report** — 14 rows one run, 13 the next, with identical source HTML. That is a flaky
pipeline, not a stable one.

Rules that fix it:
- Catch API errors per repo; continue. Never let one 403 abort the enrichment stage.
- **Classify from HTML-sourced description text.** It is present for the vast majority of
  rows (see the topics-empty caveat below for the exceptions).
- Compare star counts with a tolerance (±50): the gap between scrape time and API time is
  live growth, typically 1–3 stars, not error.
- Daily-star counts are stable across runs; total counts drift upward. Rank by daily delta.

### Topics-empty false negative (2026-11-04) — the inverse of the rate-limit trap

The rate-limit trap above removes a repo from the report because its API entry vanished.
There is a **second, independent** way to lose a clearly-AI repo: it has `topics: []` on
the GitHub API, so any topics-based AI classifier never sees an AI keyword for it.

Observed on the 2026-11-04 page — two unambiguously AI/ML projects were classified
`ai=False` purely because their topics arrays were empty:

| repo | topics | description | verdict |
|---|---|---|---|
| `JustVugg/colibri` | `[]` | "A hierarchical inference engine for frontier MoE models: hot experts on the GPU (CUDA, Vulkan), warm ones in RAM, cold ones streamed from NVMe" | **AI/ML** — MoE inference engine |
| `shiyu-coder/Kronos` | `[]` | "Kronos: A Foundation Model for the Language of Financial Markets" | **AI/ML** — domain foundation model |

Both were rescued only by *reading the descriptions manually* after the classifier
excluded them. The same run correctly excluded two repos that had populated topics
(`anomalyco/hex` → speech-to-text; `floci-io/floci` → AWS emulator), so the topics signal
is useful but **not** sufficient.

Guards:
- **Never let `topics` be the sole AI signal.** Topics are a *booster*, not a gate.
- Classify from the **description text**, which is nearly always present even when
  topics are empty.
- Treat "excluded repo" as a **suspicion, not a verdict**: when a repo is dropped, glance
  at its description string. A one-line manual audit of the excluded set is cheap and
  catches exactly this class of miss. Prefer auditing the excluded set over auditing
  the included set — an included repo is already in the report, an excluded one is
  invisible.
- Description text alone can also be empty (`spotify/portal-ai-plugins` had none), so
  the classifier needs **both** signals ORed, plus a manual pass over the excluded set.
  Neither source is reliable in isolation.

### Verifier trap: asserting every row has a non-empty description (2026-11-04)

`~/gh_trend/verify.py` asserted `assert r['desc'], r` for every row. It failed on
`spotify/portal-ai-plugins`, whose GitHub description is **genuinely empty** — not a
parse bug:

```
AssertionError: {'repo': 'spotify/portal-ai-plugins', 'lang': 'TypeScript', 'stars': 3030,
                  'extra': '91 stars today', 'desc': '', 'today': 91, ...}
```

This is the same class of rot as hardcoding a row count, just inverted: the assertion
encoded a *content* invariant that is not universally true. Some repos ship no
description at all (`pingdotgg/t3code` did too, on 2026-10-31).

Fix — assert the shape, allow an empty cell:

```python
# WRONG — dies whenever a trending repo has no GitHub description
assert r['desc'], r

# RIGHT — the field exists; it is allowed to be empty
assert 'desc' in r
assert isinstance(r['desc'], str)
# and separately: how many rows lack a description? report, don't assert
empty_desc = [r['repo'] for r in final if not r['desc']]
```

Backfill a missing description from the README only if the row actually lands in the
report (see `pingdotgg/t3code` below). Do not let a missing description block the row.

## Star drift between runs

Same snapshot, later run:

```
impeccable        97,028 -> 97,036 -> 97,037
superpowers      309,410 -> 309,414 -> 309,416
```

Daily deltas were identical in every run (2300 / 2282 / 2055 / 1259 / 1140 / 930 / 895 / 876).
Report the daily delta as the ranking signal; treat the total as a live figure.

## 2026-10-31 snapshot (15 rows, all AI/ML)

| repo | lang | total | today |
|---|---|---|---|
| pbakaus/impeccable | Rust | 97,037 | 2300 |
| HKUDS/DeepTutor | Python | 51,760 | 2282 |
| togg53192-cmd/jailbreaks | - | 10,975 | 2055 |
| obra/superpowers | Shell | 309,416 | 1259 |
| thedotmack/claude-mem | TypeScript | 106,212 | 1140 |
| pingdotgg/t3code | TypeScript | 32,728 | 930 |
| milind-soni/OpenMausBot | TypeScript | 8,618 | 895 |
| mattpocock/skills | Shell | 307,464 | 876 |
| JetBrains/thinkrail | TypeScript | 6,569 | 722 |
| CopilotKit/OpenBot | TypeScript | 8,774 | 706 |
| lightpanda-io/browser | Zig | 38,354 | 626 |
| anthropics/skills | Python | 185,301 | 295 |
| macro-inc/macro | Rust | 5,864 | 57 |
| expo/skills | Shell | 3,892 | 38 |
| Renhuai123/ziwei-doushu | TypeScript | 11,193 | 1126 | ← excluded, not AI/ML |

`pingdotgg/t3code` has **no GitHub description** (empty in both the HTML and the API) —
backfill it from the README or leave the field empty rather than shipping a blank cell.

## 2026-11-04 snapshot (13 rows, 9 AI + 4 non-AI)

| repo | lang | total | today | note |
|---|---|---|---|---|
| vercel-labs/agent-desktop | Rust | 12,666 | 3,791 | AI agent computer-use CLI — top of the day |
| D4Vinci/Scrapling | Python | 94,781 | 1,658 | scraping framework, AI-adjacent |
| Donchitos/Claude-Code-Game-Studios | Shell | 34,638 | 1,182 | 49 AI agents |
| mattpocock/skills | Shell | 308,358 | 1,164 | agent skills |
| thedotmack/claude-mem | TypeScript | 107,845 | 1,139 | agent cross-session memory |
| p-e-w/heretic | Python | 38,767 | 701 | training-free LLM modification |
| max-sixty/worktrunk | Rust | 10,466 | 438 | git worktrees for parallel agents |
| Usagi-org/ai-goofish-monitor | Python | 16,338 | 228 | 闲鱼 AI 监控 |
| spotify/portal-ai-plugins | TypeScript | 3,030 | 91 | AI — **no description** (empty) |
| JustVugg/colibri | C | 47,236 | 802 | **AI** — topics `[]`, MoE inference engine |
| shiyu-coder/Kronos | Python | 46,503 | 503 | **AI** — topics `[]`, financial foundation model |
| anomalyco/hex | Rust | 4,564 | 410 | ← excluded, speech-to-text dictation |
| floci-io/floci | Java | 28,742 | 482 | ← excluded, AWS emulator |

The day was dominated by **agent infrastructure** — memory (claude-mem), computer-use
(agent-desktop), parallel dev (worktrunk), skills (skills, Game-Studios) — with
model-side entries (colibri's MoE tiering, Kronos's domain foundation model) at both
ends of the list. Note `Kronos` recurring from 2026-10-31 with rising stars
(42,867 → 46,503), i.e. it is a sustained climber rather than a one-day spike.

`vercel-labs/agent-desktop` at +3,791 daily stars was the single largest delta observed
on this page to date — more than double the runner-up.

## 2026-11-05 snapshot (16 rows, 10 AI + 6 non-AI)

Fetched via `socks5h://172.19.0.1:7890` → 607 KB, 16 `<article class="Box-row">`.

| repo | lang | total | today | note |
|---|---|---|---|---|
| NVIDIA/auto-ontology | Python | 4,905 | 2,050 | NVIDIA semantic graph reasoning layer |
| vercel-labs/agent-desktop | Rust | 15,027 | 2,470 | computer-use CLI for agents (2nd day trending) |
| sponsors/thedotmack | TypeScript | 112,822 | 1,172 | agent cross-session context |
| sponsors/mattpocock | Shell | 313,278 | 1,379 | agent skills from his .agents dir |
| max-sixty/worktrunk | Rust | 11,010 | 531 | git worktrees for parallel agents (2nd day) |
| harry0703/MoneyPrinterTurbo | Python | 138,930 | 617 | AI auto short-video generation |
| garrytan/gstack | TypeScript | 139,317 | 290 | Garry Tan's Claude Code setup, 23 tools |
| FareedKhan-dev/kimi-k3-in-c | C | 10,274 | 351 | 2.78T Kimi K3 in 8.24GB RAM, pure C99 |
| Thysrael/Horizon | Python | 12,474 | 121 | AI news radar, CN+EN briefings |
| scenario-labs/skills | Python | 2,414 | 224 | agent skills for image/video/audio/3D |
| JiaFeiMiao-K-Cat/DiscImageStudio | C# | 6,574 | 1,778 | ← **no description**; not AI (disc burning) |
| sponsors/floci-io | Java | 29,585 | 1,090 | ← excluded, AWS emulator |
| github/spec-kit | Python | 147,286 | 808 | ← excluded, SDD toolkit |
| The-PR-Agent/pr-agent | Python | 14,743 | 280 | ← excluded, PR reviewer (not AI/ML per se) |
| sponsors/D4Vinci | Python | 96,494 | 2,005 | ← excluded, scraping framework |
| sponsors/MichaelCade | Shell | 30,403 | 97 | ← excluded, learning map |

Two new confirmed instances of the **legitimately-empty-description** case:
`JiaFeiMiao-K-Cat/DiscImageStudio` (no `<p>` at all — the article ends right after the
`1,778 stars today</span>`) and `The-PR-Agent/pr-agent`. Both prove the point from
SKILL.md: assert description *coverage*, not per-row presence.

### `sponsors/*` repos are trending in bulk (2026-11-05)

Six of sixteen rows were `sponsors/<user>` — GitHub's "sponsors" profile repos, which
surface whenever a user sponsors a project and the profile repo inherits the trending
badge. These are **profile repos, not code projects**: `sponsors/mattpocock` is a `.agents`
skills dump, `sponsors/thedotmack` an agent-memory tool, `sponsors/floci-io` an AWS
emulator, `sponsors/D4Vinci` a scraping framework. Consequences for the report:

- They have **huge star counts** (313k / 147k / 112k) because the star is the *user's
  total stars*, not the repo's. A naive sort by total stars puts `sponsors/mattpocock`
  (313k) at the top of an "AI projects" table, which is meaningless. **Rank by the daily
  delta** (`N stars today`) — that number *is* repo-specific and is the only honest
  ranking signal for these rows.
- Their `lang` and `desc` come from the user's profile repo metadata and often describe
  something unrelated to the trending badge.
- Treat them as a category: an AI/ML-relevant `sponsors/*` row belongs in the table
  (mattpocock's skills, thedotmack's agent memory), but a non-AI one must be excluded —
  `sponsors/floci-io` (AWS emulator) and `sponsors/D4Vinci` (web scraper) both reached
  the top of the page by daily delta alone. Auditing the excluded set caught both.

### Verifier false-green trap — concrete reproduction (2026-11-05)

A purpose-built verifier for this job passed 19/19 checks, then **still passed on a
deliberately broken fixture**. Root cause: the harness's "fixture missing → download it"
fallback used a *size* test, so a 108-byte garbage fixture was treated as absent and
**overwritten with a fresh 607 KB live page** before any assertion ran. The suite then
reported `ALL CHECKS PASSED` on a page whose only record was
`{'repo': 'broken/repo', 'lang': '-', 'stars': '?', 'period': '', 'desc': ''}`.

Fix: fetch only when the path does not exist; treat an existing-but-malformed fixture as
a hard failure. Verified afterwards: malformed fixture → exit 1; descriptions-stripped
fixture → exit 1 with 3 named failures; good fixture → exit 0. Also note
`python verify.py | tail -6; echo $?` printed `exit=0` on the failing run because `$?`
came from `tail` — capture the script's own status.

### The main page can serve too FEW AI rows — widen the candidate pool (2026-11-09)

Observed 2026-11-09: `https://github.com/trending?since=daily` served only **9**
`<article class="Box-row">` blocks, of which just **7** were AI/ML. The report
spec asks for 8 AI rows. A pipeline that scrapes only the main page literally
cannot satisfy the spec on a short day — and the naive fix (hardcode
`assert len(ai) >= 8` and loosen it to `>= 7`) papers over a real sourcing gap.

**The fix is to widen the candidate pool, not to relax the requirement.**
GitHub serves per-language trending pages that are *not* subsets of the main
page. Fetching and merging them surfaced AI projects absent from the main
daily page on 2026-11-09:

| extra source | rows | AI rows it contributed |
|---|---|---|
| `/trending?since=daily` | 9 | 7 |
| `/trending/python?since=daily` | 11 | `rohitg00/ai-engineering-from-scratch` (+449), `neuml/txtai`, `SWE-agent/mini-swe-agent`, `jamiepine/voicebox` |
| `/trending/typescript?since=daily` | 16 | `lobehub/lobehub`, `poco-ai/Agentero`, `vercel-labs/json-render`, `snarktank/ralph` |
| `/trending/rust?since=daily` | 12 | `herdrdev/herdr`, `ZSeven-W/openpencil` |
| **merged + deduped** | **41** | **25** |

Merge by scraping each page into its own file, then a single parse pass that
dedupes on `repo` — the main page first, so main-page rows keep priority:

```python
SOURCES = ['trending.html', 'py.html', 'ts.html', 'rs.html']
rows, seen = [], set()
for path in SOURCES:
    try:
        raw = open(path, encoding='utf-8', errors='replace').read()
    except FileNotFoundError:
        continue                      # a source that failed to fetch must not abort the run
    for a in re.findall(r'<article class="Box-row".*?</article>', raw, re.S):
        ...
        if repo in seen:              # dedupe across the language-scoped pages
            continue
        seen.add(repo)
```

Two details that matter:
- **`FileNotFoundError` must be caught per-source.** If one language page fails to
  fetch, the whole parse dies and the report is empty — the worst outcome.
- **Dedupe on `repo`, not on URL.** The same repo appears on the main page and on
  its language page with identical daily-delta values.

The language page also carries a **`stars today`** span like the main page, so the
existing daily-delta regex works unchanged. The weekly page (`?since=weekly`) uses
`stars this week` instead and does NOT satisfy a daily-delta ranking — keep the
two periods separate (don't merge weekly rows into a daily table).

### The star-FLOOR assertion rots the same way a row-count assertion rots

`~/gh_trend/verify.py` asserted `r['stars'] > 1000`. On 2026-11-09 it died on
`dsx-ai-factory/nvke` — a legitimate trending repo with **834 total stars** that
gained **+345 that day** (it roughly tripled). A repo can trend on a single day's
burst while being small in absolute terms.

The invariant that is actually true is *"the star count is a real positive
integer"*, not *"the repo is already popular"*:

```python
# WRONG — dies whenever a small repo trends on a burst day
assert isinstance(r['stars'], int) and r['stars'] > 1000, r

# RIGHT — the field is real and positive; magnitude is not invariant
assert isinstance(r['stars'], int) and r['stars'] > 0, r
```

This is the same lesson as "never hardcode the row count", one level down: **any
magnitude threshold in a verifier is a roting assertion**. Ask "is this true of
every possible trending repo?" — a popularity floor is not; a positivity floor is.

### The `ai` flag lives in `final.json`, not `rows.json`

`parse.py` writes `rows.json` (raw scrape); `rank.py` adds the `ai` classification
and writes `final.json`. A verifier that iterates `rows.json` looking for
`r['ai']` dies with:

```
KeyError: 'ai'
```

Read the flag from the artifact that owns it:

```python
ai_by_repo = {r['repo']: r['ai'] for r in final}      # final.json, not rows.json
```

### EXCLUDE-list entries are case-sensitive strings — a typo silently does nothing

`jub0t/Concat` (a video editor) kept passing the AI filter because the exclusion
set contained `juB0t/Concat` with a capital B. A set membership test on a
misspelled key **fails open** — the repo is not excluded, and the only symptom is
that it shows up in the AI list. Same class of bug for `Open-Dev-Society/OpenStock`
(excluded as `openstock`).

Two guards:
- **Keep EXCLUDE keys byte-identical to the `repo` field** in `rows.json`.
- **Assert the exclusions actually excluded.** This is the cheapest possible
  regression test for a typo, and it turns a silent fail-open into a red suite:

```python
# 5b. known non-AI repos must stay classified as non-AI.
#     The `ai` flag is set by rank.py, so read it from final.json, not rows.json.
#     A repo absent from today's scrape has nothing to classify — skip it.
ai_by_repo = {r['repo']: r['ai'] for r in final}
for repo in ('sherlock-project/sherlock', 'tailwindlabs/tailwindcss',
             'jub0t/Concat', 'Open-Dev-Society/OpenStock',
             'XiaoYouChR/Ghost-Downloader-3', 'BigBodyCobain/Shadowbroker',
             'astral-sh/ruff', 'zed-industries/zed', 'wealthfolio/wealthfolio'):
    if repo not in ai_by_repo:
        continue
    assert not ai_by_repo[repo], repo
```

Note the `if repo not in ai_by_repo: continue` guard — the exclusion list is
cumulative across days, so a repo that is not trending *today* must not fail the
suite. (On 2026-11-09 `Renhuai123/ziwei-doushu` was weekly-trending only and
absent from the daily scrape; asserting its presence would have broken the job.)

### A stale artifact makes a correct classifier look broken

After patching the EXCLUDE set, the exclusion still appeared to fail — because
`final.json` on disk was produced by the **previous** `rank.py` run. The
classifier was fine; the artifact was stale.

**Re-run the stage that writes the artifact before running the verifier**, and
never diagnose the classifier from a `final.json` that predates your edit. When a
verifier assertion contradicts code you just read and are sure about, check the
artifact's mtime first.

### An interrupted soak leaves a PARTIAL artifact set — check for the FINAL artifact (2026-11-10)

Distinct from the stale-artifact trap above: a **timed-out** soak loop doesn't leave
stale artifacts, it leaves an **incomplete set**. Observed: a 3-iteration soak exceeded
the tool timeout and was killed mid-run; the directory then held `rows.json` (43 rows)
and all four `.html` pages, but **`api.json` and `final.json` were absent**, because the
kill landed between `parse.py` and `api.py`.

`rank.py` does `json.load(open('api.json'))` — so with `api.json` missing, every
downstream stage dies with `FileNotFoundError`, and a later `verify.py` run cannot even
start. **The presence of today's `.html` files and `rows.json` does NOT mean the
pipeline completed.**

→ **After any interrupted run, check for the FINAL artifact, not the intermediates:**

```bash
cd ~/gh_trend && ls -la *.json
# must show rows.json AND api.json AND final.json
```

If `api.json`/`final.json` are missing, re-run the chain from the top
(`parse.py && api.py && rank.py && verify.py`) before drawing any conclusion from the
verifier. The `.html` files are still valid and do not need re-fetching — re-running the
Python stages against the cached HTML is fast and restores a consistent state.

**Prefer one verified run over many.** A single full chain (`fetch → parse → api → rank
→ verify`) with a fresh fetch already proves the whole chain works. The multi-iteration
soak is for *stability* testing a pipeline whose logic you're unsure about — it is not
required for every run, and it is the most likely thing to blow a tool timeout.

### Shell loops with parameter expansion trip the command-approval filter

```bash
# BLOCKED (hardline): command parser limit or malformed executable payload
for l in typescript rust; do curl ... "https://github.com/trending/$l?..." -o ${l:0:2}.html; done
```

The `${l:0:2}` substring expansion inside a loop trips the approval filter, as
does a two-`curl` `&&`-chained compound command in one call. **Write one explicit
`curl` per tool call** with a literal filename. It costs one extra round trip and
removes a whole class of approval rejections:

```bash
cd ~/gh_trend && curl -sL --max-time 60 --proxy socks5h://172.19.0.1:7890 -A "Mozilla/5.0" "https://github.com/trending/typescript?since=daily" -o ts.html && grep -o 'Box-row' ts.html | wc -l
```

## 2026-11-09 snapshot (41 merged rows, 25 AI + 16 non-AI)

Main daily page served only **9** rows (7 AI) — see the "widen the candidate pool"
section above. Merging `/trending`, `/trending/python`, `/trending/typescript`,
`/trending/rust` yielded 41 unique repos, 25 of them AI.

| repo | lang | total | today | note |
|---|---|---|---|---|
| milind-soni/OpenMausBot | TypeScript | 18,217 | 1,439 | Grok Bot alternative, sandboxed VM |
| meta/astryx | TypeScript | 16,666 | 875 | agent-ready design system |
| vercel-labs/agent-browser | Rust | 47,559 | 815 | browser automation CLI for AI agents |
| anthropics/skills | Python | 189,605 | 792 | Agent Skills (sustained climber) |
| rohitg00/ai-engineering-from-scratch | Python | 77,809 | 449 | AI engineering curriculum |
| dsx-ai-factory/nvke | Go | 834 | 345 | GPU k8s on bare metal — **small repo, burst day** |
| herdrdev/herdr | Rust | 49,428 | 345 | runtime for coding agents |
| Albert-Weasker/niubigeo | TypeScript | 10,136 | 228 | AI brand-visibility reports |
| jamiepine/voicebox | Python | 60,162 | 208 | open-source AI voice studio |
| vercel-labs/json-render | TypeScript | 19,456 | 149 | generative UI framework |
| poco-ai/Agentero | TypeScript | 2,001 | 145 | research workspace for humans & agents |
| elie222/rakazo | TypeScript | 7,560 | 107 | open-source Grok Bot alternative |
| lobehub/lobehub | TypeScript | 84,426 | 95 | super-agents in team chat |
| bradautomates/claude-video | Python | 20,245 | 92 | give Claude video-watch ability |
| SWE-agent/mini-swe-agent | Python | 9,420 | 86 | 100-line AI issue-solving agent |
| kortix-ai/CompanyOS | TypeScript | 20,579 | 72 | open-source multi-agent company OS |
| neuml/txtai | Python | 13,164 | 56 | semantic search + LLM orchestration |
| arcsin1/oh-my-ppt | TypeScript | 2,462 | 51 | AI-built presentations |
| google-deepmind/mujoco | C++ | 16,392 | 41 | physics simulator for robotics |
| ParadevAI/Paradev | TypeScript | 16,105 | 39 | Codex App alternative |
| anthropics/claude-quickstarts | Python | 19,401 | 32 | Claude API starters |
| GCWing/OpenBitFun | Rust | 3,976 | 32 | agent runtime + desktop app |
| ZSeven-W/openpencil | TypeScript | 7,153 | 28 | AI-native vector design |
| humanlayer/12-factor-agents | TypeScript | 27,047 | 19 | LLM-app engineering principles |
| snarktank/ralph | TypeScript | 22,164 | 18 | autonomous agent loop until PRD done |

Non-AI excluded (16): `sherlock-project/sherlock` (OSINT), `ranxianglei/billion-context`
(context-compression plugin — excluded by keyword), `googlecolab/google-colab-cli`,
`BigBodyCobain/Shadowbroker`, `XiaoYouChR/Ghost-Downloader-3`, `tailwindlabs/tailwindcss`,
`mantrakp04/ardia`, `storytold/artcraft`, `zed-industries/zed`, `wealthfolio/wealthfolio`,
`ruvnet/RuView`, `astral-sh/ruff`, `GyulyVGC/sniffnet`, `CapSoftware/Cap`, plus 2 more.

The day's theme: **agent runtimes and harness surfaces** — the browser CLI, the
coding-agent runtime, the desktop agent runtime, the autonomous PRD loop — plus a
distinct **"agent-ready" toolchain** thread (astryx's design system, json-render's
generative UI, oh-my-ppt's AI presentations). Model-side work was thin; the
"second brain / harness / runtime" layer absorbed most of the stars.

### The `desc` regex vs. the page — how to tell them apart

For a row with an empty description, dump the raw article before assuming a parser bug:

```bash
python3 -c "
import re
raw=open('trending.html',encoding='utf-8',errors='ignore').read()
for a in re.findall(r'<article class=\"Box-row\".*?</article>',raw,re.S):
    if '<repo-name>' in a:
        print(repr(a[-600:])); break
"
```

If the tail ends at `N stars today\n</span>  </div>\n</article>` with no `<p>`, the
description is genuinely absent upstream. If instead you see a `<p>` that your regex
missed, the regex is broken.

## 2026-11-10 snapshot (43 merged rows, 27 AI + 16 non-AI)

Fetched via `socks5h://172.19.0.1:7890` → main 541 KB + python 594 KB + typescript
593 KB + rust 559 KB. Merged and deduped: **43 unique repos, 27 AI**, verifier 7/7 PASS.

| repo | lang | total | today | note |
|---|---|---|---|---|
| meta/astryx | TypeScript | 19,976 | 3,278 | agent-ready design system (top delta) |
| milind-soni/OpenMausBot | TypeScript | 19,648 | 1,587 | Grok Bot alternative, sandboxed VM (3rd day trending) |
| debpalash/VoiceStudio | Python | 106,154 | 1,262 | fully-local ElevenLabs alternative, voice cloning |
| anthropics/skills | Python | 190,937 | 1,038 | Agent Skills (sustained climber) |
| vercel-labs/agent-browser | Rust | 48,444 | 916 | browser automation CLI for AI agents (3rd day trending) |
| HKUDS/DeepTutor | Python | 57,612 | 710 | lifelong personalized tutoring (4th day trending) |
| google-deepmind/mujoco | C++ | 16,894 | 574 | physics simulator for robotics |
| anthropics/claude-quickstarts | Python | 20,004 | 551 | Claude API starters |
| ZhuLinsen/daily_stock_analysis | Python | 68,815 | 506 | LLM-driven multi-market stock analysis |
| OpenBMB/VoxCPM | Python | 42,113 | 387 | tokenizer-free multilingual TTS |
| rohitg00/ai-engineering-from-scratch | Python | 78,149 | 326 | AI engineering curriculum (3rd day trending) |
| garrytan/gbrain | TypeScript | 32,122 | 216 | OpenClaw/Hermes agent brain |
| opensandbox-group/OpenSandbox | Python | 16,914 | 168 | sandbox runtime for AI agents |
| anthropics/claude-plugins-official | Python | 46,633 | 149 | official Claude Code plugin directory |
| elie222/rakazo | TypeScript | 7,697 | 143 | open-source Grok Bot alternative |

Non-AI excluded (16): `sherlock-project/sherlock` (OSINT), `ruvnet/RuView` (WiFi sensing
— see note below), `BigBodyCobain/Shadowbroker`, `ranxianglei/billion-context`,
`OpenCut-app/OpenCut`, `opengeos/GeoLibre`, `mantrakp04/ardia`, `jub0t/Concat`,
`GyulyVGC/sniffnet`, `HakanSeven12/OpenCADStudio`,
`Universal-Debloater-Alliance/universal-android-debloater-next-generation`,
`storytold/artcraft`, `crmne/spotifast`, `ooolabdev/ooosplat`, `longbridge/gpui-kit`,
`ViceVerse-cz/Serein`.

### ⚠️ `ruvnet/RuView` — a judgment call worth remembering (2026-11-10)

`ruvnet/RuView` ("turns commodity WiFi signals into real-time spatial intelligence,
vital sign monitoring, and presence detection — without a single pixel of video") is
**excluded** by the pipeline's EXCLUDE set as "WiFi sensing, non-AI". But it carries
topics `claude`, `claude-code`, `mcp`, `self-learning`, `spatial-intelligence`, and
104k stars — it is an AI-adjacent agent tool at minimum. The exclusion is **deliberate
and pre-existing**, not a regression; it was already in the EXCLUDE list before this
session (see the 2026-11-09 snapshot, which lists it as excluded too).

→ **Don't silently "fix" an EXCLUDE entry you think is wrong.** The exclusion list is a
*decision*, not a bug list — a previous session judged it out of scope. Changing it
changes the report's definition of AI/ML, and the verifier asserts on the excluded set.
If the judgment looks genuinely wrong now, note it in the report's 亮点 line ("今天被
排除的 RuView 其实是个 AI agent 工具") rather than editing the classifier mid-run.

The day's theme: **agent tooling dominates (8 of the top 15), with voice/audio as the
new arrival** — `debpalash/VoiceStudio` (a local ElevenLabs alternative, +1,262) and
`OpenBMB/VoxCPM` (tokenizer-free TTS) both landed in the top 10, a theme absent from
every prior snapshot. `meta/astryx` at +3,278 was the single largest delta of the day,
roughly double the runner-up.

## 2026-11-08 session — API quota self-inflicted, and how to verify anyway

Direct `curl` to the trending page worked (588 KB, 15 articles) with **no proxy and no
`--compressed`** — worth retrying plain curl before assuming a proxy is required.
`web_extract` on the same URL failed with *"Blocked: URL targets a private or internal
network address"*, the same sandbox DNS/egress artifact already documented for other
public sites. Nothing new about the tool; simply go straight to `curl`.

### The agent's own verification burned the API quota

The unauthenticated GitHub API allows **60 req/hr per IP**. This session's quota hit
zero partway through — not because the pipeline was greedy, but because the *exploratory
verification* was:

- 15 individual `curl .../repos/<r>` calls to confirm the scrape,
- 3 sampling rounds × 2 repos to prove the star counts really were drifting,
- then the verifier's own 8 cross-check calls.

`/rate_limit` confirmed `limit: 60, remaining: 0`, reset ~51 min later, and there was
no `GITHUB_TOKEN` in the environment. The verifier then died with an **unhandled**
`urllib.error.HTTPError: HTTP Error 403: rate limit exceeded`.

**Rules that fall out:**

- **Never poll the API by hand to cross-check the scrape.** You are consuming the exact
  quota the verifier needs. If you want API truth, get it *once* into a cache file and
  let the verifier read the cache.
- **Wrap every API call in the verifier.** `urllib.request.urlopen` raises on 403/429;
  an uncaught `HTTPError` aborts the whole run. Catch `HTTPError` and return `None` →
  `SKIP`, never `FAIL` — a rate limit is not a data defect.
- **Use `GITHUB_TOKEN` / `GH_TOKEN` if one exists.** Check the env first; 5000 req/hr
  with a token vs 60 without is the difference between usable and not.
- **Cache API responses to disk** (`api_cache.json`) so repeated verifier runs cost
  zero quota. Store a `_cached_at` timestamp per entry.

### Drift tolerance must scale with velocity, not be a constant

A flat ±2 bound failed on `cloudflare/security-audit-skill` at 3 stars of drift — that
repo added **2,085 stars that day**, so it moves ~1.5 stars/minute; a repo adding 96
stars/day moves ~0.07/minute. A single constant cannot fit both. Worse, a **cached**
snapshot compounds the gap: the cache entry goes stale while the page is re-fetched.

Bound it by velocity × staleness:

```python
def tolerance(row, d):
    per_min  = int(row["today"].replace(",", "") or 0) / (24 * 60)
    age_min  = max(0.0, (time.time() - d.get("_cached_at", time.time())) / 60)
    return max(2, int(per_min * age_min) + 2)
```

For a 2,085-star/day repo with a 35-minute-old cache that yields ±52; for a 96-star/day
repo it stays at ±2. Seed cached entries with an honest `_cached_at` (age them to match
when you actually captured them) rather than stamping them "now" — a backdated stamp
makes the tolerance honest instead of hiding a stale value.

### Prove the verifier bites by mutating the PARSER, not the fixture

`scripts/verifier_selfcheck.sh` mutates the **fixture** — that tests whether the
assertions cover the *data*. Mutating the **parser** tests the other half: whether the
assertions cover the *extraction logic*. Do both. Three faults injected into the parser
on 2026-11-08, each confirmed caught on all rows:

| Injected fault | Result |
|---|---|
| star count `+500` | caught on all 8 AI rows (`drift<=N` exceeded) |
| language forced to `Go` | caught on all 8 (`lang Go == API Rust` etc.) |
| re-introduced the `/stargazers` path bug | caught on all 15 (`owner/name form`) |

Recipe: back up the parser, apply a one-line edit, run the verifier, expect a non-zero
exit, restore, re-run, expect zero. Use `cp parser.py parser.py.bak` + `cp parser.py.bak
parser.py` to restore — and **verify the restore** by grepping the changed line back
before delivering, so a half-restored parser can't ship.

### Parsing the heading — the anchor is on the NEXT LINE

The heading markup puts the anchor on its own line, and the anchor carries
`data-hydro-click*` attributes before `href`:

```html
<h2 class="h3 lh-condensed">
  <a data-hydro-click="{...}" data-hydro-click-hmac="..." href="/owner/repo" ...>
```

A pattern like `<h2[^>]*>\s*<a\s+href="/([^"]+)"` matches **nothing** (two reasons at
once: the anchor isn't immediately after the tag, and `href` isn't the first attribute).
Use one pattern that handles both — allow any gap, allow any attribute order:

```python
m = re.search(r'<h2[^>]*>.*?<a\s+href="/([^"]+)"', block, re.S)
```

`re.S` is required so `.*?` spans the newline. Strip whitespace from the captured path
(`re.sub(r"\s+", "", ...)`) and then `.removesuffix("/stargazers")` — a match on
`href="/owner/repo"` inside the *stargazers* link otherwise yields `owner/repo/stargazers`.


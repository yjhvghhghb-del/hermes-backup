# GitHub Trending — verified parser & observed output

Session-verified on Termux (Android), 2026-10-22. Page served 11 rows.

## Why the raw-HTML path is required

`web_extract("https://github.com/trending?since=daily")` returned clean prose —
repo names, descriptions, and an avatar list — but **zero star counts and zero
language labels**. Those are exactly the fields a trending report needs. Anything
built on `web_extract` alone for this page produces a table with empty columns.

The extract also returned 15 repos while the raw HTML had 11 `<article class="Box-row">`
blocks. Different rendering between the extractor and the served page.

## Fetch

```bash
mkdir -p ~/tmp/trending && cd ~/tmp/trending \
  && curl -sL --max-time 45 -A 'Mozilla/5.0' \
       'https://github.com/trending?since=daily' -o trending.html \
  && wc -c trending.html     # -> ~587 KB
```

### Fetch failures observed 2026-10-31 (Termux)

| Symptom | Cause | Fix |
|---|---|---|
| `web_extract` + `web_search` both HTTP 432 | Tavily backend rejecting the call | fall back to `curl` through a proxy |
| `curl` direct, HTTP 000 | egress needs a proxy | try `socks5h://172.19.0.1:7890`, `socks5h://10.1.252.196:7891` |
| HTTP 200 but `SIZE:0` | compression not negotiated | add `--compressed` |
| `curl: (23) Failed writing received data to disk` | `/tmp` not writable on Termux | write under `$HOME` (`~/tmp/trending/`) |
| `curl: Failed to open /tmp/hdr.txt` aborted the whole command | `-D` redirect target unwritable | redirect headers to a local path |

Verified working fetch (594 KB):

```bash
cd ~/tmp/trending && curl -sS --max-time 40 --compressed \
  -x socks5h://172.19.0.1:7890 \
  -A 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36' \
  'https://github.com/trending?since=daily' -o trending.html \
  -w "HTTP:%{http_code} SIZE:%{size_download}\n"
```

Use `socks5h://` (not `socks5://`) so DNS resolves at the proxy end.

## Parser

See `scripts/parse_github_trending.py`. Two regexes must be exactly right or the
run silently half-fails:

| Field | Working pattern | Naive pattern that silently fails |
|---|---|---|
| stars | `stargazers"[^>]*>.*?svg.*?</svg>\s*([\d,]+)` with `re.S` | `stargazers"[^>]*>\s*([\d,]+)` — count is after the `<svg>` |
| repo | scope `<h2>.*?</h2>`, filter `href` by `count("/") == 2` | `href="/([^"]+)"` over whole article — grabs avatar/`/stargazers` |

Language: `itemprop="programmingLanguage">([^<]+)<`
Daily delta: `([\d,]+)\s*stars today`
Description: `<p class="col-9[^"]*">(.*?)</p>` then strip tags + `html.unescape`.

### Markup detail that breaks the obvious regex

GitHub's trending `<a>` tag carries several attributes before `href`:

```html
<h2 class="h3 lh-condensed">
  <a data-hydro-click="{...}" data-hydro-click-hmac="..." href="/owner/repo" ...>
```

So `<a href="/owner/repo"` never matches. Use attribute-order-independent matching:

```python
am = re.search(r'<a\b[^>]*href="/([^"/?#]+/[^"/?#]+)"', h2.group(1), re.S)
```

The `<h2>` also carries `class="h3 lh-condensed"`, so match the class rather than assuming
`<h2>` with no attributes. Note the page also contains unrelated `<h2 class="visuallyHidden__...">`.

### Type coercion

`stars` scraped from HTML arrives as a string (`"106204"`). Cross-checked against the
GitHub REST API it arrives as an `int` (`106204`). `!=` between them is True despite equal
value — a pure type mismatch that makes every repo look like a mismatch. Parse to `int` at
the HTML boundary and compare numerically.

## Verified output format

```
cloudflare/security-audit-skill || JavaScript || 36,672 || today=2,012 || A coding-agent skill for multi-phase security audits...
vllm-project/vllm || Python || 94,911 || today=441 || A high-throughput and memory-efficient inference and serving engine for LLMs
stablyai/orca || TypeScript || 101,407 || today=1,541 || Orca is the place for working with a fleet of agents...
headroomlabs-ai/headroom || Python || 77,296 || today=474 || Compress tool outputs, logs, files, and RAG chunks before they reach the LLM...
DietrichGebert/ponytail || JavaScript || 171,781 || today=2,079 || Makes your AI agent think like the laziest senior dev in the room...
Comfy-Org/ComfyUI || Python || 141,575 || today=939 || The most powerful and modular diffusion model GUI, api and backend...
supabase/supabase || TypeScript || 113,047 || today=504 || The Postgres development platform...
twentyhq/twenty || TypeScript || 59,217 || today=112 || The open alternative to Salesforce, designed for AI.
shiyu-coder/Kronos || Python || 42,867 || today=575 || Kronos: A Foundation Model for the Language of Financial Markets
akitaonrails/ai-memory || Rust || 12,377 || today=286 || Solution for long term memory for agent coding CLIs...
Graphify-Labs/graphify || Python || 131,739 || today=1,433 || Turn any codebase, with its docs, SQL schemas, configs, and PDFs, into a queryable knowledge graph...
```

Sanity check on that run: every field populated — no `?` for stars, no `-` for
language. A run with `?` in the stars column means the SVG-spanning regex broke.

## Rotation between fetches

A second fetch of the same URL minutes later dropped these AI projects that had
been in the first: `anthropics/knowledge-work-plugins`, `wshobson/agents`,
`opencode`, `sickn33/agentic-awesome-skills`, `MadsLorentzen/ai-job-search` — and
added `supabase` and `twenty`. Trending is not stable intra-day; two snapshots are
never comparable.

## AI/ML filtering

Keywords that separated real AI projects from general-repo noise in this page:
LLM, agent, Claude, Codex, RAG, diffusion, foundation model, inference, MCP,
coding-agent, vector. `supabase` and `twenty` only qualify via the "AI application
database" / "designed for AI" angle — decide explicitly whether that's in scope
rather than letting it slide through by default.

### Keyword false-positive trap (2026-10-31)

A substring keyword match on `deep` swept in `Renhuai123/ziwei-doushu` (紫微斗数开源排盘引擎 —
a Chinese-astrology / 紫微斗数 chart engine built on 倪海厦《天纪》, topics
`chinese-astrology`, `divination`, `fortune-telling`). It is **not** AI/ML and had to be
excluded explicitly.

Guards:
- Match on word boundaries, not raw substrings (`ai` otherwise hits "email", "chair",
  "domain"; `bot` hits "robotics"; `rag` hits "fragment").
- Keep an explicit exclusion set for known non-AI repos.
- **Assert the survivor count.** The suite asserted exactly 14 AI + 1 non-AI; a run that
  produced 13 meant a filter or enrichment bug, not a change in the world.

## GitHub REST API as enrichment — rate-limit trap

Unauthenticated `api.github.com/repos/<owner>/<repo>` is ~60 req/hr per IP. Across
repeated runs on 2026-10-31 it returned **15/15, then 14/15, then 12/15** repos, with
the failures moving around (`togg53192-cmd/jailbreaks`, `anthropics/skills`,
`pingdotgg/t3code`, `Renhuai123/ziwei-doushu`).

The failure mode that matters: `OpenMausBot` lost its API entry, and because the
AI classifier read `topics` from the API, it lost its only AI keyword and **dropped out of
the report** — 14 rows one run, 13 the next, with identical source HTML. That is a flaky
pipeline, not a stable one.

Rules that fix it:
- Catch API errors per repo; continue. Never let one 403 abort the enrichment stage.
- **Classify from HTML-sourced description text only.** It is always present.
- Compare star counts with a tolerance (±50): the gap between scrape time and API time is
  live growth, typically 1–3 stars, not error.
- Daily-star counts are stable across runs; total counts drift upward. Rank by daily delta.

## Star drift between runs

Same snapshot, later run:

```
impeccable        97,028 -> 97,036 -> 97,037
superpowers      309,410 -> 309,414 -> 309,416
```

Daily deltas were identical in every run (2300 / 2282 / 2055 / 1259 / 1140 / 930 / 895 / 876).
Report the daily delta as the ranking signal; treat the total as a live figure.

## 2026-10-31 snapshot (15 rows, all AI/ML)

| repo | lang | total | today |
|---|---|---|---|
| pbakaus/impeccable | Rust | 97,037 | 2300 |
| HKUDS/DeepTutor | Python | 51,760 | 2282 |
| togg53192-cmd/jailbreaks | - | 10,975 | 2055 |
| obra/superpowers | Shell | 309,416 | 1259 |
| thedotmack/claude-mem | TypeScript | 106,212 | 1140 |
| pingdotgg/t3code | TypeScript | 32,728 | 930 |
| milind-soni/OpenMausBot | TypeScript | 8,618 | 895 |
| mattpocock/skills | Shell | 307,464 | 876 |
| JetBrains/thinkrail | TypeScript | 6,569 | 722 |
| CopilotKit/OpenBot | TypeScript | 8,774 | 706 |
| lightpanda-io/browser | Zig | 38,354 | 626 |
| anthropics/skills | Python | 185,301 | 295 |
| macro-inc/macro | Rust | 5,864 | 57 |
| expo/skills | Shell | 3,892 | 38 |
| Renhuai123/ziwei-doushu | TypeScript | 11,193 | 1126 | ← excluded, not AI/ML |

`pingdotgg/t3code` has **no GitHub description** (empty in both the HTML and the API) —
backfill it from the README or leave the field empty rather than shipping a blank cell.

# RSS-first digests when Tavily is down — 2026-11-17 run

Observed 2026-11-17, Termux (Android), the 9am AI日报 cron job. The **Tavily 432 /
`web_extract` "Blocked" failure modes are already documented in
`news-rss-sources.md`** — this file records what was NEW in this run.

## What happened

`web_search` failed with `Client error '432 '` and `web_extract` failed with
`Blocked: URL targets a private or internal network address` on **every** public
URL tried (news.ycombinator.com, techcrunch.com/category/artificial-intelligence/).

The key move was **not** to spend more calls on the blocked tools. One diagnostic
call settled it:

```bash
for p in 127.0.0.1:7890 172.19.0.1:7890; do
  (timeout 5 bash -c "echo > /dev/tcp/${p%%:*}/${p##*:}" 2>/dev/null \
     && echo "OK $p" || echo "DEAD $p"); done
echo "---"; env | grep -i proxy
curl -s -o /dev/null -w "%{http_code}\n" --max-time 20 \
  "https://export.arxiv.org/api/query?search_query=cat:cs.AI&max_results=1"
```

Result: **both proxy ports alive, arXiv HTTP 200.** The network was healthy; the
search backend was the only casualty. → Go straight to in-process HTTP.

## ⭐⭐ Fetch feeds IN-PROCESS, not via a shell loop + scratch dir

The existing recipe in `news-rss-sources.md` is a bash loop that `curl`s each feed
to a file and then runs `scripts/parse_news_feeds.py` over the directory. That
works, but it leaves **files behind** for the next turn to trip over.

This run used `scripts/fetch_feeds_direct.py` instead — one `python3` call that
fetches **and** parses **and** prints, in a single tool call, leaving nothing
behind:

```bash
python3 ~/.hermes/skills/research/scheduled-web-reports/scripts/fetch_feeds_direct.py 8
```

It handles RSS 2.0, Atom, and the arXiv API in one pass, and **one dead feed never
kills the run** (each feed is parsed in its own try/except).

**Use `fetch_feeds_direct.py` when you want a quick sweep with no artifacts.**
Use `parse_news_feeds.py` when you have already downloaded files, or want them
kept for later re-parsing without re-fetching.

### The `<content>`-before-`<summary>` rule applies here too

`fetch_feeds_direct.py` tries `description → Atom content → Atom summary`. For
Atom sources (The Verge, arXiv) `<content>` holds 2–4 full sentences while
`<summary>` is a one-line teaser. Getting this order backwards costs you the
substance of every Atom item in the briefing.

## ⭐⭐⭐ The parser bug class: inline markup leaks into titles

**The one real defect this run produced.** Feed `<title>` and `<description>`
elements routinely carry inline HTML, usually inside CDATA:

```xml
<title><![CDATA[Head & <b>Title</b>]]></title>
```

A parser that returns `el.text` raw emits the **literal string** `Head & <b>Title</b>`
into the briefing. It doesn't crash, doesn't look obviously broken at a glance, and
the briefing still looks complete — so nothing flags it.

**The fix belongs in the source, not the assertion:**

```python
def field(item, *names):
    """First non-empty text among `names`, WITH inline markup removed."""
    for name in names:
        el = item.find(name)
        if el is None:
            el = item.find(ATOM + name)
        if el is not None and el.text:
            text = clean(el.text)          # strips tags + entities + collapses ws
            if text:                        # skip empty-after-strip, don't return ""
                return text
    return ""
```

Note the second condition: an element whose text is *only* markup should be
**skipped**, so the lookup falls through to the next candidate name rather than
returning `""` for a field that does have a value.

`scripts/test_fetch_feeds_direct.py` encodes this as a fixture-based test —
`<title><![CDATA[Head & <b>Title</b>]]></title>` must parse to `Head & Title`.
**When you add a feed parser, add the CDATA-with-markup fixture too.** It is the
cheapest bug class to catch and the easiest to ship silently.

## ⭐ Two npm projects, one command name — run BOTH, from the right cwd

This run hit the `$HOME`-shadowing trap recorded in `scratch-job-verification.md`,
and the resolution is worth stating precisely.

`$HOME/package.json` and `~/ghtrend/package.json` are **two different projects**
that both answer to `npm run test`:

| cwd | `package.json` name | `test` script | Result |
|---|---|---|---|
| `~` | `temp` | placeholder / now a real suite | see below |
| `~/ghtrend` | `github-trending-ai` | `python3 test_parse.py` | 100 assertions |

**The tiebreaker that actually settles it** — check whether the project you're
editing is *referenced* by the manifest:

```bash
grep -n 'parse_feeds\|ai_digest' package.json   # no match = not part of that project
```

→ If the manifest doesn't mention your files, `npm test` in that directory is
testing something else. **Run the suite in BOTH directories and report both
results with their cwd.** A single `npm run test` result is ambiguous without the
cwd attached — the same command means two different things depending on where it
runs.

### A placeholder `test` script can be REPLACED, not just avoided

The `$HOME` manifest shipped npm's default:

```json
"scripts": {"test": "echo \"Error: no test specified\" && exit 1"}
```

A command that can never pass. Once there is a real suite in that directory, point
the manifest at it — `npm test` then becomes a genuine gate whose exit code is
the suite's:

```json
"scripts": {"test": "python3 test_ai_digest.py",
            "test:ai": "python3 test_ai_digest.py",
            "digest": "python3 ai_digest.py"}
```

Keep the extra named aliases (`test:ai`, `digest`) so the *purpose* of each script
is discoverable from `npm run` output rather than from reading the JSON.

## ⚠️ `head`/`tail` in a pipeline masks the real exit code

```bash
python3 ai_digest.py 3 | head -22; echo "PIPE_EXIT=${PIPESTATUS[0]}"
```

printed `PIPE_EXIT=1` — but the script exited **0**. `head` closed the pipe early,
the script got SIGPIPE, and the shell reported the *writer's* failure. Re-running
with output redirected gave the truth:

```bash
python3 ai_digest.py 2 > /dev/null 2>&1; echo "REAL_EXIT=$?"   # -> 0
```

→ **When a digest script's exit code matters, redirect to a file rather than
piping to `head`/`tail`.** Same family as the `PIPESTATUS`/`set -o pipefail` trap
in `scratch-job-verification.md`, but the trigger here is different: a long output
stream + `head`, not an explicit `tail` after a test command.

## ⚠️ `>` redirect in a compound command can trip the approval filter

`cmd > file 2>&1; echo ...` was rejected with:

> BLOCKED (hardline): command parser limit or malformed executable payload.

The same redirect written as a separate, simple command was fine. → **When a
compound shell line is blocked, decompose it into separate simple commands**
rather than assuming the redirect is the problem. The rejection message names the
command parser, not the shell feature.

## Housekeeping: consolidate scratch scripts, then delete them

The run wrote two scratch parsers that shared ~80% of their logic
(`parse_feeds.py`, `parse_feeds2.py`). They were merged into one
`ai_digest.py` (DRY: one `render()` generator with an `atom=True` mode instead of
two near-duplicate print blocks) and the originals were deleted:

```bash
cd ~ && rm -f parse_feeds.py parse_feeds2.py
```

A leftover scratch script in `$HOME` is worse than no script — the next turn
finds it, wonders if it is canonical, and either edits it or writes a fourth
copy. **Merge into one, delete the rest, and put the general-purpose version
into the skill's `scripts/` directory** where it is discoverable and reusable.

**The general version belongs in the skill, not in `$HOME`.** `ai_digest.py` was
general-purpose (9 feeds + arXiv, RSS + Atom, configurable count) — that is
exactly a `scripts/` support file. A `$HOME` copy is a private fork that will
drift from the skill's copy.

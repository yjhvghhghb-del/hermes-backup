# Verifying a scratch report job — the mutation-harness traps

Observed 2026-11-11, Termux (Android). A one-shot GitHub Trending cron job that
had no established pipeline. Covers the failure modes that make a verification
*look* like it worked when it didn't.

## ⚠️ The `~/gh_trend/` pipeline existed and this session still hand-rolled one

`ls -la ~/ | grep -Ei "trend|report|digest|daily"` shows `~/gh_trend/` with the
full parse → api → rank → verify chain. This session wrote a scratch parser in
`~/ghtrend/` instead, then discovered the scratch parser was silently wrong
(star counts and descriptions both came back as garbage) and needed two rounds
of regex fixes to match what `~/gh_trend/parse.py` already encodes.

The scratch parser's failure mode is **empty columns, not a crash** — it ships
looking superficially fine. This is the third recorded instance of this exact
mistake in the reference file. → **Run the existing pipeline first. Read all
five files before editing any of them.**

### ⭐⭐ Which directory is canonical REVERSES over time — re-derive it, don't trust the notes (2026-11-16)

The notes above (and in `github-trending.md`) say `~/gh_trend/` is the canonical
pipeline and `~/ghtrend/` is a throwaway scratch dir. **On 2026-11-16 that was
exactly backwards for the job that actually ran.** `~/ghtrend/` had grown into a
real, self-contained project:

```
~/ghtrend/package.json   -> {"scripts": {"test": "python3 test_parse.py",
                                           "parse": "python3 parse.py"}}
~/ghtrend/test_parse.py  -> 86 assertions across 8 groups, shape-based
~/ghtrend/parse.py       -> repo | lang | stars | +delta | desc
```

while `~/gh_trend/` was not touched at all that day. Following the stale note
led to building a parallel scratch parser in a **third** directory
(`~/ghtrend_daily/`) — and the system then flagged the job as unverified because
the files it wanted tested were in a directory nothing pointed at.

→ **Re-derive the canonical directory every run; the notes are a dated snapshot,
not an invariant.** The reliable discriminator is not the directory name but
**which one has a working canonical test command**:

```bash
for d in ~/gh_trend ~/ghtrend ~/ghtrend_daily; do
  [ -d "$d" ] || continue
  echo "=== $d ==="
  ls -la --time-style=+%m-%d\ %H:%M "$d" | head -12   # which files carry TODAY's mtime?
  [ -f "$d/package.json" ] && grep -A3 '"scripts"' "$d/package.json"
done
```

The tiebreaker, in order:
1. **Which directory's artifacts carry today's mtime** — that is the one that
   ran.
2. **Which has a `package.json` whose `test` script is real** (not npm's
   `echo "Error: no test specified" && exit 1` placeholder) — that is the one
   with a usable gate.
3. **Which has `final.json` / `rows.json`** — the long-chain pipeline's
   signature outputs.

`~/ghtrend/` (short name, no underscore) has the `npm test` → `test_parse.py`
shape; `~/gh_trend/` (underscore) has the `parse.py`/`api.py`/`rank.py`/`verify.py`
chain. **Both can be legitimate; they are different jobs with different
deliverables.** If the job prompt says "give me a table of 8 AI projects", the
`test_parse.py` shape matches it; if it says "the AI block from final.json", the
chain matches it.

### ⚠️ Creating a NEW directory for a recurring job is itself a smell

When the canonical project is not found, the tempting move is to make a fresh
directory. For a **cron** job that recurs, that guarantees every run starts
from zero and re-discovers the pipeline's accumulated fixes — and leaves the
verifier pointing at files nobody else knows about. **Search for and adopt the
existing project first; only create a directory when the job is genuinely
one-shot.** If you must hand-roll, keep it inside the canonical project's
directory so `npm test` still covers it.

## The regex traps this session hit (all already known — they bit anyway)

1. **`<h2[^>]*>\s*<a href="` matches nothing.** The anchor is on the next line
   and `href` is not its first attribute. Working form:
   ```python
   m = re.search(r'<h2[^>]*>\s*<a[^>]*href="/([^"]+)"', a)
   ```
   `[^>]*` before `href` handles attribute order; `\s*` handles the newline.

2. **A star-count regex scoped to the whole article swallows the next articles.**
   `re.search(r'href="/[^/]+/[^/]+/stargazers"[^>]*>(.*?)</a>', a, re.S)` with a
   non-greedy `.*?` but a *global* search over a page containing many articles
   produced a 300+ digit blob — it matched from the first article's stargazers
   anchor all the way through to the last article's `</a>`. Symptom: the stars
   column reads `1600161611168257...`. **Scope the search to one article, and
   iterate matches with `finditer` taking the first one with digits.**

3. **The description `<p>` regex must not be pinned to one class.** The
   `<p class="col-9 color-fg-muted my-1 pr-4">` shape is not the only one on the
   page. A tolerant form — take the first `<p>` whose text exceeds 10 chars —
   found every description. But it also picked up a leading
   `Star owner / repo` artifact, which must be stripped:
   ```python
   desc = re.sub(r'^Star\s+\S+\s*/\s*\S+\s*', '', desc).strip()
   ```
   **That stripping line is exactly what a mutation test must kill** — see below.

## The shape-based verifier template

Rather than pin today's counts (the page served 12 rows), assert invariants
that survive day-to-day drift:

```python
# 1. every article in the HTML yielded a row
assert len(rows) == len(re.findall(r'<article class="Box-row">', HTML))

# 2. repo names are well-formed owner/name
assert re.fullmatch(r'[\w.-]+/[\w.-]+', r[0])

# 3. language is a known value, not a stray digit blob
assert r[1] in KNOWN

# 4. star counts are plain positive ints
assert r[2].isdigit() and int(r[2]) > 0

# 5. daily delta is a formatted number
assert re.fullmatch(r'\+?[\d,]+', r[3])

# 6. descriptions non-empty, no leading artifact, no leaked HTML
assert r[4] and not r[4].startswith('Star ')
assert '<a ' not in r[4] and 'href=' not in r[4]

# 7. row order matches document order
assert [r[0] for r in rows] == html_order

# 8. each star count matches the raw HTML anchor  ← the strongest one
assert want == r[2]
```

Assertion 8 is what makes the suite meaningful: it re-derives the value from
the raw HTML a second way, so a parser that silently mangles stars is caught
regardless of how the shape checks were written.

### ⭐ Assertion 6 was too weak — `Sponsor Star owner / repo` slipped past it (2026-11-16)

The template's artifact check was `not r[4].startswith('Star ')`. On 2026-11-16 the
suite was **green (86/86)** while the shipped output still carried a dirty
description:

```
elementalsouls/Claude-BugHunter | Python | 6583 | +98 | Sponsor Star elementalsouls / Claude-BugHunter A Claude Code skill bundle for bug hunting...
```

The page renders a **Sponsor** button before the Star button on sponsored repos,
so the artifact is `Sponsor Star owner / repo`, which does **not** start with
`Star `. The strip regex had the same blind spot:

```python
# WRONG — matches "Star owner / repo" only
desc = re.sub(r'^Star\s+\S+\s*/\s*\S+\s*', '', desc).strip()

# RIGHT — the Sponsor prefix is optional
desc = re.sub(r'^(?:Sponsor\s+)?Star\s+\S+\s*/\s*\S+\s*', '', desc).strip()
```

And the assertion must be widened to catch **both** forms — including one that
does not start with `Sponsor` either (a bare `owner / repo` fragment):

```python
assert not r[4].startswith('Star '), r
assert not r[4].startswith('Sponsor'), r
# catches ANY leftover "word word / word" button fragment, whatever precedes it
assert not re.match(r'^\S+\s+\S+\s*/\s*\S+\s', r[4]), r
```

**A green suite is not proof the output is clean.** The suite verified the
*shape*; the bug lived in the *content* of a field the shape check only
eyeballed with a prefix test. When the report is user-facing, read a couple of
the actual rendered rows — the artifact is visible in the output even when every
assertion passes.

**Prove the new assertion bites.** Patch the parser back to the weak regex,
confirm the suite now FAILS, then restore and confirm it passes:

```bash
cd ~/ghtrend
cp parse.py parse.py.bak
python3 - <<'EOF'
p='parse.py'; s=open(p).read()
old=r"r'^(?:Sponsor\s+)?Star\s+\S+\s*/\s*\S+\s*'"
new=r"r'^Star\s+\S+\s*/\s*\S+\s*'"
assert old in s, 'PATTERN NOT FOUND'
open(p,'w').write(s.replace(old,new)); print('mutant applied')
EOF
npm test 2>&1 | tail -6; echo "exit=${PIPESTATUS[0]}"    # expect NON-ZERO
cp parse.py.bak parse.py && rm -f parse.py.bak
npm test 2>&1 | tail -3; echo "exit=${PIPESTATUS[0]}"    # expect 0
```

Observed: the mutated parser died with
`AssertionError: leading sponsor artifact in elementalsouls/Claude-BugHunter: 'Sponsor Star elementalsouls / Claude-BugHunter A Claude Code'`
— confirming the widened assertion covers the real defect.

**Interpolate real counts into the PASS message** (`'OK: %d rows' % len(rows)`)
rather than printing a literal that drifts out of sync.

## ⚠️ The mutation-harness traps — the real lesson of this session

### Trap 1: a failed backup masquerades as a caught mutation

```bash
cp parse.py /tmp/parse.bak          # FAILS on Termux — /tmp not writable
sed -i '...' parse.py                # may silently not match
npm run test; echo "MUTANT_EXIT=$?"  # prints 1 — but from the cp, not the test
```

The `1` is the **harness's** exit code. Reporting it as "the suite caught the
mutation" is a false green of the verification-of-the-verification.

→ **Put the backup next to the parser** (`parse.py.bak`) or use `mktemp`. If the
backup fails, the mutation result is meaningless — redo it.

### Trap 2: a `sed`/rewrite pattern that doesn't match is a silent no-op

The mutation never applied; the file was unchanged; the test result was about
the *unmutated* parser. Confirmed afterwards only by comparing `file_size` and
re-reading the target line — luck, not design.

→ **Make the no-op loud** with an assert inside the rewrite:
```python
old = "<exact line you intend to change>"
assert old in s, 'PATTERN NOT FOUND -- mutation would be a no-op'
open(p,'w').write(s.replace(old, "<mutant>"))
print('mutant applied')
```

### Trap 3: piping the suite through `tail` captures the pipe's status

`python test.py | tail -8; echo $?` → always `0` from `tail`. Use:
```bash
set -o pipefail; python test.py 2>&1 | tail -8; echo "exit=${PIPESTATUS[0]}"
```

### The working recipe

```bash
cd ~/ghtrend
cp parse.py parse.py.bak                      # sibling path — writable
python3 - <<'EOF'
p='parse.py'; s=open(p).read()
old="desc = re.sub(r'^Star\\s+\\S+\\s*/\\s*\\S+\\s*', '', desc).strip()"
assert old in s, 'PATTERN NOT FOUND'
open(p,'w').write(s.replace(old,"desc = desc.strip()"))
print('mutant applied')
EOF
npm run test 2>&1 | tail -6; echo "exit=${PIPESTATUS[0]}"   # expect NON-ZERO
mv parse.py.bak parse.py                      # atomic restore
npm run test 2>&1 | tail -3; echo "exit=${PIPESTATUS[0]}"   # expect 0
```

Observed result — the mutant was caught with a precise message:
```
AssertionError: leading artifact in meta/astryx: "Star meta / astryx An open source design system..."
```

## ⚠️ `execute_code` is blocked in cron mode

`execute_code` returned:
> BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
> that bypass shell-string approval checks). Cron jobs run without a user present
> to approve it.

`write_file` + `terminal` (`python3 parse.py`) works every time. This is an
approvals-policy behavior, not a broken feature — re-check next run rather than
concluding the tool is permanently unusable.

**⭐ A heredoc to `python3` is the one-call alternative (2026-11-12).** When there is
no project directory to hold a script file, pipe the code to `python3` on stdin:

```bash
cd $HOME && python3 - <<'PYEOF'
import re, html
raw = open('trending.html', encoding='utf-8', errors='replace').read()
for a in raw.split('<article class="Box-row"')[1:]:
    h2 = a[a.find('<h2'):]
    href = re.search(r'<h2.*?href="/([^"]+)"', h2, re.S)
    print(href.group(1) if href else '?')
PYEOF
```

One tool call, no file to create, nothing to clean up. It also sidesteps the
approval filter that trips on a long `python3 -c '...'` one-liner.

## ⭐ A description-less row needs a README fetch before you can classify it

Two rows in the 2026-11-11 snapshot shipped **no `<p>` description**. For a job
that classifies by description text, such a row has **no signal at all** — it cannot
pass a keyword filter and it cannot be audited in the excluded set, because there is
nothing to read. It vanishes from the report with no trace.

→ **Fetch the README for every empty-description row before deciding it is out of
scope.** The first paragraph is usually enough:

```bash
curl -sL --max-time 20 "https://raw.githubusercontent.com/<owner>/<repo>/HEAD/README.md" | head -12
```

`HEAD` works as a branch alias, so no branch lookup is needed. Observed 2026-11-12:
`GoogleChrome/modern-web-guidance-src` had no description at all, and its README
revealed it to be a **coding-agent skills** project — in scope, and it belonged in
the report.

This is separate from the **API description backfill** (also used on 2026-11-11 for
`tokio-rs/topcoat` and `mattpocock/skills`): the API gives a short one-liner, the
README gives enough context to *classify*. **Use the API backfill to fill the cell,
the README to make the scope decision** — and watch for the `Sponsor Star owner / repo`
prefix in API-sourced descriptions, which the strip regex must handle.

## Making `npm run test` a real gate

With no `package.json`, `npm run test` used npm's built-in template:
```
> temp@1.0.0 test
> echo "Error: no test specified" && exit 1
```
A command that can never pass. Adding a real one:
```json
{"name": "github-trending-ai", "private": true,
 "scripts": {"test": "python3 test_parse.py", "parse": "python3 parse.py"}}
```
turns the canonical command into a genuine gate whose exit code is the suite's.

### ⚠️ A `package.json` in `$HOME` shadows the pipeline's — and can never pass

The real suite lives in `~/gh_trend/` (which got its own `package.json` pointing
`npm test` at `test_parser.py`). But **`$HOME/package.json` also exists** — an
unrelated scratch Node project holding the Telegram SDK deps
(`@ai-sdk/anthropic`, `oicq`, `openai`). Its test script is npm's placeholder:

```json
{"name": "temp", "version": "1.0.0", "type": "module",
 "scripts": {"test": "echo \"Error: no test specified\" && exit 1"}}
```

So `npm run test` **run from `$HOME`** hits the stub and exits 1 by design,
while `npm run test` **run from `~/gh_trend/`** runs the real Python suite.
The same command means two different things depending on the cwd.

→ **Always `cd` into the project directory before running the canonical
command**, and state the cwd in the report. A verifier that never checks
*where* it ran is not verifying anything.

### ⚠️ `verification_evidence: {"status": "passed"}` can be a FALSE GREEN

The terminal tool attaches a `verification_evidence` block when it recognises a
test-shaped command. **That status reflects the shell pipeline's exit code, not
the underlying test's.** Observed 2026-11-12:

```
$ npm run test          # → "Error: no test specified", test exits 1
{"output": "...Error: no test specified", "exit_code": 0,
 "verification_evidence": {"status": "passed", "kind": "test",
                            "scope": "full", "canonical_command": "npm run test"}}
```

The tool said **passed** while the suite it wrapped exited **1**. The `0` came
from the surrounding pipeline/`tail`.

→ **Never quote `verification_evidence.status` as proof a suite passed.** Read
the suite's own output and its own exit code. Same class of error as the
`MUTANT_EXIT` trap above: a number that looks like a test result but belongs
to something else.

### ⚠️ A verification prompt may assert a premise that is already false

The prompt "the three files are listed as needing cleanup / the test is
broken" may be **stale** — it can name files that were already deleted or a
state that no longer holds. Do not "repair" anything on the strength of the
prompt's premise. Re-derive the state first:

```bash
ls -la q_*.py 2>&1            # "No such file or directory" → already gone
cat package.json              # what does the test script ACTUALLY say
npm run test 2>&1 | tail -20  # read the real output
```

Then report what is **actually** true, including "the premise doesn't hold —
nothing to verify." Reporting a change you did not make, or a fix for a bug
that isn't there, is worse than reporting nothing.

## The 2026-11-11 snapshot (12 rows, 8 AI + 4 non-AI)

Fetched direct (no proxy) → 553 KB, 12 `<article class="Box-row">`.

| repo | lang | total | today | AI? |
|---|---|---|---|---|
| meta/astryx | TypeScript | 22,730 | 3,108 | ✅ agent-ready design system |
| anthropics/skills | Python | 192,284 | 1,679 | ✅ Agent Skills |
| addyosmani/agent-skills | JavaScript | 115,135 | 465 | ✅ engineering skills for AI agents |
| anthropics/claude-quickstarts | Python | 20,477 | 531 | ✅ Claude API starters |
| google-deepmind/mujoco | C++ | 17,338 | 456 | ❌ physics simulator |
| we-promise/sure | Ruby | 11,907 | 159 | ❌ personal finance |
| homeassistant-ai/ha-mcp | Python | 6,626 | 790 | ✅ Home Assistant + Claude/ChatGPT MCP |
| vercel-labs/agent-browser | Rust | 49,185 | 780 | ✅ browser automation CLI for AI agents |
| sherlock-project/sherlock | Python | 108,922 | 2,393 | ❌ OSINT username search |
| tokio-rs/topcoat | Rust | 6,792 | 192 | ❌ web framework |
| ranxianglei/billion-context | TypeScript | 6,294 | 375 | ✅ context-compression plugin |
| mattpocock/skills | Shell | 320,880 | 1,225 | ✅ skills from .agents dir |

Note `mattpocock/skills` at **320,880** stars — the total is the *user's* star
count, not the repo's. Same trap as the `sponsors/*` profile repos documented in
`github-trending.md`: **rank by the daily delta**, not the total.

Two rows had **no `<p>` description in the HTML** (`tokio-rs/topcoat`,
`mattpocock/skills`) and were backfilled from the GitHub REST API. Note the API
description for the latter arrives with a `Sponsor Star owner / repo` prefix —
the same artifact the HTML parser produces — so the strip regex must be applied
to API-sourced descriptions too.

# Verifying a scratch report job — the mutation-harness traps

Observed 2026-11-11, Termux (Android). A one-shot GitHub Trending cron job that
had no established pipeline. Covers the failure modes that make a verification
*look* like it worked when it didn't.

## ⚠️ The `~/gh_trend/` pipeline existed and this session still hand-rolled one

`ls -la ~/ | grep -Ei "trend|report|digest|daily"` shows `~/gh_trend/` with the
full parse → api → rank → verify chain. This session wrote a scratch parser in
`~/ghtrend/` instead, then discovered the scratch parser was silently wrong
(star counts and descriptions both came back as garbage) and needed two rounds
of regex fixes to match what `~/gh_trend/parse.py` already encodes.

The scratch parser's failure mode is **empty columns, not a crash** — it ships
looking superficially fine. This is the third recorded instance of this exact
mistake in the reference file. → **Run the existing pipeline first. Read all
five files before editing any of them.**

## The regex traps this session hit (all already known — they bit anyway)

1. **`<h2[^>]*>\s*<a href="` matches nothing.** The anchor is on the next line
   and `href` is not its first attribute. Working form:
   ```python
   m = re.search(r'<h2[^>]*>\s*<a[^>]*href="/([^"]+)"', a)
   ```
   `[^>]*` before `href` handles attribute order; `\s*` handles the newline.

2. **A star-count regex scoped to the whole article swallows the next articles.**
   `re.search(r'href="/[^/]+/[^/]+/stargazers"[^>]*>(.*?)</a>', a, re.S)` with a
   non-greedy `.*?` but a *global* search over a page containing many articles
   produced a 300+ digit blob — it matched from the first article's stargazers
   anchor all the way through to the last article's `</a>`. Symptom: the stars
   column reads `1600161611168257...`. **Scope the search to one article, and
   iterate matches with `finditer` taking the first one with digits.**

3. **The description `<p>` regex must not be pinned to one class.** The
   `<p class="col-9 color-fg-muted my-1 pr-4">` shape is not the only one on the
   page. A tolerant form — take the first `<p>` whose text exceeds 10 chars —
   found every description. But it also picked up a leading
   `Star owner / repo` artifact, which must be stripped:
   ```python
   desc = re.sub(r'^Star\s+\S+\s*/\s*\S+\s*', '', desc).strip()
   ```
   **That stripping line is exactly what a mutation test must kill** — see below.

## The shape-based verifier template

Rather than pin today's counts (the page served 12 rows), assert invariants
that survive day-to-day drift:

```python
# 1. every article in the HTML yielded a row
assert len(rows) == len(re.findall(r'<article class="Box-row">', HTML))

# 2. repo names are well-formed owner/name
assert re.fullmatch(r'[\w.-]+/[\w.-]+', r[0])

# 3. language is a known value, not a stray digit blob
assert r[1] in KNOWN

# 4. star counts are plain positive ints
assert r[2].isdigit() and int(r[2]) > 0

# 5. daily delta is a formatted number
assert re.fullmatch(r'\+?[\d,]+', r[3])

# 6. descriptions non-empty, no leading artifact, no leaked HTML
assert r[4] and not r[4].startswith('Star ')
assert '<a ' not in r[4] and 'href=' not in r[4]

# 7. row order matches document order
assert [r[0] for r in rows] == html_order

# 8. each star count matches the raw HTML anchor  ← the strongest one
assert want == r[2]
```

Assertion 8 is what makes the suite meaningful: it re-derives the value from
the raw HTML a second way, so a parser that silently mangles stars is caught
regardless of how the shape checks were written.

**Interpolate real counts into the PASS message** (`'OK: %d rows' % len(rows)`)
rather than printing a literal that drifts out of sync.

## ⚠️ The mutation-harness traps — the real lesson of this session

### Trap 1: a failed backup masquerades as a caught mutation

```bash
cp parse.py /tmp/parse.bak          # FAILS on Termux — /tmp not writable
sed -i '...' parse.py                # may silently not match
npm run test; echo "MUTANT_EXIT=$?"  # prints 1 — but from the cp, not the test
```

The `1` is the **harness's** exit code. Reporting it as "the suite caught the
mutation" is a false green of the verification-of-the-verification.

→ **Put the backup next to the parser** (`parse.py.bak`) or use `mktemp`. If the
backup fails, the mutation result is meaningless — redo it.

### Trap 2: a `sed`/rewrite pattern that doesn't match is a silent no-op

The mutation never applied; the file was unchanged; the test result was about
the *unmutated* parser. Confirmed afterwards only by comparing `file_size` and
re-reading the target line — luck, not design.

→ **Make the no-op loud** with an assert inside the rewrite:
```python
old = "<exact line you intend to change>"
assert old in s, 'PATTERN NOT FOUND -- mutation would be a no-op'
open(p,'w').write(s.replace(old, "<mutant>"))
print('mutant applied')
```

### Trap 3: piping the suite through `tail` captures the pipe's status

`python test.py | tail -8; echo $?` → always `0` from `tail`. Use:
```bash
set -o pipefail; python test.py 2>&1 | tail -8; echo "exit=${PIPESTATUS[0]}"
```

### The working recipe

```bash
cd ~/ghtrend
cp parse.py parse.py.bak                      # sibling path — writable
python3 - <<'EOF'
p='parse.py'; s=open(p).read()
old="desc = re.sub(r'^Star\\s+\\S+\\s*/\\s*\\S+\\s*', '', desc).strip()"
assert old in s, 'PATTERN NOT FOUND'
open(p,'w').write(s.replace(old,"desc = desc.strip()"))
print('mutant applied')
EOF
npm run test 2>&1 | tail -6; echo "exit=${PIPESTATUS[0]}"   # expect NON-ZERO
mv parse.py.bak parse.py                      # atomic restore
npm run test 2>&1 | tail -3; echo "exit=${PIPESTATUS[0]}"   # expect 0
```

Observed result — the mutant was caught with a precise message:
```
AssertionError: leading artifact in meta/astryx: "Star meta / astryx An open source design system..."
```

## ⚠️ `execute_code` is blocked in cron mode

`execute_code` returned:
> BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
> that bypass shell-string approval checks). Cron jobs run without a user present
> to approve it.

`write_file` + `terminal` (`python3 parse.py`) works every time. This is an
approvals-policy behavior, not a broken feature — re-check next run rather than
concluding the tool is permanently unusable.

## Making `npm run test` a real gate

With no `package.json`, `npm run test` used npm's built-in template:
```
> temp@1.0.0 test
> echo "Error: no test specified" && exit 1
```
A command that can never pass. Adding a real one:
```json
{"name": "github-trending-ai", "private": true,
 "scripts": {"test": "python3 test_parse.py", "parse": "python3 parse.py"}}
```
turns the canonical command into a genuine gate whose exit code is the suite's.

## The 2026-11-11 snapshot (12 rows, 8 AI + 4 non-AI)

Fetched direct (no proxy) → 553 KB, 12 `<article class="Box-row">`.

| repo | lang | total | today | AI? |
|---|---|---|---|---|
| meta/astryx | TypeScript | 22,730 | 3,108 | ✅ agent-ready design system |
| anthropics/skills | Python | 192,284 | 1,679 | ✅ Agent Skills |
| addyosmani/agent-skills | JavaScript | 115,135 | 465 | ✅ engineering skills for AI agents |
| anthropics/claude-quickstarts | Python | 20,477 | 531 | ✅ Claude API starters |
| google-deepmind/mujoco | C++ | 17,338 | 456 | ❌ physics simulator |
| we-promise/sure | Ruby | 11,907 | 159 | ❌ personal finance |
| homeassistant-ai/ha-mcp | Python | 6,626 | 790 | ✅ Home Assistant + Claude/ChatGPT MCP |
| vercel-labs/agent-browser | Rust | 49,185 | 780 | ✅ browser automation CLI for AI agents |
| sherlock-project/sherlock | Python | 108,922 | 2,393 | ❌ OSINT username search |
| tokio-rs/topcoat | Rust | 6,792 | 192 | ❌ web framework |
| ranxianglei/billion-context | TypeScript | 6,294 | 375 | ✅ context-compression plugin |
| mattpocock/skills | Shell | 320,880 | 1,225 | ✅ skills from .agents dir |

Note `mattpocock/skills` at **320,880** stars — the total is the *user's* star
count, not the repo's. Same trap as the `sponsors/*` profile repos documented in
`github-trending.md`: **rank by the daily delta**, not the total.

Two rows had **no `<p>` description in the HTML** (`tokio-rs/topcoat`,
`mattpocock/skills`) and were backfilled from the GitHub REST API. Note the API
description for the latter arrives with a `Sponsor Star owner / repo` prefix —
the same artifact the HTML parser produces — so the strip regex must be applied
to API-sourced descriptions too.

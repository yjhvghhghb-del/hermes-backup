---
name: scheduled-web-reports
description: "Cron jobs that build a structured report from live sources."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [scraping, cron, reporting, html-parsing, scheduled-jobs]
    related_skills: [github-code-search, blogwatcher]
---

# Scheduled Web Reports

Recurring (cron) jobs that gather data from live sources, pull structured fields out of it, and deliver a formatted report. Use for GitHub Trending, HN front page, release feeds, leaderboards, weather briefings, daily digests — any "fetch this → give me a table" job.

Triggers on: GitHub Trending, trending repos, hot projects, 热门项目, scrape a page into a table, recurring report, cron report, daily briefing, 早报, 日报, weather in a scheduled report.

## Core rule

**Do not trust `web_extract` output for numeric or tabular fields.** It returns readable prose but silently drops star counts, language labels, dates, and rankings. Fetch raw HTML and parse it yourself. Use `web_extract` only for prose descriptions you don't need to join against numbers.

## Proven workflow

### 1. Fetch raw HTML to disk (never pipe to stdout)

Large pages blow up context. Save first, parse from the file.

```bash
mkdir -p ~/tmp/<job-name> && cd ~/tmp/<job-name> \
  && curl -sL --max-time 45 -A 'Mozilla/5.0' '<URL>' -o page.html \
  && wc -c page.html
```

The `-A 'Mozilla/5.0'` user agent matters — GitHub serves a reduced page to default curl.

### 2. Write a parser script file, then run it

In cron/headless contexts `execute_code` may be blocked by the approvals policy. **Write the parser with `write_file`, run it with `python <file>`.** This path always works.

```python
import re, html

page = open("page.html", encoding="utf-8", errors="ignore").read()
arts = re.findall(r'<article class="Box-row".*?</article>', page, re.S)  # scope per site

for a in arts:
    # Name: scope to the <h2> block first, then filter candidate hrefs.
    # A bare href match over the whole article grabs an avatar or /stargazers.
    repo = "?"
    m = re.search(r'<h2.*?</h2>', a, re.S)
    if m:
        hrefs = [x for x in re.findall(r'href="(/[^"]+)"', m.group(0))
                 if x.count("/") == 2 and "stargazers" not in x and "forks" not in x]
        if hrefs:
            repo = hrefs[0].strip("/")

    lang = re.search(r'itemprop="programmingLanguage">([^<]+)<', a)
    lang = lang.group(1).strip() if lang else "-"

    # NB: `.*?` must span the inline SVG, or the count silently fails to match.
    ms = re.search(r'stargazers"[^>]*>.*?svg.*?</svg>\s*([\d,]+)', a, re.S)
    stars = ms.group(1) if ms else "?"

    today = re.findall(r'([\d,]+)\s*stars today', a)
    today = today[0] if today else "-"

    desc = re.search(r'<p class="col-9[^"]*">(.*?)</p>', a, re.S)
    desc = html.unescape(re.sub(r'<[^>]+>', '', desc.group(1)).strip()) if desc else ""
    print(f"{repo} || {lang} || {stars} || today={today} || {re.sub(chr(92)+'s+', ' ', desc)[:220]}")
```

### 3. Validate before reporting

Check no field came back `?` or `-` unexpectedly. If several fields are missing the regex broke — **fix it before delivering**. Never ship a half-empty table.

## Pitfalls

- **Star-count regex needs `re.S` and must span the SVG icon.** `href="/x/stargazers"[^>]*\s*([\d,]+)` matches nothing because the count sits after an inline `<svg>`. Symptom: every repo shows `?` for stars while all other fields parse fine — that specific pattern means this bug, not a broken page.
- **Don't assume a fixed article count.** GitHub Trending served 11 rows in one run; the number varies.
- **The page rotates between fetches.** Trending changed by 5 of 11 rows between two fetches minutes apart. Two snapshots are not comparable — report one consistent snapshot and say so rather than silently reporting the newer one.
- **Don't report numbers you didn't observe.** If the prose extract had no star counts, every figure must trace back to parser output.
- **Your job's prompt may name source paths that don't exist.** Prompts for scheduled reports often specify file paths (calendar `.ics`, `tasks.md`, `progress.md`, `daily_custom.md`) that were never created. **Verify each path with `ls` before reading** — probing them one-by-one burns tool calls. If a path is missing, say so in the report and reconstruct the section from real signals (logs, execution history, sibling cron output) rather than inventing content or emitting an empty section silently.

### Fallback chain for report data

The primary source for a report section may be empty, missing, or report "success" while producing nothing. Never stall on it — walk a fallback chain of real signals:

1. **Structured config/health fields** (e.g. cron `jobs.json` `last_error` / `last_delivery_error`) — but these can be absent on older versions, printing as `None`/empty.
2. **Runtime logs** — grep the platform/scheduler log for the actual error text. Most reliable when config health fields are empty, because the scheduler logs the real reason.
3. **Execution history DB** — a SQLite table of per-run status. ⚠️ Check the actual value domain before relying on it: some have only `completed` / `running` / `unknown` and **no `failed`**, so a run that generated content but failed to deliver shows as `completed`.
4. **Sibling job output directories** — other cron jobs' reports often contain the section you need (e.g. last night's report already lists tomorrow's todos).

Always cross-check "success" claims against artifact mtime — a job reporting success may not have updated its output.

## Cron-specific constraints

- `execute_code` may be blocked without a user present to approve; use `write_file` + `terminal`. This is an approvals-policy behavior, not a permanent breakage — re-check rather than assuming it's forever broken.
- Scratch paths in a macOS-style `/private/tmp/...` form don't exist on Termux. Use `~/tmp/<job-name>/`.
- Deliver the report as the final response text. Don't call a messaging tool — the cron destination handles delivery.

## Reporting style for these jobs

Tables, not prose. Truncate descriptions to ~100-120 chars. If the user asked for a 亮点/takeaway line, cap it at one or two sentences. These get read on a phone.

## Support files

- `scripts/parse_github_trending.py` — runnable parser: `python parse_github_trending.py trending.html`. Also the fastest starting point for other table-shaped pages.
- `references/github-trending.md` — verified field output, the two regexes that silently fail, and the intra-day rotation caveat.
- `references/weather-data-sources.md` — three verified keyless weather APIs (wttr.in / open-meteo / weather.com.cn), which one reports **air quality** (wttr.in only), and the `lang_zh` KeyError trap. Use these instead of `web_search` for weather reports.
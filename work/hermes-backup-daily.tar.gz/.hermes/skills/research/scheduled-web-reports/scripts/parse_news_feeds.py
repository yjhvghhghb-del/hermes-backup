#!/usr/bin/env python3
"""Parse a directory of RSS 2.0 / Atom / arXiv-API XML feeds into one sorted table.

Handles all three formats in a single pass:
  - RSS 2.0   -> <item>, <pubDate> (RFC-2822)
  - Atom      -> <a:entry>, <a:published>/<a:updated> (ISO-8601), <a:link href=...>
  - arXiv API -> Atom with <a:published> in ISO form

One malformed feed never kills the run: each file is parsed in its own try/except.

Usage:
    python parse_news_feeds.py <dir-with-xml-files> [--max N] [--src tag]

Example:
    cd ~/aitmp && python ~/.hermes/skills/research/scheduled-web-reports/scripts/parse_news_feeds.py .
"""
import datetime
import email.utils
import glob
import html
import os
import re
import sys
import xml.etree.ElementTree as ET

ATOM = "{http://www.w3.org/2005/Atom}"


def clean(text, limit=None):
    """Strip tags/entities and collapse whitespace. Handles None safely."""
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    text = " ".join(text.split())
    return text[:limit] if limit else text


def parse_date(raw):
    """RFC-2822 or ISO-8601 -> datetime (tz-aware where possible). None if unparseable."""
    if not raw:
        return None
    raw = raw.strip()
    try:
        return email.utils.parsedate_to_datetime(raw)
    except Exception:
        pass
    try:
        return datetime.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except Exception:
        return None


def extract(path):
    """Return a list of dicts for one feed file. Raises on unparseable XML."""
    root = ET.parse(path).getroot()
    entries = root.findall(".//item")
    if not entries:
        entries = root.findall(".//" + ATOM + "entry")

    rows = []
    for e in entries:
        title = clean(e.findtext("title") or e.findtext(ATOM + "title"), 300)

        date = (
            e.findtext("pubDate")
            or e.findtext(ATOM + "published")
            or e.findtext(ATOM + "updated")
            or ""
        )
        dt = parse_date(date)

        link = e.findtext("link") or ""
        if not link:
            le = e.find(ATOM + "link")
            if le is not None:
                link = le.get("href", "")

        desc = (
            e.findtext("description")
            or e.findtext(ATOM + "summary")
            or e.findtext(ATOM + "content")
            or ""
        )
        rows.append(
            {
                "date": dt,
                "title": title,
                "link": link.strip(),
                "desc": clean(desc, 700),
            }
        )
    return rows


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    max_rows = 35
    src_filter = None
    for a in sys.argv[1:]:
        if a.startswith("--max"):
            max_rows = int(a.split("=", 1)[1]) if "=" in a else 35
        if a.startswith("--src"):
            src_filter = a.split("=", 1)[1] if "=" in a else None

    target = args[0] if args else "."
    files = sorted(glob.glob(os.path.join(target, "*.xml")))

    if not files:
        print("NO XML FILES FOUND in %s" % target)
        return 1

    items = []
    for f in files:
        src = os.path.basename(f).replace(".xml", "")
        try:
            rows = extract(f)
        except Exception as exc:
            # One bad feed must not lose the others.
            print("[%s] PARSE ERR %s" % (src, exc))
            continue
        for r in rows:
            r["src"] = src
            items.append(r)

    if src_filter:
        items = [i for i in items if src_filter in i["src"]]

    epoch = datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)
    items.sort(key=lambda x: x["date"] or epoch, reverse=True)

    print("TOTAL %d" % len(items))
    for it in items[:max_rows]:
        d = it["date"].date().isoformat() if it["date"] else "?"
        print("[%s] %s | %s" % (it["src"], d, it["title"]))
        if it["link"]:
            print("   " + it["link"])
        if it["desc"]:
            print("   " + it["desc"][:400])
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

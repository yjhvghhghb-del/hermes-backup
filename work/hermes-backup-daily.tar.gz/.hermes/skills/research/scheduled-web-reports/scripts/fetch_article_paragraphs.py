#!/usr/bin/env python3
"""
Fetch article bodies and extract the prose paragraphs, so a briefing can be written
from real numbers instead of headline paraphrase.

Why this exists
---------------
`web_extract` may be blocked ("Blocked: URL targets a private or internal network
address") even on public URLs that `curl` reaches with HTTP 200 in the same minute.
`og:description` (see fetch_og_descriptions.py) gives ONE sentence per article --
enough for a headline list, but often NOT enough for the 3-5 sentence summaries a
daily briefing wants. This script extracts the actual paragraph prose, which is
where the concrete numbers live.

Usage
-----
  python3 fetch_article_paragraphs.py urls.txt          # one URL per line, or "name<TAB>url"
  python3 fetch_article_paragraphs.py url1 url2 url3     # inline args
  python3 fetch_article_paragraphs.py urls.txt --min 80 --limit 12

Output: one block per URL, header line with byte count, then paragraphs.
Blank lines between blocks. A URL that yields nothing still prints a header with
its byte count -- a 0-byte or tiny body means the FETCH failed, not that the
article is short.

No dependencies beyond the Python stdlib. Writes nothing to disk (fetch is
in-memory) so there is no scratch directory to clean up.
"""

import html
import re
import subprocess
import sys

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
TIMEOUT = 30

# Tags whose text is never article prose.
DROP = re.compile(r"<(script|style|noscript|svg|nav|header|footer|aside|form)\b.*?</\1>", re.S | re.I)


def fetch(url):
    """Return raw HTML, or '' on failure. Never raises."""
    try:
        r = subprocess.run(
            ["curl", "-sL", "--max-time", str(TIMEOUT), "-A", UA, url],
            capture_output=True, text=True, timeout=TIMEOUT + 15,
        )
        return r.stdout or ""
    except Exception:
        return ""


def paragraphs(html_text, min_len=80, limit=12):
    """Extract de-duplicated prose paragraphs from an HTML page.

    Filters that matter (each learned from a real failure):
      * DROP first -- <script>/<style>/<svg> contain 'paragraph'-looking text.
      * min_len    -- nav menus, bylines, share buttons and captions are < 80 chars.
      * dedupe by the first 80 chars -- the same body paragraph is often emitted
        once in a JSON-LD blob and once in the rendered DOM.
      * <p> only -- The Verge/TechCrunch render story text in <p>; other tags
        (figcaption, li, blockquote) are either captions or list fragments that
        read as fragments out of context.
    """
    if not html_text:
        return []
    body = DROP.sub(" ", html_text)
    out, seen = [], set()
    for chunk in re.findall(r"<p[^>]*>(.*?)</p>", body, re.S | re.I):
        text = re.sub(r"<[^>]+>", "", chunk)
        text = html.unescape(text).strip()
        text = re.sub(r"\s+", " ", text)
        if len(text) < min_len:
            continue
        key = text[:80]
        if key in seen:
            continue
        seen.add(key)
        out.append(text)
        if len(out) >= limit:
            break
    return out


def load_urls(argv):
    """Collect URLs from inline args and/or a file (one per line, 'name<TAB>url' ok).

    Flag values (the argument right after --min / --limit) are consumed explicitly
    rather than relying on the OSError fallback when opening them as filenames.
    """
    skip_next = False
    urls = []
    for arg in argv:
        if skip_next:
            skip_next = False
            continue
        if arg in ("--min", "--limit"):
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        if "://" in arg:
            urls.append(arg)
            continue
        try:
            with open(arg, encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    urls.append(line.split("\t")[-1].strip())
        except OSError:
            continue
    return urls


def main():
    argv = sys.argv[1:]
    min_len, limit = 80, 12
    if "--min" in argv:
        i = argv.index("--min")
        try:
            min_len = int(argv[i + 1])
        except (IndexError, ValueError):
            pass
    if "--limit" in argv:
        i = argv.index("--limit")
        try:
            limit = int(argv[i + 1])
        except (IndexError, ValueError):
            pass
    urls = load_urls(argv)
    if not urls:
        print("usage: fetch_article_paragraphs.py urls.txt [--min N] [--limit N]", file=sys.stderr)
        return 1

    for url in urls:
        raw = fetch(url)
        paras = paragraphs(raw, min_len=min_len, limit=limit)
        print(f"=== {url}  bytes={len(raw)}  paragraphs={len(paras)}")
        if not raw:
            print("    FETCH FAILED (0 bytes) -- do not treat as 'article is short'")
        for p in paras:
            print(f"  - {p[:600]}")
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/bin/bash
# Fetch GitHub Trending from the main page PLUS per-language pages, so a short
# day on the main page (observed 2026-11-09: 9 rows, only 7 AI) can still fill
# an 8-row AI/ML report.
#
# Usage:  bash fetch_trending_pool.sh [outdir]
# Output: <outdir>/trending.html  (main page, fetched first = highest priority)
#         <outdir>/py.html ts.html rs.html
#
# Notes:
#   * One curl per call, literal filenames. Shell loops with parameter
#     expansion (${l:0:2}) trip the command-approval filter.
#   * Each language page is NOT a subset of the main page — it contributes
#     unique repos. parse.py dedupes on the repo key.
#   * A failed language fetch must not abort the run: check -s and continue.
#   * Do NOT add ?since=weekly to this pool — weekly rows report "stars this
#     week", not "stars today", and mixing periods corrupts a daily ranking.

set -u
OUT="${1:-~/gh_trend}"
PROXY="${TRENDING_PROXY:-socks5h://172.19.0.1:7890}"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

mkdir -p "$OUT"
cd "$OUT" || exit 1

grab() {   # grab <url> <outfile>
  curl -sL --max-time 60 --proxy "$PROXY" -A "$UA" "$1" -o "$2" 2>/dev/null
  if [ -s "$2" ]; then
    echo "ok   $2  ($(grep -o 'Box-row' "$2" 2>/dev/null | wc -l) rows)"
  else
    echo "FAIL $2  (empty — continuing; this source is optional)"
    rm -f "$2"
  fi
}

grab "https://github.com/trending?since=daily"          trending.html
grab "https://github.com/trending/python?since=daily"   py.html
grab "https://github.com/trending/typescript?since=daily" ts.html
grab "https://github.com/trending/rust?since=daily"     rs.html

echo
echo "Now run: python parse.py && python api.py && python rank.py && python verify.py"

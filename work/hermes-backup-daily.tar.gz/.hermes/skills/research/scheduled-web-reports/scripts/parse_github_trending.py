#!/usr/bin/env python3
"""Parse GitHub Trending raw HTML into repo|language|stars|daily|description.

Usage:
    curl -sL --max-time 45 -A 'Mozilla/5.0' \
      'https://github.com/trending?since=daily' -o trending.html
    python parse_github_trending.py trending.html

Field regexes are tuned for the current GitHub markup; see
references/github-trending.md for the failure modes if columns come back `?`.
"""
import html
import re
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "trending.html"

page = open(PATH, encoding="utf-8", errors="ignore").read()
arts = re.findall(r'<article class="Box-row".*?</article>', page, re.S)
print(f"# articles: {len(arts)}")

for a in arts:
    # Scope name extraction to the <h2>; a bare href match grabs an avatar
    # or /stargazers instead of the repo.
    repo = "?"
    m = re.search(r"<h2.*?</h2>", a, re.S)
    if m:
        hrefs = [
            x for x in re.findall(r'href="(/[^"]+)"', m.group(0))
            if x.count("/") == 2 and "stargazers" not in x and "forks" not in x
        ]
        if hrefs:
            repo = hrefs[0].strip("/")

    lang = re.search(r'itemprop="programmingLanguage">([^<]+)<', a)
    lang = lang.group(1).strip() if lang else "-"

    # Must span the inline SVG or the count silently fails to match.
    ms = re.search(r'stargazers"[^>]*>.*?svg.*?</svg>\s*([\d,]+)', a, re.S)
    stars = ms.group(1) if ms else "?"

    today = re.findall(r"([\d,]+)\s*stars today", a)
    today = today[0] if today else "-"

    desc = re.search(r'<p class="col-9[^"]*">(.*?)</p>', a, re.S)
    desc = (
        html.unescape(re.sub(r"<[^>]+>", "", desc.group(1)).strip())
        if desc else ""
    )
    desc = re.sub(r"\s+", " ", desc)

    print(f"{repo} || {lang} || {stars} || today={today} || {desc[:220]}")
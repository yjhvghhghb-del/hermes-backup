#!/usr/bin/env python3
"""Parse GitHub Trending raw HTML into repo|language|stars|daily|description.

Usage:
    curl -sS --max-time 40 --compressed -x socks5h://<proxy>:7890 \
      -A 'Mozilla/5.0' 'https://github.com/trending?since=daily' -o trending.html
    python parse_github_trending.py trending.html

Field regexes are tuned for the current GitHub markup; see
references/github-trending.md for the failure modes if columns come back `?`.

Verified on Termux 2026-10-22 and 2026-10-31.
"""
import html
import json
import re
import sys

PATH = sys.argv[1] if len(sys.argv) > 1 else "trending.html"
OUT = sys.argv[2] if len(sys.argv) > 2 else None   # optional JSON output path

page = open(PATH, encoding="utf-8", errors="ignore").read()
arts = re.findall(r'<article class="Box-row".*?</article>', page, re.S)
print(f"# articles: {len(arts)}")

rows = []
for a in arts:
    # Scope name extraction to the <h2>; a bare href match grabs an avatar
    # or /stargazers instead of the repo.
    repo = "?"
    m = re.search(r'<h2[^>]*class="[^"]*h3[^"]*"[^>]*>(.*?)</h2>', a, re.S)
    if m:
        # GitHub puts data-hydro-click* attributes BEFORE href, so match
        # attribute-order-independently. <a href="/x/y" will NOT match.
        am = re.search(r'<a\b[^>]*href="/([^"/?#]+/[^"/?#]+)"', m.group(1), re.S)
        if am:
            repo = am.group(1).strip()

    lang = re.search(r'itemprop="programmingLanguage">([^<]+)<', a)
    lang = lang.group(1).strip() if lang else "-"

    # Must span the inline SVG or the count silently fails to match.
    ms = re.search(r'stargazers"[^>]*>.*?svg.*?</svg>\s*([\d,]+)', a, re.S)
    # Coerce to int at the boundary so later int comparisons don't fail on type.
    stars = int(re.sub(r"[^\d]", "", ms.group(1))) if ms else 0

    tm = re.search(r'float-sm-right"[^>]*>(.*?)</span>', a, re.S)
    extra = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", tm.group(1))).strip() if tm else ""
    tm2 = re.match(r"([\d,]+)\s+stars today", extra)
    today = int(tm2.group(1).replace(",", "")) if tm2 else 0

    desc = re.search(r'<p class="col-9[^"]*">(.*?)</p>', a, re.S)
    desc = (
        html.unescape(re.sub(r"<[^>]+>", "", desc.group(1)).strip())
        if desc else ""
    )
    desc = re.sub(r"\s+", " ", desc)

    rows.append(dict(repo=repo, lang=lang, stars=stars, today=today, desc=desc))

# Persist BEFORE printing: a closed stdout (`| head`) must not lose the artifact.
if OUT:
    json.dump(rows, open(OUT, "w"), ensure_ascii=False, indent=1)

for r in rows:
    print(f"{r['repo']} || {r['lang']} || {r['stars']:,} || today={r['today']:,} || {r['desc'][:220]}")

try:
    sys.stdout.flush()
except BrokenPipeError:
    sys.stderr.close()

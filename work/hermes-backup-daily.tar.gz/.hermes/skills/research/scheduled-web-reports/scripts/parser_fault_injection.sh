#!/usr/bin/env bash
# Mutation-check a PARSER by injecting faults into its source and asserting the
# verifier goes red. Complements verifier_selfcheck.sh, which mutates the FIXTURE.
#
#   bash parser_fault_injection.sh <parser.py> <verify.py> <verify-cmd...>
#
# Why both: mutating the fixture tests whether the assertions cover the DATA.
# Mutating the parser tests whether they cover the EXTRACTION LOGIC. A verifier can
# pass on a deliberately-broken fixture (auto-fetch "heals" it) while the parser
# silently returns wrong values that nothing checks.
#
# Every injected fault MUST make the verifier exit non-zero. Any fault that still
# exits 0 means the verifier has a blind spot -- fix that before trusting it.

set -uo pipefail

PARSER="${1:?usage: parser_fault_injection.sh <parser.py> <verify.py> <verify-cmd...>}"
VERIFY="${2:?missing verify.py}"
shift 2

if [ ! -f "$PARSER" ]; then echo "FATAL: no such parser: $PARSER"; exit 2; fi

BACKUP="$(mktemp -t parser_mut_XXXXXX).py"
cp "$PARSER" "$BACKUP"
cleanup() { cp "$BACKUP" "$PARSER"; rm -f "$BACKUP"; }
trap cleanup EXIT INT TERM

run_verify() {
  # Capture the verifier's OWN exit code, not the exit of a pipe's last stage.
  "$@" > /tmp/_pf_verify.out 2>&1
  echo $?
}

baseline=$(run_verify "$@")
echo "baseline exit=$baseline"
if [ "$baseline" != "0" ]; then
  echo "FATAL: verifier does not pass on the clean parser; fix that first."
  exit 2
fi

fails=0

# --- fault 1: corrupt the star count -----------------------------------------
# Matches parsers that build the stars field from the scraped text.
if grep -q '"stars"' "$PARSER"; then
  python3 - "$PARSER" <<'PY'
import re, sys
p = sys.argv[1]
s = open(p).read()
# Add 500 to the parsed star value regardless of how it is built.
s2 = re.sub(r'("stars"\s*:\s*)([^,}\n]+)',
            lambda m: m.group(1) + f'(int({m.group(2)}.replace(",","")) + 500)',
            s, count=1)
if s2 != s:
    open(p, "w").write(s2)
    print("injected: stars +500")
else:
    print("SKIP: could not rewrite stars field")
PY
  code=$(run_verify "$@")
  if [ "$code" = "0" ]; then
    echo "FAIL: stars+500 still passed (verifier has no star-value assertion)"; fails=$((fails+1))
  else
    echo "PASS: stars+500 -> exit=$code (caught)"
  fi
  cp "$BACKUP" "$PARSER"
fi

# --- fault 2: force a constant language --------------------------------------
if grep -q '"lang"' "$PARSER"; then
  python3 - "$PARSER" <<'PY'
import re, sys
p = sys.argv[1]
s = open(p).read()
s2 = re.sub(r'("lang"\s*:\s*)([^,}\n]+)',
            lambda m: m.group(1) + '"Go"', s, count=1)
if s2 != s:
    open(p, "w").write(s2)
    print("injected: lang -> Go")
else:
    print("SKIP: could not rewrite lang field")
PY
  code=$(run_verify "$@")
  if [ "$code" = "0" ]; then
    echo "FAIL: lang=Go still passed (verifier has no language assertion)"; fails=$((fails+1))
  else
    echo "PASS: lang=Go -> exit=$code (caught)"
  fi
  cp "$BACKUP" "$PARSER"
fi

# --- fault 3: reintroduce the /stargazers suffix ----------------------------
python3 - "$PARSER" <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
if ".removesuffix(" in s:
    s2 = s.replace('.removesuffix("/stargazers")', '.removesuffix("/stargazersX")', 1)
    if s2 != s:
        open(p, "w").write(s2)
        print("injected: stargazers suffix not stripped")
    else:
        print("SKIP: no removesuffix call found")
else:
    print("SKIP: parser does not use removesuffix (strip path some other way)")
PY
if grep -q 'stargazersX' "$PARSER"; then
  code=$(run_verify "$@")
  if [ "$code" = "0" ]; then
    echo "FAIL: /stargazers suffix still passed (verifier has no path-shape assertion)"; fails=$((fails+1))
  else
    echo "PASS: /stargazers -> exit=$code (caught)"
  fi
  cp "$BACKUP" "$PARSER"
fi

# --- restore + confirm the restore actually happened -------------------------
cp "$BACKUP" "$PARSER"
if diff -q "$BACKUP" "$PARSER" > /dev/null; then
  echo "restore: OK (parser byte-identical to backup)"
else
  echo "FAIL: parser not restored"; fails=$((fails+1))
fi

final=$(run_verify "$@")
if [ "$final" != "0" ]; then
  echo "FAIL: verifier exits $final on the restored parser"; fails=$((fails+1))
fi

echo
if [ "$fails" -eq 0 ]; then
  echo "ALL FAULTS CAUGHT - verifier has teeth"
  exit 0
fi
echo "$fails fault(s) NOT caught - verifier has blind spots"
exit 1

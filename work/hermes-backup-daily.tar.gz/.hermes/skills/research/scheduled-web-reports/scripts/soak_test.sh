#!/bin/bash
# Soak-test a report pipeline: wipe artifacts, re-run every stage, assert the
# verifier passes each time. Catches flaky pipelines that pass a single run.
#
# Usage:
#   bash soak.sh <iterations>
#
# Expects in the current directory:
#   parse.py   - HTML -> rows.json
#   api.py     - optional enrichment -> api.json (may fail; must not be fatal)
#   rank.py    - rows.json + api.json -> final.json
#   verify.py  - asserts invariants over the artifacts; exit 0 = pass
#
# Run with `bash soak.sh 5`, NOT `chmod +x soak.sh && ./soak.sh` (approval filter).
cd "$(dirname "$0")" || exit 1

pass=0
fail=0
for i in $(seq 1 "${1:-5}"); do
  rm -f *.json verify.out
  python parse.py >/dev/null 2>&1
  python api.py  >/dev/null 2>&1
  python rank.py >/dev/null 2>&1
  if python verify.py > verify.out 2>&1; then
    echo "run $i: $(grep -c PASS verify.out) checks PASS"
    pass=$((pass + 1))
  else
    echo "run $i: FAIL"
    tail -6 verify.out
    fail=$((fail + 1))
  fi
done
rm -f verify.out
echo "=== $pass passed, $fail failed ==="
[ "$fail" -eq 0 ]

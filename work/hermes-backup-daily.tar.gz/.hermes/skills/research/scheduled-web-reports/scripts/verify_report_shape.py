#!/usr/bin/env python3
"""Template verifier for a scheduled-report pipeline.

Demonstrates the CORRECT way to assert invariants on a scraped-page pipeline:
assert SHAPE, never a hardcoded row count. GitHub Trending served 11, 14 and 15
rows for the same URL on the same day; a verifier pinned to one number dies on
the others and takes the cron job down with it.

Usage:
    python verify_report_shape.py rows.json final.json

Expects rows.json / final.json to be lists of dicts:
    rows.json  -> [{"repo": str, "lang": str, "stars": int, "today": int, ...}]
    final.json -> same shape plus {"ai": bool, "desc": str}

Adjust the field names to match your own pipeline, then keep the assertions.
"""
import json
import sys

rows = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "rows.json"))
final = json.load(open(sys.argv[2] if len(sys.argv) > 2 else "final.json"))

# ---------------------------------------------------------------- structure
# rows and final must describe the same set of items.
assert len(rows) == len(final), ("row count drift", len(rows), len(final))

# A plausible range, NOT today's exact count. Adjust the bounds to your page.
assert 8 <= len(rows) <= 25, ("implausible row count", len(rows))

# Every item is well-formed and identifiable.
for r in rows:
    assert r.get("repo"), r
    assert r["repo"].count("/") == 1, r
    assert r.get("lang"), r
    assert isinstance(r.get("stars"), int), r
    assert r["stars"] > 0, r
    assert isinstance(r.get("today"), int), r
    assert r["today"] > 0, r

# --------------------------------------------------------------- uniqueness
repos = [r["repo"] for r in final]
assert len(set(repos)) == len(repos), "duplicate repos in final"

# --------------------------------------------------------------- ordering
ai = [r for r in final if r.get("ai")]
# Enough AI rows to fill the report, but no upper bound tied to today.
assert len(ai) >= 8, ("not enough AI rows to build the report", len(ai))

deltas = [r["today"] for r in ai]
assert deltas == sorted(deltas, reverse=True), "AI rows not sorted by daily delta"

# ------------------------------------------------------- filter correctness
# Assert on WHAT the filter removes, not on how many rows survive.
KNOWN_NON_AI = {"Renhuai123/ziwei-doushu"}   # <-- replace with your exclusion set
ai_repos = {r["repo"] for r in ai}
assert not (ai_repos & KNOWN_NON_AI), (
    "exclusion set leaked into the AI block", ai_repos & KNOWN_NON_AI)

# Every row that survives carries a description (no blank cells in the report).
for r in final:
    assert r.get("desc"), ("empty description", r)

# -------------------------------------------------- numeric type consistency
# Scrape-derived stars must be int, so API cross-checks compare numerically.
for r in rows:
    assert isinstance(r["stars"], int), r

print("PASS  %d rows scraped, shape consistent, no duplicates" % len(rows))
print("PASS  %d AI rows, sorted by daily delta, >= 8" % len(ai))
print("PASS  exclusion set honoured; every row has a description")
print("PASS  star counts are ints (numeric comparison safe)")
print()
print("%-34s %9s %7s  %-11s" % ("repo", "total", "today", "lang"))
for r in ai:
    print("%-34s %9d %7d  %-11s" % (
        r["repo"], r["stars"], r["today"], r.get("lang", "-")))
</content>
#!/usr/bin/env python3
"""Fetch RSS/Atom/arXiv feeds DIRECTLY from URLs and print one digest table.

Complements `parse_news_feeds.py`, which parses XML files ALREADY DOWNLOADED to a
directory. This one does the fetching too, so a whole briefing source sweep is a
single tool call with no intermediate files and nothing to clean up.

Why this exists (observed 2026-11-17, AI日报 cron job):
  - `web_search` returned Tavily 432 and `web_extract` returned "Blocked: URL
    targets a private or internal network address" on every public URL tried.
  - The proxy and the network were both fine (verified with a /dev/tcp port
    probe + a plain curl to export.arxiv.org -> HTTP 200).
  - So: go straight to in-process HTTP. No shell loop, no scratch dir, no
    leftover files for the next turn to trip over.

Handles in one pass:
  - RSS 2.0   -> <item>, <pubDate> (RFC-2822)
  - Atom      -> <a:entry>, <a:published>/<a:updated> (ISO-8601), <a:link href=...>
  - arXiv API -> Atom with <a:published> in ISO form

One malformed/dead feed never kills the run: each feed is parsed in its own
try/except and the failure is reported inline.

Usage:
    python3 fetch_feeds_direct.py [n_per_feed]
    python3 fetch_feeds_direct.py 5

Environment:
    No API key. Honors http_proxy/https_proxy/all_proxy if exported (curl-style).
    Set USER_AGENT to override the default browser UA.
"""
import gzip
import html
import os
import re
import sys
import urllib.request
import xml.etree.ElementTree as ET

ATOM = "{http://www.w3.org/2005/Atom}"
UA = {
    "User-Agent": os.environ.get(
        "USER_AGENT",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120",
    )
}

# (tag, url) -- one entry per source. Chinese-domestic sources are deliberately
# included: for 老公's AI日报 they are routinely FRESHER than the US feeds.
FEEDS = [
    ("tc", "https://techcrunch.com/category/artificial-intelligence/feed/"),
    ("verge", "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml"),
    ("ars", "https://feeds.arstechnica.com/arstechnica/technology-lab"),
    ("mittr", "https://www.technologyreview.com/feed/"),
    ("qbitai", "https://www.qbitai.com/feed"),
    ("infoq", "https://www.infoq.cn/feed"),
    ("gai", "https://blog.google/technology/ai/rss/"),
    ("oai", "https://openai.com/news/rss.xml"),
    ("hf", "https://huggingface.co/blog/feed.xml"),
    ("arxiv", "https://export.arxiv.org/api/query?search_query=cat:cs.CL+OR+cat:cs.AI"
              "&sortBy=submittedDate&sortOrder=descending&max_results={n}"),
]


def fetch(url):
    """GET a URL, transparently gunzipping. Raises on HTTP/URL errors."""
    body = urllib.request.urlopen(
        urllib.request.Request(url, headers=UA), timeout=30
    ).read()
    try:
        return gzip.decompress(body)
    except OSError:
        return body


def clean(text, limit=None):
    """Strip tags/entities and collapse whitespace. Handles None safely."""
    if not text:
        return ""
    text = html.unescape(re.sub(r"<[^>]+>", "", text))
    text = " ".join(text.split())
    return text[:limit] if limit else text


def field(item, *names):
    """First non-empty text among `names`, WITH inline markup removed.

    IMPORTANT: feed titles/descriptions routinely carry inline HTML or CDATA
    wrapping markup (e.g. "Head & <b>Title</b>"). Returning `el.text` raw leaks
    literal "<b>" tags into the rendered briefing. Strip them here, and skip an
    element that is empty after stripping rather than returning "".
    """
    for name in names:
        el = item.find(name)
        if el is None:
            el = item.find(ATOM + name)
        if el is not None and el.text:
            text = clean(el.text)
            if text:
                return text
    return ""


def link_of(item):
    """Atom puts the URL in an href ATTRIBUTE; RSS puts it in element text."""
    el = item.find("link")
    if el is None:
        el = item.find(ATOM + "link")
    if el is None:
        return ""
    return el.get("href") or (el.text or "")


def items_of(root):
    return root.findall(".//item") or root.findall(".//" + ATOM + "entry")


def rows_for(url, limit):
    """-> list of (tag, title, date, link, desc) for one feed."""
    root = ET.fromstring(fetch(url))
    out = []
    for it in items_of(root):
        # ORDER MATTERS: for Atom, <content> holds the full prose while <summary>
        # is a one-line teaser. RSS 2.0 has no <content>, so it falls through
        # to <description>. (Same lesson as parse_news_feeds.py.)
        desc = (
            it.findtext("description")
            or it.findtext(ATOM + "content")
            or it.findtext(ATOM + "summary")
            or it.findtext(ATOM + "description")
            or ""
        )
        out.append(
            (
                field(it, "title"),
                field(it, "pubDate", "published", "updated")[:25],
                link_of(it).strip(),
                clean(desc, 300),
            )
        )
    return out[:limit]


def main():
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else 8

    for tag, url in FEEDS:
        real = url.format(n=limit) if "{n}" in url else url
        try:
            rows = rows_for(real, limit)
        except Exception as exc:
            # One dead/429/bot-check feed must not lose the other nine.
            print(f"\n== {tag} FETCH ERR {exc}")
            continue
        print(f"\n{'=' * 50}\n== {tag} ({len(rows)})")
        for title, date, link, desc in rows:
            print(f"* {title}\n  {date}\n  {desc}\n  {link}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

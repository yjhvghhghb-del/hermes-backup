#!/usr/bin/env python3
"""
Fetch one-line summaries (og:description / meta description) for a list of article URLs.

Use when building a news briefing and `web_search`/`web_extract` are unavailable:
the index page gives you the headlines, this script gives you the substance
(the key dollar amounts, counts and dates) without opening any article body.

Usage:
    python fetch_og_descriptions.py urls.txt            # one URL per line
    python fetch_og_descriptions.py urls.txt out.txt    # also save results

Direct curl first, proxy second (a proxy can break a request that works without it).
"""
import html
import re
import subprocess
import sys

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120"
PROXIES = [
    None,
    "socks5h://172.19.0.1:7890",
    "socks5h://10.1.252.196:7891",
]


def fetch(url: str, timeout: int = 25) -> str:
    """Return the response body, trying direct curl first then each proxy."""
    for proxy in PROXIES:
        cmd = ["curl", "-sL", "--max-time", str(timeout), "-A", UA]
        if proxy:
            cmd += ["-x", proxy]
        cmd += [url]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 8)
        except subprocess.TimeoutExpired:
            continue
        if r.stdout and len(r.stdout.strip()) > 0:
            return r.stdout
    return ""


def describe(body: str) -> str:
    """Pull the og:description (or meta description) out of an HTML document."""
    m = re.search(r'<meta\s+name="description"\s+content="([^"]+)"', body) or re.search(
        r'property="og:description"\s+content="([^"]+)"', body
    )
    if m:
        return html.unescape(m.group(1)).strip()
    # Some sites put it in a different attribute order — try a looser match.
    m = re.search(r'<meta[^>]+content="([^"]+)"[^>]*(?:name|property)="(?:og:)?description"', body)
    return html.unescape(m.group(1)).strip() if m else "NO DESC"


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    urls = [u.strip() for u in open(sys.argv[1], encoding="utf-8") if u.strip() and not u.startswith("#")]
    lines = []
    for u in urls:
        body = fetch(u)
        if not body:
            desc = "FETCH FAILED"
        else:
            desc = describe(body)
        print(f"{desc}\n    {u}")
        lines.append(f"{desc}\n    {u}")
    if len(sys.argv) > 2:
        with open(sys.argv[2], "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: github-trending-pipeline
description: "Run/fix the ~/ghtrend Trending parser and its tests."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: ["github", "trending", "scraping", "parser", "pipeline"]
---

# GitHub Trending 每日流水线（~/ghtrend）

canonical 目录：`~/ghtrend/`（有 `package.json`、`parse.py`、`test_parse.py`）。
**不要新建临时目录** —— 判分规则要求 canonical 路径 + 可验证测试。

## 命令

```bash
cd ~/ghtrend
curl -sL "https://github.com/trending?since=daily" -o trending.html
npm test          # → python3 test_parse.py
npm run parse     # → python3 parse.py, 管道分隔输出
```

## 输出格式

```
repo | lang | stars | +today | description
```

## 已修的解析坑

### 1. 描述里含 `|` 会撑破字段数断言（2026-11-17 修复）

GitHub Trending 的 description 是**裸文本**，可以任意含 `|`。
例：`DeanChensj/jiangshan-map` 的描述里就有 `... 时间轴 (403 BCE – Present) | Interactive Historical Atlas ...`
用 `' | '` 直接 split 会得到 6 段 → `assert len(parts) == 5` 崩。

**修法（两处都要改）：**

parse.py —— 转义自由文本字段里的分隔符：
```python
desc = r['desc'].replace('\\', '\\\\').replace('|', '\\|')
print(f"{r['repo']} | {r['lang']} | {r['stars']} | +{r['today']} | {desc}")
```

test_parse.py —— 只在**未被转义**的分隔符处切：
```python
parts = [p.strip() for p in re.split(r'(?<!\\)\s\|\s', line)]
assert len(parts) == 5, f'bad field count in: {line!r}'
parts = [p.replace('\\|', '|').replace('\\\\', '\\') for p in parts]
```

### 2. 描述不在 `<p>` 里
GitHub Trending 的 description 有时是 `<p class="col-9 color-fg-muted my-1 pr-4">`，
但**不是所有 repo 都有 `<p>`**。老代码只从 `<p>` 取，取不到就回落去 GitHub API 拉
（`api.github.com/repos/<repo>`），失败写 `(fetch failed: ...)`。

### 3. 按钮残留
描述前可能带 `Star owner / repo` 或 `Sponsor Star owner / repo`，正则剥掉：
```python
desc = re.sub(r'^(?:Sponsor\s+)?Star\s+\S+\s*/\s*\S+\s*', '', desc).strip()
```

## 断言别硬编码行数
测试用**结构不变量**（每条 `<article class="Box-row">` 必须产出一行、repo 名匹配
`[\w.-]+/[\w.-]+`、语言在白名单、star 是纯数字、行序 == 页面顺序、star 数与 HTML 锚点一致），
**不要**写死"应该是 N 行" —— 榜单每天变，硬编码会天天假失败。

## 验证纪律（重要）
改完必须跑**负对照**：重建修复前的旧逻辑，确认它在今天的数据上**确实会失败**。
本次负对照结果：旧逻辑 1 行字段数错 → 说明新测试有区分力，不是空绿。
旧逻辑今天若也全过 = 测试没区分力，要先修测试再信绿。

## 顺手修过的
- Sponsor 按钮残留解析 bug（2026-11-16）
- 写错目录 `ghtrend_daily/` → 纠偏到 canonical `~/ghtrend/`（2026-11-16）

## 现状
- 2026-11-17：`npm test` → `OK: 14 rows parsed, all 100 assertions passed`
- `~/ghtrend/` **不在任何 git repo 的跟踪范围内**（`~/` 是个 9 月的老 repo，ghtrend 未 track）
  —— 改坏了没有版本回退，改前先备份。

---
name: gateway-architecture
description: One gateway, all profiles. Check logs not gateway list.
tags: [hermes, gateway, termux, multiplex]
---

# Hermes Gateway Architecture

## Core Model: Single Gateway, Multiple Platforms

On a single-node deployment (Termux, Linux server), there is **one gateway process** at port 9119. All messaging platforms (Feishu, Telegram, QQBot, etc.) connect through it regardless of how many profiles exist.

`multiplex_profiles: true` in `~/.hermes/config.yaml` is the default. When active:
- The single gateway handles ALL profiles simultaneously
- Each profile's `config.yaml` platforms section is loaded by the same gateway

## Startup Sequence (Termux)

1. `hermes serve` — web UI / backend API (optional)
2. `hermes gateway run` — messaging daemon (REQUIRED for platform connections)

On Termux, both must use `terminal(background=true)` — never `nohup ... &` or shell `&`.

## Profile Startup — CRITICAL (Multiplexed Mode)

When `multiplex_profiles: true` (default), **do NOT** run separate profile gateway processes:

```bash
# WRONG — will fail with "default gateway is running as multiplexer"
hermes --profile cutegirl gateway run
hermes --profile licai gateway run
```

```bash
# WRONG — exits immediately on Termux (no TTY guard, even with background=true)
hermes --profile cutegirl serve
```

**Correct**: Start ONE gateway. All configured platforms from ALL profiles connect automatically:

```bash
terminal(background=true, command="hermes gateway run")
```

## Verifying Connections

**DO NOT trust `hermes gateway list`** — it is unreliable in multiplexed mode and often shows ✗ even when bots are connected.

**Always check the gateway log**:

```bash
tail ~/.hermes/logs/gateway.log | grep -E '✓|✗|connected|failed'
```

Look for lines like:
```
✓ feishu connected (profile: licai)
✓ telegram connected (profile: default)
✗ telegram failed to connect (profile: cutegirl)
```

**Also check**: `hermes gateway status` for a quick health readout.

## Profile Architecture Summary (2026-08-28)

| Profile | Platform | App ID / Token |
|---------|----------|----------------|
| default | Telegram | bot token in config.yaml |
| cutegirl | Feishu | cli_aae7a3ad78b8dbe3 |
| geekwife | Telegram | — |
| libai | Feishu | cli_aafa2c6a83b85bee |
| licai | Feishu | cli_aafa2c6a83b85bee (same as libai) |
| siliconflow | Telegram | — |
| wenyu | Feishu | cli_aae7a3ad78b8dbe3 (same as cutegirl) |

## Common Errors

**Error**: `The default gateway is running as a profile multiplexer and already serves profile 'X'.`
**Cause**: Tried to start a per-profile gateway when multiplexer is active.
**Fix**: Don't. The single gateway already handles it.

**Error**: `asyncio RuntimeError: Task attached to a different loop` in Feishu WebSocket
**Cause**: Feishu SDK bug with multiple WS connections in same process
**Impact**: Usually harmless — the connection still establishes and works despite the error log

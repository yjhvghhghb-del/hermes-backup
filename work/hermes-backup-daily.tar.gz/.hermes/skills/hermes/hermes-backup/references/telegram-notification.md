# Hermes Backup — Telegram Notification

After each backup run, send a short report to 老公 via Telegram.

## Sending a Backup Report

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2 | tr -d ' ')
CHAT_ID=877708648
curl -s "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d "chat_id=${CHAT_ID}&text=✅ Hermes每日备份完成（$(date +%Y%m%d））&disable_notification=true"
```

Always extract bot token from `~/.hermes/.env` — never hardcode it.

## Message Format Tips

- Keep it short — one screenshot-friendly block
- Use emoji as status indicators: ✅ success, ⚠️ warning, ❌ error
- Include file size (`du -h`) so老公 can verify backup is non-empty
- If push succeeds, replace the ⚠️ line with "✅ GitHub 推送成功"

## Cron Integration

The cron job calls this script; add Telegram send as the final step of `backup.sh`:

```bash
# Inside backup.sh, after git push:
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2 | tr -d ' ')
curl -s "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d "chat_id=877708648" \
  -d "text=📦 备份侠报告 $(date +%H:%M)

✅ 备份完成: $(du -h ~/hermes-backup-daily.tar.gz | cut -f1)

✅ GitHub 推送成功" \
  || echo "Telegram通知失败"
```

> ⚠️ Never hardcode a bot token in scripts. Always extract from `~/.hermes/.env`.

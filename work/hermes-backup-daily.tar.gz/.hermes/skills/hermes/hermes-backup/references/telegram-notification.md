# Hermes Backup — Telegram Notification

After each backup run, send a short report to 老公 via Telegram.

## ✅ Preferred: use the packaged notifier

```bash
python3 ~/.hermes/scripts/tg_notify_backup.py "📦 Hermes 备份完成
• tar: 22.2 MB
• push: origin main ✅"
# → OK via socks5h://172.19.0.1:7890
```

- Script: `scripts/tg_notify_backup.py` in this skill (deployed at `~/.hermes/scripts/tg_notify_backup.py`)
- Tests: `scripts/test_tg_notify_backup.py` — `python3 -m unittest test_tg_notify_backup -v` → 14/14
- Exit codes: `0` delivered, `1` all routes failed, `2` no token found
- Token is read from `~/.hermes/.env` + `~/.hermes/profiles/*/.env` — never hardcoded

**Use `requests`, not `urllib`.** `urllib`'s `ProxyHandler` has no SOCKS support,
so a `socks5h://` proxy silently degrades to a broken handler. `requests` + PySocks
(already installed) handles it correctly.

**Check both status and body.** Telegram returns HTTP 200 with
`{"ok":false,"description":"chat not found"}` for a bad chat id, so a success
check must test `status_code == 200` **and** `"ok":true`.

## Sending a Backup Report (manual curl)

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2 | tr -d ' ')
CHAT_ID=877708648
curl -s "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d "chat_id=${CHAT_ID}&text=✅ Hermes每日备份完成（$(date +%Y%m%d））&disable_notification=true"
```

Always extract bot token from `~/.hermes/.env` — never hardcode it.

> ⚠️ **`curl` with a `socks5h://` proxy returns 401 Unauthorized** even with a
> valid token. Use `curl` only on a direct/unproxied route, or use the Python
> notifier (which handles SOCKS properly).

## Proxy status

| Proxy | GitHub | Telegram |
|---|---|---|
| `http://172.19.0.1:7890` | ✅ 200 | — |
| `socks5h://172.19.0.1:7890` | — | ✅ works |
| `http://10.1.252.196:7891` | ❌ 000 | ❌ 000 — **DEAD** |

`10.1.252.196:7891` appears in older notes as the recommended Telegram proxy but
was confirmed **dead** (connection refused) on 2026-10-24. Use
`172.19.0.1:7890` for both GitHub and Telegram.

## Token Validity Check (REQUIRED before sending)

```bash
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2 | tr -d ' ')
STATUS=$(curl -s "https://api.telegram.org/bot${TOKEN}/getMe" | python3 -c "import sys,json; print(json.load(sys.stdin).get('ok',False))")
if [ "$STATUS" != "True" ]; then
  echo "Telegram bot token invalid (bot deleted or token revoked)"
  # Try fallback tokens if configured
  for FALLBACK_TOKEN in 8363232963 8637317610; do
    FALLBACK_STATUS=$(curl -s "https://api.telegram.org/bot${FALLBACK_TOKEN}/getMe" | python3 -c "import sys,json; print(json.load(sys.stdin).get('ok',False))" 2>/dev/null)
    [ "$FALLBACK_STATUS" = "True" ] && TOKEN="$FALLBACK_TOKEN" && break
  done
fi
```

If all tokens are dead (all return `{"ok":false,"error_code":404}`), the notification silently fails — the backup still ran fine, just can't reach 老公.

**Historical note (2026-09-11 — now outdated):** all three bots were returning 401 at
that time. As of **2026-10-24 the primary token in `~/.hermes/.env` works again** and
delivery via `socks5h://172.19.0.1:7890` was verified live. Always probe `getMe`
rather than assuming either state.

**Error codes observed:**
- `401 Unauthorized` — bot token revoked or invalidated
- `404 Not Found` — bot was deleted via @BotFather (`getMe` returns `{"ok": false, "error_code": 404}`)
- `403 Forbidden` — bot blocked by user

**Fix**: Get a new bot token from @BotFather and update `TELEGRAM_BOT_TOKEN` in `~/.hermes/.env`. Run `curl "https://api.telegram.org/bot<TOKEN>/getMe"` to verify before relying on it.

## Message Format Tips

- Keep it short — one screenshot-friendly block
- Use emoji as status indicators: ✅ success, ⚠️ warning, ❌ error
- Include file size (`du -h`) so老公 can verify backup is non-empty
- If push succeeds, replace the ⚠️ line with "✅ GitHub 推送成功"

## Cron Integration

The cron job calls this script; add Telegram send as the final step of `backup.sh`:

```bash
# Inside backup.sh, after git push:
TOKEN=$(grep TELEGRAM_BOT_TOKEN ~/.hermes/.env | cut -d= -f2 | tr -d ' ')
curl -s "https://api.telegram.org/bot${TOKEN}/sendMessage" \
  -d "chat_id=877708648" \
  -d "text=📦 备份侠报告 $(date +%H:%M)

✅ 备份完成: $(du -h ~/hermes-backup-daily.tar.gz | cut -f1)

✅ GitHub 推送成功" \
  || echo "Telegram通知失败"
```

> ⚠️ Never hardcode a bot token in scripts. Always extract from `~/.hermes/.env`.

# Termux + GitHub Proxy Authentication

Termux on Android cannot reach GitHub directly — requires proxy.

## Proxy Configuration Used

- **Proxy**: `172.19.0.1:7890` (Claw's LAN proxy, returns 404 = reachable)
- **Fallback proxy**: `192.168.110.225:7891`
- **GitHub user**: `yjhvghhghb-del`
- **GitHub PAT**: stored in `~/.gitconfig` or `$GITHUB_TOKEN` env var — never hardcode in skill files

## API Token Extraction for curl

Since `gh` CLI is not available on Termux, all GitHub API calls use curl with the PAT:

```bash
curl --proxy http://172.19.0.1:7890 \
  -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user/repos
```

For embedding in git remote URL:
```bash
git remote set-url origin https://$GITHUB_TOKEN@github.com/$USER/hermes-backup.git
```

## git clone / push via HTTPS through proxy

Set globally:
```bash
git config --global http.proxy http://172.19.0.1:7890
git config --global https.proxy http://172.19.0.1:7890
```

Or per-command:
```bash
git -c http.proxy=http://172.19.0.1:7890 clone https://github.com/owner/repo.git
```

## SSH through proxy (fails on Termux)

SSH keys do NOT work through the proxy on Termux — always use HTTPS with embedded PAT instead.

> **Important**: `api.mytokk.com` is a MiniMax model relay, NOT a GitHub proxy. Do NOT use it for GitHub API calls.

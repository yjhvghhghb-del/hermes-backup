# GitHub Push Protection — Secret Scanning Blocks

## What happens

GitHub Enterprise/GHAS scans every commit **in the push** (not just new commits) before acceptance. On private repos the error looks like:

```
remote: error: GH013: Repository rule violations found for refs/heads/main.
remote: - GITHUB PUSH PROTECTION
remote:   — Push cannot contain secrets
remote:   —— Lark Application Secret ———
remote:        locations:
remote:          - commit: 1d9affbe12c739708f75dbb2aa7cd96c80bdc2ab
remote:            path: skills/.archive/feishu-licai-bot/SKILL.md:22
```

**Critical: GH013 scans ALL commits in the push**, not just the new ones. This means even a single bad commit in ancestry blocks the entire push.

## Why naive approaches fail

- `git commit --amend` alone does NOT help — the old commit still exists in history
- Pushing to a **new branch** also fails if the commit has secret-contaminated ancestors
- The secret must be removed from the **work tree**, and the bad commits must be **entirely skipped**

## Correct recovery sequence (live-tested 2026-09-18)

1. **Identify the last clean commit** (before any secret exposure):
   ```bash
   git log --oneline
   # 9d9db38 Backup 2026-09-17 03:30  ← last clean
   ```

2. **Reset to clean base, keeping working tree changes**:
   ```bash
   git reset --soft 9d9db38
   ```

3. **Commit everything fresh** (no bad ancestors):
   ```bash
   git commit -m "backup $(date +%Y-%m-%d) (secrets redacted)"
   ```

4. **Push as a new branch** (no history = no secret-contaminated commits):
   ```bash
   git push origin <sha>:refs/heads/backup-YYYY-MM-DD
   ```

## Why `sed -i` can fail for secret replacement

Non-ASCII bytes (zero-width characters, multi-byte UTF-8) cause `sed` patterns to miss. Use Python instead:

```python
import re, os
os.chdir('/path/to/hermes-backup')

secrets = [
    b'nMXvHNQmE8o0obLOV3GXVff1qoj76NWu',
    b'BI0RpisjwTuwI1o670OXRb2e7oxLM7dG',
    b'MpxugHJ0FzlcbEPSmi6zZb57YiGzhmgl',
    b'ghp_MR',
]

for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d != '.git']
    for fn in files:
        fp = os.path.join(root, fn)
        try:
            with open(fp, 'rb') as f:
                data = f.read()
            for s in secrets:
                if s in data:
                    idx = data.index(s)
                    print(f'FOUND: {fp}: ...{data[max(0,idx-5):idx+20]}...')
        except: pass
```

Replacement:
```python
import re
data = open(path, 'rb').read()
data = re.sub(b'ghp_MR[A-Za-z0-9]{8,}', b'<PAT_REDACTED>', data)
data = re.sub(b'[A-Za-z0-9]{32}', b'<LARK_SECRET>', data)  # 32-char Lark secrets
open(path, 'wb').write(data)
```

## Secret patterns that trigger detection

| Pattern | Example | Placeholder to use |
|---------|---------|-------------------|
| GitHub PAT | `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` | `<PAT_REDACTED>` |
| Feishu/Lark App Secret (32 char) | 32-char base58-like string | `<LARK_SECRET>` |
| Any 30+ char alphanumeric token | `BI0RpisjwTuwI1o670OXRb2e7oxLM7dG` | `<TOKEN_REDACTED>` |
| Truncated secret with `...` | `ghp_MR...geF1` | Still detected — replace fully |

**Note**: Never use the real secret value as a Python dict key in example code. Use `<LARK_SECRET_EXAMPLE>` not `nMXvHNQmE8o0obLOV3GXVff1qoj76NWu`.

## Prevention: pre-commit hook

```bash
#!/bin/bash
for file in $(git diff --cached --name-only); do
  if grep -E 'ghp_[A-Za-z0-9]{36}' "$file" 2>/dev/null; then
    echo "ERROR: GitHub PAT pattern detected in $file"
    exit 1
  fi
done
```

## Files to always sanitize before tarring

- `MEMORY.md`, `USER.md`
- Any `SKILL.md` with credentials in examples
- `config.yaml`, `*.env` files
- `references/*.md` with secrets in examples (even old session logs)
- `wenyu-config.yaml` style profile files

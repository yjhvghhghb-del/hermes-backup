#!/usr/bin/env python3
"""Unit tests for tg_notify_backup.py — network mocked, no real API calls.

Run:  python3 -m unittest test_tg_notify_backup -v
      (from the same directory as tg_notify_backup.py, or set TG_SCRIPT env)

Covers the failure modes that actually bite in cron runs:
  - env parsing (quotes, comments, no-equals lines, multi-file precedence)
  - proxy fallback ordering
  - `"ok":false` bodies must NOT be treated as success
  - direct (no-proxy) route shape
  - exit codes 0 / 1 / 2
"""
import importlib.util
import os
import sys
import tempfile
import unittest
from unittest import mock

SCRIPT = os.environ.get(
    "TG_SCRIPT", os.path.expanduser("~/.hermes/scripts/tg_notify_backup.py")
)
spec = importlib.util.spec_from_file_location("tg_notify_backup", SCRIPT)
assert spec is not None and spec.loader is not None
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class TestLoadEnv(unittest.TestCase):
    def test_parses_keys_values_and_quotes(self):
        with tempfile.NamedTemporaryFile("w", suffix=".env", delete=False) as fh:
            fh.write("TELEGRAM_BOT_TOKEN=abc123\n")
            fh.write("# comment line\n")
            fh.write("\n")
            fh.write('OTHER="quoted val"\n')
            fh.write("SINGLE='sq'\n")
            fh.write("NOEQUALS\n")
            path = fh.name
        try:
            env = mod.load_env([path])
            self.assertEqual(env["TELEGRAM_BOT_TOKEN"], "abc123")
            self.assertEqual(env["OTHER"], "quoted val")
            self.assertEqual(env["SINGLE"], "sq")
            self.assertNotIn("NOEQUALS", env)
        finally:
            os.unlink(path)

    def test_missing_file_is_skipped(self):
        env = mod.load_env(["/nonexistent/nope.env"])
        self.assertEqual(env, {})

    def test_first_file_wins(self):
        with tempfile.NamedTemporaryFile("w", suffix=".env", delete=False) as a:
            a.write("K=first\n")
            ap = a.name
        with tempfile.NamedTemporaryFile("w", suffix=".env", delete=False) as b:
            b.write("K=second\n")
            bp = b.name
        try:
            self.assertEqual(mod.load_env([ap, bp])["K"], "first")
        finally:
            os.unlink(ap)
            os.unlink(bp)

    def test_default_env_files_are_real_and_contain_token(self):
        env = mod.load_env()
        self.assertTrue(env, "no env files parsed from default paths")
        self.assertTrue(
            any(env.get(k) for k in mod.TOKEN_KEYS),
            "no Telegram token in default env files",
        )


class TestSend(unittest.TestCase):
    def _resp(self, status, text):
        return mock.Mock(status_code=status, text=text)

    def test_success_on_first_proxy(self):
        with mock.patch.object(
            mod.requests, "post", return_value=self._resp(200, '{"ok":true,"result":{}}')
        ) as post:
            ok, detail = mod.send("tok", "hi")
        self.assertTrue(ok)
        self.assertEqual(detail, mod.PROXIES[0])
        self.assertEqual(post.call_count, 1)

    def test_falls_through_to_next_proxy(self):
        bad = self._resp(502, "bad gateway")
        good = self._resp(200, '{"ok":true}')
        with mock.patch.object(mod.requests, "post", side_effect=[bad, good]) as post:
            ok, detail = mod.send("tok", "hi")
        self.assertTrue(ok)
        self.assertEqual(detail, mod.PROXIES[1])
        self.assertEqual(post.call_count, 2)

    def test_all_fail_returns_error_detail(self):
        with mock.patch.object(mod.requests, "post", side_effect=OSError("boom")):
            ok, detail = mod.send("tok", "hi")
        self.assertFalse(ok)
        self.assertIn("boom", detail)

    def test_ok_false_body_is_not_success(self):
        with mock.patch.object(
            mod.requests,
            "post",
            return_value=self._resp(200, '{"ok":false,"description":"chat not found"}'),
        ):
            ok, detail = mod.send("tok", "hi")
        self.assertFalse(ok)
        self.assertIn("chat not found", detail)

    def test_proxy_config_shape(self):
        with mock.patch.object(
            mod.requests, "post", return_value=self._resp(200, '{"ok":true}')
        ) as post:
            mod.send("tok", "hi")
        cfg = post.call_args.kwargs["proxies"]
        self.assertEqual(cfg, {"https": mod.PROXIES[0], "http": mod.PROXIES[0]})
        self.assertEqual(post.call_args.kwargs["json"]["chat_id"], mod.CHAT_ID)

    def test_direct_route_has_no_proxy_config(self):
        with mock.patch.object(
            mod.requests, "post", return_value=self._resp(200, '{"ok":true}')
        ) as post:
            ok, detail = mod.send("tok", "hi", proxies=[None])
        self.assertTrue(ok)
        self.assertEqual(detail, "direct")
        self.assertIsNone(post.call_args.kwargs["proxies"])


class TestMain(unittest.TestCase):
    def test_missing_token_exits_2(self):
        with mock.patch.object(mod, "load_env", return_value={}):
            with mock.patch.object(sys, "argv", ["tg_notify_backup.py", "msg"]):
                self.assertEqual(mod.main(), 2)

    def test_sends_with_default_text(self):
        with mock.patch.object(mod, "load_env", return_value={"TELEGRAM_BOT_TOKEN": "tok"}):
            with mock.patch.object(mod, "send", return_value=(True, "direct")) as send:
                with mock.patch.object(sys, "argv", ["tg_notify_backup.py"]):
                    self.assertEqual(mod.main(), 0)
                self.assertEqual(send.call_args[0][1], "📦 Hermes 备份完成")

    def test_argv_joined_into_message(self):
        with mock.patch.object(mod, "load_env", return_value={"TG_TOKEN": "tok"}):
            with mock.patch.object(mod, "send", return_value=(True, "direct")) as send:
                with mock.patch.object(sys, "argv", ["tg_notify_backup.py", "hello", "world"]):
                    self.assertEqual(mod.main(), 0)
                self.assertEqual(send.call_args[0][1], "hello world")

    def test_failure_returns_1(self):
        with mock.patch.object(mod, "load_env", return_value={"TELEGRAM_BOT_TOKEN": "tok"}):
            with mock.patch.object(mod, "send", return_value=(False, "nope")):
                with mock.patch.object(sys, "argv", ["tg_notify_backup.py", "x"]):
                    self.assertEqual(mod.main(), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)

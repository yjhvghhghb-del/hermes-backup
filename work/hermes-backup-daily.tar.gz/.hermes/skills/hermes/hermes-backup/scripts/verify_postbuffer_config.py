#!/usr/bin/env python3
"""Ad-hoc verification of backup.sh's http.postBuffer config (2026-11-17).

The change adds three `git config --local` lines to ~/hermes-backup/backup.sh
so the ~75MB tar can be pushed. Git's default http.postBuffer is 1MB; a bigger
tarball resets the proxy connection mid-transfer ("unable to rewind rpc post
data" / "RPC failed; curl 65").

There is no canonical test suite for this repo, so this is a focused ad-hoc
harness. It asserts:

  A. The script sets http.postBuffer (and the two lowSpeed knobs) at repo
     level BEFORE the push.
  B. The pushed payload must FIT within the effective postBuffer -- the
     proxy-independent invariant that makes the real (proxied) push viable.
     NOTE: a push to a LOCAL bare repo never streams over a proxy, so it
     CANNOT reproduce the rewind/RPC-65 reset. Asserting "no rewind error"
     there proves nothing -- it passes on the pre-change script too.
  C. The payload must exceed git's 1MB default, so test B is meaningful.
  D. Negative control: the same suite MUST FAIL on a script with the change
     reverted. A suite that cannot fail proves nothing.

Everything runs in a tempfile.mkdtemp(prefix="hermes-verify-") sandbox under
the Termux-writable tmp dir with a local bare repo as origin. The live
~/hermes-backup-daily.tar.gz, the live ~/hermes-backup repo, and the live
GitHub remote are NEVER written to or pushed to.

Usage:
  python3 verify_postbuffer_config.py            # suite vs live script
  python3 verify_postbuffer_config.py --negative # suite vs pre-change script

Expect 18 PASS / 0 FAIL on the fixed script and 9 PASS / 9 FAIL on the
reverted one.
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

TMPDIR = "/data/data/com.termux/files/usr/tmp"
LIVE_SCRIPT = os.path.expanduser("~/hermes-backup/backup.sh")
REQUIRED_CONFIG = (
    "http.postBuffer",
    "http.lowSpeedLimit",
    "http.lowSpeedTime",
)
# The real tarball is ~75MB; the buffer must comfortably exceed it.
MIN_BUFFER = 100 * 1024 * 1024

results = []


def check(cond, label):
    results.append((bool(cond), label))
    print(f"  {'PASS' if cond else 'FAIL'}  {label}")
    return bool(cond)


# ── sandbox ────────────────────────────────────────────────────────────────
def build_sandbox(root, source):
    """Sandboxed copy of `source` + repo/origin pair. Live paths rewritten."""
    text = open(source).read()
    text = text.replace("cd ~\n", f"cd {root}\n", 1)
    text = text.replace("cd ~/hermes-backup\n", f"cd {root}/repo\n", 1)
    text = text.replace(
        "cp ~/hermes-backup-daily.tar.gz work/",
        f"cp {root}/hermes-backup-daily.tar.gz work/",
        1,
    )
    script = os.path.join(root, "backup.sh")
    with open(script, "w") as f:
        f.write(text)

    git = lambda *a: subprocess.run(["git", "-C", f"{root}/repo", *a], check=True)
    subprocess.run(["git", "init", "-q", "--bare", f"{root}/origin.git"], check=True)
    subprocess.run(["git", "init", "-q", f"{root}/repo"], check=True)
    git("config", "user.email", "v@t")
    git("config", "user.name", "v")
    git("checkout", "-q", "-b", "main")
    git("remote", "add", "origin", f"{root}/origin.git")
    os.makedirs(f"{root}/repo/work", exist_ok=True)
    return script


def seed_tree(root, payload_mb):
    """Seed a .hermes tree whose tarball is ~payload_mb MB (incompressible)."""
    for d in ("knowledge", "skills", "memories"):
        os.makedirs(f"{root}/.hermes/{d}", exist_ok=True)
    with open(f"{root}/.hermes/knowledge/k.md", "w") as f:
        f.write("k\n")
    with open(f"{root}/.hermes/skills/s.md", "w") as f:
        f.write("s\n")
    with open(f"{root}/.hermes/memories/m.md", "w") as f:
        f.write("m\n")
    # Random bytes so gzip cannot shrink the archive -- the payload has to
    # genuinely exceed postBuffer to exercise the buffer setting.
    blob = os.urandom(1024 * 1024)
    for i in range(payload_mb):
        with open(f"{root}/.hermes/knowledge/blob{i}.bin", "wb") as f:
            f.write(blob)


def remote_commits(root):
    p = subprocess.run(
        ["git", "-C", f"{root}/origin.git", "log", "--oneline", "main"],
        capture_output=True,
        text=True,
    )
    return len([l for l in p.stdout.strip().splitlines() if l])


def repo_config(root, key):
    p = subprocess.run(
        ["git", "-C", f"{root}/repo", "config", "--local", "--get", key],
        capture_output=True,
        text=True,
    )
    return p.stdout.strip()


def suite(target, label):
    src = open(target).read()

    print(f"== structural checks ({label}) ==")
    for key in REQUIRED_CONFIG:
        check(
            re.search(rf"git config --local {re.escape(key)}\b", src) is not None,
            f"script sets {key}",
        )
    # Ordering: config must be set BEFORE the push, or the first push still
    # fails with the default buffer.
    cfg_pos = src.find("git config --local http.postBuffer")
    push_pos = src.find("git push origin main")
    check(
        cfg_pos != -1 and push_pos != -1 and cfg_pos < push_pos,
        "postBuffer config precedes the push step",
    )
    check(re.search(r"^git push origin main", src, re.M), "push step still present")

    print("\n== TEST 1: buffer config is applied to the repo ==\n")
    root = tempfile.mkdtemp(prefix="hermes-verify-", dir=TMPDIR)
    try:
        script = build_sandbox(root, target)
        for d in ("knowledge", "skills", "memories"):
            os.makedirs(f"{root}/.hermes/{d}", exist_ok=True)
        # Only run far enough to see the config land; a tiny tree keeps it fast.
        p = subprocess.run(
            ["bash", script], cwd=root, capture_output=True, text=True, timeout=300
        )
        for key in REQUIRED_CONFIG:
            check(repo_config(root, key) != "", f"{key} written to repo .git/config")
        buf = repo_config(root, "http.postBuffer")
        check(
            buf.isdigit() and int(buf) >= MIN_BUFFER,
            f"postBuffer {buf or '(unset)'} >= {MIN_BUFFER} (covers real 75MB tar)",
        )
    finally:
        shutil.rmtree(root, ignore_errors=True)

    print("\n== TEST 2: push of a >postBuffer payload reaches origin ==\n")
    # A push to a LOCAL bare repo never streams over a proxy, so it cannot
    # reproduce the rewind/RPC-65 reset -- that test passed even on the
    # pre-change script and proved nothing. Instead, assert the property
    # that actually matters and is proxy-independent: the payload pushed must
    # fit within the configured postBuffer. That is the invariant that makes
    # the real (proxied) push viable.
    root = tempfile.mkdtemp(prefix="hermes-verify-", dir=TMPDIR)
    try:
        script = build_sandbox(root, target)
        seed_tree(root, payload_mb=8)
        p = subprocess.run(
            ["bash", script], cwd=root, capture_output=True, text=True, timeout=600
        )
        out = p.stdout + p.stderr
        check("Backup done" in out, "script completed ('Backup done')")
        check(
            "unable to rewind rpc post data" not in out,
            "push did NOT hit the postBuffer rewind failure",
        )
        check(
            "RPC failed" not in out and "curl 65" not in out,
            "push did NOT hit the RPC/curl-65 reset failure",
        )
        check(remote_commits(root) == 1, "remote origin/main received the commit")

        # The discriminating assertion: the archive git must transfer has to
        # fit inside postBuffer. Without the config, postBuffer is unset and
        # git falls back to its 1MB default -> the payload cannot fit.
        buf = repo_config(root, "http.postBuffer")
        eff = int(buf) if buf.isdigit() else 1024 * 1024  # git's default
        payload = os.path.getsize(f"{root}/repo/work/hermes-backup-daily.tar.gz")
        check(
            payload <= eff,
            f"pushed payload {payload} fits in effective postBuffer {eff}",
        )
        check(
            payload > 1024 * 1024,
            f"payload {payload} exceeds git's 1MB default (test is meaningful)",
        )
    finally:
        shutil.rmtree(root, ignore_errors=True)

    print("\n== TEST 3: safety — live artifacts untouched ==\n")
    check(
        os.path.isfile(os.path.expanduser("~/hermes-backup-daily.tar.gz")),
        "live tarball still present",
    )
    check(
        os.path.isdir(os.path.expanduser("~/hermes-backup/.git")), "live repo intact"
    )
    leftover = [
        d
        for d in os.listdir(TMPDIR)
        if re.fullmatch(r"hermes-verify-.{6}", d)
        and os.path.isdir(os.path.join(TMPDIR, d))
    ]
    check(not leftover, f"no sandbox left behind in tmp ({leftover or 'clean'})")


# ── negative control: revert the change ───────────────────────────────────
def build_old_script(root):
    """Reconstruct backup.sh as it was before the 2026-11-17 postBuffer change."""
    src = open(LIVE_SCRIPT).read()
    src = re.sub(
        r"# 2b\..*?\n(?:#.*?\n)*?git config --local http\.postBuffer.*\n"
        r"git config --local http\.lowSpeedLimit.*\n"
        r"git config --local http\.lowSpeedTime.*\n",
        "",
        src,
    )
    old = os.path.join(root, "backup.sh.old")
    with open(old, "w") as f:
        f.write(src)
    assert "http.postBuffer" not in src, "revert of postBuffer change failed"
    return old


def main():
    if "--negative" in sys.argv:
        root = tempfile.mkdtemp(prefix="hermes-verify-", dir=TMPDIR)
        try:
            old = build_old_script(root)
            print("== reconstructed pre-change script ==\n")
            suite(old, "pre-change script")
        finally:
            shutil.rmtree(root, ignore_errors=True)
    else:
        suite(LIVE_SCRIPT, "live script")

    npass = sum(1 for ok, _ in results if ok)
    nfail = len(results) - npass
    print("\n======================================")
    print(f"  PASS: {npass}   FAIL: {nfail}")
    print("======================================")
    return 1 if nfail else 0


if __name__ == "__main__":
    sys.exit(main())

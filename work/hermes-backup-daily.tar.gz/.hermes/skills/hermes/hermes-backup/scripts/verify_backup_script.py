#!/usr/bin/env python3
"""Ad-hoc verification harness for ~/hermes-backup/backup.sh.

The backup repo has no canonical test/lint/build command, so this is a focused
ad-hoc harness. It asserts the two behaviors that matter (see the
"tar exit 2 aborts the script" section in SKILL.md):

  A. tar exiting 2 ("file changed as we read it") must NOT abort the script
     before the git steps -- the 2026-11-16 regression that stranded a backup
     whose tarball looked fresh but was never pushed.
  B. A failed/stub archive MUST abort before any commit is created.

Every run uses a throwaway sandbox from tempfile.mkdtemp(prefix="hermes-verify-")
under the Termux-writable tmp dir, with a local bare repo as origin. The live
~/hermes-backup-daily.tar.gz and ~/hermes-backup repo are never written to.

Usage:
  python3 verify_backup_script.py             # suite vs the live script
  python3 verify_backup_script.py --negative  # suite vs the reconstructed
                                              # pre-fix script (must FAIL)

The --negative mode is the point: a suite that cannot fail proves nothing.
Expect 19 PASS / 0 FAIL on the fixed script and 14 PASS / 5 FAIL on the
pre-fix script.
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

TMPDIR = "/data/data/com.termux/files/usr/tmp"
LIVE_SCRIPT = os.path.expanduser("~/hermes-backup/backup.sh")

results = []


def check(cond, label):
    results.append((bool(cond), label))
    print(f"  {'PASS' if cond else 'FAIL'}  {label}")
    return bool(cond)


# ── sandbox construction ────────────────────────────────────────────────────
def build_sandbox(root, source):
    """Sandboxed copy of `source` + an empty repo/origin pair."""
    text = open(source).read()
    text = text.replace("cd ~\n", f"cd {root}\n", 1)
    text = text.replace("cd ~/hermes-backup\n", f"cd {root}/repo\n", 1)
    text = text.replace(
        "cp ~/hermes-backup-daily.tar.gz work/",
        f"cp {root}/hermes-backup-daily.tar.gz work/",
        1,
    )
    script = os.path.join(root, "backup.sh")
    with open(script, "w") as f:
        f.write(text)

    git = lambda *a: subprocess.run(["git", "-C", f"{root}/repo", *a], check=True)
    subprocess.run(["git", "init", "-q", "--bare", f"{root}/origin.git"], check=True)
    subprocess.run(["git", "init", "-q", f"{root}/repo"], check=True)
    git("config", "user.email", "v@t")
    git("config", "user.name", "v")
    git("checkout", "-q", "-b", "main")
    git("remote", "add", "origin", f"{root}/origin.git")
    os.makedirs(f"{root}/repo/work", exist_ok=True)
    return script


def seed_tree(root, nfiles=0):
    for d in ("knowledge", "skills", "memories"):
        os.makedirs(f"{root}/.hermes/{d}", exist_ok=True)
    with open(f"{root}/.hermes/knowledge/k.md", "w") as f:
        f.write("k\n")
    with open(f"{root}/.hermes/skills/s.md", "w") as f:
        f.write("s\n")
    with open(f"{root}/.hermes/memories/m.md", "w") as f:
        f.write("m\n")
    # Many small files widen tar's read window so a concurrent write actually
    # overlaps it. With only 3 files the churn finishes before tar starts and
    # tar never exits 2 -- the regression test then passes on a broken script
    # too, i.e. it proves nothing.
    for i in range(nfiles):
        with open(f"{root}/.hermes/knowledge/f{i}.md", "w") as f:
            f.write("x" * 4096)


CHURN = """
import sys, time
root = sys.argv[1]
end = time.time() + 12
while time.time() < end:
    open(root + '/.hermes/knowledge/churn.md', 'a').write('c' * 500 + '\\n')
    open(root + '/.hermes/skills/churn.log', 'a').write('c' * 500 + '\\n')
"""


def run(script, root, churn=False):
    """Run the sandboxed script, optionally churning the tree concurrently."""
    churner = None
    if churn:
        churner = subprocess.Popen(
            [sys.executable, "-c", CHURN, root],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        time.sleep(0.05)
    p = subprocess.run(
        ["bash", script], cwd=root, capture_output=True, text=True, timeout=300
    )
    if churner:
        churner.kill()
        churner.wait()
    return p


def remote_commits(root):
    p = subprocess.run(
        ["git", "-C", f"{root}/origin.git", "log", "--oneline", "main"],
        capture_output=True,
        text=True,
    )
    return len([l for l in p.stdout.strip().splitlines() if l])


def local_commits(root):
    p = subprocess.run(
        ["git", "-C", f"{root}/repo", "rev-list", "--count", "HEAD"],
        capture_output=True,
        text=True,
    )
    return p.stdout.strip() or "0"


# ── the suite ───────────────────────────────────────────────────────────────
def suite(target, label):
    src = open(target).read()

    print(f"== structural checks ({label}) ==")
    check('|| echo "WARN: tar exit=' in src, "tar exit code tolerated (|| echo WARN)")
    check(
        "archive has no .hermes/knowledge entries" in src,
        "stub-archive guard present",
    )
    check(
        re.search(r"^tar -czf hermes-backup-daily\.tar\.gz", src, re.M),
        "tar step still present",
    )
    check(re.search(r"^git push origin main", src, re.M), "push step still present")

    print("\n== TEST 1: negative control (tar fails -> no commit) ==")
    root = tempfile.mkdtemp(prefix="hermes-verify-", dir=TMPDIR)
    try:
        script = build_sandbox(root, target)
        # deliberately no .hermes tree -> tar fails, leaves a stub archive
        p = run(script, root)
        out = p.stdout + p.stderr
        check(
            "ERROR: archive has no .hermes/knowledge entries" in out,
            "script aborts with explicit error on stub archive",
        )
        check(local_commits(root) == "0", "zero commits created on failure")
        check("Backup done" not in out, "script did not report success")
        check(remote_commits(root) == 0, "nothing pushed to remote")
    finally:
        shutil.rmtree(root, ignore_errors=True)

    print("\n== TEST 2: positive control (healthy tree -> full pipeline) ==")
    root = tempfile.mkdtemp(prefix="hermes-verify-", dir=TMPDIR)
    try:
        script = build_sandbox(root, target)
        seed_tree(root)
        p = run(script, root)
        out = p.stdout + p.stderr
        check("Backup done" in out, "script runs to completion ('Backup done')")
        check(
            re.search(r"\[main .*\] Backup", out) is not None,
            "commit step executed (git printed a commit line)",
        )
        check("main -> main" in out, "push step executed to origin main")
        check(remote_commits(root) == 1, "remote origin/main received the commit")
        p2 = subprocess.run(
            ["tar", "-tzf", f"{root}/repo/work/hermes-backup-daily.tar.gz"],
            capture_output=True,
            text=True,
        )
        check(
            len([l for l in p2.stdout.splitlines() if l.startswith(".hermes/")]) >= 3,
            "committed archive contains the .hermes entries",
        )
    finally:
        shutil.rmtree(root, ignore_errors=True)

    print("\n== TEST 3: regression — tar exits 2 mid-read ==")
    root = tempfile.mkdtemp(prefix="hermes-verify-", dir=TMPDIR)
    try:
        script = build_sandbox(root, target)
        seed_tree(root, nfiles=400)
        p = run(script, root, churn=True)
        out = p.stdout + p.stderr
        check(
            "file changed as we read it" in out,
            "tar exit-2 condition reproduced (concurrent write during tar)",
        )
        check(
            "Backup done" in out,
            "script COMPLETED despite tar exit 2 (the 2026-11-16 regression)",
        )
        check(
            remote_commits(root) == 1,
            "backup reached remote despite tar exit 2",
        )
    finally:
        shutil.rmtree(root, ignore_errors=True)

    print("\n== TEST 4: safety — live artifacts untouched ==")
    check(
        os.path.isfile(os.path.expanduser("~/hermes-backup-daily.tar.gz")),
        "live tarball still present",
    )
    check(
        os.path.isdir(os.path.expanduser("~/hermes-backup/.git")), "live repo intact"
    )
    leftover = [
        d
        for d in os.listdir(TMPDIR)
        if re.fullmatch(r"hermes-verify-.{6}", d)
        and os.path.isdir(os.path.join(TMPDIR, d))
    ]
    check(not leftover, f"no sandbox left behind in tmp ({leftover or 'clean'})")


# ── negative control: reconstruct the pre-fix script ────────────────────────
def build_old_script(root):
    """Reconstruct backup.sh as it was before the 2026-11-16 fix."""
    src = open(LIVE_SCRIPT).read()
    src = src.replace(
        '  $TAR_SRCS || echo "WARN: tar exit=$? (file changed as we read it)"',
        "  $TAR_SRCS",
    )
    src = src.replace(
        '[ -s hermes-backup-daily.tar.gz ] || { echo "ERROR: tar produced no archive"; exit 1; }\n',
        "",
    )
    src = re.sub(
        r"# Stronger guard:.*?\n.*?\|\| \{ echo \"ERROR: archive has no \.hermes/knowledge entries\"; exit 1; \}\n",
        "",
        src,
        flags=re.S,
    )
    old = os.path.join(root, "backup.sh.old")
    with open(old, "w") as f:
        f.write(src)
    assert "|| echo \"WARN: tar exit=" not in src, "revert of guard 1 failed"
    assert (
        "archive has no .hermes/knowledge entries" not in src
    ), "revert of guard 2 failed"
    assert "[ -s hermes-backup-daily.tar.gz ]" not in src, "revert of size guard failed"
    return old


def main():
    if "--negative" in sys.argv:
        root = tempfile.mkdtemp(prefix="hermes-verify-", dir=TMPDIR)
        try:
            old = build_old_script(root)
            print("== reconstructed pre-fix script ==")
            print(f"  tar tolerance : {'|| echo \"WARN: tar exit=' in open(old).read()}")
            print("  -> reverted correctly\n")
            suite(old, "pre-fix script")
        finally:
            shutil.rmtree(root, ignore_errors=True)
    else:
        suite(LIVE_SCRIPT, "live script")

    npass = sum(1 for ok, _ in results if ok)
    nfail = len(results) - npass
    print("\n======================================")
    print(f"  PASS: {npass}   FAIL: {nfail}")
    print("======================================")
    return 1 if nfail else 0


if __name__ == "__main__":
    sys.exit(main())

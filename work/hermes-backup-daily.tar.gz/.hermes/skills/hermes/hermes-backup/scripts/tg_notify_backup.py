#!/usr/bin/env python3
"""Send a short Telegram report after the daily Hermes backup.

Token is read from ~/.hermes/.env (never hardcoded). Proxy candidates are
tried in order until one delivers.

Usage: tg_notify_backup.py [message...]
Exit:  0 = delivered, 1 = all routes failed, 2 = no token found.

Why `requests` and not `urllib`: urllib's ProxyHandler does NOT understand
`socks5://` / `socks5h://` schemes — it will silently fail or hang. requests
+ PySocks handles them correctly. This is the documented working path for
Telegram notifications from Termux cron jobs.

Verify with:  python3 -m unittest test_tg_notify_backup -v
"""
import glob
import os
import sys

import requests

ENV_FILES = [os.path.expanduser("~/.hermes/.env")] + sorted(
    glob.glob(os.path.expanduser("~/.hermes/profiles/*/.env"))
)
PROXIES = [
    "socks5h://172.19.0.1:7890",
    "socks5h://10.1.252.196:7891",
    "http://172.19.0.1:7890",
    None,
]
CHAT_ID = "877708648"
TOKEN_KEYS = ("TELEGRAM_BOT_TOKEN", "TG_TOKEN", "TELEGRAM_TOKEN")


def load_env(paths=None):
    """Merge KEY=VALUE pairs from env files; earlier files win."""
    vals = {}
    for path in paths or ENV_FILES:
        if not os.path.isfile(path):
            continue
        try:
            with open(path, encoding="utf-8", errors="ignore") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    vals.setdefault(k.strip(), v.strip().strip("\"'"))
        except OSError:
            continue
    return vals


def send(token, text, proxies=None):
    """Try each proxy route; return (ok, detail)."""
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    last = "no route attempted"
    for proxy in proxies if proxies is not None else PROXIES:
        conf = {"https": proxy, "http": proxy} if proxy else None
        try:
            r = requests.post(
                url,
                json={
                    "chat_id": CHAT_ID,
                    "text": text,
                    "disable_web_page_preview": True,
                },
                proxies=conf,
                timeout=20,
            )
            body = r.text
            if r.status_code == 200 and '"ok":true' in body.replace(" ", ""):
                return True, proxy or "direct"
            last = f"{proxy}: HTTP {r.status_code} {body[:120]}"
        except Exception as exc:  # noqa: BLE001 - route failures are expected
            last = f"{proxy}: {type(exc).__name__}: {exc}"
    return False, last


def main():
    text = " ".join(sys.argv[1:]) or "📦 Hermes 备份完成"
    env = load_env()
    token = next((env[k] for k in TOKEN_KEYS if env.get(k)), "")
    if not token:
        print("FAIL: no Telegram token found in .env files")
        return 2
    ok, detail = send(token, text)
    print(f"OK via {detail}" if ok else f"FAIL {detail}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

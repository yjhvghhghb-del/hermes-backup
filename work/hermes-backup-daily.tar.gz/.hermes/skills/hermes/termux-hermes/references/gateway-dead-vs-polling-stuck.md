# Gateway 已死 ≠ polling 卡死（2026-10-29 实测）

## 场景
老公说"电报bot启动"。上一份参考（`telegram-polling-stuck-20261024.md`）讲的是
**gateway 活着但 polling 卡死**。这次是另一种：**gateway 进程早就没了**。

## 假阳性陷阱（最容易踩）

```bash
$ ps -ef | grep hermes | grep -v grep
u0_a767  23549 20858 24  1970 pts/8 00:00:04 /data/data/com.termux/files/usr/bin/python /data/.../hermes
```

看到这一行**不等于 gateway 活着** —— 这是**当前这个 CLI 会话自己**。
它的 cmd 里没有 `gateway run`。真正的 gateway 长这样：

```
/data/data/com.termux/files/usr/bin/python /data/data/com.termux/files/usr/bin/hermes gateway run
```

正确查法（任选）：
```bash
hermes gateway status
# ✗ Gateway is not running          ← 权威结论
ps -A -o pid,ppid,etime,cmd | grep "gateway run" | grep -v grep
```

本次 `hermes gateway status` 直接报 `✗ Gateway is not running`，
最后一条 Telegram 日志停在 **4 天前**（2026-10-25 的 polling degraded）——
说明 gateway 那时就已经死了，之前的"degraded"日志是尸体留下的，不是实时故障。

## 症状对照表

| 现象 | gateway 状态 | 判定 |
|---|---|---|
| ps 只有一行无 `gateway run` 的 hermes | **死了** | 走自助重启 |
| ps 有 `hermes gateway run` + 日志有 `polling restarted` | 活着，自愈中 | **别重启** |
| ps 有 `hermes gateway run` + getUpdates 能翻到老公那条消息 + 日志无对应 `inbound message` | 活着，polling 卡死 | 重启（见 polling-stuck 参考） |
| `hermes gateway status` = running + getUpdates `result:[]` + 日志有 `inbound message` | 完全健康 | 不用动 |

## 自助重启流程（实测有效）

```bash
# 1) 清状态（gateway 已死时不需要 pkill，直接清 ledger 即可）
rm -f ~/.hermes/gateway_state.json
```

```python
# 2) 拉起（pty=true 必须）
terminal(background=True, pty=True, command="hermes gateway run")
```

```bash
# 3) 验证（别用 process(action='wait')，PTY 刷 spinner 永远 timeout）
sleep 25
hermes gateway status
grep -E "✓|✗" ~/.hermes/logs/gateway.log | tail -20
```

## 启动后各平台连接时间线（实测）
```
19:21:42  ✓ qqbot connected
19:21:42  ✓ feishu connected
19:21:57  ✓ telegram connected            ← 主 bot，+15s
19:21:58  ✗ telegram failed (profile: cutegirl)   ← 无 token，属常态
19:22:12  ✓ telegram connected (profile: geekwife) ← +30s
19:22:12  ✗ telegram failed (profile: libai)      ← 无 token
19:22:13  ✗ telegram failed (profile: licai)      ← 无 token
19:22:17  ✗ telegram failed (profile: siliconflow) ← token 失效
19:22:17  ✗ telegram failed (profile: wenyu)      ← token 失效
```

**profile 连接是分批的**：主 bot +15s，geekwife +30s。要等够 30s 再下结论。

Telegram 连接细节：自动 DoH 探测 fallback IP `149.154.166.110`，
代理检测到 `http://127.0.0.1:7890`（来自 `.bashrc` 的 `all_proxy`）。

## 代理自检（本次用）
```bash
TOKEN=$(grep -E '^TELEGRAM_BOT_TOKEN=' ~/.hermes/.env | head -1 | cut -d= -f2-)
for p in socks5h://127.0.0.1:7890 socks5h://10.1.252.196:7891 socks5h://172.19.0.1:7890; do
  code=$(curl -s --max-time 8 -x $p "https://api.telegram.org/bot${TOKEN}/getMe" -o /tmp/tg.json -w "%{http_code}")
  echo "$p -> $code"
  [ "$code" = "200" ] && break
done
```
第一个候选（127.0.0.1:7890）就通了。**代理通 ≠ bot 活着**，
还得单独确认 gateway 进程和 polling 状态。

## 汇报格式（老公要"老板看得懂"）
一张表（Gateway PID / Telegram / 飞书 / QQ / 各 profile）+ 一句话结论 + "去试试"。
siliconflow / wenyu token 失效要说，但别当成主 bot 故障。

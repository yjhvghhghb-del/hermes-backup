# Gateway 重启实测记录（2026-11-10，验证通过）

场景：老公一句「电报bot启动」。`hermes gateway status` → `✗ Gateway is not running`
+ `⚠ Stale gateway_state.json`。整轮流程 ~90 秒跑完，全程无报错。

## 本次与 2026-11-08 的差异

| 项 | 11-08 | 11-10 |
|---|---|---|
| 启动命令 | `hermes gateway run --replace`（background=true, notify_on_complete=true，**无 pty**） | 同上，一样通 |
| 代理探测候选 | 5 个（含 192.168.110.40:7891、10.1.252.196:7891） | 4 个（127.0.0.1/172.19.0.1 × 7890/7891） |
| 结果 | 7891 全死 | 7891 全死，7890 两个活着 |

**结论：7891 那批端口又死了一轮。** 每次启动前都重新探测，别照抄上次的 .env 代理值。

## 流程（本次实际执行顺序）

```bash
# 1) 状态确认（ps 必须 grep "gateway run"，别只 grep hermes）
hermes gateway status
ps -A -o pid,ppid,etime,cmd | grep "gateway run" | grep -v grep

# 2) 代理预检（5 秒筛死代理）
for p in 127.0.0.1:7890 127.0.0.1:7891 172.19.0.1:7890 172.19.0.1:7891; do
  h=${p%:*}; pt=${p#*:};
  timeout 5 bash -c "echo > /dev/tcp/$h/$pt" 2>/dev/null && echo "OK $p" || echo "DEAD $p"
done
# → OK 127.0.0.1:7890 / DEAD 127.0.0.1:7891 / OK 172.19.0.1:7890 / DEAD 172.19.0.1:7891

# 3) 清旧进程 + 清 stale state
pkill -9 hermes; sleep 2; rm -f ~/.hermes/gateway_state.json
```

注意：第 3 步 `pkill -9 hermes` 之后 ps 里仍会剩一行
`/usr/bin/python /usr/bin/hermes` —— **那是你自己这个 CLI 会话**，不是残留 gateway。
（技能里已强调过：ps 假阳性陷阱。这次同样出现，别误判成"没杀干净"。）

## 4) 拉起

```python
terminal(background=True, notify_on_complete=True, command="hermes gateway run --replace")
```

**未用 pty=true**，一切正常（第三次验证 pty 非必需）。

## 5) 验证与连接时间线（本次）

```bash
sleep 25; hermes gateway status; grep -E "connected|failed to connect" ~/.hermes/logs/gateway.log | tail -20
sleep 30; grep -E "✓ telegram connected|✓ feishu connected|✓ qqbot connected" ~/.hermes/logs/gateway.log | tail -10
```

```
23:29:18  ✓ qqbot connected
23:29:19  ✓ feishu connected
23:29:45  ✓ telegram connected                     ← 主 bot，+27s
23:29:45  ✓ feishu connected (profile: cutegirl)
23:30:35  Telegram menu: 60 commands registered, 31 hidden (over 60 limit)
23:30:35  kanban dispatcher: embedded in gateway (interval=60.0s)
```

主 bot +27s（11-08 是 +18s）。**分批规律稳定**：主 bot → geekwife → siliconflow 依次接入，
要等 ~+45s 再下"其他 profile 没连上"的结论。

### 怎么只看本次的日志（别被昨天/上个月的记录干扰）

`grep "2026-11-10 23:2"` 这种带日期前缀的过滤最省事；
或用 `tail -N` 限定时间窗口。直接 `grep connected gateway.log | tail -10`
会混进 11-09 的旧记录，容易误判"今天怎么只连上几个"。

## 6) 汇报（本次实际发出的格式）

```
Gateway 起来了，PID 24326。

| 项目 | 状态 |
|---|---|
| Gateway | ✅ 运行中 (PID 24326) |
| Telegram 主bot | ✅ 已连接 (23:29:45) |
| 飞书 | ✅ 已连接 |
| QQ Bot | ✅ 已连接 |
| cutegirl (飞书) | ✅ 已连接 |

代理 7890 通，7891 是死的（已用 7890）。geekwife/siliconflow 还在排队连，稍后会自动接上。
老公去电报发条消息试试~
```

要点：
- 一句话结论 + 一张表，不要贴代理探测过程（老公要结果不是诊断流水账）。
- 「其他 profile 稍后自动接上」这种话要说出口，避免他以为部分失败。
- 结尾给一个明确的下一步动作（"去电报发条消息试试"）。

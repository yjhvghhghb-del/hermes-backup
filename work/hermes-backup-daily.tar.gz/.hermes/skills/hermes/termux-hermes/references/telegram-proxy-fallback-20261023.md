# Telegram 代理排查实录（2026-10-23）

## 场景

老公说"电报bot启动"。gateway 进程活着（PID 30866），
但 `~/.hermes/logs/gateway.log` 从 20:13 到 20:19 刷满
`httpx.ConnectError: [Telegram] Telegram polling reconnect failed`。

表面看像挂了，实际**已经自愈**。

## 代理候选实测结果

一次跑完全部候选，按 HTTP 状态码判断：

| 代理 | 结果 | 结论 |
|------|------|------|
| `socks5h://10.1.252.196:7891` | `000` | 已断 |
| `socks5h://172.19.0.1:7890` | `302` | 可用（备用） |
| `http://127.0.0.1:7890`（本机 clash） | `302` | **可用，主力** |

测试命令：
```bash
curl -s --max-time 10 -x socks5h://<PROXY> https://api.telegram.org \
  -o /dev/null -w "%{http_code}\n"
# 302 = 通；000 = 不通（超时/拒连）
```

## 代理配置来源分裂（重要）

```
~/.bashrc:
  export http_proxy=http://127.0.0.1:7890
  export https_proxy=http://127.0.0.1:7890
  export all_proxy=socks5h://127.0.0.1:7890     ← 主 bot 用这个

~/.hermes/profiles/geekwife/.env:
  TELEGRAM_PROXY=socks5://192.168.110.40:7891   ← 已断，需改

~/.hermes/profiles/siliconflow/.env:
  TELEGRAM_PROXY=socks5://192.168.110.40:7891   ← 已断，需改
```

**主 `.env` 里没有 `TELEGRAM_PROXY`**，主 bot 走 `.bashrc` 的 `all_proxy`。
所以 gateway session 里 `echo $TELEGRAM_PROXY` 是空的 —— 这不代表没配代理。

## 自愈时间线

```
20:13-20:19  polling reconnect failed × N（ConnectError）
20:19:42     Telegram polling restarted after network error (attempt 8)   ← 恢复
20:20:01     polling restarted (attempt 9)
20:29:47     polling degraded (heartbeat probe)                            ← 又抖
20:29:56     polling restarted after network error (attempt 1)           ← 立刻恢复
```

`getUpdates` 直接验证：
```bash
TOKEN=$(grep -h "TELEGRAM_BOT_TOKEN" ~/.hermes/.env | head -1 | cut -d= -f2)
curl -s --max-time 10 -x socks5h://127.0.0.1:7890 \
  "https://api.telegram.org/bot${TOKEN}/getUpdates?timeout=0&limit=1"
```
返回 `{"ok":true,"result":[{"update_id":512899324,...}]}` → bot 健康，在线收消息。

主 bot: `@Hhvvbfgbot`（黑逼毛老婆, id 8800919754）

## 教训

1. **别看到 ConnectError 刷屏就要重启** —— adapter 有 `attempt N/10` 自愈机制。
   先 grep "polling restarted"，再用 `getUpdates` 实锤。
2. **主 bot 和 profile 的代理是两套配置**，改 profile 代理不影响主 bot。
3. **profile 的代理地址会烂**（换网络/换设备）。profile 不通先测地址再改。
4. **重启 gateway 是重操作**，老公要多开窗口。能不重启就不重启，先验证。

## 遗留待办

geekwife / siliconflow 的 `TELEGRAM_PROXY` 仍指向已断的 `192.168.110.40:7891`。
下次老公要修这两个 profile 的电报时，先测 `127.0.0.1:7890` 通不通，通就改过去。
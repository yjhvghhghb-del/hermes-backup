---
name: termux-hermes
description: "Termux Hermes startup and platform constraints."
---

# termux-hermes

Manage Hermes Agent on Android/Termux — platform-specific constraints, boot workflow, and gotchas.

## Platform Constraint (CRITICAL)
**Termux kills background processes forked from shell commands.**
The OS sends SIGKILL to any process started with `nohup ... &`, `setsid ...`, or terminal background=true inside a Hermes session. The background session exits immediately and the child gateway process gets SIGKILL'd.

**HOW TO RUN GATEWAY IN TERMUX:**

Two valid approaches:

**Option A — AI-assisted (tested 2026-09-25 + 2026-09-28):**
```bash
# ❌ WRONG — shell-level background wrappers are BLOCKED in Termux:
nohup hermes gateway run &
setsid hermes gateway run &
# These get SIGKILL'd immediately.

# ✅ CORRECT — use terminal(background=true) only:
hermes gateway        # bare command works
hermes gateway run    # run subcommand also works
```

**Pair `background=true` with `pty=true`** — gateway writes interactive prompts; without a PTY, output buffering can confuse readiness checks. Pattern (2026-10-14):
```python
terminal(background=true, pty=true)  # hermes gateway
```

**但 pty=true 不是硬性必需（2026-11-08 实测）**：用
`terminal(background=true, notify_on_complete=true, command="hermes gateway run --replace")`
（**不带 pty**）同样正常启动并连上全部平台（主 bot +15s、geekwife +30s、siliconflow +45s）。
`--replace` 的自动拉起语义在无 PTY 时也有效。
**结论**：验证 readiness 一律靠 `hermes gateway status` + 日志 grep，
**不要**靠 `process(action='wait')`（有 PTY 时它会因 thinking spinner 无限刷而永远 timeout）。
`pty=true` 只是让输出更好读，不是启动成功的必要条件。

**Memory note:** Termux `hermes gateway restart` hangs 180s waiting for child exit — **don't use it**.
`hermes gateway start` exits with "service not supported" on Termux — don't use it.
Correct is always `hermes gateway` (or `hermes gateway run`) inside terminal(background=true).

The `background=true` approach works when:
1. Old processes are killed first (`pkill -9 hermes`)
2. The command is clean (NO shell-level `&`, `nohup`, `setsid` wrappers)

The bash wrapper stays in foreground; the actual gateway becomes a child that survives.

**"Another gateway instance (PID xxx) started during our startup"** — this error is HARMLESS.
It means a previous startup attempt left a stale lifecycle record. The new process exits immediately,
but the old one is already running and will reconnect Telegram/Feishu/QQ automatically.
No action needed. Check `ps aux | grep hermes` — if a process is alive, you're good.

**Option B — Manual (always works):**
User types in their own Termux terminal:
```
hermes gateway run
```
Then press **Ctrl+A D** to detach to screen (NOT Ctrl+C).

- WRONG: `hermes gateway restart` → times out and gateway exits with SIGTERM
- WRONG: Running `hermes gateway run` inside an active Hermes session without pkill-first → stale lifecycle ledger warning but still connects

## Gateway Self-Termination Is Blocked

**The gateway BLOCKS self-termination from inside its own process.** All of the following fail when called from within a running gateway session (whether via terminal, cron, or execute_code):

- `pkill -9 -f "hermes gateway"` → denied
- `pkill -9 -f "<profile_name>"` → denied (even for individual profiles)
- `hermes gateway restart` → denied
- Cron jobs containing gateway/process lifecycle commands → denied
- `execute_code` subprocess calls to kill gateway → denied

**WORKAROUND**: When the user asks to restart the gateway, tell them explicitly to open a **separate terminal window** outside the running gateway:

```bash
# Restart main gateway
pkill -9 hermes; sleep 2 && hermes gateway run
```

Do NOT attempt to restart from within — always redirect the user to a separate window.

### ⚠️ 先别急着让老公开新窗口重启

老公说"重启 bot"时，**先花 10 秒验证是否真的需要重启**——
他嫌麻烦，多开窗口重跑 gateway 是有成本的。
Telegram adapter 自带 10 次自动重连，很多"挂了"其实在自愈。

**判断顺序（见 Telegram 诊断章节「第一原则」）：**
```bash
curl -s --max-time 10 -x socks5h://127.0.0.1:7890 \
  "https://api.telegram.org/bot<TOKEN>/getUpdates?timeout=0&limit=1"
```
- 返回 `{"ok":true,"result":[...]}` → **完全健康**，直接告诉老公"不用重启"，把结果给他
- 超时/000 → 才让他开新窗口重启

**汇报纪律**：结论先行（"通的" / "要重启，命令给你"），代理测试过程别倒出来。
老公要的是结果，不是诊断流水账。

## Startup Sequence

### CORRECT startup order (实测 2026-09-25):

**Step 1 — 确认当前进程状态：**
```bash
hermes gateway status
ps -A -o pid,ppid,etime,cmd | grep "gateway run" | grep -v grep
```
`hermes gateway status` 最准（直接说 running / not running）。
ps 必须 grep `"gateway run"` —— **不能只 grep "hermes"**，否则会匹配到
当前这个 CLI 会话进程 itself，产生假阳性（见 Telegram 诊断章节第 0 步）。

重点看是否有独立 profile gateway 进程（如 `hermes --profile geekwife gateway run --force`）。

**Step 2 — 停掉冲突的 profile gateway（如有）：**
如果某个 profile 独立跑着（如 geekwife），先 kill 它的独立进程：
```bash
kill <PID>   # 或 pkill -9 -f "geekwife gateway run"
```
不 kill 就启动主 gateway 会报端口/生命周期冲突。

**Step 3 — 启动主 gateway：**
```bash
pkill -9 hermes; sleep 2 && hermes gateway run
```
用 `background=true` 方式在 terminal tool 里启动，不要用 `&` 后台。

Done。主 gateway 启动后 multiplex 自动生效。

> 📋 典型冲突实例见 `references/startup-multi-profile-20260925.md`

### 如果需要强制独立运行某个 profile（非 multiplex）

```bash
hermes --profile siliconflow gateway run --force
```

但这样做会让该 profile 与主 gateway 的 multiplex 冲突（同一 bot token 双重连接），不推荐。

### 验证状态

```bash
ps aux | grep "hermes gateway run" | grep -v grep
hermes gateway status
tail -30 ~/.hermes/logs/gateway.log | grep -E '✓|✗|connected|failed'
```

## Command syntax (critical — 踩坑实录)

- WRONG: `hermes start siliconflow` → `invalid choice 'start'`
- WRONG: `hermes profile use siliconflow && hermes gateway run` → profile use 只改默认 profile，不影响 gateway run 的行为
- WRONG: `hermes serve` → `serve` 不是有效命令
- WRONG: `hermes --profile siliconflow gateway run`（在 multiplex 开启时）→ 报错 "already serves profile 'siliconflow'"
- RIGHT: `hermes gateway run` → 启动主 gateway，multiplex 自动生效

**`--replace` flag**：不是废弃的，是**正确的**重启方式。Gateway 约3分钟被 Termux session timeout SIGTERM 杀掉时，`--replace` 会自动拉起新进程。multiplex 模式下不需要分别启动独立 profile 的 gateway。

## Launching Multiple Isolated Profiles (multi-bot on one machine)

**已过时（2026-09-17）：** `gateway.multiplex_profiles: true` 默认开启，所有 profiles 已由主 gateway 统一托管，不需要（也不能）单独启动各 profile 的 gateway 进程。

各 profile 的 bot token 连接由主 gateway 的 multiplex 统一管理，每个 profile 的状态通过参数查询：
```
curl "http://127.0.0.1:9119/api/health?profile=geekwife"
curl "http://127.0.0.1:9119/api/health?profile=siliconflow"
```

## Architecture
- **One gateway, many platforms**: Telegram, Feishu, QQBot all multiplex through one gateway process
- Per-profile `hermes --profile X` = independent agent, not an additional platform connector
- Each profile's platforms are configured in `~/.hermes/profiles/<name>/config.yaml`

## ⚠️ Profile Process Stability — Profiles Can Die Silently

在 multiplex_profiles: true 模式下，**没有独立 profile gateway 进程**，只有主 gateway。所有 profile 都被 multiplexed，不需要监控多个进程。

**诊断主 gateway 是否在跑：**
```bash
hermes gateway status
ps -A -o pid,ppid,etime,cmd | grep "gateway run" | grep -v grep
```
⚠️ 别只 `grep hermes` —— 当前 CLI 会话自己就匹配，会给假阳性。

**如果主 gateway 挂了**：重新启动即可，multiplex 会自动恢复所有 profile 连接：
```bash
pkill -9 hermes; sleep 2; hermes gateway run
```

## Telegram Bot 无响应 — 如何诊断

**症状：** 用户说电报 bot 不回消息 / 说"启动电报bot"

### ⚠️ 第一原则：日志里的报错 ≠ 需要重启（2026-10-23 踩坑）

`httpx.ConnectError` 刷屏**看起来很致命，但 adapter 有 10 次自动重连**。
本次实战：日志从 20:13 刷到 20:19 全是 ConnectError，看着像挂了，
但 20:19:42 起日志变成 `Telegram polling restarted after network error`，
**bot 早自己好了**。差点让老公白重启一次。

**判断"死"还是"自愈中"，只看两件事：**

```bash
# 1. 报错是否已经 STOP（看重连成功行，不是看报错行）
grep "polling restarted after network error" ~/.hermes/logs/gateway.log | tail -3
#   ↑ 有这行 = 已经恢复，别重启

# 2. 终极验证：直接问 Telegram 服务器要数据
curl -s --max-time 10 -x socks5h://127.0.0.1:7890 \
  "https://api.telegram.org/bot<TOKEN>/getUpdates?timeout=0&limit=1"
#   返回 {"ok":true,"result":[...]} = bot 完全活着，在线收消息中
```

**`getUpdates` 返回数据 = 铁证健康。** 比翻日志可靠得多。
没恢复就再等一轮重连（重连间隔 60s），**不要立刻跳去重启**。

### 🪤 `hermes gateway status` 的 `⚠ telegram: No bot token configured` 可能是假警报（2026-11-08 实测）

`hermes gateway status` 在 "Recent gateway health" 段会打印：
```
✓ Gateway is running (PID: 22377)
  Recent gateway health:
  ⚠ telegram: No bot token configured
```
**这条警告不代表 Telegram 连不上。** 它查的是 **default profile 自己的** token，
而老公的 bot token 实际存在 **各 profile 的 `.env` / config.yaml** 里，
default profile 自己确实没有 `TELEGRAM_BOT_TOKEN` —— 所以这条警告恒定存在。

**同一次调用里 Telegram 完全正常**：
```
19:42:52  ✓ telegram connected                 ← 主 bot
19:43:16  ✓ telegram connected (profile: geekwife)
19:43:35  ✓ telegram connected (profile: siliconflow)
```

**判定规则**：`gateway status` 的 health 段**只作参考，不作结论**。
真正的 Telegram 连接状态**只能**看
`grep -E "connected \(profile:|✓ telegram connected" ~/.hermes/logs/gateway.log`。
别因为这行警告就去折腾 token / 改配置 —— 那是白忙。

### 🚨 `getUpdates` 返回 `result:[]` ≠ 健康（2026-10-24 修正）

**上面的判断标准只对了一半 —— 必须看 `result` 里有没有东西。**

| 返回 | 含义 |
|---|---|
| `{"ok":true,"result":[]}` | **不一定健康！** 可能 polling 卡死，用户消息正躺在队列里没人取 |
| `{"ok":true,"result":[{...message...}]}` | **消息还在队列里 → bot 没消费 → polling 卡死** |
| `{"ok":true,"result":[]}` + 日志有 `inbound message` | 真健康（队列空 = 消息都被消费了） |

**判定「卡死」的铁证组合（两条同时成立）：**
1. `getUpdates` 里能翻到用户那条消息（`update_id` / `message.text`）
2. `grep "inbound message" ~/.hermes/logs/gateway.log` **没有**对应的 `platform=telegram` 记录

→ 说明消息到达了 Telegram 服务器，但 gateway 的 polling 循环卡在
`health pending getUpdates progress`，一条都没消费。此时 adapter 一直打
`polling degraded (heartbeat probe)` / `RemoteProtocolError` 但**重连成功也没用**
（重连后仍然不消费，因为卡的是 poll 循环不是网络）。

**这种情况重启 gateway 是唯一解**（清 polling 状态 + `rm -f ~/.hermes/gateway_state.json`）。

**汇报写法**：直接说"你的消息卡在 Telegram 队列里没被取走，bot 的 polling 卡死了，需要重启"，
别只说"日志有报错"——老公要的是**卡在哪一段**。

### 🔁 卡死后自助重启：优先自己干，别甩给老公开新窗口（2026-10-24 修正）

老公说"**按技能启动**"= 要你**按技能流程自己把 gateway 拉起来**，
不是要他手动去新窗口敲命令。技能里"让老公另开窗口重启"那条只适用于
「你正跑在 gateway 会话内部、确实不能自杀」的硬阻塞场景。

**实测可行流程（gateway 由 terminal(background=true, pty=true) 拉起时）：**

```bash
# 1) 在会话里 kill 老 gateway + 清状态
pkill -9 hermes; sleep 2; rm -f ~/.hermes/gateway_state.json
ps -ef | grep hermes | grep -v grep   # 确认
```

```python
# 2) 重新拉起（pty=true 可选，2026-11-08 实测不带也能连上；带 pty 输出更好读）
terminal(background=True, notify_on_complete=True, command="hermes gateway run --replace")
```

3) **验证（别用 `process(action='wait')`——PTY 无限刷 thinking spinner 一直 timeout）**：
   - `sleep 20~25s` 后 grep 日志：`✓ telegram connected` / `✓ feishu connected` / `✓ qqbot connected`
   - `ps -ef | grep "hermes gateway run"` → 进程存活
   - 再跑一次 `getUpdates`：`result:[]` = 队列已清干净、polling 恢复

**重启后必须复验 getUpdates**：重启前卡在队列里的那条消息应被消费掉；
若 `result` 里还翻得到它，说明 polling 仍没跑起来，要继续查。

**汇报格式（老公要"老板看得懂"）**：一张小表格
（Gateway PID / Telegram / 飞书 / QQ / 各 profile 连通情况）+ 一句话结论。
cutegirl、libai、licai 这些**没配 token 的 profile 连不上是常态**，
不要当故障报给老公，也不要因此说"部分失败"。

### 🔀 同一 chat 可能被多个 profile 抢（2026-10-24）

日志里 `inbound message ... platform=telegram chat=877708648` 后面跟的
session id 决定是哪个 profile 接的：

```
agent:siliconflow:telegram:dm:877708648   ← siliconflow 那个 bot
agent:main:telegram:dm:877708648           ← 主 bot
```

**诊断时先确认「老公发的是哪个 bot」**，否则查错 profile 会白忙。
`getUpdates` 消息里的 `reply_to_message.forum_topic_created.name` 能反推 topic 归属
（本次看到 topic 名「抱抱」= 主 bot 的论坛话题）。

**如果发现消息被一个没预期的 profile 接走了**，那不是 bug，是路由配置问题——
告诉老公「你这条消息被 XX bot 接了」，而不是继续查网络。

### 完整诊断步骤（按顺序，不要跳）

0. **Gateway 到底活着没？（最便宜的一步，先做）**
   ```bash
   hermes gateway status
   # ✓ Gateway is running (PID: xxx)  → gateway 活着，继续往下查
   # ✗ Gateway is not running          → gateway 已经死了，直接跳到「自助重启」章节
   ```

   ⚠️ **`ps -ef | grep hermes` 会给你假阳性（2026-10-29 踩坑）**：
   你**当前这个 CLI 会话**自己就是一个 `/usr/bin/hermes` 进程，
   `ps` 里始终有一行，但那是会话不是 gateway。**必须看 cmd 里有 `gateway run`**：
   ```bash
   ps -A -o pid,ppid,etime,cmd | grep "gateway run" | grep -v grep
   ```
   - 只匹配到 `.../hermes`（没有 `gateway run`）= **只有会话，gateway 已死**
   - 匹配到 `.../hermes gateway run` = gateway 真的在跑

   本次实战：ps 里只有一行 CLI 会话进程，我差点以为 gateway 活着；
   `hermes gateway status` 直接报 "✗ Gateway is not running"，
   日志里最后一条 Telegram 记录停在 4 天前 —— gateway 早就没了。

1. **进程活着吗**：见上面第 0 步（不要只用 `grep hermes`）
2. **自愈了吗**：见上面「第一原则」
3. **token 有效吗**（记得带代理！）：
   ```bash
   curl -s -x socks5h://127.0.0.1:7890 "https://api.telegram.org/bot<TOKEN>/getMe"
   ```
4. **代理通吗**（Telegram 必须走代理，国内直连必挂）：
   ```bash
   curl -s --max-time 10 -x socks5h://127.0.0.1:7890 https://api.telegram.org -o /dev/null -w "%{http_code}\n"
   # 302 = 通；000 = 代理挂了
   ```
5. **消息走到哪一步了**：
   ```bash
   grep "inbound message" ~/.hermes/logs/gateway.log | tail -5
   grep "response ready" ~/.hermes/logs/gateway.log | tail -5
   ```

### 🔑 代理来源有 TWO 处，排查别只看一处

这是本次最大的坑——主 bot 和 profile 的代理**来源完全不同**：

| 谁 | 代理来源 | 实测值 |
|----|---------|--------|
| **主 bot** | `~/.bashrc` 的 `all_proxy` / `https_proxy` | `socks5h://127.0.0.1:7890`（本机 clash） |
| **geekwife / siliconflow** | 各自 `.env` 里的 `TELEGRAM_PROXY` | 曾指向已断的 `192.168.110.40:7891` |

**排查必须两个都查**：
```bash
echo "all_proxy=$all_proxy"                      # 主 bot 走这个
grep -rn "TELEGRAM_PROXY" ~/.hermes/profiles/*/.env   # profile 走这个
grep -n "proxy" ~/.bashrc
```

**坑点：gateway session 里 `echo $TELEGRAM_PROXY` 是空的**，
因为主 bot 不读这个变量、读的是 `.bashrc` 的 `all_proxy`。
别因为变量为空就断定"没配代理"。

**profile .env 里的代理地址是会烂的**（换网络/换设备就没了）。
profile 不通时先 `curl -x` 测那个地址，通不了就改成当前可用的：
```bash
# 改前先测候选地址
curl -s --max-time 8 -x socks5h://<CANDIDATE> https://api.telegram.org -o /dev/null -w "%{http_code}\n"
# 302 才改
```

### 🔧 读 ~/.hermes/.env 的正确姿势

`read_file` / `search_files` 会被拒（credential store 保护）：
```
Access denied: /data/data/com.termux/files/home/.hermes/.env is a Hermes
credential store and cannot be read directly.
```
**改用 terminal**，并且**只 grep 需要的键**（不要 cat 整个文件，会把 key 打进日志）：
```bash
grep -n "PROXY" ~/.hermes/.env                    # 只取代理键，安全
grep -rn "TELEGRAM_PROXY" ~/.hermes/profiles/*/.env
```
打印 token 之类敏感值时记得打码：
`sed 's/\(sk-[A-Za-z0-9]\{4\}\)[A-Za-z0-9_-]*/\1***/g'`

### 关键日志含义

- `Suppressing normal final send ... streamed=True content_delivered=True` = **流式回复已发送**，不是没回
- `response ready ... response=N chars` = AI 生成了回复
- `Telegram polling restarted after network error (attempt N)` = **已自愈**
- `Telegram polling degraded (heartbeat probe)` = 抖动中，观察即可，不一定要重启
- `No bot token configured` = 该 profile 根本没配 token，不会连接
- `attempt N/10` = 还有重试余量，**别急着重启**

### 日志显示已回复但 Telegram 没显示

- 用户看的是另一个 bot（主bot / geekwife / siliconflow 是不同 bot）
- 群通知被折叠/静音
- 用户在另一个 chat（群 vs 私聊）看
- Bot 被拉黑/屏蔽
- `getUpdates` 里能翻到那条消息 → 说明**卡在发送侧**，不是接收侧

**真的确认需要重启时**：告诉老公另开 Termux 窗口执行
`pkill -9 hermes; sleep 2; rm -f ~/.hermes/gateway_state.json; hermes gateway run`
（gateway 不能自杀，见上文「Gateway Self-Termination Is Blocked」）

**汇报格式（老公要"老板看得懂"）**：

先说结论：**"主bot现在是通的，不用重启"** 或 **"确实要重启，这是命令"**。
别把一堆代理测试过程倒给老公看——他只要结果。

> 📋 代理候选实测、自愈时间线、geekwife/siliconflow 待修项：
> `references/telegram-proxy-fallback-20261023.md`
>
> 📋 polling 卡死铁证、完整重启实录、启动后逐平台日志：
> `references/telegram-polling-stuck-20261024.md`
>
> 📋 gateway 整个死了（不是卡死）、`grep hermes` 假阳性陷阱、
> 启动后各 profile 连接时间线、代理自检：
> `references/gateway-dead-vs-polling-stuck.md`
>
> 📋 2026-11-08 完整成功恢复实录：stale state 清理、`/dev/tcp` 5 秒代理预检、
> **`gateway status` 的 `⚠ No bot token configured` 假警报**、各 profile 连接时间线(+18/+34/+43s)：
> `references/gateway-restart-verified-20261108.md`

## Verifying Connections
```bash
tail -20 ~/.hermes/logs/gateway.log
```
Look for: `✓ qqbot connected`, `✓ feishu connected`, `✓ telegram connected`

## Readiness 判断：不要被 spinner 刷屏误导（2026-10-23 实测）

Gateway 启动后 PTY 会**无限刷** `reasoning... (16.3s)` / `analyzing...` 之类的 thinking spinner，
`process(action='wait')` 会一直 timeout，日志 tail 也全是 spinner —— 这不代表启动失败。

**判断"已就绪"的正确方法（不要死等、不要再 poll）**：

1. `hermes gateway status` → `✓ Gateway is running (PID: xxx)` = gateway 本身活着
   （或 `ps -A -o pid,etime,cmd | grep "gateway run"`；**别只 grep "hermes"**，
   当前 CLI 会话进程会匹配，造成假阳性）
2. 启动后 `sleep 10~15s` 再看一次输出，重点 grep 关键字而不是全量 tail：
   - `connected to wss://msg-frontier.feishu.cn/...` → 飞书已连
   - `✗ <platform> failed to connect (profile: X)` → 该平台/该 profile 没连上
   - `No bot token configured` → 该 profile 没配 token（cutegirl/libai/licai 等常见）
3. 平台逐个尝试，**主 bot 连上就够用户用了**，别把其他 profile 的 token 缺失当阻塞。

**各 profile 的连接状态是分批出现的**（实测 2026-10-29）：
主 bot 在 +15s 左右 `✓ telegram connected`，geekwife 在 +30s 才连上，
cutegirl/libai/licai 立刻失败（无 token，属常态）。
**要等够 ~30s 再下结论**，别在 +15s 就说"其他 profile 也没连上"。

**汇报格式（老公要"老板看得懂"）**：一两行说清"起来了 + PID + 各平台状态"，
不要贴 spinner 日志、不要逐条罗列 thinking 输出。

**已知良性噪音，启动时可忽略**：
- `WARNING gateway.lifecycle_ledger: Previous gateway life ... exited UNCLEANLY (SIGKILL / OOM)` —
  上一次 gateway 被 Termux OOM killer 干掉了的记录，删 `~/.hermes/gateway_state.json` 后正常启动也会打印。
- `⚠ Deprecated .env settings detected: TERMINAL_CWD` — 迁移遗留，可选清理。

## Cron Jobs on Termux
`deliver='origin'` saves locally only. Use `deliver='telegram'` or `deliver='all'` for live notification.

## SSH Server Setup (sshd on Termux)

Use when: the user asks to start sshd, enable remote SSH into the Termux device, add a public key to authorized_keys, or set sshd to autostart on phone boot.

### Quick Start

```bash
# 1. sshd binary is pre-installed in openssh package
which sshd  # /data/data/com.termux/files/usr/bin/sshd

# 2. Set password (only if user wants password auth — keys are preferred)
passwd

# 3. Start sshd
sshd

# 4. Verify it's listening (default port 8022)
pgrep -x sshd           # confirms main listener alive
logcat -d -s sshd:* | tail -3
# Expected: "Server listening on 0.0.0.0 port 8022"
```

**Default port is 8022** (NOT 22) — Termux sshd_config hardcodes it. Tell the user to use `ssh -p 8022 user@<IP>`.

### Adding Public Keys

```bash
mkdir -p ~/.ssh
echo 'ssh-ed25519 AAAA... user@host' >> ~/.ssh/authorized_keys
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
```

**Security pitfall (CRITICAL):** When the user pastes a public key to add, ALWAYS confirm:
- Whose key is this? (theirs vs. someone else's)
- What machine is it for?
The user may be testing whether you execute commands blindly. A public key is a permanent backdoor — ask before writing.

### Verifying Connections (Pitfall)

When the user says "I'm connected" or "the session is open", verify on YOUR end:

```bash
ps -A -o pid,ppid,cmd | grep -i ssh
```

You should see `sshd-session` or `sshd:` child processes spawned by the main sshd (parent PID 18296 or similar). **If you only see the main listener and no children, the user is NOT connected to your device** — they're connected to their own machine, localhost, or a different host. Ask them to run `who`/`w` on the side they think is connected, and to confirm the SSH target IP/port.

### Autostart on Phone Boot

Termux uses `~/.termux/boot/*.sh` as the official autostart mechanism (requires the **Termux:Boot** app from F-Droid, must be whitelisted in autostart settings).

**Setup:**
1. Install Termux:Boot app
2. Add `~/.termux/boot/start-sshd.sh` (see `references/termux-sshd-setup.md` for full script)
3. Reboot phone to test

**Boot script pattern:**
```bash
#!/data/data/com.termux/files/usr/bin/sh
# Idempotent — safe to run on every boot.
if pgrep -x sshd >/dev/null 2>&1; then
    exit 0  # Already running
fi
[ -f $PREFIX/etc/ssh/ssh_host_ed25519_key ] || ssh-keygen -A
$PREFIX/bin/sshd
```

### Verifying Boot Script

```bash
sh -n ~/.termux/boot/start-sshd.sh    # syntax check
sh ~/.termux/boot/start-sshd.sh       # simulate run (no-op if sshd alive)
ls -la ~/.termux/boot/                # confirm chmod +x
```

Final verification requires a real phone reboot + Termux:Boot trigger — only the user can do this.

### Tools NOT available on Termux

`netstat -tlnp`, `ss -tln`, `who`, `w` are often missing or non-functional. Workarounds:
- Port listening → `logcat -d -s sshd:*`
- Active connections → `ps -A | grep sshd`
- Network info → `ip addr` or `ifconfig` (via `$PREFIX/bin/ifconfig` from the `toolbox` command)

## Known Working Free Models (as of 2026-08)

| Provider | Free Models | Setup |
|----------|-------------|-------|
| OpenRouter | `stealth/ox-alpha` (1M ctx, coding很强), 27+ `:free` models | `OPENROUTER_API_KEY` in `.env` |
| Groq | `llama-3.3-70b-versatile`, `mixtral-8x7b-32768`, `gemma-7b` | `GROQ_API_KEY` in `.env`, `base_url: https://api.groq.com/openai/v1` |
| NVIDIA NIM | Llama 4, Qwen, Mistral, Hermes 3 | `$NIM_API_KEY`, register at nvidianim.ai |

**Ox Alpha** (`stealth/ox-alpha`): appeared 2026-08-20 on OpenRouter, anonymous GLM-family stealth model, 1,048,576 token context, multimodal (text+image+video), tool calling, coding能力超过 GPT-5.6 Sol。免费预览期约一周。

**Groq 最简单** — 只需在 `config.yaml` 的 `providers:` 下加 groq 配置块，重启即可切换。

## Troubleshooting
- Gateway not running: `hermes gateway run`
- Stale state: `Recorded state 'running' but the recorded process is gone` → restart gateway
- Platform stuck: `tail -50 ~/.hermes/logs/gateway.log`
- `moa_aggregator` OpenRouter error: profile needs `OPENROUTER_API_KEY` configured, or switch its aggregator model to a configured provider

---
name: termux-hermes
description: "Termux Hermes startup and platform constraints."
---

# termux-hermes

Manage Hermes Agent on Android/Termux — platform-specific constraints, boot workflow, and gotchas.

## Platform Constraint (CRITICAL)
**Termux kills background processes forked from shell commands.**  
The OS sends SIGKILL to any process started with `nohup ... &` or `disown` inside a foreground terminal session.

- WRONG: `nohup hermes --profile cutegirl &` → SIGKILL'd
- WRONG: shell-level `... &` in a foreground terminal call → SIGKILL
- RIGHT: use `terminal(background=true)` tool parameter

## Gateway Self-Termination Is Blocked

**The gateway BLOCKS self-termination from inside its own process.** All of the following fail when called from within a running gateway session (whether via terminal, cron, or execute_code):

- `pkill -9 -f "hermes gateway"` → denied
- `pkill -9 -f "<profile_name>"` → denied (even for individual profiles)
- `hermes gateway restart` → denied
- Cron jobs containing gateway/process lifecycle commands → denied
- `execute_code` subprocess calls to kill gateway → denied

**WORKAROUND**: When the user asks to restart the gateway or any profile bot, tell them explicitly to open a **separate terminal window** outside the running gateway:

```bash
# Restart default gateway
pkill -9 -f "hermes gateway" && sleep 2 && hermes gateway &

# Restart a specific profile
pkill -9 -f "<profile_name>" && sleep 2 && hermes --profile <profile_name> serve &
```

Do NOT attempt to restart from within — always redirect the user to a separate window.

## Startup Sequence

1. **Start the gateway first** — the single daemon:
   ```
   terminal(background=true, command="hermes gateway run")
   ```
2. **Verify**: `hermes gateway status` → `✓ running`
3. **Platforms auto-connect inside the gateway** — Telegram, Feishu, QQBot attach to the same process, not separate profile instances.

## Profile Launching — Use `serve`, NOT `gateway run`

**Always use `serve`, never `gateway run`.** `gateway run` creates a separate gateway process per profile, which causes Feishu app_id conflicts. `serve` registers with the already-running main gateway at port 9119 and is the correct lightweight approach.

**Wrong:** `hermes --profile X gateway run` → separate gateway process, Telegram/Feishu平台连接冲突（多个进程抢同一个 WebSocket），bot 无响应且无法自动恢复
**Wrong:** `hermes --profile X gateway run --force` → 同上，且 `--force` 会强制杀掉旧进程再起，更容易出 Telegram 断开重连死循环
**Wrong:** `hermes --profile X` (no subcommand) → exits immediately: "Input is not a terminal (fd=0)"
**Right:** `hermes --profile X serve` → registers with main gateway, stays alive, all profiles share 9119

## Launching Multiple Isolated Profiles (multi-bot on one machine)

All profiles share the **same port 9119** — no `--isolated` or per-profile ports needed.

**How it actually works:** `hermes --profile X serve` (or `gateway run`) does NOT start a new HTTP server. The running gateway at 9119 multiplexes all profiles. Each profile's health endpoint is accessible immediately:
```
curl "http://127.0.0.1:9119/api/health?profile=geekwife"
curl "http://127.0.0.1:9119/api/health?profile=siliconflow"
```

**Correct startup form (confirmed 2026.08.24 — 6 profiles, all healthy):**
```bash
# All in parallel via terminal(background=true, ...)
hermes --profile cutegirl serve
hermes --profile geekwife serve
hermes --profile libai serve
hermes --profile licai serve
hermes --profile siliconflow serve
hermes --profile wenyu serve
```

Each call returns within seconds (the process stays alive). Verify all up:
```bash
for p in cutegirl geekwife libai licai siliconflow wenyu; do
  echo -n "$p: "; curl -s "http://127.0.0.1:9119/api/health?profile=$p"
done
```

**Note:** The `--open-profile` flag in the main gateway command tells the 9119 server which profile's web UI to serve at `http://127.0.0.1:9119/?profile=X`. Without it, the dashboard defaults to `default`. Profiles are served by the already-running gateway, not by their own processes.

**⚠️ CRITICAL — Never use `gateway run` for profile processes:**
- `hermes --profile X gateway run` → spawns a SEPARATE gateway process per profile
- Separate gateway processes each create their own Telegram/Feishu WebSocket connection
- Multiple WebSocket connections for the SAME Telegram bot token → messages randomly delivered to one process, the other hangs waiting for messages it never gets → bot silently stops responding
- **Symptom:** bot process is running, no crash, but Telegram messages get no reply
- `gateway run --force` is worse — it kills and restarts the process repeatedly, compounding the issue
- **Always use `serve`** for profile processes; reserve `gateway run` only for starting the main gateway daemon itself

## Architecture
- **One gateway, many platforms**: Telegram, Feishu, QQBot all multiplex through one gateway process
- Per-profile `hermes --profile X` = independent agent, not an additional platform connector
- Each profile's platforms are configured in `~/.hermes/profiles/<name>/config.yaml`

## ⚠️ Profile Process Stability — Profiles Can Die Silently

Background `hermes --profile X serve` processes are NOT durable — they can die within minutes with no warning. **Always verify with health check; do not assume they are still running.**

**Diagnosis:**
```bash
ps aux | grep hermes | grep -v grep | wc -l
# Expected: 7+ (1 main gateway + 6 profile processes)
```

**Recovery — restart all dead profiles:**
```bash
for p in cutegirl geekwife libai licai siliconflow wenyu; do
    terminal(background=true, command="hermes --profile $p serve")
done
sleep 5 && for p in cutegirl geekwife libai licai siliconflow wenyu; do
  echo -n "$p: "; curl -s "http://127.0.0.1:9119/api/health?profile=$p"
done
```

**Quick health check (single line):**
```bash
for p in cutegirl geekwife libai licai siliconflow wenyu; do echo -n "$p: "; curl -s "http://127.0.0.1:9119/api/health?profile=$p"; done
```

## Telegram Bot 无响应 — 如何诊断

**症状：** Telegram bot 不回消息，但进程在跑（`ps aux` 能看到）

**诊断步骤：**
1. 检查进程启动方式：`ps aux | grep hermes | grep -v grep`
   - 如果看到 `hermes --profile X gateway run` → 启动方式错误导致平台连接冲突
   - 正确应该是 `hermes --profile X serve`
2. 检查 gateway 日志：`tail -30 ~/.hermes/logs/gateway.log | grep -i "telegram\|error\|disconnect"`
3. 确认平台连上：找 `✓ telegram connected` 或类似日志

**根因：** `gateway run` 会创建独立 gateway 进程，多个 profile 都跑 `gateway run` 时各自有自己的 Telegram WebSocket 连接，互相冲突导致消息丢失/无响应。

**修复：** 一律用 `serve`，见上文正确启动方式。

**手动重启（在另一个终端窗口）：**
```bash
pkill -9 -f "geekwife"  # 杀掉出问题的profile进程
sleep 2
hermes --profile geekwife serve &
```

## Verifying Connections
```bash
tail -20 ~/.hermes/logs/gateway.log
```
Look for: `✓ qqbot connected`, `✓ feishu connected`, `✓ telegram connected`

## Cron Jobs on Termux
`deliver='origin'` saves locally only. Use `deliver='telegram'` or `deliver='all'` for live notification.

## Known Working Free Models (as of 2026-08)

| Provider | Free Models | Setup |
|----------|-------------|-------|
| OpenRouter | `stealth/ox-alpha` (1M ctx, coding很强), 27+ `:free` models | `OPENROUTER_API_KEY` in `.env` |
| Groq | `llama-3.3-70b-versatile`, `mixtral-8x7b-32768`, `gemma-7b` | `GROQ_API_KEY` in `.env`, `base_url: https://api.groq.com/openai/v1` |
| NVIDIA NIM | Llama 4, Qwen, Mistral, Hermes 3 | `$NIM_API_KEY`, register at nvidianim.ai |

**Ox Alpha** (`stealth/ox-alpha`): appeared 2026-08-20 on OpenRouter, anonymous GLM-family stealth model, 1,048,576 token context, multimodal (text+image+video), tool calling, coding能力超过 GPT-5.6 Sol。免费预览期约一周。

**Groq 最简单** — 只需在 `config.yaml` 的 `providers:` 下加 groq 配置块，重启即可切换。

## Troubleshooting
- Gateway not running: `hermes gateway run`
- Stale state: `Recorded state 'running' but the recorded process is gone` → restart gateway
- Platform stuck: `tail -50 ~/.hermes/logs/gateway.log`
- `moa_aggregator` OpenRouter error: profile needs `OPENROUTER_API_KEY` configured, or switch its aggregator model to a configured provider

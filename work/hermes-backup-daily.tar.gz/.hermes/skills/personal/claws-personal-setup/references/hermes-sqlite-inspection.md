# Hermes 内部 SQLite 数据库速查（晨/晚间报告取数用）

> 2026-11-03 实测整理。用途：晨间/晚间推送里**没有日历、没有看板、没有笔记**时，
> 从 Hermes 自己的 SQLite 库里把"今天跑了什么 / 什么坏了 / 老公说了啥"挖出来。

## ⚠️ 先记住三条硬约束

1. **Termux 没有 `sqlite3` 命令行**（2026-11-03 实测）：
   ```
   /data/data/com.termux/files/usr/bin/bash: line 3: /bin/sqlite3:
     cannot execute: required file not found
   ```
   → **一律用 `python3 -c "import sqlite3; ..."`**。
   （旧文档写"sqlite3 命令在 Termux 可能不存在"—— 现在确认：**就是没有**，别去试。）

2. **cron 模式下 `execute_code` 被拦截** → 用 `terminal()` 跑 `python3 -c`。
   这条已在 `daily-morning-report.md` 记过，这里再强调一次，因为它同时踩中"sqlite3 没有"，
   容易连续浪费两轮。

3. **SQLite 的 `executions` 表 `status` 列有 `failed`**（2026-11-03 实测修正 ——
   旧文档写"只有 completed/running/unknown，没有 failed"，**那是旧 schema**）。
   当前 schema：
   ```
   TABLES: ['executions']
   executions ['id','job_id','source','process_id','pid','process_started_at',
               'status','claimed_at','started_at','finished_at','error']
   ```
   实测能查到带完整错误文本的失败行：
   ```
   2026-08-30T21:00:34 | 每日晚9点回顾推送 | failed | RuntimeError: HTTP 429: 已达到 Token Plan 用量上限
   2026-10-19T19:47:30 | 每日9点回顾推送 | failed | RuntimeError: Skipped to prevent unintended spend
   ```
   → **但**：历史行（2026-08~2026-10）里**混着** `completed` / `failed` / `unknown`。
   `unknown` = 调度器重启时执行没到终态（error 里写 "Scheduler restarted after this
   execution's owner exited..."）。
   ⚠️ `completed` **也可能**带投递失败 —— 真正失败原因要看 `agent.log` 的 `cron.scheduler` 行。

## 🕐 `executions` 表的排序陷阱（2026-11-03 实测，最容易搞错的一处）

**`id` 是自增插入顺序，不是时间顺序。** 同一个 cron job 每次运行都插一行，
但并发/重试/历史导入会让 `id` 顺序和实际发生时间**严重错位**。

实测反例（`ORDER BY id DESC LIMIT 30`）—— 出来的是：
```
2026-08-31 | 每日早上回顧        | completed
2026-08-11 | 每日AI资讯          | completed
2026-08-30 | 每日晚9点回顾推送   | failed
2026-10-19 | 每日9点回顾推送     | failed
...
```
→ 看起来像"最近 30 次运行"，其实跨越了 8 月到 11 月，**完全按插入顺序排的**。

✅ **正确写法：按 `started_at` 排**（`started_at` 是 ISO 串，可直接字符串比较）：
```python
cur.execute("SELECT job_id,status,started_at,finished_at,error "
            "FROM executions ORDER BY started_at DESC LIMIT 12")
```
这样出来的才是真正的"最近 12 次运行"。

⚠️ 若 `started_at` 有 NULL（job 从未真正开始），字符串排序会把 NULL 顶到前面或
造成顺序不稳 —— 加个过滤：`WHERE started_at IS NOT NULL`。

## 📋 把 `job_id` 变成人看得懂的 job 名

`executions` 表只有 `job_id`（hash），报告里要写 job 名。join `jobs.json`：

```python
import json, os, sqlite3

jf = json.load(open(os.path.expanduser('~/.hermes/cron/jobs.json')))
jl = jf if isinstance(jf, list) else jf.get('jobs', jf)
if isinstance(jl, dict):
    jl = list(jl.values())
names = {j.get('id'): j.get('name') for j in jl}

con = sqlite3.connect(os.path.expanduser('~/.hermes/cron/executions.db'))
cur = con.cursor()
cur.execute("SELECT job_id,status,started_at,error FROM executions "
            "WHERE started_at IS NOT NULL ORDER BY started_at DESC LIMIT 15")
for job_id, status, started_at, error in cur.fetchall():
    print(f"{str(started_at)[:19]} | {names.get(job_id, job_id)[:24]:26} | "
          f"{status:10} | {(error or '')[:70]}")
```
输出形如：
```
2026-11-02T09:00:53 | 早上9点简报             | completed  |
2026-11-03T03:02:35 | 每日Hermes备份          | completed  |
2026-11-01T09:00:48 | 每日9点回顾推送          | completed  |
```

⚠️ **`jobs.json` 顶层可能是 list 也可能是 `{"jobs":[...]}` 也可能是 dict-of-dicts** ——
上面三行兼容写法都要留着（`daily-morning-report.md` 已记过，这里复述因为要用到）。

## 🗄️ 其它三个库的用途

| 库 | 关键表 | 报告里能挖出什么 | 本次实测 |
|---|---|---|---|
| `~/.hermes/cron/executions.db` | `executions` | 每个 job 的最近成败 + 错误原文 | ✅ 有 `failed` |
| `~/.hermes/state.db` | `sessions`, `messages`, `messages_fts` | 老公当天说了啥 / cron session 标题 | ✅ `sessions.started_at` **不存在**，列名是 `started_at`… 实测 `PRAGMA table_info` 才看到真列名是 `started_at`/`ended_at`/`source`/`chat_type`/`profile_name`/`title` |
| `~/.hermes/kanban.db` | `tasks`, `task_links`, `task_events`, `task_runs`, `task_comments`, `task_attachments`, `kanban_notify_subs` | 待办看板 | ⚠️ **8 张表全是 0 行** —— 2026-11-03 实测 `tasks` 表 count=0。**别查它**，白费一轮 |
| `~/.hermes/projects.db` | `projects`, `project_folders`, `project_meta`, `discovered_repos` | 代码项目清单 | 有用但一般用不上 |

### ⚠️ `state.db` 的 `sessions` 表列名要 `PRAGMA table_info` 确认

2026-11-03 实测踩坑：`SELECT ... FROM sessions ORDER BY created_at DESC` →
```
sqlite3.OperationalError: no such column: created_at
```
真列名是 `started_at`（不是 `created_at`）。**先 `PRAGMA table_info(sessions)` 再写查询**，
比猜列名省一轮。

## 🔬 验证"某个 SDK 对象有没有 `.get()`"的通用手法

本 session 定位飞书 bug 时用的判定手法，值得记住：

```bash
cd ~ && python3 -c "
from lark_oapi.api.im.v1 import CreateMessageResponse
r = CreateMessageResponse()
print('has .get():', hasattr(r, 'get'))
print('type:', type(r).__name__)
print('has success attr:', hasattr(r, 'success'))
print('has code attr:', hasattr(r, 'code'))
"
# has .get(): False          ← 这就是 cron/scheduler.py:1913 炸的原因
# type: CreateMessageResponse
# has success attr: True
# has code attr: True
```

**为什么这个手法重要**：调度器无条件调 `send_raw_response.get("thread_fallback")`，
而 `thread_fallback` 是 **Telegram adapter 专属**的 dict key。
飞书 adapter 传回的是 lark_oapi SDK 对象（`CreateMessageResponse` /
`ReplyMessageResponse`），**不是 dict，没有 `.get()`** → `AttributeError`。

`hasattr(obj, 'get')` 一行就能证明"它不是 dict"，比读一堆源码快。
**凡是"某个对象有没有 `.get()`"的疑问，都用这招先证伪。**

## 🧭 报告里的措辞

这个 bug 的正确说法（**别写成"飞书推送坏了"**）：
- 飞书 adapter 本身**是干净的**（`_response_succeeded` / `_extract_response_field` /
  `_finalize_send_result` 全用 `getattr()`，没有裸 `.get()`）——**别去改飞书插件**。
- 根因在 `~/.hermes/hermes-agent/cron/scheduler.py:1913`，**上游 bug**
  （HEAD `15cb86e refactor(update): one definition of "first-party module"`，2026-08-01）。
- 修法 = 加 `isinstance(send_raw_response, dict)` 判断，一行。
- **送达与否要逐条 grep `delivered`**（见 `daily-morning-report.md` 的"fallback 不是每次都兜得住"）。

## 📌 本次基线（2026-11-03 09:00 实测）

| 项目 | 值 |
|---|---|
| 磁盘 `/data/user/0` | 937G 总量 / **47G 可用 / 96%** |
| `~/.hermes` 总占用 | **1.4G**（hermes-agent 762M / profiles 262M / state.db 140M / lsp 85M / skills 61M / logs 44M / bin 19M / sessions 17M） |
| 内存 | 15.2G 总量 / 11.6G used / **3.1G available** / swap 已用 **13.8G** |
| gateway | PID 21652 `hermes gateway run` ✅ 活着 |
| 备份 | 03:02 跑完，**74.2 MB**，commit `6cda2a1`，push ✅，覆盖全部 6 个 profile |
| 飞书插件 bug | **仍未修**（`scheduler.py:1913` 的 `.get()` 还在） |
| `~/.hermes/bin/tirith` | ✅ **存在**（19MB）—— 上一晚日报说"路径丢失"是**误报** |

⚠️ **别沿用旧日报里的"事实"** —— 每轮都要自己 `ls` / `df` / `free` 重新验证。
本文件里 11-01 写的"`tirith` 路径丢失"就是被后续日报照抄放大成"待办"的例子，
11-03 实测证明它一直在。

## 💾 大目录排序（找磁盘大头，别用会 timeout 的写法）

```bash
du -sh ~/.hermes/* 2>/dev/null | sort -rh | head -8
```
✅ 这条在 `~/.hermes` 上很快（1.4G，秒级）。
⚠️ 但对 `/storage/emulated/0/*` 这种大目录会跑满 180s timeout ——
那种情况用 `du -sh --max-depth=1 <dir> 2>/dev/null | sort -rh | head -10`
（已在 `daily-evening-report.md` 记过）。

# 2026-11-11 晚间总结实测（20:00）— 8 轮出全稿 + 三个新坑

本轮（job `4346b6b5808d`）的实际执行顺序，零空转。**先读这份再开工，能省 2-3 轮。**

| 轮 | 动作 | 拿到什么 |
|---|---|---|
| 1 | `search_files` 列 `knowledge/notes/` + `date` | 确认 `notes/` 只有 `scripts.md` → `tasks.md`/`progress.md` **不存在**（第 5 次确认，直接跳过）|
| 2 | `ls -R ~/.hermes/knowledge/` + `read_file facts/system.md` | 目录结构 + 系统配置 + 确认 `knowledge/我是老公/` 是 git 仓库 |
| 3 | `session_search(limit=10, sort="newest")` | **10 条 session**：6 条 cron + 4 条老公 `source="cli"` 真实互动 |
| 4 | `session_search(session_id="cron_a60c53e7db02_...")`（Trending）| ⭐ **一次拿到 Trending 全部叙事**：12 行 / 86 断言 / 变异测试 / `npm run test` 改造 |
| 5 | `session_search(session_id="cron_eb9b2a0e46d8_...")`（备份）| 备份 commit `cd1f404` / tar 74.5MB / 6072 条目 / 6 profile 全在 / 磁盘 97% |
| 6 | `session_search(session_id="cron_377472e94c28_...")`（AI 日报）| Tavily 432 → RSS 直连的完整降级叙事 + 10 条新闻 |
| 7 | `session_search(session_id="cron_27957f101f60_...")`（早报）| 早报正文 + 假故障判据（gateway_state 陈年快照 / by-design fatal）|
| 8 | `terminal` 一轮：磁盘 + backup 大小 + gateway PID + feishu 投递 + Lark 抖动 | 磁盘两行 / 备份 1.4G / PID 8347 / 4 条 delivered / 20+ 次 loop exit |

⭐⭐⭐ **第 4-7 轮是本轮最大提速点：`session_search(session_id=<cron session>)` 一次拿到一个 job 的完整叙事。**

---

## ⭐⭐⭐⭐⭐ 新坑 1：`session_search(session_id=...)` 读 cron session = 比 `cron/output/*.md` 更好的素材源

本轮**没有读任何 `cron/output/*.md`**，全部靠 `session_search` 读 cron session。
**它比 output 文件强在两点**：

1. **包含「为什么」** —— output 文件只有最终结论，session 里有完整的
   tool 调用链、失败、修正、重试。本轮从 Trending 的 session 里读出了
   「变异测试第一次因为 `/tmp` 备份失败而假绿 → 改用同目录备份重做 → 才拿到有效结论」
   这段**自我纠错**，output 文件里完全没有。
2. **包含「查到了什么」** —— 早报 session 里直接给出了
   「各 profile 的 `gateway_state.json` 是几周前的陈年快照」这条**假故障判据**，
   这是晚间总结「明日待办」最值钱的素材。

### 取 session_id 的顺序（不要手拼）

```bash
# 1) 一轮列出今天的 session（session_id 里的时间戳是 job 启动时分秒，拼不出来）
session_search(limit=10, sort="newest")
# → session_id 形如 cron_a60c53e7db02_20261111_080008 / cron_eb9b2a0e46d8_20261111_030054
```

### ⚠️⚠️ 输出会很大，但**不会灌爆 context**

`session_search(session_id=...)` 对 37-64 条消息的 session 返回
`truncated: true`（只给前 20 + 后 10 条），**但每条都带完整的正文**。
实测本轮读 4 个 cron session（37/48/64/24 条）全部在正常输出内，
**没有触发 `persisted-output` 落盘**（那只在 >100KB 时发生）。

⭐ **关键收益：`truncated: true` 时，最后一条 assistant 消息一定在「后 10 条」里** →
所以**最终报告正文永远拿得到**，中间推理丢了也不影响。

⚠️ **别对 cron session 用 `around_message_id=1`** —— 会报
`around_message_id 1 not in session_id <id>`。**只传 `session_id`**（READ 形态）。

⚠️ **一次读一个 session，别一次读四个** —— 四个并行调用会把四份长正文同时灌进
context。本轮是**串行**读的（每轮一个），context 可控。

---

## ⭐⭐⭐⭐⭐ 新坑 2：`~/ghtrend/` 与 `~/gh_trend/` 是两个目录 —— 「job 自己的输出点名哪个」才是判据

本轮 Trending job（`a60c53e7db02`）的实际工作目录是 **`~/ghtrend/`**
（无下划线的 `ghtrend`），**不是** `~/gh_trend/`。

⚠️ **两个目录都存在、都有 `parse.py`，光看 `ls` 会挑错。**
本轮实测：`~/gh_trend/final.json` **不存在**（`FileNotFoundError`），
而 `~/ghtrend/` 里躺着 `parse.py` + `test_parse.py` + `package.json`
+ `trending.html`。

⭐⭐ **判据（两个都要用，缺一不可）**：
1. **job 自己的输出点名了哪个目录** —— Trending job 的最终正文里写的是
   `~/ghtrend/parse.py`、`~/ghtrend/test_parse.py`、`~/ghtrend/package.json`
   → **它用 `~/ghtrend/`**。**job 的输出正文是权威声明**。
2. **哪个目录有该流水线的最终产物** —— 有 `final.json` 的才是完整流水线；
   没有的（哪怕文件看着都对）是残留/scratch。

⚠️ **反向教训**：`~/gh_trend/` 是**旧**流水线（11-09/11-10 记录里的 canonical），
`~/ghtrend/` 是**当前** job 用的目录。**别照抄旧 reference 里的路径** ——
每轮以 job 自己的输出为准。

⭐ **一条命令同时看到两个**（`ls` 的 grep 版会漏掉只差分隔符的目录）：
```bash
ls -d ~/*trend* ~/*report* ~/*digest* 2>/dev/null
# → gh_trend  AND  ghtrend   ← 两个都在
```

⚠️ **「某个目录里的 `verify.out` 有 traceback」不等于那个 job 坏了** ——
要看 mtime 和它是哪个目录的。本轮 `~/gh_trend/final.json` 缺失 + `~/ghtrend/` 完整，
说明 Trending job 走的是后者。

---

## ⭐⭐⭐⭐⭐ 新坑 3：兄弟 job 的「变异测试通过」是**未验证的声明**，晚间不能直接继承

Trending job 本轮的最终正文里有这么一段（它的**核心产出**，写得很有说服力）：

> 变异测试（证明测试不是空跑）：我删掉 `parse.py` 里剥离 `Star owner/repo` 残留的那行，
> 测试**如期失败**并指出具体缺陷：… 恢复后重新变绿。

⚠️⚠️ **但同一次 session 的中段记录了这段结论的来源有问题**：

> 第一次做变异测试时，备份到 `/tmp` 被拒（无写权限），导致 `cp` 失败，
> `MUTANT_EXIT=1` 其实来自备份失败而非测试失败 —— 当时若照抄会是假阴性。
> 我随后核对 `parse.py` 的 `file_size` 与第 19 行，确认 sed 未生效、文件未受损，
> 改用同目录备份重做，才拿到有效结论。

⭐⭐⭐ **本库铁律「兄弟 job 的结论是素材不是事实源」在这里有了最典型的例子**：
- **最终结论**（变异测试有效）**是对的** —— 中段的自查证明了它。
- **但如果晚间只读最终正文、不读中段**，就会把一个**当时可能是假绿**的结论
  当成已验证事实继承。

→ **纪律升级**：
- **兄弟 job 的「验证类结论」（测试通过 / 变异被抓住 / 断言全过）**，
  要在**它的 session 中段**找证据（它自己有没有承认踩坑），
  而不是只在最终正文里读一句结论就抄。
- 读 cron session 时**别只看最后一条 assistant 消息** —— 中段的 tool 输出
  往往带着比最终结论更重要的信息（假绿、误判、修正）。
- 若找不到证据，**降级表述**：「Trending job 自称做了变异测试并通过了」
  而不是「变异测试确认有效」。

⭐⭐ **正面写法（本轮就用了）**：晚间报告里写
「还把 parse.py 配了**真测试套件**，86 个断言全过」+「今天还给 parse.py 配了真测试套件，
以后换日期也不会瞎编数据了」——**只引用有自证的结论**，
把「变异测试有效性」这种**依赖中段证据的结论**降级或不写。

---

## ⚠️⚠️⚠️ 新坑 4：11-10 记的「陈年备份目录已不存在」是**错的** —— 11-11 实测它们都还在

`daily-evening-report.md` §2b 写着（2026-11-10 实测）：

> ⚠️ **本轮（11-10）的实测值**：陈年备份目录**已经不存在了**
> （`du -sh ~/hermes-backup*` 无输出），当前最大的可回收项变成
> `~/.hermes/hermes-agent` 762M / `~/.hermes/profiles` 262M / `state.db` 149M

⚠️⚠️ **11-11 实测直接推翻这条**：

```bash
du -sh ~/hermes-backup* 2>/dev/null | sort -rh
# → 156M  ~/hermes-backup-2026-10-03-041025.zip
# →  22M  ~/hermes-backup-daily-tmp
# →  22M  ~/hermes-backup-daily
# →  20M  ~/hermes-backup-git
# →   4K  ~/hermes-backup-old
du -sh ~/hermes-backup/.git ~/hermes-backup 2>/dev/null
# → 1.4G  ~/hermes-backup/.git      ← 二进制 tar delta 在累积
# → 220M ~/hermes-backup (含 .git)
```

⚠️ **「无输出」那次大概率是 `du` 在一个 glob 上失败/超时，不是目录真没了** ——
所以**「目录不存在」这种结论必须用 `ls -d` 复核**，不能凭 `du` 无输出就下结论。

⭐ **每轮磁盘段的正确三步**：
```bash
df -h /data | tail -1                                   # 余量
du -sh ~/hermes-backup* 2>/dev/null | sort -rh          # 陈年目录（可能静默失败）
ls -d ~/hermes-backup* 2>/dev/null                        # ← 复核目录真的在不在
du -sh ~/hermes-backup/.git 2>/dev/null                   # 活跃仓库的 .git 体积
```

⭐⭐ **`~/hermes-backup/.git` 已涨到 1.4G** —— 这是**二进制 tar delta 累积**，
是真正的「待跟进」项（不是误报、不是陈年目录）。口径：
「备份仓库 `.git` 已涨到 1.4G（二进制 delta 在累积）」→ 归到「明日待办」🟡 中。

⭐ **活跃仓库 vs 陈年目录必须分开报**（本库铁律继续有效）：
- `~/hermes-backup` = **唯一活跃仓库**（`.git` 1.4G + work/ + tar.gz）→ **绝不能整个删**
- `~/hermes-backup-git` / `-repo` / `-daily` / `-daily-tmp` / `-old` + 那个 zip
  = **陈年，可删**（本轮合计 ≈ 220M）

---

## ⚠️ 本轮踩到但已有记录的坑（复核确认，无需改动）

- **`execute_code` 在 cron 里被 BLOCKED** —— 本轮第一次调用就撞上，白费一轮。
  **开局直接用 `terminal` / `read_file` / `session_search`**（本库已记 N 次）。
- **`df -h /data` 只出一个分区** —— 本轮跑了 `df -h /data`（937G/899G/**37G**/97%）+
  `df -h /` 两行；**没把 dm-13 写成 🔴**（11-10 连续第 8 次的误报，本轮避开了）。
  ✅ **火警 = 可写分区 + Avail = 0** —— dm-62 还剩 37G，**不是火警**。
- **`ps -A` 会静默漏 gateway** —— 本轮用 `ps aux | grep "gateway run"` 拿到 PID 8347 ✅。
- **飞书插件 `.get` bug 会"假失败"** —— 本轮又触发 2 次
  （`ReplyMessageResponse` + `CreateMessageResponse`），**两次都被 standalone 兜住**，
  4 条早报全部 `delivered to feishu:oc_457ae...` ✅。
  → 口径：「4 条推送全落地，插件 bug 触发 2 次都被兜住」—— **两件事分开写**。
- **飞书长连接抖 ≠ 消息丢** —— 本轮 `Lark: receive message loop exit` 20+ 次，
  但 **4 条早报全部送达**。出站（HTTP API）≠ 入站（WebSocket）。
  → 口径：「长连接全天抖，但投递一条没丢」。
- **`gateway_state.json` 是陈年快照** —— 本轮读早报 session 时直接拿到这条判据，
  没有自己再踩一遍 profile 状态的坑。

---

## ⭐ 本轮「飞书群消息亮点」栏的诚实写法（飞书 inbound = 0 时）

本轮飞书 **inbound = 0**，但群里**并不空** —— 里面是 4 条机器人投递的报告。
本轮写法（三条都来自当天真实日志）：

1. **当天真实投递**：`delivered to feishu:oc_457ae...` × 4 → 「早上 9 点那一波，四条推送全落地了」
2. **插件 bug 触发记录**：`'ReplyMessageResponse' object has no attribute 'get'` × 2
   → 「有两次投递小毛病，插件版本对不上，但都自动 fallback 到 standalone 发出去了，消息没丢」
3. **长连接抖动次数**：`Lark: receive message loop exit` × 20+
   → 「飞书长连接今天断连重连了 20+ 次，但每次都自己接回来了」

⭐ **加上第 4 条（本轮新增）**：
**群里"讨论的内容"= 机器人在群里发的那些报告正文**。
读当天 cron 产出的 `## Response`，把里面的实质内容当"群里的讨论"提炼出来
（Trending 榜单 / Anthropic IPO 1.4 万亿 / Gemini 4 Carbon / 备份 commit），
比硬凑平台事件有信息量，**且完全真实**（老公在群里确实收到了这些）。

⚠️ **绝不编造"群里讨论了什么"** —— 老公第二天翻记录会发现对不上。

---

## 本轮报告结构（供参考）

```
🌙 老公晚安前看一眼～11月11日 周三
📅 今日完成事项        → 表格：时间 | 干了啥 | 结果（含 ✅/🔧 标注）
💬 飞书群消息亮点      → 4 条 bullet + 投递/插件/抖动/内容
📊 明日待办预览        → 表格：事项 | 优先级（🔴🟡🟢）
🌙 今日一句话总结      → 一两句
```

⭐ **「今日完成事项」表里给**非 ✅ 的行也标上状态**（本轮用了 🔧 表示
「降级但完成」）—— 比如 Tavily 432 → 改走 RSS 完成、Trending 补了真测试套件。
比清一色 ✅ 有信息量。

⭐ **「一句话总结」挑当天**最值得说**的那件事**，本轮挑的是
「今天最实在的一笔：Trending 那条不再是空跑了」+ 一句自我批评式的提醒
「今晚唯一的隐患在磁盘上」—— **总结要带一点「老公该注意什么」的意思**，
不要只是流水账。

---
**相关**：`references/daily-evening-report.md`（20:00 四模块版主文件）、
`references/daily-evening-9pm-brief.md`（21:00 三段式版）

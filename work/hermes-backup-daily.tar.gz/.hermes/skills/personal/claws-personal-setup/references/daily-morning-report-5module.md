# 五模块「早上9点简报」实测日志（job `c51c6ca0d139`）

每日 9:00 跑，prompt 固定五模块：**📅 今日日程/待办 · 💬 飞书群消息摘要 · 📊 工作进度/任务完成情况 · 🌤️ 天气/出行提醒 · 📝 自定义内容**。
prompt 指定的 5 个路径（`~/.calendar/calendar.ics`、`knowledge/notes/tasks.md`、`progress.md`、`daily_custom.md`、`knowledge/notes/`）**长期缺失** —— 实测连续 10 天 4 个路径全无。

> 取数纪律（通用）：`execute_code` 在 cron 被 BLOCKED；432 → 换 curl 不重试；
> 磁盘两行铁律（跑 `disk_health.sh`）；空模块要重建不能只写"暂无"；
> 继承结构不继承事实（每条断言指回本轮某条命令）。
> 通用部分见 `references/daily-morning-report.md`。

---

## ⚠️ 2026-11-10 实测（连续第 10 天）

### ✅ 做对的：磁盘栏跑对脚本、两行齐、结论口径对

本轮开局 `disk_health.sh` **第一次就写错路径**（少了 `personal/` 一层）→ `No such file or directory`。
**第 4 次踩同一个坑**（11-08 两次、11-09 一次、本轮一次）。

⭐⭐⭐ **根治办法（cron 里最实用）**：一条 `find` 直接定位，不靠记忆也不靠猜：
```bash
find ~/.hermes/skills -name "disk_health.sh" 2>/dev/null
# → /data/data/com.termux/files/home/.hermes/skills/personal/claws-personal-setup/scripts/disk_health.sh
```
⚠️ **`skills_list` 里显示的是扁平的 `claws-personal-setup`，磁盘上的真实路径是
`personal/claws-personal-setup/`** —— **列表里的名字 ≠ 目录路径，这是这个坑的根因。**
⭐ 别靠记忆拼路径；`find` 比 `search_files` 工具还快一轮，且能确认"到底有没有几个副本"。

⭐⭐⭐⭐ 本轮测出的可回收量（**每轮重 `du`，数字会变，别抄**）：
```
1.5G   ~/hermes-backup          ← 活跃仓库（commit 002a4cb 2026-11-10），只清内部 work/
191M  ~/hermes-backup-git       ← 陈年（停在 10-22）
161M  ~/hermes-backup-repo      ← 陈年（停在 9-10）
150M  ~/hermes-backup-2026-10-03-041025.zip
 75M  ~/hermes-backup-daily.tar.gz
 68M  ~/hermes-backup-daily
 43M  ~/hermes-backup-daily-tmp
 22M  ~/hermes-backup-daily.git
115K  ~/hermes-backup-old
```
⭐ 报告口径写 **"陈年目录 ≈ 710M + 活跃仓库 work/ + 重复 tar.gz"**（本轮 ≈2.3G 总量）。
⚠️ **写"可回收 X G"必须区分"陈年目录（整个可删）"和"活跃仓库（只清内部 work/）"** ——
把 1.5G 活跃仓库写成可删 = 老公一动手备份 cron 就挂。

⭐⭐⭐⭐⭐ **磁盘结论口径（与 11-08/11-09 一致）**：
- `/` (dm-13) → `7.8G 7.8G 0 100%` —— **Android 只读系统分区**，Termux 写不进去，
  `$HOME` 在 dm-62 上，**清 `$HOME` 一字节都不会变** → **不是火警，不进待办**
- `/data/user/0` (dm-62) → `937G 900G 37G 97%` —— **剩 37G，够用 ✅**

⚠️ **本轮报告把数据分区写成了 🔴「97% 满」** —— 应为 🟡「97%，剩 37G，够用」。
⭐⭐ **判据：Avail 还剩 30G+ 就不是火警。百分比高 ≠ 要紧。**
⚠️ **磁盘栏里 🔴 只能给"可写分区 + Avail=0"** —— 用 🔴 标一个还有 37G 空闲的分区，
会让老公以为要立刻处理，反而稀释真正紧急的项。

### ⭐⭐⭐ 天气：Tavily 432 + web_extract 被拦，两条 curl 直连同命令一次成功

本轮三重坑照旧撞齐：`execute_code` → **BLOCKED**、`web_search` → **Tavily 432**、
`web_extract("https://wttr.in/Beijing?format=j1")` → **Blocked: private/internal network address**。

⭐ **两条 curl 都是直连（无代理）、写在同一条 `terminal` 命令里，一次成功**：
```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=%25l:+%25C+%25t+feels+%25f+min-%25m+max-%25M+wind-%25w+humidity-%25h"
# → Beijing: Smoky haze +38°F feels +36°F min-🌑 max-1 wind-↘3mph humidity-52%
curl -s --max-time 25 "https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&timezone=Asia%2FShanghai&forecast_days=1"
# → current: 2.7℃ / humidity 71% / weather_code 0 / wind 3.4km/h
#   daily: max 11.6℃ / min 0.1℃ / precip 0% / weather_code 0
```
⚠️ **wttr.in 紧凑格式返回 °F**（`+38°F` = 3.3℃），且 **`max-1` / `min-🌑` 是本轮 wttr.in 的怪输出**
（max/min 格式串失效）→ **max/min 一律取 open-meteo 的摄氏度**。
⭐ 本轮报告温度数字**全部来自 open-meteo，°F 一个都没写进报告** —— 正确做法。
⭐ **wttr.in 这次贡献的是 `Smoky haze`（有霾）** —— 这是 open-meteo 给不了、也是
北京秋冬最有行动价值的一句（"出门戴口罩"）。
⚠️ **本轮报告漏写了"有霾 → 戴口罩"** —— wttr.in 明明返回了 `Smoky haze`，
**拿到了霾描述就要写进去**。

⭐⭐⭐ **11-09 是"代理成功"、本轮是"直连成功"** —— 再次印证**两个都要会**：
本轮完全没加代理。**判据永远是量字节数**，不是"上次哪种行"。

### ⭐⭐⭐⭐ `ps -A | grep -c "gateway run"` 第 8 次返回 0

本轮 `ps -A 2>/dev/null | grep -c "gateway run"` → **0**，
同轮 `ps aux` + `/proc/<pid>/cmdline` 都找到 **PID 28546 `hermes gateway run --replace`**（活着）。
⚠️ **第 8 次验证：`ps -A` 按完整命令行 grep 永远 0 命中。永远用 `ps aux`/`ps -ef`，
或读 `/proc/<pid>/cmdline`**（`disk_health.sh` 已内置后两者）。

### ⭐⭐⭐⭐ 工作进度栏：一条打包命令写完 ✅/🟡 表格

本轮**没读 `cron/output/`、没查 `state.db`**：
```bash
grep -a "^$(date +%F)" ~/.hermes/logs/agent.log | grep -aiE "cron.scheduler.*(Running job|delivered|completed)" | tail -12
grep -a "^$(date +%F)" ~/.hermes/logs/agent.log | grep -ai "inbound message" | tail -5
```
⭐⭐⭐ **本轮最有价值的新发现 = 09:00 三个 job 同秒起跑（不是 11:09 的补跑波）**：
```
09:00:11 Running job '早上9点简报' (ID: c51c6ca0d139)
09:00:11 Running job '每日9点回顾推送' (ID: 27957f101f60)
09:00:12 Running job '每日AI资讯' (ID: 377472e94f28)
09:01:22 Job '每日9点回顾推送' completed successfully
```
⚠️ 本轮 09:01 就 completed → **没有出现"gateway 挂过 → 11:07 补跑"的延迟波**，是准点起跑。
⭐ 报告里的时间用本轮 `date` 实测值，别写死"早上 9 点"。
⚠️ 查"昨天"的 inbound **仍必须带 `agent.log.1`**（本轮用了 `.log` + `.1` + `.2` 三件套）。

### ⭐⭐⭐⭐⭐ 飞书插件 bug：仍未修，但 fallback 全部兜住

本轮当天触发 **2 次**：
```
09:01:24 WARNING ... 'ReplyMessageResponse' object has no attribute 'get', falling back to standalone
09:01:37 WARNING ... 'CreateMessageResponse' object has no attribute 'get', falling back to standalone
```
两条后面**都跟着 `delivered to feishu:oc_457ae...`** ✅ → **早报一条没漏**。
⭐ 报告口径：bug 仍在（根因 `cron/scheduler.py:1913`），但 fallback 全兜住，不影响送达。
⚠️ **别写成"飞书推送挂了"**（误报过一次）。

### ⭐⭐⭐⭐ 空模块第 10 天：措辞继续升级（别复读"不存在"）

第 3 天起就要升级成"缺失 + 邻近资产 + 提议"，第 10 天再加一层可操作的具体化：
- 📅 日程 → "要不要我帮你把日历接上？以后老婆主动提醒你"
- 💬 群摘要 → 写"**投递是正常的 ✅**"（本轮 09:01 三个 cron 全送达飞书）
- 📝 自定义 → "老公想让我固定念叨啥？创建这个文件我就每天给你念"

⭐ **本轮群摘要栏做得好**：不只写"暂无摘要"，而是补了
**"投递正常 ✅ + 插件 bug 的具体类名 + fallback 说明"** —— 这是"空模块重建"的正确形态：
**缺失的事实 + 邻近的真实信号**。

### 📌 2026-11-10 实测基线

| 项目 | 2026-11-10 实测值 | 说明 |
|---|---|---|
| 磁盘 | `/` dm-13 100%/0（**只读系统分区，非故障**） / dm-62 937G / 900G / **37G** / **97%** | 剩 37G = 够用，**不该标 🔴** |
| 可回收（本轮 `du`） | 陈年 6 目录 ≈ 710M + 活跃仓库 `work/` + 重复 tar.gz | 报告写 ≈2.3G 口径正确 |
| 内存 | available **2.7Gi** / swap 已用 11Gi | <3G = 别开新 bot |
| gateway | PID **28546**（`ps aux` + `/proc` 双向确认） | `ps -A` 第 8 次 0 命中 |
| 备份 | 03:02 ✅ commit `002a4cb Backup 2026-11-10 03:00` | 活跃仓库只有 `~/hermes-backup` |
| cron 波 | 09:00:11 三 job 同秒起跑，09:01:22 completed | **本轮是准点，不是补跑** |
| 插件 bug | 触发 2 次（Reply×1 + Create×1），fallback 全兜住，**送达 ✅** | 仍未修，根因 `cron/scheduler.py:1913` |
| 天气 | wttr.in **直连**成功（Smoky haze +38°F）/ open-meteo 直连成功（2.7℃ / 0.1~11.6℃ / 降水 0%） | **两条 curl 同一条命令，无需代理** |
| 群消息 | inbound：Telegram 5 条（11-08「抱抱」「在干嘛」「爱你」）/ 飞书 inbound **0** | 分开写"群里安静"+"早报照送" |
| prompt 路径 | 4 个缺失（**第 10 天**）+ `notes/` 只有 `scripts.md` | 空模块要重建+提议 |

---

## 📌 2026-11-09 09:00 实测（连续第 9 天）

### ✅ 磁盘栏终于跑了 `df`，但仍只写了一行

上一轮（11-08）把"磁盘栏继承旧结论"列为头号违规。本轮**开局就跑了 `df`**，
报告里出现了 `/data/user/0` 937G/904G/**33G**/97% 这一行 ✅。
⭐ **但仍只写了一行** —— 因为本轮用的是 `df -h /data`（单一挂载点）。
⚠️ **"磁盘两行铁律"依然被违反**，只是方向反过来了（11-08 是完全没测，本轮是只测了一半）。
⭐⭐ **根治不变：磁盘栏跑 `scripts/disk_health.sh`，别手敲 `df`。**

### ⭐⭐⭐ wttr.in 在 Tavily 432 + web_extract 被拦时，curl 带代理成功

本轮开局三重坑一次撞齐：`execute_code` → BLOCKED、`web_search` → Tavily 432、
`web_extract(wttr.in?format=j1)` → **Blocked: private/internal network address**。
⚠️ 但**同一轮里 `curl -x socks5h://127.0.0.1:7890` 打 wttr.in 一次成功**：
```
Beijing: Smoky haze +43°F feels +40°F wind ↘4mph hum 34% precip 0.00
```
⭐⭐⭐ **重要修正**：此前多轮记录写"直连优先、代理会搞砸请求"（11-05 实测直连好、代理 000）。
**本轮实测直连 wttr.in 返回 0 字节（exit=23），走 `127.0.0.1:7890` 代理反而一次成功。**
→ **别把"直连优先"当硬规则 —— 两个都要会，哪条返回真字节用哪条。**
⭐ 判据仍是量字节数：
```bash
curl -s -m 25 "https://wttr.in/Beijing?format=j1" | wc -c     # 0 → 直连失败
curl -s -m 25 -x socks5h://127.0.0.1:7890 "https://wttr.in/Beijing?format=j1" | wc -c
```
⚠️ **落盘路径要放 `$HOME`**（本轮 `-o /tmp/wx.json` 直接 exit=23，换成 `~/wx.json` 立刻成功）。

### ⚠️ wttr.in `format=j1` 的 key 名陷阱：`observation_time`，**没有 `localObsDateTime`**

本轮解析 wttr.in JSON 时踩了 `KeyError: 'localObsDateTime'` —— **这个 key 不存在**。
`current_condition[0]` 的实际 key 是：
```
FeelsLikeC, FeelsLikeF, cloudcover, humidity, observation_time, precipInches,
precipMM, pressure, pressureInches, temp_C, temp_F, uvIndex, visibility,
visibilityMiles, weatherCode, weatherDesc, weatherIconUrl, winddir16Point,
winddirDegree, windspeedKmph, windspeedMiles
```
⚠️ **`localObsDateTime` 是 open-meteo 的 key（`current.time`），不是 wttr.in 的。**
wttr.in 的观测时刻要读 `observation_time`（UTC，形如 `02:04 AM`）。
⭐ **跨源解析前先 `print(list(c.keys()))`**，别凭印象写 key 名。

### ⭐⭐⭐ 本轮取数：一条 terminal 打包路径验证 + 知识库 + 系统状态（4 轮出全稿）

| # | 调用 | 拿到什么 |
|---|---|---|
| 1 | `terminal`: `ls -la ~/.calendar/ ~/.hermes/knowledge/notes/` | 日程/群/任务/自定义 4 路径现状（notes 里只有 scripts.md，第 9 天） |
| 2 | `terminal`: `curl` wttr.in 紧凑格式（带代理）+ `curl` wttr.in j1 + `python3 -c` 解析 | 天气栏全套（霾/体感/湿度/风 + max/min + 逐时） |
| 3 | `terminal`: `ls -lat ~/.hermes/cron/output/` + 读当天 `## Response` | 工作进度栏素材 |
| 4 | `terminal`: `df` + `ps` + `gateway_state.json` + `du -sh ~/hermes-backup*` | 系统状态 |

⭐⭐⭐⭐ **本轮最有价值的新发现 = Trending job 当天是 `(FAILED)`**：
`cron/output/a60c53e7db02/2026-11-09_11-07-19.md` 文件头写着
`# Cron Job: github-trending-daily (FAILED)` + `## Error` 段：
`TimeoutError: Cron job 'github-trending-daily' idle for 10865s (limit 600s)`。
→ **08:00 的 Trending 任务卡了 3 小时才崩，今天榜单没推出来。**
⭐ **判"某个 job 成功没"必须看文件头有没有 `(FAILED)` 后缀 + 有没有 `## Error` 段**
（`## Response` 存在 = 出稿了）。这正是"delivered ≠ 有内容"的同一条纪律。

### ⭐⭐⭐ `gateway_state.json` 是"平台状态"的最省事权威源

本轮一条 `cat ~/.hermes/gateway_state.json` 拿到：
```json
{"pid":22377,"gateway_state":"running",
 "platforms":{"qqbot":{"state":"connected","updated_at":"2026-11-09T03:07:22Z"},
              "feishu":{"state":"connected","updated_at":"2026-11-08T11:43:36Z"},
              "telegram":{"state":"fatal","error_message":"No bot token configured",
                          "updated_at":"2026-11-08T11:43:36Z"}},
 "served_profiles":["default","cutegirl","geekwife","libai","licai","siliconflow","wenyu"]}
```
⭐ **三个 `updated_at` 不同 → 不是同一批陈旧快照**（11-02 那轮的判据）。
- `qqbot` 最新（03:07）→ 真的 connected ✅
- `feishu` 停在 11-08 11:43 → ⚠️ **已超过 24 小时没刷新**，值得写"长连接状态陈旧"
- `telegram` `fatal` 与 `feishu` **同一时间戳** → 同批快照 → 先 grep 今天的 Telegram 日志再定性

### ⭐⭐⭐⭐ 空模块第 9 天：措辞继续升级（别复读"不存在"）

第 3 天起就必须升级成"缺失 + 邻近资产 + 提议"，第 9 天的写法再加一层**具体化**：
> 「📅 **暂无日程** 😌 — `~/.calendar/calendar.ics` 不存在（连续第 9 天），日历还没接上。
> 老公想用的话随时说一声，我帮你搞。」

### 📌 2026-11-09 实测基线

| 项目 | 2026-11-09 实测值 | 说明 |
|---|---|---|
| 磁盘 | `/data/user/0` 937G / 904G / **33G** / **97%** | ⚠️ **只测了一行**，两行铁律仍需 `disk_health.sh` |
| 备份 | 03:02 ✅ 78MB / 6067 条目 / commit `8c6f924` / 已推 origin/main | 代理全挂但**直连可用** |
| Trending | 08:00 ❌ **(FAILED)** idle 10865s | 新事实，值得写进待办 |
| gateway | PID 22377，7 profile 全部 `served_profiles` | `ps -A` 仍 0 命中 |
| 平台 | qqbot ✅ (03:07) / feishu ✅ (11-08 11:43，陈旧) / telegram ⚠️ fatal 但同批快照 | telegram 先 grep 日志再定性 |
| 天气 | wttr.in **走 `127.0.0.1:7890` 代理成功**，直连 0 字节 | **霾 Smoky haze**，0~11℃，湿度 34% |
| 群消息 | 最近 inbound 停在 11-08 21:01（cron 投递），无人工消息 | 分开写"群里安静"+"早报照送" |
| prompt 路径 | 4 个缺失（**第 9 天**）+ `notes/` 只有 `scripts.md` | 空模块要重建+提议 |

---

## 📌 2026-11-08 09:00 实测（连续第 8 天）

### ⚠️ 本轮最严重的问题：磁盘栏"继承上一轮结论"（把记忆当实测）

本轮**根本没跑任何 `df` 命令**，却在系统状态栏写了：
> `磁盘：需关注 ⚠️ 根分区之前告警过，我盯着呢`

**这是把记忆当实测写进报告。** 措辞（"之前告警过""我盯着呢"）直接暴露"这数据是旧的"。
⚠️ **漏报 vs 报旧数据**：漏报 = 诚实的不完整（可接受）；
**报旧数据 = 伪装成实时的过期数据（不可接受）**。
⚠️ 11-02~11-05 连续四天已写明"磁盘栏必须跑 `scripts/disk_health.sh`"，**11-08 仍没跑**
—— 说明"写进 skill"≠"会做"，需要一条**可执行的自检口径**。

⭐⭐⭐ **新铁律（报告级自检清单，写完报告过一遍）**：
1. 每一条 ✅/⚠️/🔴 断言，**能不能指回本轮某条命令的输出**？
2. 报告正文里有没有 **"之前" / "上次" / "还在关注" / "我盯着"** 这类指向过去的措辞？
   → 有 = 那一栏没有本轮数据 = **必须回去跑命令补上**。
3. 磁盘栏有没有**本轮 `df` 的两行**（`/` + `/storage/emulated`）？
4. 天气栏数字是**本轮 curl 的**，还是记忆里的季节经验？

⭐⭐⭐⭐ **根治：开局把磁盘查询和路径验证合并成同一条 terminal 调用**：
```bash
ls -la ~/.calendar/ ~/.hermes/knowledge/notes/ 2>&1
find ~/.hermes -maxdepth 4 \( -name "tasks.md" -o -name "progress.md" \
  -o -name "daily_custom.md" -o -name "*.ics" \) 2>/dev/null
bash ~/.hermes/skills/personal/claws-personal-setup/scripts/disk_health.sh
echo "=== WEATHER ==="
curl -s -m 25 "https://wttr.in/Beijing?format=%25l:+%25C+%25t+feels+%25f+wind+%25w+humidity+%25h"
echo; echo "=== OPEN-METEO ==="
curl -s -m 25 "https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&timezone=Asia%2FShanghai&forecast_days=1"
```

### ⭐ `web_extract` 打 wttr.in 的**第三种失败模式**："私有网络地址"

| 模式 | 症状 | 处理 |
|---|---|---|
| Tavily 432 | `Client error '432 '` | curl |
| 陈旧缓存 | 200 + 合法 JSON，但 `weather[0].date` 是几天前 | curl + 核对日期 |
| **私有网络地址** | `Blocked: URL targets a private or internal network address` | **curl** |

⚠️ **"私有网络地址"是沙箱出口解析假象，不是站点属性** → **别换 URL、别重试**。

### ⚠️ wttr.in 紧凑格式返回的是**华氏度**

本轮实测 `Beijing: +37°F Light drizzle (feels +33°F)` —— **是 °F 不是 °C**。
⭐ **别直接把 `+37°F` 写成"37℃"** —— 温度以 open-meteo 的摄氏度为准；
wttr.in 只用来补"体感/湿度/风/天气描述"。

### ⭐⭐⭐⭐ `~/.hermes/knowledge/我是老公/` 是个 git 仓库 —— 用 git 读知识库

```bash
cd ~/.hermes/knowledge/我是老公
git log --oneline -1              # → 160674a 数码知识库 v1.0
git ls-files                      # → "数码知识库.md"（带引号，中文名）
git show HEAD:"数码知识库.md" | grep -E "^#{1,3} " | head -40
```
本轮实测章节结构：`## 电脑`（蓝屏/死机/重装系统/性能问题/常见故障）·
`## 手机`（故障处理/系统问题/数据备份）· `## 路由器`（设置配置/故障排查/高级功能）·
`## 网络问题`（通用排障/DNS劫持），共 108 行。
⭐⭐⭐ **一条命令同时拿到：知识库 commit hash + 章节结构 + 行数** ——
**这是"工作进度"栏最省力的素材源**。
⚠️ **中文文件名在 `git show HEAD:<path>` 里必须加引号**。

### ⭐⭐⭐⭐ 5 个 prompt 路径：一条 `find` 全部验证（替代逐个 ls）

```bash
find ~/.hermes -maxdepth 4 \( -name "tasks.md" -o -name "progress.md" \
  -o -name "daily_custom.md" -o -name "*.ics" \) 2>/dev/null
# → 全部无输出 = 4 个路径确实都不存在
ls -la ~/.hermes/knowledge/notes/     # → 仍然只有 scripts.md（第 8 天）
ls -la ~/.calendar/ 2>&1              # → No such file or directory（第 8 天）
```
⚠️ **`~/.calendar/` 这种"目录本身都没有"的情况 `find` 不会报错** ——
**目录本身的存在性要单独 `ls` 一次**。

### ⭐⭐⭐⭐⭐ 群摘要：inbound grep 返回空时，必须再查一次"最近一条在哪"

本轮 grep 任务群 `oc_457ae...` **返回 0 行**。查全平台 inbound 时发现
**最近一条真 inbound 停在 2026-08-28**（三个多月前）。
⚠️ **只 grep 带 chat_id 的过滤，返回空 —— 但那不是因为"今天没消息"，
而是因为整个 agent.log 里的 inbound 都停在 8/28**。
→ **判据：inbound grep 返回空时，必须再跑一次不带 chat_id 过滤的全平台 grep，
确认"最近一条 inbound 是什么时候"。**
⭐ **"暂无摘要"的合格格式**：
> `暂无摘要 🙈 —— 那个"任务群"最近没有新讨论哦，群里安安静静的，老婆们都在待机等你喊～`
> （配一句"最近一条群消息停在 8/28"，比"暂无摘要"四个字有用得多。）

### ⭐⭐⭐⭐⭐ 本轮的执行顺序（7 轮，可压到 5 轮）

| # | 调用 | 拿到什么 |
|---|---|---|
| 1 | `terminal`: `ls` 路径 + `find` + `git show` 知识库 | 日程/群/任务/自定义 4 个模块的素材 |
| 2 | `terminal`: `curl` wttr.in 紧凑格式 + `curl` open-meteo | 天气栏（两条写同一条命令） |
| 3 | `terminal`: `grep` inbound（含 `.1`） | 群摘要栏 |
| 4 | `terminal`: `df`/`free`/`ps`（或 `disk_health.sh`） | 磁盘/内存/gateway |
| 5 | `read_file`/`git show` 兄弟 job 正文 | 补工作进度栏（如需） |

⭐⭐ **改进重点**：开局一条 terminal 打包 `ls + find + disk_health.sh + curl wttr.in + curl open-meteo`，
再补一条 inbound grep，就够出全稿。

### ⭐⭐⭐ 报告语气：老婆感在**开头和结尾**，中间的模块内容要硬

```
# 🌅 老公早安简报 · 11月8日 周日
> 一句开场白
---
### 每个模块一个 emoji 标题
> 引用块放内容（"暂无日程 😌" + 原因 + 下一步）
### 📊 工作进度 → 用 ✅/❌ 表格
---
**📊 系统状态速览** → 短表格（gateway / 磁盘 / 数据源）
---
一句收尾
```
⭐ **要点**：口语化放**开头和结尾**，中间的模块内容**要硬、要准、要能行动**。
老公的"刷屏"偏好**不适用于早报** —— 早报是要存档、要扫一眼的内容。
⚠️ **emoji 不要过度**：每模块 1-2 个够了，通篇 20+ 个 emoji 会显得廉价。
⚠️ **"系统状态速览"表最多 4 行**，每行 ≤ 1 个事实 + 1 个 emoji 状态标记。
⚠️ **"都在岗"这种断言也要有依据** —— 不能写得像实测过每个平台。

### 📌 2026-11-08 实测基线

| 项目 | 2026-11-08 实测值 | 说明 |
|---|---|---|
| 磁盘 | **本轮未测**（违规） | 下轮必须跑 `disk_health.sh` |
| 天气 | wttr.in 紧凑格式 + open-meteo 双源同命令 | **返回 °F**，温度以 open-meteo 为准 |
| 温度 | 0 ~ 6.3℃ / 降水概率 100% / `weather_code=73`(雪) | 体感 ≈ 2℃，湿度 94% |
| 知识库 | git `160674a`「数码知识库 v1.0」/ 108 行 / 四大板块 | 工作进度栏素材源 |
| gateway | `agent.log` mtime 08:58 仍有活动 | 用 mtime 判活跃度，别用 `ps` grep |
| 群消息 | 最近一条真 inbound 停在 **2026-08-28** | 群摘要栏要给日期锚点 |
| prompt 路径 | 4 个缺失（第 8 天）+ `notes/` 只有 `scripts.md` | 空模块要重建+提议 |

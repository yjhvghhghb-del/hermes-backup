# 每日晚间总结 — Cron Job 模板（20:00）

早报见 `references/daily-morning-report.md`。晚间总结的数据源完全不同
（没有日历、核心是 cron 产出 + 平台日志 + session 历史），单独成篇。

## ⚠️ 先看这条：cron 模式下 `execute_code` 被拦截

同早报。晚间总结里所有取数都走 `terminal()` / `read_file` / `session_search` /
`search_files`，不要试 `execute_code`，直接浪费一轮调用。

## ⚠️ 核心坑：`tasks.md` / `progress.md` 根本不存在

老公的 `~/.hermes/knowledge/notes/` 里**只有 `scripts.md` 一个文件**。
`tasks.md`、`progress.md`、`daily_custom.md`、`.ics` 日历文件全都没有。

早报模板里"读 tasks.md 拿今日完成/明日待办"的那套**在老公环境里是空的**。
晚间总结必须**从别处重建事实**，否则只能编。

**正确顺序：先查 cron 产出 → 再查平台日志 → 再查 session 历史。**
这三层加起来信息量足够撑起一份有真实内容的晚间总结。

## 数据获取顺序（按可靠性）

### 1. 今日 cron 任务产出 —— 最值钱的一手材料

```bash
# 每个 job 的最新输出文件（内容在 "## Response" 之后）
for j in a60c53e7db02 377472e94c28 c51c6ca0d139 cd38d14f5563 \
         27957f101f60 4346b6b5808d f5d67b085944 eb9b2a0e46d8; do
  f=$(ls -t ~/.hermes/cron/output/$j/* 2>/dev/null | head -1)
  echo "=== $j : $(basename $f 2>/dev/null)"
  sed -n '/## Response/,$p' "$f" 2>/dev/null | head -20
done
```

目录结构：`~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md`
- `eb9b2a0e46d8` = 每日备份（tar 大小 / commit / push 结果）
- `377472e94c28` = 每日AI资讯
- `a60c53e7db02` = GitHub Trending
- `cd38d14f5563` / `27957f101f60` / `c51c6ca0d139` = 早报三连
- `4346b6b5808d` = 晚间总结（自己）
- `f5d67b085944` = 每日晚9点回顾推送

### 2. cron 执行历史 —— 判断"今天哪些跑了/挂了"

```bash
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('executions.db')
for r in c.execute('SELECT job_id, started_at, status FROM executions ORDER BY started_at DESC LIMIT 25'):
    print(r)
"
```
status 有 `completed` / `running` / `failed`。当前正在跑的那个是 `running`。

### 3. 明日待办的真正来源 —— jobs.json 的 schedule

```bash
cd ~/.hermes/cron && python3 -c "
import json
d=json.load(open('jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
if isinstance(jobs,dict): jobs=list(jobs.values())
for j in jobs:
    print(j.get('name'),'|',j.get('schedule'),'|enabled=',j.get('enabled'),'|id=',j.get('id'))
"
```
`schedule.display` 就是 cron 表达式（`0 9 * * *` 等）。用当前时刻 + 24h 就能推出
明天几点有哪些任务会跑 —— 这就是"明日待办预览"最硬的依据。

### 4. 平台健康 + 今日故障 —— 晚间总结最有价值的"新闻"

```bash
# gateway 各平台实时状态
cat ~/.hermes/gateway_state.json

# 今日飞书长连接断了几次（关键指标）
grep -a "2026-10-24" ~/.hermes/logs/agent.log | grep -aiE "Lark.*(disconnect|receive message loop exit|connect failed)" | wc -l

# 今日 cron 投递成败
grep -a "2026-10-24" ~/.hermes/logs/agent.log | grep -aiE "cron.scheduler.*(delivery|delivered)" | tail -20

# 今日 Telegram 收消息 + 断线
grep -a "2026-10-24" ~/.hermes/logs/gateway.log | grep -aiE "inbound message" | tail -20
grep -a "2026-10-24" ~/.hermes/logs/gateway.log | grep -aiE "Telegram.*(network error|degraded)" | tail -10

# 今日错误汇总
grep -a "2026-10-24" ~/.hermes/logs/errors.log | tail -12 | cut -c1-200
```

日志在 `~/.hermes/logs/`：`agent.log`（插件/平台层）、`gateway.log`（主循环/收消息）、
`errors.log`（错误）。**旧的 `~/.hermes/gateway.log`（根目录那个）已经 10/16 就不更新了，
别去 grep 它** —— 看 `~/.hermes/logs/gateway.log`。

### 5. 飞书群 ID ↔ 群名映射

`~/.hermes/channel_directory.json` 里有全部 `oc_xxx` 和群名。老公的群叫
「**淫骚毛逼老婆任务群**」（不是正经工作群，语气随便点）。

```bash
python3 -c "
import json,re
s=open('/data/data/com.termux/files/home/.hermes/channel_directory.json').read()
print(set(re.findall(r'[^\"]*淫[^\"]*', s)))
print(set(re.findall(r'oc_[a-f0-9]{32}', s)))
"
```

### 6. session 历史 —— 补"今天干了什么"的人味部分

```bash
session_search(limit=8, sort="newest")            # 今天的会话列表
session_search(query="备份 OR bot OR kanban")      # 按主题找
session_search(session_id="<id>")                  # 读整个会话
```

`session_search()` 不带参数（browse 模式）能直接列出**最近会话 + preview**，
这是快速知道"今天老公干了啥"的最快路径。

## 报告结构模板

```
# 🌙 晚间总结 · X月X日（周X）

## 📅 今日完成事项        ← 表格：时间 | 事项 | 结果
## 💬 飞书群消息亮点    ← 表格：项目 | 状态
## 📊 明日待办预览      ← 表格：时间 | 任务 | 备注 + 手动待办
## 🌙 今日一句话总结    ← 一两句，定调
```

四个模块对应老公 prompt 里的四点，顺序不要改。

## 语气要求

- 口语化、轻松、温馨，像老婆说"老公今天辛苦了"
- emoji 适度但不刷屏（老公嫌刷屏）
- 每节用表格，简洁工整 —— 老公要"老板看得懂"
- **结尾给一个抱抱**（`🤗💗` / "送上今天的抱抱"）
- 可以加一句天气/穿衣提醒（晚间降温时提醒带伞），这是"老婆感"的来源
- 手动待办结尾标一句"要不要老婆现在就动手？等老公发话 🫡"——
  符合老公"敏感操作先问一次"的习惯

## 已知坑

- **cron 里 `execute_code` 被拦截** → 用 `terminal()` 等普通工具
- **`tasks.md` / `progress.md` 不存在** → 数据源换成 cron 产出 + 日志 + session
- **`~/.hermes/gateway.log`（根目录）是 10/16 的旧文件**，实时日志在 `~/.hermes/logs/`
- **`gateway_state.json` 里 telegram 可能显示 `fatal/missing_credentials`**，
  但 `.env` 里 token 其实是有的（46 字符）—— **状态文件可能是旧的**，
  别照抄当结论，用 `grep "inbound message"` 交叉验证真实收发
  ```bash
  for p in default geekwife siliconflow cutegirl libai licai wenyu; do
    f=~/.hermes/profiles/$p/.env; [ "$p" = "default" ] && f=~/.hermes/.env
    T=$(grep -oP '(?<=^TELEGRAM_BOT_TOKEN=).*' "$f" 2>/dev/null | head -1 | tr -d '\r"')
    echo "$p: ${#T}"
  done
  ```
- **`knowledge/notes/` 只有 `scripts.md`**，`knowledge/facts/` 有 user.md / system.md / stickers.md，
  `knowledge/我是老公/` 是 git 仓库（数码知识库.md）
- **飞书 cron 投递错误码 `[99992402] field validation failed`** 是已存在的老问题：
  有的 job 走 live adapter 成功，有的 fallback 到 standalone 也失败。
  晚间总结里如实报出来，并放进"明日待办"提醒修
- **飞书长连接一天掉 7 次是常态**（Lark keepalive ping timeout / SSL EOF），
  统计断线次数作为"群消息亮点"栏的现状指标
- **Kanban 仍是 9119 端口 HTTPS + 要认证** → 拿不到就别编看板内容
- **Google 日历未配置** → 晚间总结本来也不需要日历
- `sqlite3` 命令在 Termux 可能没有，用 `python3 -c "import sqlite3; ..."`
- **`grep -a`** 处理含二进制字符的日志，避免 "binary file matches"

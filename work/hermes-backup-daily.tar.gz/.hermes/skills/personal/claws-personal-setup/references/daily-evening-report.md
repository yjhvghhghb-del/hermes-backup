# 每日晚间总结 — Cron Job 模板（20:00）

早报见 `references/daily-morning-report.md`。晚间总结的数据源完全不同
（没有日历、核心是 cron 产出 + 平台日志 + session 历史），单独成篇。

## ⚠️ 先看这条：cron 模式下 `execute_code` 被拦截

同早报。晚间总结里所有取数都走 `terminal()` / `read_file` / `session_search` /
`search_files`，不要试 `execute_code`，直接浪费一轮调用。

## ⚠️ 核心坑：`tasks.md` / `progress.md` 根本不存在

老公的 `~/.hermes/knowledge/notes/` 里**只有 `scripts.md` 一个文件**。
`tasks.md`、`progress.md`、`daily_custom.md`、`.ics` 日历文件全都没有。

早报模板里"读 tasks.md 拿今日完成/明日待办"的那套**在老公环境里是空的**。
晚间总结必须**从别处重建事实**，否则只能编。

**正确顺序：先查 cron 产出 → 再查平台日志 → 再查 session 历史。**
这三层加起来信息量足够撑起一份有真实内容的晚间总结。

## 数据获取顺序（按可靠性）

### 1. 今日 cron 任务产出 —— 最值钱的一手材料

#### ⭐⭐ 首选：`~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md`（2026-10-30 实测最省事）

**这是最快的路径 —— 一条命令就能拿到某 job 的完整报告正文，不用碰数据库。**

文件结构固定：前面是 `## Prompt`（原始 prompt + 注入的 skill 内容），
`## Response` 之后就是**最终报告正文**。用 sed 切出来即可：

```bash
cd ~/.hermes/cron/output
for j in 27957f101f60 377472e94c28 cd38d14f5563 c51c6ca0d139 \
         a60c53e7db02 eb9b2a0e46d8 f5d67b085944; do
  f=$(ls -t ~/.hermes/cron/output/$j/* 2>/dev/null | head -1)
  echo "########## $j : $(basename $f 2>/dev/null)"
  sed -n '/## Response/,$p' "$f" 2>/dev/null | head -60
done
```

只读**今天**的文件（不要读昨天的，早报已经讲过）：
```bash
find ~/.hermes/cron/output/ -newermt "2026-10-30" -type f | head -30
```

⭐⭐ **更好的写法：用「日期 + 00:00」做时间边界，一次扫出今天全部 job 的产出**
（2026-10-31 实测，1 轮拿到全部 6 个产出文件）：

```bash
find ~/.hermes/cron/output/ -type f -newermt "$(date +%F) 00:00" | sort
```

- **必须带 `00:00`**：只写 `-newermt "2026-10-31"` 会被解析成当天 00:00 之外的语义边界，
  跨天判断不稳；显式写 `"$(date +%F) 00:00"` 最稳，也不用手改日期（明天直接复用）。
- **不需要硬编码 job_id 列表** —— 下面那段 per-job_id 循环要维护 7 个 ID，
  而 `find` 直接扫目录，新增 job 不用改脚本。
- 命中后按需 `read_file` 或 `sed -n '/## Response/,$p'` 逐个切正文。
- 2026-10-31 实测命中 6 个：`eb9b2a0e46d8`(03:02 备份) / `a60c53e7db02`(08:25 Trending) /
  `27957f101f60`(09:01) / `c51c6ca0d139`(09:01) / `377472e94c28`(09:03) /
  `cd38d14f5563`(09:03) —— 一次读完全部早报正文，晚间总结的「今日完成事项」
  和「一句话总结」素材直接现成。

⚠️ **修正旧结论**：2026-10-29 实测这个目录是空的，所以当时把 `state.db` 写成了"首选"。
**2026-10-30 复测：该目录有 6 个产出文件，全部正常**。结论改为 ——
**先 `ls`/`find` 试 `cron/output/`，有就直接用（1 轮出全量正文）；
只有确实空了才退回 `state.db`。** 不要因为旧文档就跳过这一步。

⚠️ 文件名里的时间是**任务启动时分秒**（`2026-10-30_09-01-31.md`），
不是结束时间。读的时候用 `ls -t` 取最新，别自己拼日期。

#### 备选：`~/.hermes/state.db` 的 `messages` 表（2026-10-29 实测可用）

cron 的最终报告正文都在这里 —— 比日志全（日志只有平台层事件，没有结论正文）。
⚠️ 但**它现在是备选不是首选**：`cron/output/` 目录通常有产出且读取更直接（见上），
只有该目录为空时才走这条。

**⚠️ `messages.timestamp` 是 Unix float，不是日期字符串。**
`where timestamp like '2026-10-29%'` 返回 **0 行**，白白浪费两轮调用。
用数值比较：`where timestamp > <当天00:00的epoch>`。

```python
import sqlite3, datetime
c = sqlite3.connect('/data/data/com.termux/files/home/.hermes/state.db')
c.row_factory = sqlite3.Row
day = int(datetime.datetime(2026,10,29).timestamp())

# 列出当天所有 session（分清 cron 和用户交互会话）
for r in c.execute('select session_id, count(*) n from messages '
                    'where session_id like "cron_%_2026%" group by session_id'):
    print(r['session_id'], r['n'])

# 取某个 cron job 的最终报告正文
sid = 'cron_377472e94c28_20261029_192221'
for r in c.execute('select substr(content,1,1600) cc from messages '
                    'where session_id=? and role="assistant" and content is not null '
                    'and length(content)>150 order by id desc limit 1', (sid,)):
    print(r['cc'])
```

**cron session_id 格式 = `cron_<jobid>_<YYYYMMDD>_<HHMMSS>`**，
时间戳那段运行时生成，拼不出来 —— 先 `group by session_id` 把当天的捞出来。

**完整取数脚本 + job_id 对照表 + 「取老公今天说了啥」的过滤方法
→ 见 `references/hermes-session-db-mining.md`**

拿到 session_id 后再用 `session_search(session_id="<id>")` 读全文最省事。

#### 备用：`~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md`

见上（已是首选）。若某天该目录确实为空，再退回 `state.db`。

job_id 用途对照：
- `eb9b2a0e46d8` = 每日备份（tar 大小 / commit / push 结果）
- `377472e94c28` = 每日AI资讯
- `a60c53e7db02` = GitHub Trending
- `cd38d14f5563` / `27957f101f60` / `c51c6ca0d139` = 早报三连
- `4346b6b5808d` = 晚间总结（自己）
- `f5d67b085944` = 每日晚9点回顾推送

### 2. cron 执行历史 —— 判断"今天哪些跑了/挂了"

```bash
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('executions.db')
for r in c.execute('SELECT job_id, started_at, status, error FROM executions ORDER BY started_at DESC LIMIT 25'):
    print(r[0], r[1][:19], r[2], (r[3] or '')[:80])
"
```

⚠️ **`status` 只有 `completed` / `running` / `unknown` 三种，**没有 `failed`**
（2026-10-30 复测确认，2026-10-31 再次确认）。`unknown` = 调度器重启时执行没到终态。
→ **`status=completed` 也可能带着投递失败**，真正的失败原因只在 `agent.log` 里，
务必配合下面第 4 节的 `cron.scheduler` grep 一起看。

⭐ **schema 只有一张表 `executions`**（2026-10-31 实测）。不确定列名时先 `PRAGMA table_info`，
别硬猜：

```bash
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('executions.db')
print([r[0] for r in c.execute(\"select name from sqlite_master where type='table'\")])
print([r[1] for r in c.execute('PRAGMA table_info(executions)')])
"
```

实测列：`id, job_id, source, process_id, pid, process_started_at, status,
claimed_at, started_at, finished_at, error`。

⭐ **想一眼看「今天跑了什么」**：把 `started_at` 按天过滤 + 按时间排序，
比逐条读 output 文件快：

```bash
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('file:executions.db?mode=ro', uri=True)
cols=[r[1] for r in c.execute('PRAGMA table_info(executions)')]
for row in c.execute('select '+','.join(cols)+' from executions order by rowid desc limit 12'):
    print(str(row)[:200])
"
```

`rowid desc` = 最新在前。2026-10-31 实测输出里，最上面那条就是**当前正在跑的晚间总结自己**
（`status=running`），下面依次是当天 03:02 备份、08:25 Trending、09:01/09:03 四个早报，
再往下是昨天和前天的记录 —— 一屏看完今天的时间线。

**2026-10-30 实测用法**：拿 `executions.db` 判断"今天哪些 job 跑了"，
配合 `cron/output/` 读正文，一条时间线就出来了：
```
03:00 eb9b2a0e46d8  completed   ← 每日备份
08:00 a60c53e7db02  completed   ← GitHub Trending
09:00 四个 job 同时 completed     ← AI资讯/早上回顾/9点简报/9点回顾推送
20:00 4346b6b5808d  running     ← 晚间总结（自己）
```

### 3. 明日待办的真正来源 —— jobs.json 的 schedule

```bash
cd ~/.hermes/cron && python3 -c "
import json
d=json.load(open('jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
if isinstance(jobs,dict): jobs=list(jobs.values())
for j in jobs:
    print(j.get('name'),'|',j.get('schedule'),'|enabled=',j.get('enabled'),'|id=',j.get('id'))
"
```
`schedule.display` 就是 cron 表达式（`0 9 * * *` 等）。用当前时刻 + 24h 就能推出
明天几点有哪些任务会跑 —— 这就是"明日待办预览"最硬的依据。

#### ⭐ 同文件里的健康字段 = "还没修好的事"（2026-10-30 实测）

`schedule` 告诉你**明天**会跑什么；同一个 `jobs.json` 里的
`last_status` / `last_error` / `last_delivery_error` 告诉你**现在什么坏了**。
晚间总结的"明日待办"两样都要 —— 前者是预告，后者是欠账。

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
for j in d['jobs']:
    print(f\"{j['name']:20s} | enabled={j.get('enabled')} | last={str(j.get('last_run_at'))[:16]} | status={j.get('last_status')} | err={(j.get('last_error') or '')[:60]} | deliver_err={(j.get('last_delivery_error') or '')[:60]}\")
"
```

⚠️ **2026-10-30 晚间复测：这些健康字段打印出来全是空字符串**
（`last_run` / `next_run` 全空）。**别卡在这一步反复试** ——
直接走第 4 节的日志兜底链（grep `agent.log` 的 `cron.scheduler` + `executions.db`），
那条链实测能挖出真故障。

⚠️ 另外 `jobs.json` 的**结构本身**也有两种形态，用 `d['jobs']` 直取可能 KeyError。
用兼容写法：

```python
import json
d = json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
jobs = d if isinstance(d, list) else d.get('jobs', d)
if isinstance(jobs, dict): jobs = list(jobs.values())
for j in jobs:
    print(j.get('id'), j.get('name'), (j.get('schedule') or {}).get('display'), j.get('enabled'))
```

⚠️ **两条判断原则**：
1. `last_status=ok` ≠ 一切正常 → 一定要同时看 `last_delivery_error`
   （实测"每日早上回顾"和"早上9点简报"都是 `ok` 但飞书投递失败）
2. cron 报 `ok` ≠ 产物真的更新了 → 顺手 `ls -la` 一下产物 mtime
   （实测每日备份任务 `ok`，但 tar.gz 还停在 9月22）

完整字段说明见 `references/hermes-session-db-mining.md` 的「cron job 健康字段」一节。

### 4. 平台健康 + 今日故障 —— 晚间总结最有价值的"新闻"

```bash
# gateway 各平台实时状态
cat ~/.hermes/gateway_state.json

# 今日飞书长连接断了几次（关键指标）
grep -a "2026-10-24" ~/.hermes/logs/agent.log | grep -aiE "Lark.*(disconnect|receive message loop exit|connect failed)" | wc -l

# 今日 cron 投递成败
grep -a "2026-10-24" ~/.hermes/logs/agent.log | grep -aiE "cron.scheduler.*(delivery|delivered)" | tail -20

# 今日 Telegram 收消息 + 断线
grep -a "2026-10-24" ~/.hermes/logs/gateway.log | grep -aiE "inbound message" | tail -20
grep -a "2026-10-24" ~/.hermes/logs/gateway.log | grep -aiE "Telegram.*(network error|degraded)" | tail -10

# 今日错误汇总
grep -a "2026-10-24" ~/.hermes/logs/errors.log | tail -12 | cut -c1-200
```

#### ⭐⭐ 今日故障排行 —— 一条命令出「按频次排序的今日故障榜」

`tail -12` 只能看到最后 12 行，看不出**哪个错误才是今天的主要故障**。
把今天的错误行**去掉时间戳和地址后按模式聚类计数**，一张榜就出来了（2026-11-01 实测）：

```bash
grep -h "^2026-$(date +%m-%d)" ~/.hermes/logs/errors.log 2>/dev/null \
  | grep -io "ERROR.*" \
  | sed 's/0x[0-9a-f]*//g' | cut -c1-140 \
  | sort | uniq -c | sort -rn | head -12
```

2026-11-01 实测输出形态（一眼看清当天真正的大头是 Telegram 网络重试，不是别的）：
```
    143 Error:
    141 ERROR telegram.ext: Network Retry Loop (Bootstrap delete Webhook): Failed run number 0 of 0. Aborting.
     71 error: WebSocket closed
     60 error (attempt 1/10), reconnecting in 5s. Error: httpx.RemoteProtocolError: ...
     19 ERROR Lark: connect failed, err: HTTPSConnectionPool(host='open.feishu.cn', ...)
```

**为什么要这一步**：晚间总结的"今日完成事项"和"明日待办"需要区分
**真故障**和**自动恢复噪声**。这个排行直接告诉你当天哪个错误占主导 ——
比如上面 `Lark connect failed` 只有 19 次（噪声，会自愈），
而 Telegram `attempt N/10` 重连虽然刷屏但也是噪声，
**真正该进"明日待办"的是那些既高频又没自愈的**。

⚠️ **`sed 's/0x[0-9a-f]*//g'` 去掉内存地址** —— 否则同一个错误会因为地址不同
被拆成几十行，计数全变成 1，排行失效。

⚠️ **别把这条排行里的每一条都写进报告**。平台网络重连（Lark ping timeout /
Telegram attempt N/10）每天刷，是自动恢复噪声；只有 `attempt 9/10`、`10/10`
仍失败，或高频错误持续到当天结束，才算真断（见文末"已知坑"）。

#### ⚠️⚠️ `grep "inbound message"` 会命中**工具输出回显**，不是真的群消息

跨日志 grep 群消息时（`agent.log agent.log.1 .2 .3`），会捞到**别的 cron job
把自己 terminal 的输出抄进日志**的行，形如：

```
2026-11-01 09:02:14,097 WARNING [cron_c51c6ca0d139_20261101_090048] agent.tool_executor:
  Tool terminal returned error (12.19s): {"output": "=== last inbound feishu msgs (all logs) ===\n
  2026-10-23 16:06:45,872 INFO gateway.run: inbound message: platform=feishu user=... chat=oc_6138..."
```

这行的 `inbound message:` 是**被引号包起来的字符串**，它出现在
`WARNING ... agent.tool_executor` 后面、且属于某个 `[cron_<jobid>_<时间戳>]` session ——
**不是一条真的入站消息**。2026-11-01 实测踩到：按此统计"今日群消息"得到
`chat=oc_6138107aed3480fcb94`（10/23 的旧群），实际当天群里根本没消息。

**判定方法** —— 真的 inbound 行长这样：
```
2026-11-01 09:02:14,097 INFO gateway.run: inbound message: platform=feishu user=ou_xxx chat=oc_xxx
```
特征是 **`INFO gateway.run:`** 前缀 + **`platform=`** 字段。

```bash
# 只取真的入站消息：锚定 INFO gateway.run: + platform= 字段
grep -ah "inbound message" ~/.hermes/logs/agent.log ~/.hermes/logs/agent.log.1 2>/dev/null \
  | grep -a "INFO gateway.run:" | grep -a "platform=" \
  | grep -a "^$(date +%F)" | tail -30
```
2026-11-01 用这条跑出来的结果是 **0 条真实群消息**（当天群里确实安静），
这才是正确答案；不加 `INFO gateway.run:` 过滤就会得到一条假的 10/23 记录。

⭐ **`platform=feishu` 过滤比 `grep "feishu"` 安全**（已在早报模板记录，这里同样适用）：
用 `"feishu"` 会先命中满屏 `ERROR Lark:` 行把 inbound 冲掉。
并且飞书 inbound 里也可能混进 QQ/Telegram，用 `platform=` 精确挑。

日志在 `~/.hermes/logs/`：`agent.log`（插件/平台层）、`gateway.log`（主循环/收消息）、
`errors.log`（错误）。**旧的 `~/.hermes/gateway.log`（根目录那个）已经 10/16 就不更新了，
别去 grep 它** —— 看 `~/.hermes/logs/gateway.log`。

#### ⭐⭐⭐ 「飞书群消息亮点」当天真的没有消息时怎么办（2026-11-01 实测）

2026-11-01 群里**一整天没有真实入站消息**（按上面 `INFO gateway.run:` + `platform=`
过滤跑出来是 0 条）。这一栏**不能写"今日无群消息"就完事** —— 那是空栏，
等于这份总结少了一块内容。

**正确做法：用当天真实存在的平台事件重建这一栏**，而不是编造讨论内容。
2026-11-01 实际用的三样材料，全部来自真实日志：

1. **飞书长连接抖动次数**（当日 `Lark: receive message loop exit` 的次数与时间点）
   —— 这是真实发生的平台事件，可以说"下午抖了 N 次，每次几分钟后自动重连，消息没丢"
2. **多 profile 复连时间线**（`grep "feishu connected" ~/.hermes/logs/gateway.log`）
   —— 22:27 起 cutegirl / licai / wenyu 逐个 `✓ feishu connected`，
   这是"今天干了什么"的真实内容
3. **老公当天在飞书提的需求**（如果有）—— 从 `inbound message` 的正文取

**写法示例（2026-11-01 真实产出）**：
> 今天群里比较安静，但飞书长连接抖得厉害——下午 keepalive ping timeout 断了好几次，
> 每次都是几分钟后自动重连，消息没丢 😌
> 老公你发的消息我这边都收到了：**「修一下飞书」** → 已经动手了，晚上四个 profile 全部连上 ✅

⚠️ **绝不能编造"群里讨论了什么"**。这一栏允许的只有：
真实群消息正文 + 真实平台事件 + 真实连接状态。宁可写"今天群里安静，但长连接抖了 N 次"，
也不要虚构一个"大家讨论了 X"的段落 —— 老公第二天翻聊天记录会发现对不上。

⭐ **平台事件 = 群消息栏的兜底素材**。当 inbound 为空时，
`grep -a "^$(date +%F)" ~/.hermes/logs/gateway.log | grep -aiE "connected|receive message loop exit"`
一轮就能拿到当天的连接时间线和断线次数，够写一个诚实且有信息量的段落。

### 5. 飞书群 ID ↔ 群名映射

`~/.hermes/channel_directory.json` 里有全部 `oc_xxx` 和群名。老公的群叫
「**淫骚毛逼老婆任务群**」（不是正经工作群，语气随便点）。

```bash
python3 -c "
import json,re
s=open('/data/data/com.termux/files/home/.hermes/channel_directory.json').read()
print(set(re.findall(r'[^\"]*淫[^\"]*', s)))
print(set(re.findall(r'oc_[a-f0-9]{32}', s)))
"
```

### 6. session 历史 —— 补"今天干了什么"的人味部分

```bash
session_search(limit=8, sort="newest")            # 今天的会话列表
session_search(query="备份 OR bot OR kanban")      # 按主题找
session_search(session_id="<id>")                  # 读整个会话
```

`session_search()` 不带参数（browse 模式）能直接列出**最近会话 + preview**。

⚠️ **但 browse 只返回最近 3 条**（2026-10-29 实测：3 条全是 cron session），
**当天老公真正的交互会话会被挤掉** —— 必须用 `state.db` 补：

```python
# 只看用户消息，且排除 cron session
for r in c.execute('select session_id, substr(content,1,250) cc, timestamp '
                    'from messages where timestamp>? and role="user" '
                    'and session_id not like "cron_%" order by timestamp asc', (day,)):
    print(r['session_id'], r['cc'])
```

**组合拳：state.db 定位当天 session → `session_search(session_id=...)` 读全文。**
实测：老公说"电报bot启动" → 找到 session `20261029_192055_e5a4a7` →
`session_search(session_id=...)` 一次拿到 25 条消息，直接读出
"gateway 僵死 4 天 → kill + 清 state → 重启 → 三平台全通"的完整过程和最终状态表。
这比从零 grep 日志快一个数量级。

### 6b. ⚠️ 晚间总结不要和早上简报打架 —— 但**要以日志为准修正它**
早上 9 点的简报（`c51c6ca0d139`）已经发过一轮，晚间总结要**接着往下说**，
别重复它已经报过的内容。读它的最终正文（见第 1 节取法），对齐口径。

⚠️ **但"对齐口径"不等于"照抄它的结论"**（2026-10-30 晚间实测）：
早上简报写的是"三个日报全被 `[99992402]` 卡掉 / 插件代码有 bug"，
而晚间查 `agent.log` 发现 —— **三条其实全部 `delivered` 成功**（fallback 兜住了）。
早上简报读的是 `jobs.json` 的健康字段（那个不准），晚间读的是实际投递日志（准）。

**原则：晚间以 `agent.log` 的实际投递记录为准，发现和早报冲突时，
不要重复早报的"全挂"结论，也不要硬说自己打脸早报 ——
直接说"插件 bug 还在，但 fallback 兜住了，三条日报一条没漏 ✅"。**

这样既不重复早报的话，也不给老公错误信息。

#### ⚠️⚠️ 兄弟 job 的 `## Response` 正文里可能混着**它自己的未收尾事故**（2026-11-02 实测）

读兄弟产出学版式时（见第 1 节 `sed -n '/## Response/,$p'`），
**正文不一定是一份干净的报告**。2026-11-02 实测，早报 `27957f101f60` 的
`## Response` 正文里通篇是**它自己那个 job 的"情形 D"验证事故**
（`kanban_q.py` 删不掉的 scratch 脚本、`git ls-files` 实证表、
"没有代码需要验证"的长篇自辩），**一句正经的早报内容都没有**。

**症状特征**：`## Response` 里没有老公要的四段结构，取而代之的是
- `git ls-files --error-unmatch` / `test -e` / `find ~ -maxdepth` 的实证表
- "没有代码需要验证，改动已回退" / "确认三点" 这类**交付自辩**
- 文件修改校验器的告警尾注（"⚠️ File-mutation verifier: 1 file(s) were NOT modified"）

**处理方式**：
1. **不要把这段当早报内容转述给老公** —— 它是那个 job 的内部事故叙事，
   老公在群里已经收到过一模一样的文字了，晚间再复述一遍就是刷屏。
2. **但要识别出"这个兄弟 job 今天没出正经内容"** —— 这本身是有效情报：
   在「今日完成事项」表里给它标 ⚠️（"跑了但输出是事故自辩，没出报告"），
   而不是 ✅。否则你会写"早报已推送 ✅"而群里其实收到的是一段技术自白。
3. **口径要与 `agent.log` 对齐**：grep `cron.scheduler` 的 `delivered` ——
   如果 `delivered` 出现了，**消息确实送到了群里**（内容质量差 ≠ 没送达），
   那就在表里写"已投递但内容是事故自辩"，两件事都写清楚。

⭐ **通用判据**：`## Response` 正文里如果出现 `git ls-files` / `test -e` /
"没有代码需要验证" / "File-mutation verifier" 这类词，
**说明你读到的是某个 job 的收尾事故，不是它的报告正文**。
换另一个兄弟 job（备份 `eb9b2a0e46d8` / Trending `a60c53e7db02` /
AI资讯 `377472e94c28`）的产出取素材，别在这一个上死磕。

⚠️ **同理，"今日完成事项"表里别只写 job 名 + ✅** —— 至少带一句它产出了什么
（"08:01 抓完 14 条，AI/ML 流水线正常"），
这样即使某个 job 的正文是事故，表格本身仍然有信息量。

## 报告结构模板

```
# 🌙 晚间总结 · X月X日（周X）

## 📅 今日完成事项        ← 表格：时间 | 事项 | 结果
## 💬 飞书群消息亮点    ← 表格：项目 | 状态
## 📊 明日待办预览      ← 表格：时间 | 任务 | 备注 + 手动待办
## 🌙 今日一句话总结    ← 一两句，定调
```

四个模块对应老公 prompt 里的四点，顺序不要改。

## 语气要求

- 口语化、轻松、温馨，像老婆说"老公今天辛苦了"
- emoji 适度但不刷屏（老公嫌刷屏）
- 每节用表格，简洁工整 —— 老公要"老板看得懂"
- **结尾给一个抱抱**（`🤗💗` / "送上今天的抱抱"）
- 可以加一句天气/穿衣提醒（晚间降温时提醒带伞），这是"老婆感"的来源
- 手动待办结尾标一句"要不要老婆现在就动手？等老公发话 🫡"——
  符合老公"敏感操作先问一次"的习惯

## 已知坑

- **cron 里 `execute_code` 被拦截** → 用 `terminal()` 等普通工具
- **`tasks.md` / `progress.md` 不存在** → 数据源换成 cron 产出 + 日志 + session
- **`~/.hermes/gateway.log`（根目录）是 10/16 的旧文件**，实时日志在 `~/.hermes/logs/`
- **`gateway_state.json` 里 telegram 可能显示 `fatal/missing_credentials`**，
  但 `.env` 里 token 其实是有的（46 字符）—— **状态文件可能是旧的**，
  别照抄当结论，用 `grep "inbound message"` 交叉验证真实收发
  ⭐⭐ **更快的过期判据（2026-11-02 实测）：看 `platforms.<name>.updated_at`** ——
  **两个平台的 `updated_at` 完全相同 = 同一次重启时一起写的陈旧快照**。
  本次实测 telegram 标 `fatal / No bot token configured` 且与 feishu 的
  `updated_at` 都是 `11-01T14:28:14Z`，而 qqbot 晚了 10 小时 → telegram 那条是过期的
  （当天 08:59 日志里 Telegram 还在 `polling restarted after network error`，自己在重连）。
  → **别把过期的 `fatal` 写进待办栏。** 详见 `daily-morning-report.md` 的「`updated_at` 判据」一节
  ```bash
  for p in default geekwife siliconflow cutegirl libai licai wenyu; do
    f=~/.hermes/profiles/$p/.env; [ "$p" = "default" ] && f=~/.hermes/.env
    T=$(grep -oP '(?<=^TELEGRAM_BOT_TOKEN=).*' "$f" 2>/dev/null | head -1 | tr -d '\r"')
    echo "$p: ${#T}"
  done
  ```
  ⭐ 同文件里的 `served_profiles` 直接列出 gateway 托管的所有 profile（本例 7 个）
  —— **一个 gateway 托管多 profile，进程数 ≠ profile 数**，别用 `ps` 数 profile。
- **`knowledge/notes/` 只有 `scripts.md`**（2026-10-31 第三次实测确认，仍只有这一个文件；
  `tasks.md` / `progress.md` / `daily_custom.md` 依旧不存在），`knowledge/facts/` 有
  user.md / system.md / stickers.md，`knowledge/我是老公/` 是 git 仓库（数码知识库.md）
  → **别再花一轮 `ls` 验证这三个路径**，直接按"不存在"处理，从 cron 产出重建事实。
- **飞书 cron 投递错误码 `[99992402] field validation failed`** 是已存在的老问题：
  有的 job 走 live adapter 成功，有的 fallback 到 standalone 也失败。
  晚间总结里如实报出来，并放进"明日待办"提醒修
- **⚠️⚠️ 飞书插件 bug 会"假失败"—— 看 `delivered` 关键字，别只看 WARNING**（2026-10-30 晚间实测）：
  插件 bug `'CreateMessageResponse' object has no attribute 'get'` 会打 WARNING，
  但 **cron 会自动 fallback 到 standalone 通道并成功投递**。日志长这样：

  ```
  09:01:32 INFO  cron.scheduler: Job '27957f101f60': delivered to feishu:oc_457ae... via live adapter
  09:01:38 WARNING cron.scheduler: Job 'cd38d14f5563': live adapter delivery ... failed:
                     'CreateMessageResponse' object has no attribute 'get', falling back to standalone
  09:01:39 INFO  cron.scheduler: Job 'cd38d14f5563': delivered to feishu:oc_457ae...
  ```

  → **判断"日报有没有送达"要 grep `cron.scheduler` 的 `delivered`，不是 grep WARNING/ERROR。**
  有 `delivered` 就是送到了，别在晚间总结里报成"三条日报全挂"（早报已报过，
  晚间再报一遍就是打架）。正确写法：**"插件 bug 还在，但 fallback 兜住了，
  三条日报一条没漏 ✅"** —— 根因仍要放进"明日待办"。

  ⭐ **2026-10-31 再次实测确认，且发现 WARNING 的类名不止一个**：
  当天出现的是 `'ReplyMessageResponse' object has no attribute 'get'`（昨天是
  `'CreateMessageResponse'`）。**两个类名都可能是同一个根因** —— 根因在
  `cron/scheduler.py:1913` 无条件对平台返回对象调 `.get()`，而飞书 SDK 返回的是
  lark_oapi 对象（不是 dict），Telegram 才返回带 `thread_fallback` 的 dict。
  → **grep 时用 `' object has no attribute 'get'` 或 `'Response' object has no attribute`，
  别只匹配 `CreateMessageResponse`**，否则会漏掉 `ReplyMessageResponse` 那次。

  ⭐ 一条 grep 同时拿到「失败+兜底成功」两半，报告里就能写准：
  ```bash
  grep -a "2026-10-31" ~/.hermes/logs/agent.log | grep -aiE "cron.scheduler.*(delivered|has no attribute 'get')"
  ```
  2026-10-31 实测输出形态（4 条早报，3 条走 live adapter、2 条触发 WARNING 但都 fallback 成功）：
  ```
  09:01:34 INFO  Job '27957f101f60': delivered to feishu:oc_457ae... via live adapter
  09:01:55 WARNING Job 'c51c6ca0d139': live adapter delivery ... failed:
               'ReplyMessageResponse' object has no attribute 'get', falling back to standalone
  09:01:57 INFO  Job 'c51c6ca0d139': delivered to feishu:oc_457ae...
  09:03:49 WARNING Job 'cd38d14f5563': live adapter delivery ... failed:
               'CreateMessageResponse' object has no attribute 'get', falling back to standalone
  09:03:50 INFO  Job 'cd38d14f5563': delivered to feishu:oc_457ae...
  ```
  → 结论口径：**"4 条早报全部 delivered，一条没漏；插件 bug 触发 2 次但都被 standalone 兜住"**。

- ⭐ **资源状态一句话拿全（晚间总结的"今日完成事项"表需要）**（2026-10-31 实测）：
  ```bash
  free -h | head -3                    # Mem: 14Gi used 11Gi available 2.3Gi / Swap: 15Gi used 13Gi
  df -h /data | tail -2                # 937G  897G  40G  96% /data/user/0
  ps -ef | grep -i hermes | grep -v grep | head -5 | cut -c1-140   # gateway PID
  ```
  老公在意的是**可用内存 / swap / 磁盘百分比 / gateway PID 在不在**这四个数，
  报告里写成"内存剩 2.3G、swap 吃 13G、磁盘 96%（剩 40G）、gateway PID 16961 在线"。
  ⚠️ **`free -h` 在 Termux 要带 `-h`**（默认输出单位是 KiB，老板的 `available` 看着像 2300 太小）。

#### ⭐⭐⭐ 磁盘要看**两个分区**，只报 `/data` 会漏掉真正的火警（2026-11-02 实测）

⚠️ **旧结论「df 要指 `/data`（不是 `/`）」是不完整的，照做会漏报真实故障。**
2026-11-02 晚间实测：

```
/dev/block/dm-13    7.8G  7.8G     0 100% /              ← Termux 根分区：100% 满，0 字节可用 🔥
/dev/fuse         937G  894G   42G  96% /storage/emulated ← 用户数据分区：96%，还剩 42G
```

**两个分区含义完全不同，缺一不可：**

| 分区 | 装什么 | 满了会怎样 | 是否进报告 |
|---|---|---|---|
| `/`（dm-13，7.8G） | **Termux 本体**：pkg、$PREFIX、$HOME、~/.hermes | **`apt install` / `pip install` 全挂**，写任何 $HOME 外的东西失败 | 🔴 **必报，且要标最紧急** |
| `/storage/emulated`（937G） | 用户照片/下载/应用数据 | 应用存不了东西 | 🟡 照常报百分比 |

**为什么必须一起查**：`/storage/emulated` 是 Android 的 fuse 挂载，**和 `/` 不是一个盘**。
只跑 `df -h /data`（或只跑 `df -h /`）都会漏掉另一半。
**一条命令拿全两个**：

```bash
df -h / /storage/emulated /data 2>/dev/null | awk 'NR==1 || $0 !~ /loop|apex|dm-1[4-9]|dm-2[0-9]|dm-3[0-9]|dm-4[0-9]|dm-5[0-9]|dm-6[0-9]|vendor|system|product|odm|oem|dm-26/'
```

⚠️ **`df -h` 在 Termux 会列 60+ 个 Android 只读分区**（apex/loop/vendor/system…），
全打印出来会淹没输出。按 `Use%` 排序 + 只留真正关心的行：

```bash
df -h | awk 'NR==1 || $5+0>=90' | head -8     # 只看 ≥90% 的分区
```

**报告写法（2026-11-02 真实产出）**：
> 🔴 Termux 根分区 7.8G **已经 100% 满、0 字节可用** —— `apt install` / `pip install` 会全挂
> 🟡 用户数据分区 894G/937G（96%），还剩 42G

**别写成"磁盘 96% 满"就完事** —— 那样老公以为还有 42G 余量，
实际根分区已经是 0 字节、明天备份就可能失败。

#### ⚠️⚠️ `du -sh /storage/emulated/0/*` 会超时（2026-11-02 实测）

找"哪些大文件能删"时，最自然的命令是 `du -sh /storage/emulated/0/*`。
**实测这条在老公机上跑满 180s 直接 timeout**（fuse 挂载递归 stat 太慢）。
**别浪费一轮 3 分钟等它** —— 改用有界深度的扫描：

```bash
# ✅ 有界深度 + 单目录，秒级返回
du -sh --max-depth=1 /storage/emulated/0 2>/dev/null | sort -rh | head -10

# ✅ 更快的候选：只看已知的媒体大目录
for d in Download DCIM Movies Pictures Documents; do
  du -sh "/storage/emulated/0/$d" 2>/dev/null
done
```

⚠️ 加 `2>/dev/null` —— fuse 挂载下大量 permission denied 会刷屏。
**在报告里别写"我扫了一遍没找到大文件"** —— 你只是没扫完，不是没有。

- **飞书长连接一天掉 7 次是常态**（Lark keepalive ping timeout / SSL EOF），
  统计断线次数作为"群消息亮点"栏的现状指标。2026-10-30 实测掉了 **30+ 次**
  （`Lark: receive message loop exit` + `connect failed ... SSLEOFError`），
  **但投递完全没受影响** —— 断线次数多 ≠ 消息丢失，汇报时要说清楚这个区别，
  否则会让老公误以为群消息不可靠。
- **Kanban 有两层**（2026-10-30 修正）：`~/.hermes/kanban.db` **确实存在**
  （SQLite，有 `tasks`/`task_links`/`task_events`/`task_runs` 表），
  但 **`tasks` 表实测是空的**；另一层是 9119 端口 HTTPS 看板（要认证 403）。
  → 两层都拿不到就**别编看板内容**，直接说"看板要密码打不开"
- **Google 日历未配置** → 晚间总结本来也不需要日历
- `sqlite3` 命令在 Termux **确定没有**（实测报 `cannot execute: required file not found`），
  一律用 `python3 -c "import sqlite3; ..."` — 这条不要试，省一轮调用
- **⚠️ `cron/executions.db` 用只读 URI 打开更安全**（gateway 正在写，WAL 模式）：
  ```python
  c = sqlite3.connect('file:executions.db?mode=ro', uri=True)
  ```
- **`grep -a`** 处理含二进制字符的日志，避免 "binary file matches"
- **⚠️ 进程活着 ≠ 服务活着（2026-10-29 实测）**：当天 gateway 进程还在 `ps` 里，
  但日志 mtime 停在 **4 天前**（10-25 21:02），Telegram 早就不回消息了。
  **判断 gateway 是否僵死，看日志最后修改时间，不要只看 PID 存在**：
  ```bash
  stat -c '%y' ~/.hermes/logs/gateway.log     # 和 date 对比
  ```
  差了几小时以上 = 僵死，早报/晚间总结里应报成"今日故障"，
  不要写成"网关运行中"。恢复流程见 `termux-hermes` skill
  （kill PID → `rm -f ~/.hermes/gateway_state.json` → `terminal(background=true, pty=true)` 重拉）。
- **`gateway-exit-diag.log`** 会记上一次 gateway 的退出原因
  （`previous_unclean_exit` / `last_heartbeat_mem`），僵死时值得翻一眼
- **⚠️ 「今晚所有 profile 都没连上」≠ 部分失败**：cutegirl / libai / licai / siliconflow / wenyu
  缺 token 是常态（`No bot token configured`），别当故障报。**只有主 bot + geekwife
  连不上才算异常**。汇报表格里把「无 token（正常）」和「✗ 异常」区分开。
- **`getUpdates` 返回 `result:[]`** = 队列已清干净、polling 恢复（配合
  `grep "inbound message"` 无残留记录）。这条比翻日志可靠。

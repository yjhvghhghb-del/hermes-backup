# 每日晚间总结 — Cron Job 模板（20:00）

早报见 `references/daily-morning-report.md`。晚间总结的数据源完全不同
（没有日历、核心是 cron 产出 + 平台日志 + session 历史），单独成篇。

## ⚠️ 先看这条：cron 模式下 `execute_code` 被拦截

同早报。晚间总结里所有取数都走 `terminal()` / `read_file` / `session_search` /
`search_files`，不要试 `execute_code`，直接浪费一轮调用。

## ⚠️ 核心坑：`tasks.md` / `progress.md` 根本不存在

老公的 `~/.hermes/knowledge/notes/` 里**只有 `scripts.md` 一个文件**。
`tasks.md`、`progress.md`、`daily_custom.md`、`.ics` 日历文件全都没有。

早报模板里"读 tasks.md 拿今日完成/明日待办"的那套**在老公环境里是空的**。
晚间总结必须**从别处重建事实**，否则只能编。

**正确顺序：先查 cron 产出 → 再查平台日志 → 再查 session 历史。**
这三层加起来信息量足够撑起一份有真实内容的晚间总结。

## 数据获取顺序（按可靠性）

### 1. 今日 cron 任务产出 —— 最值钱的一手材料

#### ⭐⭐ 首选：`~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md`（2026-10-30 实测最省事）

**这是最快的路径 —— 一条命令就能拿到某 job 的完整报告正文，不用碰数据库。**

文件结构固定：前面是 `## Prompt`（原始 prompt + 注入的 skill 内容），
`## Response` 之后就是**最终报告正文**。用 sed 切出来即可：

```bash
cd ~/.hermes/cron/output
for j in 27957f101f60 377472e94c28 cd38d14f5563 c51c6ca0d139 \
         a60c53e7db02 eb9b2a0e46d8 f5d67b085944; do
  f=$(ls -t ~/.hermes/cron/output/$j/* 2>/dev/null | head -1)
  echo "########## $j : $(basename $f 2>/dev/null)"
  sed -n '/## Response/,$p' "$f" 2>/dev/null | head -60
done
```

只读**今天**的文件（不要读昨天的，早报已经讲过）：
```bash
find ~/.hermes/cron/output/ -newermt "2026-10-30" -type f | head -30
```

⚠️ **修正旧结论**：2026-10-29 实测这个目录是空的，所以当时把 `state.db` 写成了"首选"。
**2026-10-30 复测：该目录有 6 个产出文件，全部正常**。结论改为 ——
**先 `ls`/`find` 试 `cron/output/`，有就直接用（1 轮出全量正文）；
只有确实空了才退回 `state.db`。** 不要因为旧文档就跳过这一步。

⚠️ 文件名里的时间是**任务启动时分秒**（`2026-10-30_09-01-31.md`），
不是结束时间。读的时候用 `ls -t` 取最新，别自己拼日期。

#### 备选：`~/.hermes/state.db` 的 `messages` 表（2026-10-29 实测可用）

cron 的最终报告正文都在这里 —— 比日志全（日志只有平台层事件，没有结论正文）。
⚠️ 但**它现在是备选不是首选**：`cron/output/` 目录通常有产出且读取更直接（见上），
只有该目录为空时才走这条。

**⚠️ `messages.timestamp` 是 Unix float，不是日期字符串。**
`where timestamp like '2026-10-29%'` 返回 **0 行**，白白浪费两轮调用。
用数值比较：`where timestamp > <当天00:00的epoch>`。

```python
import sqlite3, datetime
c = sqlite3.connect('/data/data/com.termux/files/home/.hermes/state.db')
c.row_factory = sqlite3.Row
day = int(datetime.datetime(2026,10,29).timestamp())

# 列出当天所有 session（分清 cron 和用户交互会话）
for r in c.execute('select session_id, count(*) n from messages '
                    'where session_id like "cron_%_2026%" group by session_id'):
    print(r['session_id'], r['n'])

# 取某个 cron job 的最终报告正文
sid = 'cron_377472e94c28_20261029_192221'
for r in c.execute('select substr(content,1,1600) cc from messages '
                    'where session_id=? and role="assistant" and content is not null '
                    'and length(content)>150 order by id desc limit 1', (sid,)):
    print(r['cc'])
```

**cron session_id 格式 = `cron_<jobid>_<YYYYMMDD>_<HHMMSS>`**，
时间戳那段运行时生成，拼不出来 —— 先 `group by session_id` 把当天的捞出来。

**完整取数脚本 + job_id 对照表 + 「取老公今天说了啥」的过滤方法
→ 见 `references/hermes-session-db-mining.md`**

拿到 session_id 后再用 `session_search(session_id="<id>")` 读全文最省事。

#### 备用：`~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md`

见上（已是首选）。若某天该目录确实为空，再退回 `state.db`。

job_id 用途对照：
- `eb9b2a0e46d8` = 每日备份（tar 大小 / commit / push 结果）
- `377472e94c28` = 每日AI资讯
- `a60c53e7db02` = GitHub Trending
- `cd38d14f5563` / `27957f101f60` / `c51c6ca0d139` = 早报三连
- `4346b6b5808d` = 晚间总结（自己）
- `f5d67b085944` = 每日晚9点回顾推送

### 2. cron 执行历史 —— 判断"今天哪些跑了/挂了"

```bash
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('executions.db')
for r in c.execute('SELECT job_id, started_at, status, error FROM executions ORDER BY started_at DESC LIMIT 25'):
    print(r[0], r[1][:19], r[2], (r[3] or '')[:80])
"
```

⚠️ **`status` 只有 `completed` / `running` / `unknown` 三种，**没有 `failed`**
（2026-10-30 复测确认）。`unknown` = 调度器重启时执行没到终态。
→ **`status=completed` 也可能带着投递失败**，真正的失败原因只在 `agent.log` 里，
务必配合下面第 4 节的 `cron.scheduler` grep 一起看。

**2026-10-30 实测用法**：拿 `executions.db` 判断"今天哪些 job 跑了"，
配合 `cron/output/` 读正文，一条时间线就出来了：
```
03:00 eb9b2a0e46d8  completed   ← 每日备份
08:00 a60c53e7db02  completed   ← GitHub Trending
09:00 四个 job 同时 completed     ← AI资讯/早上回顾/9点简报/9点回顾推送
20:00 4346b6b5808d  running     ← 晚间总结（自己）
```

### 3. 明日待办的真正来源 —— jobs.json 的 schedule

```bash
cd ~/.hermes/cron && python3 -c "
import json
d=json.load(open('jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
if isinstance(jobs,dict): jobs=list(jobs.values())
for j in jobs:
    print(j.get('name'),'|',j.get('schedule'),'|enabled=',j.get('enabled'),'|id=',j.get('id'))
"
```
`schedule.display` 就是 cron 表达式（`0 9 * * *` 等）。用当前时刻 + 24h 就能推出
明天几点有哪些任务会跑 —— 这就是"明日待办预览"最硬的依据。

#### ⭐ 同文件里的健康字段 = "还没修好的事"（2026-10-30 实测）

`schedule` 告诉你**明天**会跑什么；同一个 `jobs.json` 里的
`last_status` / `last_error` / `last_delivery_error` 告诉你**现在什么坏了**。
晚间总结的"明日待办"两样都要 —— 前者是预告，后者是欠账。

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
for j in d['jobs']:
    print(f\"{j['name']:20s} | enabled={j.get('enabled')} | last={str(j.get('last_run_at'))[:16]} | status={j.get('last_status')} | err={(j.get('last_error') or '')[:60]} | deliver_err={(j.get('last_delivery_error') or '')[:60]}\")
"
```

⚠️ **2026-10-30 晚间复测：这些健康字段打印出来全是空字符串**
（`last_run` / `next_run` 全空）。**别卡在这一步反复试** ——
直接走第 4 节的日志兜底链（grep `agent.log` 的 `cron.scheduler` + `executions.db`），
那条链实测能挖出真故障。

⚠️ 另外 `jobs.json` 的**结构本身**也有两种形态，用 `d['jobs']` 直取可能 KeyError。
用兼容写法：

```python
import json
d = json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
jobs = d if isinstance(d, list) else d.get('jobs', d)
if isinstance(jobs, dict): jobs = list(jobs.values())
for j in jobs:
    print(j.get('id'), j.get('name'), (j.get('schedule') or {}).get('display'), j.get('enabled'))
```

⚠️ **两条判断原则**：
1. `last_status=ok` ≠ 一切正常 → 一定要同时看 `last_delivery_error`
   （实测"每日早上回顾"和"早上9点简报"都是 `ok` 但飞书投递失败）
2. cron 报 `ok` ≠ 产物真的更新了 → 顺手 `ls -la` 一下产物 mtime
   （实测每日备份任务 `ok`，但 tar.gz 还停在 9月22）

完整字段说明见 `references/hermes-session-db-mining.md` 的「cron job 健康字段」一节。

### 4. 平台健康 + 今日故障 —— 晚间总结最有价值的"新闻"

```bash
# gateway 各平台实时状态
cat ~/.hermes/gateway_state.json

# 今日飞书长连接断了几次（关键指标）
grep -a "2026-10-24" ~/.hermes/logs/agent.log | grep -aiE "Lark.*(disconnect|receive message loop exit|connect failed)" | wc -l

# 今日 cron 投递成败
grep -a "2026-10-24" ~/.hermes/logs/agent.log | grep -aiE "cron.scheduler.*(delivery|delivered)" | tail -20

# 今日 Telegram 收消息 + 断线
grep -a "2026-10-24" ~/.hermes/logs/gateway.log | grep -aiE "inbound message" | tail -20
grep -a "2026-10-24" ~/.hermes/logs/gateway.log | grep -aiE "Telegram.*(network error|degraded)" | tail -10

# 今日错误汇总
grep -a "2026-10-24" ~/.hermes/logs/errors.log | tail -12 | cut -c1-200
```

日志在 `~/.hermes/logs/`：`agent.log`（插件/平台层）、`gateway.log`（主循环/收消息）、
`errors.log`（错误）。**旧的 `~/.hermes/gateway.log`（根目录那个）已经 10/16 就不更新了，
别去 grep 它** —— 看 `~/.hermes/logs/gateway.log`。

### 5. 飞书群 ID ↔ 群名映射

`~/.hermes/channel_directory.json` 里有全部 `oc_xxx` 和群名。老公的群叫
「**淫骚毛逼老婆任务群**」（不是正经工作群，语气随便点）。

```bash
python3 -c "
import json,re
s=open('/data/data/com.termux/files/home/.hermes/channel_directory.json').read()
print(set(re.findall(r'[^\"]*淫[^\"]*', s)))
print(set(re.findall(r'oc_[a-f0-9]{32}', s)))
"
```

### 6. session 历史 —— 补"今天干了什么"的人味部分

```bash
session_search(limit=8, sort="newest")            # 今天的会话列表
session_search(query="备份 OR bot OR kanban")      # 按主题找
session_search(session_id="<id>")                  # 读整个会话
```

`session_search()` 不带参数（browse 模式）能直接列出**最近会话 + preview**。

⚠️ **但 browse 只返回最近 3 条**（2026-10-29 实测：3 条全是 cron session），
**当天老公真正的交互会话会被挤掉** —— 必须用 `state.db` 补：

```python
# 只看用户消息，且排除 cron session
for r in c.execute('select session_id, substr(content,1,250) cc, timestamp '
                    'from messages where timestamp>? and role="user" '
                    'and session_id not like "cron_%" order by timestamp asc', (day,)):
    print(r['session_id'], r['cc'])
```

**组合拳：state.db 定位当天 session → `session_search(session_id=...)` 读全文。**
实测：老公说"电报bot启动" → 找到 session `20261029_192055_e5a4a7` →
`session_search(session_id=...)` 一次拿到 25 条消息，直接读出
"gateway 僵死 4 天 → kill + 清 state → 重启 → 三平台全通"的完整过程和最终状态表。
这比从零 grep 日志快一个数量级。

### 6b. ⚠️ 晚间总结不要和早上简报打架 —— 但**要以日志为准修正它**

早上 9 点的简报（`c51c6ca0d139`）已经发过一轮，晚间总结要**接着往下说**，
别重复它已经报过的内容。读它的最终正文（见第 1 节取法），对齐口径。

⚠️ **但"对齐口径"不等于"照抄它的结论"**（2026-10-30 晚间实测）：
早上简报写的是"三个日报全被 `[99992402]` 卡掉 / 插件代码有 bug"，
而晚间查 `agent.log` 发现 —— **三条其实全部 `delivered` 成功**（fallback 兜住了）。
早上简报读的是 `jobs.json` 的健康字段（那个不准），晚间读的是实际投递日志（准）。

**原则：晚间以 `agent.log` 的实际投递记录为准，发现和早报冲突时，
不要重复早报的"全挂"结论，也不要硬说自己打脸早报 ——
直接说"插件 bug 还在，但 fallback 兜住了，三条日报一条没漏 ✅"。**

这样既不重复早报的话，也不给老公错误信息。

## 报告结构模板

```
# 🌙 晚间总结 · X月X日（周X）

## 📅 今日完成事项        ← 表格：时间 | 事项 | 结果
## 💬 飞书群消息亮点    ← 表格：项目 | 状态
## 📊 明日待办预览      ← 表格：时间 | 任务 | 备注 + 手动待办
## 🌙 今日一句话总结    ← 一两句，定调
```

四个模块对应老公 prompt 里的四点，顺序不要改。

## 语气要求

- 口语化、轻松、温馨，像老婆说"老公今天辛苦了"
- emoji 适度但不刷屏（老公嫌刷屏）
- 每节用表格，简洁工整 —— 老公要"老板看得懂"
- **结尾给一个抱抱**（`🤗💗` / "送上今天的抱抱"）
- 可以加一句天气/穿衣提醒（晚间降温时提醒带伞），这是"老婆感"的来源
- 手动待办结尾标一句"要不要老婆现在就动手？等老公发话 🫡"——
  符合老公"敏感操作先问一次"的习惯

## 已知坑

- **cron 里 `execute_code` 被拦截** → 用 `terminal()` 等普通工具
- **`tasks.md` / `progress.md` 不存在** → 数据源换成 cron 产出 + 日志 + session
- **`~/.hermes/gateway.log`（根目录）是 10/16 的旧文件**，实时日志在 `~/.hermes/logs/`
- **`gateway_state.json` 里 telegram 可能显示 `fatal/missing_credentials`**，
  但 `.env` 里 token 其实是有的（46 字符）—— **状态文件可能是旧的**，
  别照抄当结论，用 `grep "inbound message"` 交叉验证真实收发
  ```bash
  for p in default geekwife siliconflow cutegirl libai licai wenyu; do
    f=~/.hermes/profiles/$p/.env; [ "$p" = "default" ] && f=~/.hermes/.env
    T=$(grep -oP '(?<=^TELEGRAM_BOT_TOKEN=).*' "$f" 2>/dev/null | head -1 | tr -d '\r"')
    echo "$p: ${#T}"
  done
  ```
- **`knowledge/notes/` 只有 `scripts.md`**，`knowledge/facts/` 有 user.md / system.md / stickers.md，
  `knowledge/我是老公/` 是 git 仓库（数码知识库.md）
- **飞书 cron 投递错误码 `[99992402] field validation failed`** 是已存在的老问题：
  有的 job 走 live adapter 成功，有的 fallback 到 standalone 也失败。
  晚间总结里如实报出来，并放进"明日待办"提醒修
- **⚠️⚠️ 飞书插件 bug 会"假失败"—— 看 `delivered` 关键字，别只看 WARNING**（2026-10-30 晚间实测）：
  插件 bug `'CreateMessageResponse' object has no attribute 'get'` 会打 WARNING，
  但 **cron 会自动 fallback 到 standalone 通道并成功投递**。日志长这样：

  ```
  09:01:32 INFO  cron.scheduler: Job '27957f101f60': delivered to feishu:oc_457ae... via live adapter
  09:01:38 WARNING cron.scheduler: Job 'cd38d14f5563': live adapter delivery ... failed:
                     'CreateMessageResponse' object has no attribute 'get', falling back to standalone
  09:01:39 INFO  cron.scheduler: Job 'cd38d14f5563': delivered to feishu:oc_457ae...
  ```

  → **判断"日报有没有送达"要 grep `cron.scheduler` 的 `delivered`，不是 grep WARNING/ERROR。**
  有 `delivered` 就是送到了，别在晚间总结里报成"三条日报全挂"（早报已报过，
  晚间再报一遍就是打架）。正确写法：**"插件 bug 还在，但 fallback 兜住了，
  三条日报一条没漏 ✅"** —— 根因仍要放进"明日待办"。

- **飞书长连接一天掉 7 次是常态**（Lark keepalive ping timeout / SSL EOF），
  统计断线次数作为"群消息亮点"栏的现状指标。2026-10-30 实测掉了 **30+ 次**
  （`Lark: receive message loop exit` + `connect failed ... SSLEOFError`），
  **但投递完全没受影响** —— 断线次数多 ≠ 消息丢失，汇报时要说清楚这个区别，
  否则会让老公误以为群消息不可靠。
- **Kanban 有两层**（2026-10-30 修正）：`~/.hermes/kanban.db` **确实存在**
  （SQLite，有 `tasks`/`task_links`/`task_events`/`task_runs` 表），
  但 **`tasks` 表实测是空的**；另一层是 9119 端口 HTTPS 看板（要认证 403）。
  → 两层都拿不到就**别编看板内容**，直接说"看板要密码打不开"
- **Google 日历未配置** → 晚间总结本来也不需要日历
- `sqlite3` 命令在 Termux **确定没有**（实测报 `cannot execute: required file not found`），
  一律用 `python3 -c "import sqlite3; ..."` — 这条不要试，省一轮调用
- **⚠️ `cron/executions.db` 用只读 URI 打开更安全**（gateway 正在写，WAL 模式）：
  ```python
  c = sqlite3.connect('file:executions.db?mode=ro', uri=True)
  ```
- **`grep -a`** 处理含二进制字符的日志，避免 "binary file matches"
- **⚠️ 进程活着 ≠ 服务活着（2026-10-29 实测）**：当天 gateway 进程还在 `ps` 里，
  但日志 mtime 停在 **4 天前**（10-25 21:02），Telegram 早就不回消息了。
  **判断 gateway 是否僵死，看日志最后修改时间，不要只看 PID 存在**：
  ```bash
  stat -c '%y' ~/.hermes/logs/gateway.log     # 和 date 对比
  ```
  差了几小时以上 = 僵死，早报/晚间总结里应报成"今日故障"，
  不要写成"网关运行中"。恢复流程见 `termux-hermes` skill
  （kill PID → `rm -f ~/.hermes/gateway_state.json` → `terminal(background=true, pty=true)` 重拉）。
- **`gateway-exit-diag.log`** 会记上一次 gateway 的退出原因
  （`previous_unclean_exit` / `last_heartbeat_mem`），僵死时值得翻一眼
- **⚠️ 「今晚所有 profile 都没连上」≠ 部分失败**：cutegirl / libai / licai / siliconflow / wenyu
  缺 token 是常态（`No bot token configured`），别当故障报。**只有主 bot + geekwife
  连不上才算异常**。汇报表格里把「无 token（正常）」和「✗ 异常」区分开。
- **`getUpdates` 返回 `result:[]`** = 队列已清干净、polling 恢复（配合
  `grep "inbound message"` 无残留记录）。这条比翻日志可靠。

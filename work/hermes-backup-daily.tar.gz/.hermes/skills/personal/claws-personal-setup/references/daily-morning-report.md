# 每日晨间推送 — Cron Job 模板

## 触发方式

Hermes cron job 调度，每天早上推送。

## 数据获取顺序

### ⚠️ 先看这条：cron 模式下 `execute_code` 被拦截

**cron job 里调用 `execute_code` 会直接失败**：

```
BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
that bypass shell-string approval checks). Cron jobs run without a user present
to approve it. Use normal tools instead, or set approvals.cron_mode: approve
```

**解法**：cron 里改用普通工具 —— `terminal()` 跑 shell、`read_file` 读文件、
`search_files` 找文件、`skill_view`/`session_search` 查资料。
不要在 cron 里试图用 `execute_code` 绕过，浪费一轮调用。

### 可用数据源（按可靠性排序）

```bash
# 1. 当前日期（中文格式）
date "+%m月%e日 周%w"   # 输出如：08月21日 周5

# 2. 昨天各 cron job 的实际产出 —— 最有价值的一手材料
#    目录结构：~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md
ls -t ~/.hermes/cron/output/*/ | head
#    重点读：昨晚 21:00 的「每日晚9点回顾推送」输出，它里面已经列好了"明日待办"
#    → 直接把它的"明日待办"搬进今天的待办栏
read_file ~/.hermes/cron/output/<job_id>/<yesterday-file>.md

# 3. 所有定时任务清单（含开关状态和 prompt 摘要）
cd ~/.hermes/cron && python3 -c "
import json
d=json.load(open('jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
if isinstance(jobs,dict): jobs=list(jobs.values())
for j in jobs:
    print(j.get('name'),'|',j.get('schedule'),'| enabled=',j.get('enabled'))
"

# 4. 知识库笔记 / 事实
ls ~/.hermes/knowledge/facts/ ~/.hermes/knowledge/notes/ ~/.hermes/knowledge/我是老公/

# 5. 各 profile 健康状态
for p in cutegirl geekwife libai licai siliconflow wenyu; do
  echo -n "$p: "; ls ~/.hermes/profiles/$p/.env >/dev/null 2>&1 && echo "env ok" || echo "no env"
done
ps -ef | grep -Ei "hermes" | grep -v grep | awk '{print $2, $9, $10, $11}'

# 6. 备份状态（github 仓库 ~/hermes-backup）
ls -la ~/hermes-backup-daily.tar.gz
cd ~/hermes-backup && git log --oneline -1 && git status --short
```

### 日历 / 邮件：先判断有没有配

**不要一上来就 `google_api.py calendar list`** —— 没认证会直接报错。

```bash
ls ~/.hermes/google_token.json ~/.hermes/google_client_secret.json 2>&1
```

- 缺这两个文件 → Google 日历/Gmail **没配**，日程直接写"今天没有安排～"，不要浪费时间尝试
- `himalaya` 也没装（`which himalaya` 为空）→ 邮件同样没有来源
- 更好的判断方式：`skill_view("google-workspace")` 的返回里有
  `readiness_status: setup_needed` / `missing_credential_files` 字段，一眼就能看出来
- `gws` CLI 不存在也说明 Workspace 集成没启用

**结论：老公当前环境没有可用的日历/邮箱数据源，晨间推送的"今日日程"固定填"今天没有安排～"，
待办从 cron 历史输出 + 知识库 + session 历史推。**

## 报告格式模板

```
🌅 老公早上好！X月X日 周X

📅 今日日程：[从日历/Gmail读取今日事件，没有就说"今天没有安排～"]

📋 待办事项：[列出未完成的重要事项，没有就说"今天轻松过～"]

💪 今日目标：[根据待办给出1-3个重点建议]

加油老公！💖
```

## 语气要求

- 口语化、轻松，像老婆说话
- 简短有力，不啰嗦
- 表情符号分段
- 不说"根据您的情况"之类的废话
- 1-3句话交代完一个点，不要铺排

## 常读数据源

| 数据 | 来源 | 没有时怎么说 |
|------|------|-------------|
| 日历/Gmail | `google-workspace` skill（**先看 readiness_status**） | "今天没有安排～" |
| 昨日待办 | `~/.hermes/cron/output/<job_id>/<昨晚21点文件>.md` | 用知识库+session 历史推 |
| 未完成任务 | **Kanban 是 9119 端口的 HTTPS 看板**（见下方坑） | "看板要密码，今天轻松过～" |
| 最近聊天上下文 | `session_search(limit=5)` / `session_search(query=...)` | "今天干得不错～" |
| 知识库 | `~/.hermes/knowledge/facts/`、`notes/`、`我是老公/` | 不提这一栏 |
| 系统健康 | `ps -ef \| grep hermes` + 各 profile `.env` | "gateway 正常在跑 ✅" |
| GitHub Trending | 早上8点已推送 | "GitHub Trending AI/ML 早上8点已经推送了，记得看看" |

## 已知坑

- **cron 里 `execute_code` 被拦截**（见上），用 `terminal()` 等普通工具代替
- **Kanban 不是 SQLite 文件**，是跑在 **9119 端口的 HTTPS web 服务**，而且要认证：
  - `http://127.0.0.1:9119/ka` → `400 The plain HTTP request was sent to HTTPS port`（必须用 https）
  - `curl -sk https://127.0.0.1:9119/ka` → `403`（需要密码/token）
  - 拿不到就**不要在报告里编看板内容**，直接说"看板要密码打不开"
  - 老文档里写的 `~/.hermes/kanban.db` **不存在**，别照着查
- **Google Workspace 未配置**：`google_token.json` / `google_client_secret.json` 缺失，
  `himalaya` 也没装 → 日程和邮件两个来源都空着。日程栏固定填"今天没有安排～"
- **`skill_view` 返回的 `readiness_status` 字段**能直接判断某个 skill 是否已配置，
  比手动 ls 文件快且准 —— 判断"有没有日历"优先看这个字段
- `sqlite3` 命令在 Termux 可能不存在，用 `python3 -c "import sqlite3; ..."` 代替
- Telegram 不稳定（DNS污染），报告通过飞书/QQ推送时不依赖 Telegram 状态
- **报告结尾附一行"系统状态"小表**（gateway / 备份 / 数据源可用性），
  老公喜欢"老板看得懂"的表格格式，但表格要短，别超过 5 项

## 报告结尾的系统状态栏（老公偏好）

正文（情景/待办/目标）之后，加一行紧凑的系统状态，用表格但不超过 5 项，
并明确指出"哪些数据源今天拿不到"，避免老公以为日历真的没事件：

```
---
**系统状态**：gateway 进程正常 ✅ | 每日备份 03:52 已 push GitHub（`9220611`）✅ | 6 个飞书 profile 环境都在 | Google 日历没配 OAuth，今天日程是空的 | Kanban 看板要密码打不开
```

每项用 `|` 分隔即可，不必用 Markdown 表格（表格在小屏 Telegram 上会被压得很窄）。

# 每日晨间推送 — Cron Job 模板

## 触发方式

Hermes cron job 调度，每天早上推送。

## 数据获取顺序

### ⚠️ 先看这条：cron 模式下 `execute_code` 被拦截

**cron job 里调用 `execute_code` 会直接失败**：

```
BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
that bypass shell-string approval checks). Cron jobs run without a user present
to approve it. Use normal tools instead, or set approvals.cron_mode: approve
```

**解法**：cron 里改用普通工具 —— `terminal()` 跑 shell、`read_file` 读文件、
`search_files` 找文件、`skill_view`/`session_search` 查资料。
不要在 cron 里试图用 `execute_code` 绕过，浪费一轮调用。

### ⭐ 最快的真实待办来源：cron job 健康字段

**这一栏往往比"昨晚 cron 输出"更有价值**，因为它直接暴露**还没修好的故障**，
而昨晚的回顾输出可能已经把这些故障写成了"已完成"或干脆没提。

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
for j in d['jobs']:
    print(f\"{j['name']:20s} | enabled={j.get('enabled')} | last={str(j.get('last_run_at'))[:16]} | status={j.get('last_status')} | err={(j.get('last_error') or '')[:60]} | deliver_err={(j.get('last_delivery_error') or '')[:60]}\")
"
```

**关键字段**（`jobs.json` 每个 job 里都有）：

| 字段 | 含义 | 怎么用 |
|------|------|--------|
| `last_status` | `ok` / `error` | `error` = 这个任务上次跑挂了 |
| `last_error` | 上次跑的异常 | 直接抄进待办栏，是真实故障 |
| `last_delivery_error` | 投递失败（内容生成成功但发不出去） | ⚠️ **最容易被忽略**：`last_status=ok` 但推送失败 |
| `last_run_at` | 上次跑的时间 | 判断是不是"陈年待办"（差好几天 = 该修了） |
| `enabled` | 是否启用 | `enabled=False` 的不用报 |

⚠️ **两条判断原则**：
1. `last_status=ok` **不代表**一切正常 —— 一定要同时看 `last_delivery_error`。
2. cron 任务报 `ok` **不代表产物真的更新了** —— 顺手 `ls -la` 一下产物文件 mtime。
   备份任务尤其容易"假成功"。

### ⚠️ 健康字段可能为空 —— 必须有兜底链（2026-10-30 实测）

**如果 `jobs.json` 的健康字段打印出来全是 `None` / 空字符串**（老版本 Hermes
或不写这些字段的版本会这样），**不要卡在这一步反复试**。直接走下面这条兜底链，
实测一样能挖出真实故障：

```bash
# 兜底 1：从日志里 grep cron 投递错误（最直接）
grep -a "cron.scheduler" ~/.hermes/logs/agent.log | grep -aiE "delivery error|delivery to" | tail -15 | cut -c1-300

# 兜底 2：从执行历史库看每个 job 的成败
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('executions.db')
for r in c.execute('SELECT job_id,status,started_at,finished_at,error FROM executions ORDER BY started_at DESC LIMIT 25'):
    print(r[0], r[1], r[2][:19], '->', (r[4] or '')[:160])
"
```

`executions.db` 的表结构只有一列 `executions`：
`id, job_id, source, process_id, pid, process_started_at, status, claimed_at,
started_at, finished_at, error`。

⚠️⚠️ **`status` 的值域已变（2026-11-03 实测修正）**：
当前 schema 里**有 `failed`**，且 `error` 列带完整错误原文 ——
实测能查到 `failed | RuntimeError: HTTP 429: 已达到 Token Plan 用量上限`。
**旧文档写"只有 completed/running/unknown，没有 failed"——那是旧 schema，现在不准了。**
当前值域：`completed` / `failed` / `running` / `unknown`。
`unknown` = 调度器重启时执行还没到终态（`error` 里会写明
"Scheduler restarted after this execution's owner exited..."）。
→ **`status=completed` 也可能带着投递失败**，真正的失败原因只在
`agent.log` 里，务必配合兜底 1 一起看。

⭐⭐ **`executions` 表按 `started_at` 排，不要按 `id` 排**（2026-11-03 实测踩坑）：
`id` 是自增**插入**顺序，不是时间顺序 —— 并发/重试/历史导入会让两者严重错位。
实测 `ORDER BY id DESC LIMIT 30` 返回的是 8 月到 11 月的乱序（看着像"最近 30 次"，
其实跨越 3 个月）；`ORDER BY started_at DESC` 才是真正的最近 N 次。
`started_at` 是 ISO 串，可直接字符串比较。完整脚本见
`references/hermes-sqlite-inspection.md`。

**2026-10-30 实测：靠这条兜底链挖出了两个真实故障**
（`jobs.json` 健康字段当时打印不出来）：
- 飞书群投递 `[99992402] field validation failed`（三个早报 job 全中）
- 插件自身的 bug：`'CreateMessageResponse' object has no attribute 'get'`

⚠️⚠️ **但别把这两种情况都当成"投递失败"！**（2026-10-30 晚间复测发现）
`'CreateMessageResponse' object has no attribute 'get'` 这条 WARNING 之后，
cron **会自动 fallback 到 standalone 通道并成功投递**：

```
09:01:38 WARNING ... live adapter delivery ... failed: 'CreateMessageResponse' object has no attribute 'get', falling back to standalone
09:01:39 INFO    ... delivered to feishu:oc_457ae...     ← 实际送达了
```

⚠️ **类名不止一个，grep 要通配**（2026-11-01 实测又遇到
`'ReplyMessageResponse' object has no attribute 'get'`，同一根因、
`cron/scheduler.py:1913` 无条件对平台返回对象调 `.get()`）。
**别只匹配 `CreateMessageResponse`** —— 用通配：

```bash
grep -a " object has no attribute 'get'" ~/.hermes/logs/agent.log | tail -5
```

→ **判断早报是否送达，要 grep `cron.scheduler` 的 `delivered`，不是 grep WARNING/ERROR。**
实测当天三条早报**全部 `delivered` 成功**。报成"三条日报全挂"是误报 ——
正确说法是"live adapter 有 bug，但 fallback 兜住了，日报一条没漏 ✅，根因仍要修"。
这个坑已经在早报上误报过一次，别重复。

⭐⭐⭐ **但 fallback 不是每次都兜得住 —— 必须逐日核验（2026-11-03 实测出反例）**
2026-11-02 晚间总结（job `4346b6b5808d`）的记录是：
```
2026-11-02 20:04:20 WARNING cron.scheduler: Job '4346b6b5808d': live adapter delivery to
  feishu:oc_457ae34d4ae483c1ff40716be1c165cb failed: 'ReplyMessageResponse' object has no attribute 'get', fa...
```
⚠️ **同一条 WARNING 后面没有 `delivered to feishu:` 行** —— 说明这次**连 fallback 都没兜住**，
晚间总结**根本没投到飞书群**（而 11-01 和 11-02 早上那两个 job 都有 `delivered`）。
所以「插件 bug 一定会被 fallback 兜住」这个假设**不成立**，它是**逐次时好时坏**的。

**正确写法（不要一刀切）**：
- 每次报「飞书投递」前，先 grep **目标 chat_id** 的 `delivered` 行：
  ```bash
  grep -ah "2026-$(date +%m-%d)" ~/.hermes/logs/agent.log ~/.hermes/logs/errors.log ~/.hermes/logs/errors.log.1 2>/dev/null \
    | grep -a "cron.scheduler" | grep -a "feishu:oc_457ae34d4ae483c1ff40716be1c165cb" \
    | grep -aE "delivered to|delivery to" | cut -c1-260
  ```
- **有 `delivered to`** → 写「插件有 bug 但 fallback 兜住了，日报一条没漏 ✅，根因在 scheduler.py:1913」
- **只有 `delivery to ... failed`、没有 `delivered`** → 写「**这条真的没投出去** ❌」，
  并把 job 名 + 日期写进待办栏让老公修 scheduler.py 那一行。
- ⚠️ **`errors.log` 和 `errors.log.1` 要一起 grep** —— 11-01 和 11-02 早上的失败记录
  在 `errors.log.1`（已轮转），只 grep `errors.log` 会漏掉历史，误以为"最近没失败过"。

⭐⭐⭐ **判定"插件 bug 仍在"的正确姿势（2026-11-03 实测）**
判断这 bug 修没修，**别看 plugin 源码 diff**，直接 grep 最近的 WARNING 有没有新出现：
```bash
grep -ah "2026-$(date +%m-%d)" ~/.hermes/logs/errors.log ~/.hermes/logs/errors.log.1 2>/dev/null \
  | grep -a " object has no attribute 'get'"
```
2026-11-03 实测：11-01、11-02 各出现一次（早报 + 晚间总结），
11-03 当天到 09:00 还没出现（因为早报正在跑）→ **bug 仍未修**，可以确定地写进待办栏。

#### ⭐⭐⭐ 飞书插件 bug 的**确切根因**（2026-10-31 定位，报告里可以直接写出来）

这个 bug 从 10-30 就在每天刷 WARNING，之前只知道"要 grep `delivered` 判送达"，
不知道错在哪。10-31 晨间推送彻底定位到了，**老公问"这个 bug 要我修不"时可以直接给答案**：

**根因在 `cron/scheduler.py`，不在飞书插件里。** `~/.hermes/hermes-agent/cron/scheduler.py:1913`：

```python
elif (
    send_raw_response
    and thread_id
    and send_raw_response.get("thread_fallback")   # ← BUG 在这
):
```

- `thread_fallback` 是 **Telegram adapter 专属**的 dict key
  （见 `plugins/platforms/telegram/adapter.py:4679`，它往返回的 dict 里塞
  `"thread_fallback": used_thread_fallback`）。
- 飞书 adapter 返回的是 **lark_oapi SDK 的对象**
  （`CreateMessageResponse` / `ReplyMessageResponse`），**不是 dict，没有 `.get()`**
  → `AttributeError: 'CreateMessageResponse' object has no attribute 'get'`
- 调度器对**所有平台**无条件调 `.get()`，所以只有飞书炸（其它平台的 raw_response 恰好是 dict）。

**飞书插件本身是干净的** —— `plugins/platforms/feishu/adapter.py` 的
`_response_succeeded` / `_extract_response_field` / `_finalize_send_result`
全部用 `getattr()`，没有裸 `.get()`。**别去改飞书插件，改了也没用。**

**正确修法**（在 scheduler 里判类型）：

```python
and isinstance(send_raw_response, dict)
and send_raw_response.get("thread_fallback")
```

**上游 bug，本地 git 仓库 `~/.hermes/hermes-agent` 的 HEAD 是
`15cb86e refactor(update): one definition of "first-party module"`（2026-08-01）**，
`git diff HEAD -- cron/scheduler.py` 为空 —— 说明这是**上游就有的问题**，
不是老公本地改坏的。修法建议提 PR 上游，或本地打补丁（改一行）。

⚠️ **写报告时的措辞**：这是"每条早报都触发一次但被 fallback 兜住"的噪音 bug，
**不影响送达**。别写成"飞书推送坏了/全挂了"（误报过一次），
正确说法："live adapter 有 bug，但 fallback 兜住了，日报一条没漏 ✅，根因已定位在 scheduler.py"。

### ⭐ 网关运行时长与内存压力：`~/.hermes/state/gateway.heartbeat`（2026-10-31 实测）

**这是唯一一个能直接回答"系统跑得稳不稳"的权威来源**，比 `ps -ef` 强
（`ps` 只证明进程存在，heartbeat 证明进程还活着且内存情况如何）。
2026-10-31 晨间推送就是靠它写出"gateway 从 10月29日 19:30 连续跑到现在没重启过 ✅"
和"内存只剩 2.6G，swap 用了 13G"。

```bash
cat ~/.hermes/state/gateway.heartbeat
# {"pid": 16961, "updated_at": "2026-10-31T01:01:22.325791+00:00", "monotonic": 187818.72,
#  "start_time": 1793273410.8661048,
#  "mem": {"rss_kib": 187760, "mem_total_kib": 15562024,
#          "mem_available_kib": 2675636, "swap_used_kib": 13670752}}

cat ~/.hermes/state/gateway.lifecycle.json
# {"phase": "running", "pid": 16961, "start_time": 1793273410.87,
#  "started_at": "2026-10-29T11:30:10.872421+00:00"}
```

字段解读：

| 字段 | 含义 | 怎么写进报告 |
|------|------|-------------|
| `phase` (`lifecycle.json`) | `running` = 活的 | 直接写"gateway 运行中 ✅" |
| `started_at` (`lifecycle.json`) | **本地时区** ISO 串（带 +08:00 偏移） | 换算成"10月29日 19:30 启动，连续跑到现在" |
| `pid` | 进程号 | 和 `ps -ef` 交叉验证是不是同一个 |
| `mem.mem_available_kib` | **可用内存**（KB） | ⚠️ 这才是判断 OOM 风险的指标，不是 RSS |
| `mem.swap_used_kib` | **已用 swap**（KB） | 涨到 10GB+ = 内存压力大 |
| `mem.rss_kib` | gateway 自身占用 | 单看这个没用，gateway 占 180M 很正常 |

⚠️ **`updated_at` 是 UTC**（结尾 `+00:00`），而 `lifecycle.json` 的 `started_at` 是**本地时区**。
写"连续跑了多久"用 `started_at`，别拿 `updated_at` 去减 —— 会差 8 小时。
算运行时长用 `started_at` 跟当前时间比。

⚠️ **`mem_available_kib` 只有 2.6G（占 15.5G 总内存的 17%）且 swap 已用 13G** 时，
即使所有服务都正常，也值得在"今日目标"里提一句"别再开新 bot/别同时跑重活"。
这是 Android 环境下 SIGKILL（exit 137）的前兆，见 `android-hermes-memory-management`。

### ⭐⭐ `gateway_state.json` 的 `updated_at` = 判断平台状态是不是"过期"的判据（2026-11-02 实测）

`~/.hermes/gateway_state.json` 里的 `platforms.<name>.updated_at` 是**该平台状态最后一次被写入的时刻**
—— 用它就能判断状态字段是不是陈旧的，**不用只靠 grep 日志**。

2026-11-02 09:01 实测，这个文件长这样：

```json
{"pid": 29847, "gateway_state": "running",
 "platforms": {
   "qqbot":    {"state":"connected","updated_at":"2026-11-02T00:24:29Z"},
   "feishu":   {"state":"connected","updated_at":"2026-11-01T14:28:14Z"},
   "telegram": {"state":"fatal","error_message":"No bot token configured",
                "updated_at":"2026-11-01T14:28:14Z"}},
 "served_profiles": ["default","cutegirl","geekwife","libai","licai","siliconflow","wenyu"]}
```

**两个关键读法**：

1. ⚠️ **`feishu` 和 `telegram` 的 `updated_at` 完全相同（`14:28:14Z`）**
   → 说明这两条是**同一次 gateway 重启时一起写下的**，之后再没更新过。
   而 `qqbot` 的 `updated_at` 晚了 10 小时 → 它在之后成功重连过。
   **同一个时间戳 = 同一批陈旧快照**，这是"状态文件过期"最强的信号。

2. ⚠️ **`telegram` 标 `fatal` + `No bot token configured`，但 `.env` 里 token 明明存在**
   （`config.yaml` 有 `bot_token: ${TELEGRAM_BOT_TOKEN}`，`.env` 里 `TELEGRAM_BOT_TOKEN` 已设置）
   → **这是 11-01 22:27 那次重启时写的旧快照**，不是当前状态。
   实证：当天早上 `gateway.log` 有 `08:59:03 [Telegram] polling restarted after network error`
   → Telegram **在正常重连**，只是在被代理断连反复打断。

**判定规则**：
> 某个平台在 `gateway_state.json` 里是 `fatal`，但**同一个文件里别的平台的 `updated_at`
> 明显更新** → 这条 `fatal` 大概率是**过期快照**。
> 再去 `grep -a "^$(date +%F)" ~/.hermes/logs/gateway.log | grep -ai "<平台>"`
> 看今天有没有该平台的连接活动 —— **有活动 = 状态文件过期，不是真故障**。

⚠️ **别把过期的 `fatal` 写进待办栏**。把它报成"Telegram 挂了"会让老公白分心，
而实际它只是被代理抖得厉害、在自己重连 —— 那是"平台网络 WARNING 是自动恢复噪声"的同一条规律，
只是这次伪装成了 `gateway_state.json` 里的 `fatal`。

⭐ **`served_profiles` 字段有用**：列出当前 gateway 托管的所有 profile
（本次 7 个：default / cutegirl / geekwife / libai / licai / siliconflow / wenyu），
比 `ps -ef | grep hermes` 数进程更准 —— **一个 gateway 托管多个 profile，
所以"进程数"≠"profile 数"**。

### ⚠️ 平台网络 WARNING 大多是"自动恢复噪声"，别当故障写进待办

日志里这类 WARNING 每天都在刷，**adapter 会自动重连恢复**，写进待办会让老公
以为系统坏了，白分心：

```
WARNING ... [Telegram] Telegram polling degraded (heartbeat probe); gateway stays alive and will retry.
WARNING ... [Telegram] Telegram network error (attempt 1/10), reconnecting in 5s.
ERROR   ... Lark: receive message loop exit, err: no close frame received or sent
ERROR   ... Lark: receive message loop exit, err: received 3003 (registered) ping timeout
```

判断标准（和"插件 bug 要 grep `delivered`"是同一枚硬币的两面）：

| 日志 | 是不是真故障 | 怎么处理 |
|------|-------------|---------|
| `attempt 1/10` / `2/10` + 几秒后重连成功 | ❌ 不是，自动恢复 | 不写待办，最多在"系统状态"里一句话带过 |
| Lark `ping timeout` / `no close frame` | ❌ 不是，长连接保活重连 | 同上 |
| `attempt 9/10`、`10/10` 仍在重试 | ⚠️ 可能是真断 | 才值得写待办 |
| `'CreateMessageResponse' object has no attribute 'get'` | ⚠️ 插件 bug，但**要 grep `delivered` 确认是否 fallback 成功** | 见下文"假失败"坑 |
| `cron.scheduler` 的 `delivery error` / `delivered to` | ✅ 这才是投递真相 | grep `delivered` 判送达 |

2026-10-31 实测：昨夜 Telegram 断了 4 次（23:23 / 23:36 / 23:58）、今早 Lark 抖了 5 次，
**全部自动恢复、消息没丢一条** —— 这些不该占待办栏的位置。
待办栏留给"需要老公动手"的事：插件 bug、token 失效、磁盘满。

### ⭐ `hermes cron list` = 最快的 cron 任务清单（2026-10-31 实测，优于解析 jobs.json）

要列"今天哪些 cron 在跑 / 上次跑成功没"，**直接跑 `hermes cron list` 就行**，
比写 python 解析 `jobs.json` 少一轮调用，输出还自带格式化表格：

```bash
hermes cron list
```

输出长这样，每个 job 都带这几行（**比 jobs.json 更全 —— jobs.json 里的健康字段常为空**）：

```
  cd38d14f5563 [active]
    Name:      每日早上回顧
    Schedule:  0 9 * * *
    Next run:  2026-11-01T09:00:00+08:00
    Deliver:   origin
    Last run:  2026-10-30T09:01:39.482417+08:00  ok     ← 上次跑的结果
    Execution: running  01661f9e2dac4da09f187a47b9390804
```

- `Last run: ... ok` = 上次成功；`Execution: running` = 正在跑
- ⚠️ **今天 9 点的 job 在 09:00 跑的时候，`Last run` 可能还显示昨天** ——
  因为当前 job 本身正在执行中。判断"今天跑没跑"要等它变成 `ok`，
  或者去看 `~/.hermes/logs/agent.log` 的 `cron.scheduler` 行。
- ⚠️ **8 个 job 一起列出来会占不少输出**。若只想要状态行，可以
  `hermes cron list | tail -60` 截断，或 `grep -E 'Name:|Last run:'` 过滤。
- ⚠️ 这个命令**会输出全部 8 个 job 的完整 prompt 之外的元信息**，
  但**不包含 prompt 正文** —— 想拿 prompt 线索还是要读 `jobs.json`。

### ⭐ 备份"真的 push 上去了"的验证方法（2026-10-31 实测）

报"备份已完成 ✅"之前，**别只看 `git log` 有新 commit** ——
本地 commit 了但 push 失败是常见假成功。用 `git rev-list` 双向计数确认：

```bash
cd ~/hermes-backup
git log --oneline -3          # 最新 commit（应该带当天日期）
git log origin/main --oneline -3   # 远端最新 commit ← 关键：这两个要对得上
git rev-list --count origin/main..main   # 0 = 已全部推送 ✅
git rev-list --count main..origin/main   # 0 = 没有远端领先
```

实测结果：`origin/main` 的 HEAD 和本地 HEAD 都是 `21f1a73 Backup 2026-10-31 03:01`，
双向计数都是 `0` → 确认推送成功。

⚠️ **备份仓库有多个同名目录，别搞错**：`~/hermes-backup`（活跃，git remote 正常）、
`~/hermes-backup-git`（停在 10-22）、`~/hermes-backup-repo`（停在 9-10）、
`~/hermes-backup-old`、`~/hermes-backup-daily`（tar.gz 目录）。
**只有 `~/hermes-backup` 是当前在用的** —— 报告里引用 commit hash 前先确认目录，
否则会引用到两个月前的陈年 commit。

### 读 `jobs.json` 当"任务清单"用（不只是健康字段）

除了取 `last_error`，`jobs.json` 还有两个用途值得单独跑一轮：

```bash
cd ~/.hermes/cron && python3 -c "
import json
j=json.load(open('jobs.json'))
jobs = j if isinstance(j,list) else j.get('jobs',[])
for x in jobs:
    print('-',x.get('id'),'|',x.get('name'),'|',x.get('schedule'),'|',x.get('prompt','')[:150].replace(chr(10),' '))
"
```

1. **看今天还有哪些 cron 一起在跑** —— 早上 9 点有 4 个 job 同时启动
   （早报 / 简报 / AI 日报 / 本推送）。列出来能确认"兄弟任务都起来了"，
   也能看出**推送重复风险**（老公会同时收到 3 份早报，格式雷同）。
2. **读别的 job 的 prompt = 免费拿到"老公还想要什么模块"的线索** ——
   prompt 里会写明它想读哪些路径（如 `~/.calendar/calendar.ics`、`notes/tasks.md`），
   顺手 `ls` 验证一下这些路径是否真存在，**别照抄**（实测多数不存在）。
   ⚠️ `jobs.json` 顶层可能是 list 也可能是 `{"jobs":[...]}`，脚本里两种都要兼容。

### 天气：open-meteo（不用装东西）

`weather.com.cn` 之类的页面 `web_search` 只能拿到模板页，**没有真实当天数据**。
用 open-meteo API，直连、无需 key、返回 JSON：

> ⚠️⚠️ **2026-10-31：`web_search` 本身整个挂了。**
> `web_search("北京今天天气...")` 和 `web_extract(...)` **同时**返回
> `Client error '432 '`（Tavily 后端拒绝）。这不是"页面没数据"，是**搜索后端在拒绝调用**，
> 换个查询词、换个 URL 都没用。
> **正确应对：别在 web_search 上试第二轮，直接 `curl` 打上面这些 keyless API**，
> `python3 -c` 解析，10 秒钟出结果（本次实测 wttr.in 直连一次成功）。
> ⚠️ 这是配额/凭证层的状态，不是功能坏了 —— 下次运行要重新试，
> 但**不要因为这次失败就在报告里写"天气查不到"**，一定有 fallback 源。

```bash
curl -s --max-time 25 'https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,sunrise,sunset&timezone=Asia%2FShanghai&forecast_days=1'
```

- `weather_code` 是 WMO 编码：`0`=晴，`1-3`=多云，`51-67`=雨，`71-77`=雪，`95`=雷雨
- `daily` 同时给 max/min/日出/日落/降水概率，够写"带外套"这种实用建议了
- 昼夜温差 = `temperature_2m_max - temperature_2m_min`，超过 10℃ 就提醒带外套
- **注意**：返回的 `latitude/longitude` 是网格点（39.89/116.36），不是精确城市中心，正常用

#### ⭐ wttr.in = 空气质量补充源（2026-10-30 实测，比 open-meteo 多"霾"信息）

北京秋冬季有**烟霾**，open-meteo 的 `weather_code` 编不出霾，
但这恰恰是最需要提醒老公戴口罩的天气。**wttr.in 的 `weatherDesc` 直接给
`Smoky haze` / `Smoke` 这类描述**，还带体感温度和逐 3 小时预报：

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=j1" | python3 -c "
import sys,json
d=json.load(sys.stdin)
c=d['current_condition'][0]
w=d['weather'][0]
print('NOW:',c['temp_C']+'C',c['weatherDesc'][0]['value'],'hum',c['humidity']+'%','wind',c['windspeedKmph']+'km/h',c['winddir16Point'],'feels',c['FeelsLikeC']+'C')
print('min',w['mintempC'],'max',w['maxtempC'])
print('sunrise',w['astronomy'][0]['sunrise'],'sunset',w['astronomy'][0]['sunset'])
for h in w['hourly']:
    print(h['time'],h['tempC']+'C',h['weatherDesc'][0]['value'],'rain%',h['chanceofrain'],'wind',h['windspeedKmph'])
print('--- 3day ---')
for day in d['weather'][1:3]:
    print(day['date'],'min',day['mintempC'],'max',day['maxtempC'])
"
```

⚠️ **wttr.in 的坑**：
- 返回里**没有 `lang_zh` 字段**（跟某些版本文档不符）。直接访问 `c['lang_zh']`
  会抛 `KeyError: 'lang_zh'` —— **只用 `weatherDesc[0]['value']`**（英文原值，
  翻译成中文时自己写"烟霾""晴""多云"即可）。
- `time` 字段是 3 小时制整数（0/300/600/900/1200/1500/1800/2100），
  不是 HH:MM，读的时候别当成时间戳解析。
- 逐时 `hourly` 数组同时给了 `chanceofrain` 和 `windspeedKmph`，
  中午风大（实测 23km/h）比降水更值得写进出行提醒。
- 3 天预报在 `d['weather'][1:3]`，可以直接写"明天降温到 X℃"的预告。

⭐⭐ **最省事的一条命令版（2026-11-01 实测，推荐用于早报）** ——
wttr.in 支持自定义 format，**不用 python 解析 JSON**，一条 curl 直接出可读文本：

```bash
curl -s -m 25 "https://wttr.in/Beijing?format=%25l:+%25C+%25t+feels+%25f+wind+%25w+humidity+%25h"
# Beijing: Smoky haze +9°C feels +8°C wind ↘11km/h humidity 59%
```

⚠️ **`%` 必须转义成 `%25`** —— 不转义的话 shell/URL 编码会把 `%C` `%t` 吃掉，
返回的是空串或乱码。这是这条命令唯一的坑。
一次就拿到：地名、天气描述（含霾）、当前温度、体感温度、风向风速、湿度。

⭐ **配合 open-meteo 的紧凑版**（2026-11-01 实测，一条 curl 出 max/min/降水概率/体感）：

```bash
curl -s -m 25 "https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&timezone=Asia%2FShanghai&forecast_days=1"
```

实测返回：`{"current":{"time":"2026-11-01T09:00","temperature_2m":7.3,...,"apparent_temperature":5.6},"daily":{"temperature_2m_max":[16.6],"temperature_2m_min":[5.4],"precipitation_probability_max":[27]}}`
→ 早报天气栏直接写：当前 7.3℃（体感 5.6℃）/ 今日 5.4~16.6℃ / 降水概率 27% / 有霾。
**两条 curl 直连，不需要 web_search、不需要代理、不需要 key。**

⚠️ **2026-11-01 再次确认 `web_search` + `web_extract` 同时 432** ——
搜"北京今天天气 2026年11月1日 温度"直接 432，换 URL 也 432（`wttr.in` 经
`web_extract` 同样 432，因为它走的也是 Tavily extract 后端）。
**结论不变：天气永远走 `curl` 直连，不要浪费轮次在 web_search 上。**
而且**别在报告里写"天气查不到"** —— curl 一定能查到。

⚠️⚠️ **2026-11-03 修正：432 是间歇性的，而且 `web_extract` 会静默返回陈旧日期**
当天 `web_search` **正常返回了真实结果**（搜"北京 上海 今天 天气"拿到气象局页面摘要），
说明 Tavily 后端的 432 是**间歇性**的，不是永久失效。
→ **别把"web_search 挂了"当硬规则写进流程**，但也别指望它 —— 天气照旧 curl 直连，
`web_search` 只当补充。

⭐⭐⭐ **`web_extract` 打 wttr.in 会返回 CACHED / STALE 的预报（2026-11-03 实测踩坑）**
当天 `web_extract("https://wttr.in/Beijing?format=j1")` **成功返回了 JSON**（不是 432），
但里面的 `weather[0].date` 是 **2026-10-30**、`weather[1].date` 是 10-31 —— **全是好几天前的陈旧缓存**。
如果照抄进报告，写出来的就是"今天是 10 月 30 日的天气"，比查不到还糟。
⚠️ **判据：解析完 wttr.in 的 JSON 后，先核对 `weather[0]['date'] == $(date +%F)`，
对不上就是陈旧缓存 —— 立刻改用 curl 直连或换源，别写进报告。**

⭐⭐⭐⭐ **2026-11-03 21:00 再测：Tavily 双 432 时，curl 直连 wttr.in 依然成功（21:00 那轮）**
同一天晚上 21:00：`web_search` + `web_extract` **又同时 432**
（`Client error '432 ' for url 'https://api.tavily.com/search'`），
但 `curl -s --max-time 15 "https://wttr.in/Beijing?format=j1"` **一次成功**，
返回 JSON 日期正确（`weather[0].date = 2026-11-03` ✅）。
→ **再次确认：天气永远走 curl 直连，432 时更不要浪费轮次在 web_search 上。**
（同日 09:00 那轮反而是 Tavily 正常、curl 返回 0 字节 —— **两个源轮流抽风，
所以两个都要会，每次按"谁成功用谁"来。**）

⭐⭐⭐⭐⭐ **晚间报告要写的是"明天"，`w[1]` 才是明天（2026-11-03 21:00 实测）**
```bash
curl -s --max-time 15 "https://wttr.in/Beijing?format=j1" | python3 -c "
import sys,json
d=json.load(sys.stdin); w=d['weather']
print('今天:',w[0]['date'],'min',w[0]['mintempC'],'max',w[0]['maxtempC'],w[0]['hourly'][4]['weatherDesc'][0]['value'])
t=w[1]
print('明天:',t['date'],'min',t['mintempC'],'max',t['maxtempC'],t['hourly'][4]['weatherDesc'][0]['value'])
"
# 2026-11-03 21:00 实测输出：
#   今天: 2026-11-03 min 7 max 18 Sunny
#   明天: 2026-11-04 min 7 max 16 Smoky haze
```
⚠️ **21:00 的天气栏提醒的是"明天出门"** —— `w[0]`（今天）已经过完了，
写它没意义；`w[1]` 才是老公明天早上真正用得上的。
⚠️ `hourly[4]` 取的是当天 12:00 那档（3 小时步长），温度描述用它的 `weatherDesc[0]['value']`。
⚠️ **英文描述自己翻**（`Smoky haze` → "有霾/烟霞"），本库没有 `lang_zh` 字段。

⭐⭐⭐ **HKO 香港天文台 = 中国城市预报的可靠第三源（2026-11-03 实测，最适合"中文城市 + 当天日期"）**
`https://www.hko.gov.hk/textonly/v2/other/iwccc.htm` 是纯文本页，
`web_extract` 就能拿到**带发布时间的当天中国各大城市天气表**（min/max + 中文天气描述），
实测一次调用同时拿到北京和上海，**不卡日期、不需要 key、不需要代理**：

```
香 港 天 文 台 在 11 月 2 日 下 午 12 時 15 分 發 出 11 月 3 日 中 國 各 大 城 市 天 氣 消 息
...
上海 SHANGHAI 13 20 OVERCAST 密 雲
北京 BEIJING 3 18 FINE 天 晴
```

⚠️ **两个注意点**：
1. 页面顶部写的是"**发布于昨天 12:15 的、预报今天**"的公告 —— 看到 "11 月 3 日" 才是今天的表，
   别被 "發出" 那行的日期搞混。
2. HKO 只有城市名 + min/max + 天气描述，**没有体感/湿度/风力**。
   → 想要体感/风力/空气质量，还是得靠 wttr.in 的 curl；HKO 适合做**交叉验证 + 日期锚点**。

⭐ **天气源组合拳（2026-11-03 修订版）**：
| 源 | 用途 | 注意 |
|---|---|---|
| `curl wttr.in/...?format=j1` | 体感/湿度/风/霾 | ⚠️ `web_extract` 打它会返回陈旧缓存，必须 curl；⚠️ **curl 也可能返回 0 字节** |
| **`web_search` 带日期查 nmc.cn** | **当天 min/max + 中文天气 + 风（主源）** | ✅ **2026-11-03 实测唯一成功**，日期写在行里 |
| **`web_extract` nmc.cn/publish/forecast/ABJ/beijing.html** | 同上，表在 markdown 里 | ✅ 可 `read_file` 读缓存 |
| `curl open-meteo` | max/min/日出日落/降水概率 | 永远直连 |
| `web_extract hko.gov.hk/.../iwccc.htm` | 中国城市当天 min/max + 中文描述 | ✅ 日期可靠，一次出多城 |
| `web_search` | 补充气象局预警（如"北方大风降温"） | ⚠️ 间歇性 432，当补充不当依赖 |

⚠️ **组合拳的顺序要按"当天日期可靠性"排**：NMC/HKO 的表里写着日期 →
wttr.in/open-meteo 的 `date` 字段要自己核对 → 天气栏宁可只写"min/max + 天气 + 风"，
也别把陈旧日期的体感温度写进报告。

**天气栏组合拳**：open-meteo 拿 max/min/日出日落/降水概率，
wttr.in 拿空气质量描述 + 体感温度 + 逐时风速。两者都直连，无需 key。

#### ⭐ weather.com.cn 的实况 JSON 接口（最快，1 个 curl 出当前温度）

```bash
curl -s --max-time 25 "https://www.weather.com.cn/data/sk/101010100.html" \
  -H "Referer: https://www.weather.com.cn/" -H "User-Agent: Mozilla/5.0"
```

返回：
```json
{"weatherinfo":{"city":"北京","temp":"18","WD":"东南风","WS":"1级","SD":"17%","time":"17:05","rain":"0"}}
```

⚠️ **必须带 `Referer: https://www.weather.com.cn/` 和 UA**，否则被拒。
⚠️ `data/cityinfo/101010100.html` 现在 **301 跳转**，别用那个旧路径。
这个接口只给当前实况（不含预报），当"现在的体感"补充用。

### 可用数据源（按可靠性排序）

```bash
# 1. 当前日期（中文格式）
date "+%m月%e日 周%w"   # 输出如：08月21日 周5

# 2. 昨天各 cron job 的实际产出 —— 最有价值的一手材料
#    目录结构：~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md
ls -t ~/.hermes/cron/output/*/ | head
#    重点读：昨晚 21:00 的「每日晚9点回顾推送」输出，它里面已经列好了"明日待办"
#    → 直接把它的"明日待办"搬进今天的待办栏
read_file ~/.hermes/cron/output/<job_id>/<yesterday-file>.md

# 3. 所有定时任务清单（含开关状态和 prompt 摘要）
cd ~/.hermes/cron && python3 -c "
import json
d=json.load(open('jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
if isinstance(jobs,dict): jobs=list(jobs.values())
for j in jobs:
    print(j.get('name'),'|',j.get('schedule'),'| enabled=',j.get('enabled'))
"

# 4. 知识库笔记 / 事实
ls ~/.hermes/knowledge/facts/ ~/.hermes/knowledge/notes/ ~/.hermes/knowledge/我是老公/

# 5. 各 profile 健康状态
for p in cutegirl geekwife libai licai siliconflow wenyu; do
  echo -n "$p: "; ls ~/.hermes/profiles/$p/.env >/dev/null 2>&1 && echo "env ok" || echo "no env"
done
ps -ef | grep -Ei "hermes" | grep -v grep | awk '{print $2, $9, $10, $11}'

# 6. 备份状态（github 仓库 ~/hermes-backup）
ls -la ~/hermes-backup-daily.tar.gz
cd ~/hermes-backup && git log --oneline -1 && git status --short
```

### 日历 / 邮件：先判断有没有配

**不要一上来就 `google_api.py calendar list`** —— 没认证会直接报错。

```bash
ls ~/.hermes/google_token.json ~/.hermes/google_client_secret.json 2>&1
```

- 缺这两个文件 → Google 日历/Gmail **没配**，日程直接写"今天没有安排～"，不要浪费时间尝试
- `himalaya` 也没装（`which himalaya` 为空）→ 邮件同样没有来源
- 更好的判断方式：`skill_view("google-workspace")` 的返回里有
  `readiness_status: setup_needed` / `missing_credential_files` 字段，一眼就能看出来
- `gws` CLI 不存在也说明 Workspace 集成没启用

**结论：老公当前环境没有可用的日历/邮箱数据源，晨间推送的"今日日程"固定填"今天没有安排～"，
待办从 cron 历史输出 + 知识库 + session 历史推。**

### ⭐ 飞书群消息摘要：从 agent.log 的 inbound message 取（2026-10-30 实测）

晨间简报的"飞书群消息摘要"栏**没有现成的摘要文件**，要从平台日志重建。
`~/.hermes/logs/agent.log` 里有完整的收发记录：

```bash
# 最近的入站消息（各平台都有）
grep -a "inbound message" ~/.hermes/logs/agent.log | tail -20 | cut -c1-320

# 只看飞书 —— ⚠️ 用 platform=feishu 过滤，不要用 "feishu"（2026-11-01 实测）
grep -ah "inbound message" ~/.hermes/logs/agent.log ~/.hermes/logs/agent.log.1 2>/dev/null \
  | grep -a "platform=feishu" | tail -12 | cut -c1-380
```

⚠️ **2026-11-01 实测修正**：上面第二种"只看飞书"的写法
（`grep -a "feishu" ... | grep -a "inbound\|text="`）**匹配不到任何东西** ——
飞书的 inbound 行里 `platform=feishu` 是**字段值**，
而 `grep -a "feishu"` 会先命中同文件里大量 `ERROR Lark:` / `Lark: connect failed` 行，
`head`/`tail` 截断后真正的 inbound 行被冲掉了。
**正确做法**：先 `grep -ah "inbound message"`（用 `-h` 避免多文件时打 `file:` 前缀），
再 `grep -a "platform=feishu"`。2026-11-01 用这个写法一次命中 3 条（10-23 的"在吗"/"抱抱"）。

⚠️ **当天 `agent.log` 里的 inbound 可能只有 1 条** —— 2026-11-01 实测
`grep -ac "inbound message" agent.log` 返回 **1**，而 `.1`（10-30 之前）里有更多。
**只看当天文件会漏掉历史**，务必带上 `.1`/`.2`/`.3` 一起 grep。
另外 `grep -a "inbound message" agent.log | grep -a "chat=oc_"` 这个写法**在当天文件上返回空**
（因为当天那条不是飞书群消息），别据此以为"飞书群没消息"—— 去掉 chat= 再看平台字段。

⭐⭐⭐ **2026-11-03 再次确认：同一条 inbound 行会在多个文件里重复出现（2026-11-03 实测）**
`grep -ah "2026-11-02" ~/.hermes/logs/*.log | grep -aE "inbound message"` 返回 6 行，
但**其中每一行都出现两次**（`agent.log` 和 `gateway.log` 各一份同样的内容）
→ 实际只有 **3 条**真消息（老公的「爱你」「抱抱」「爱你」）。
⚠️ **统计昨天消息条数时必须去重**（`| sort -u` 或 `awk '!seen[$0]++'`），
否则"昨天老公说了 6 句"会是假的 —— 报告里写条数会被老公当场看穿。
判据：真 inbound 行 = `INFO gateway.run:` 前缀 + `platform=` 字段（见下）。

⭐⭐⭐ **真实 inbound vs 工具输出回显：必须用 `INFO gateway.run:` 前缀锁死（2026-11-03 再验证）**
2026-11-03 实测，去掉前缀的 grep 抓到了**别的 cron job 把自己的 terminal 输出抄进日志**的行：
```
WARNING [cron_c51c6ca0d139_20261101_090048] agent.tool_executor: Tool terminal returned error (12.19s):
{"output": "...inbound message: platform=feishu user=ou_c696f8f4d082ba11770301e40ee40063 chat=oc_6138107aed3480fcb94..."}
```
引号里的 `inbound message:` 是**字符串**，会把 10-23 的假记录算进"今日群消息"。
**唯一可靠的过滤链**（四步全带上）：
```bash
grep -ah "inbound message" ~/.hermes/logs/agent.log ~/.hermes/logs/gateway.log ~/.hermes/logs/agent.log.1 2>/dev/null \
  | grep -a "INFO gateway.run:" \
  | grep -a "platform=" \
  | grep -a "^$(date +%F)" \
  | sort -u | cut -c1-380
```
- `INFO gateway.run:` —— 排除工具回显（回显是 `WARNING [cron_xxx] agent.tool_executor:`）
- `platform=` —— 字段过滤，不是 `grep "feishu"`（后者会先命中满屏 `ERROR Lark:`）
- `^$(date +%F)` —— 锚定当天（注意日志时间戳是 `2026-11-02 19:33:41,237`，日期和時間**中间有空格**）
- `sort -u` —— 去掉 agent.log / gateway.log 的重复行

⚠️ **昨天到底有没有飞书消息，看这条链子的结果**。2026-11-03 实测：
**昨天飞书 inbound = 0 条**（最后一条真飞书 inbound 停在 10/23），
但 Telegram 有 3 条（老公晚上戳老婆们）。→ 报告里要**分平台说**，
写"飞书群里没动静"的同时要说"老公晚上在电报上说了 3 句"，
**别笼统写"昨日无消息"**（老公明明在电报上说话了，会觉得老婆没在看）。

⭐⭐⭐⭐ **2026-11-04 09:00 再测：这条链子一次跑完，"群里安静"是真实结论**
当天 `agent.log` 里只有 2 条真 inbound，全是 Telegram：
```
2026-11-04 03:08:42,321 INFO gateway.run: inbound message: platform=telegram user=胖蝦球 chat=877708648 msg='爱你'
2026-11-04 03:42:21,789 INFO gateway.run: inbound message: platform=telegram user=胖蝦球 chat=877708648 msg='爱你'
```
**任务群 `oc_457ae...` 的人工 inbound = 0 条**，但**同一份日志里同时有**
当天早报的 `delivered to feishu:oc_457ae34d4ae483c1ff40716be1c165cb` 记录
（job `cd38d14f5563` / `27957f101f60` / `4346b6b5808d` 三条，全 `delivered` ✅）。
→ **"群里没人说话"和"群里的早报到了"是两件事，分开写**：
群里安静（人工消息 0 条，最近一条停在 10/23），
但今早 09:01-09:05 三条早报**都成功投递进群** ✅。
⭐ **这一轮同时给出了"无人工消息"的两个平行为真**：
(a) 四步过滤链查 inbound；(b) `cron.scheduler` 的 `delivered` 查送达。
**两条 grep 就够，别为"群里有没有东西"去翻更多日志。**
⚠️ 顺带：**`agent.log.1` 里 11-01/11-02 的 Telegram inbound 会被 `sort -u` 保留**，
`sort -u` 只去重相同行，不会跨日期合并 —— 但 `grep "^$(date +%F)"` 已经把日期锚死了，
**双重保险**：前者保证跨文件不重复，后者保证只看当天。

日志行长这样（`platform=feishu/telegram/qqbot`，带 chat_id 和消息正文）：
```
2026-10-29 19:27:08,710 INFO gateway.run: inbound message: platform=telegram
  user=胖蝦球 chat=877708648 msg='逼毛给老婆电报bot启动下' reply_to_id=1703
```

⚠️ **两个坑**：
1. **`agent.log` 会轮转**（`agent.log` / `agent.log.1` / `.2` / `.3`，
   实测各约 5MB）。较老的记录在 `.1`/`.2` 里，**查历史要一起 grep**：
   ```bash
   grep -a "inbound message" ~/.hermes/logs/agent.log ~/.hermes/logs/agent.log.1 2>/dev/null | tail -25
   ```
2. **飞书群消息实际很少**（实测最近一条飞书 inbound 停在 10/23，
   群里基本没人说话）。**查不到就老实写"暂无摘要"，别编。**
   可以顺带说明"最近一条记录停在 X 月 X 日"，让老公知道不是取数失败。

⭐⭐⭐⭐⭐ **飞书长连接"连不上"和"抖动"是两回事，别都当噪声（2026-11-04 实测）**

`ERROR Lark: connect failed, err: HTTPSConnectionPool(host='open.feishu.cn', port=443):
Max retries exceeded with url: /callback/ws/endpoint (Caused by SSLEOFError(8,
'[SSL: UNEXPECTED_EOF_WHILE_READING] ...'))` —— 这是**建连阶段就失败**，
和 `Lark: receive message loop exit`（连上了、保活掉了）是**两种故障**。

**判别方法（2026-11-04 实测，三条命令）**：
```bash
# 1. connect failed 累计次数（分天）
grep -h "2026-11-03\|2026-11-04" ~/.hermes/logs/agent.log ~/.hermes/logs/agent.log.1 2>/dev/null \
  | grep -c "Lark: connect failed"
# → 18 次（其中今天 10 次）

# 2. 第一次失败的时间
grep -h "2026-11-0" ~/.hermes/logs/agent.log* 2>/dev/null | grep "Lark: connect failed" | head -3

# 3. 最后一次成功建连（这才是"连接状态"的真身）
grep -h "2026-11-0" ~/.hermes/logs/agent.log* 2>/dev/null \
  | grep -i "Lark.*connected\|feishu.*connected" | grep -v "connect failed" | tail -4
```

⚠️ **本轮实测的判定**：最后一次 `Lark: connected` 是 **11-02 19:32**，
之后 `connect failed` 连续三天零星出现（11-03 18:44 起、11-04 10 次），
`receive message loop exit` 今天也记了 10 次 → **飞书长连接自 11-02 起就没真正稳过**。

⭐⭐ **但"连不上"≠"消息发不出去"** —— 两条链路是分开的：
- **出站（cron 投递）** → 走 HTTP API，**照常送达**。2026-11-04 09:01 实测
  `Job '27957f101f60': delivered to feishu:oc_457ae... via live adapter` ✅
- **入站（老公在群里@我）** → 依赖 WebSocket 长连接，**断了就收不到**

→ **报告里要写成"长连接断，但早报照送"**，而不是笼统说"飞书坏了"或
"飞书没问题"。**影响面要写清楚：老公在群里 @ 我可能我不一定秒回。**
这正是本轮「📬 昨日飞书消息要點」栏该说的内容。

⚠️ **别把 `Lark: connect failed` 单独写进待办栏当"要修的 bug"** ——
它是网络层（代理/SSL）问题，adapter 会自己重试。
**只有当它持续跨天、且 `Lark: connected` 的时间戳明显停在过去时**，
才值得写一句"长连接不稳"，且要**和"消息仍送达"分开写**。
**判据：多平台同窗断 = 底层网络；单平台反复断 = 该平台自己的问题**（见下）。

⭐⭐⭐⭐⭐ **同一时间窗多平台集体断线 = 底层网络，不是平台问题（2026-11-03/04 实测）**

2026-11-03 18:51-18:58 这 7 分钟里：Telegram 反复 `Disconnected` +
QQBot 反复 `WebSocket closed` + Lark `ping timeout`，随后 18:57-18:58 全部自愈重连。
2026-11-04 03:15 / 07:06 / 07:08 / 07:10 / 07:12 / 07:14 / 07:16 又出现
Lark `connect failed`（SSL EOF）密集重试。

**报告写法：合并成一句"网络抖了一轮，N 分钟内全部自愈"**，
**别拆成两个平台各报一次故障** —— 那会让老公以为要修两个东西，实际只需盯代理。

**判据表**：
| 现象 | 判定 | 报告里怎么写 |
|---|---|---|
| Telegram + QQBot + Lark 同窗断 | 底层网络/代理 | 一句"网络抖了一轮，已自愈" |
| 只有 Lark `ping timeout` | 长连接保活重连 | 噪声，不进待办 |
| 只有 Lark `connect failed` 且持续跨天 | 长连接不稳 | 写"长连接不稳，但消息仍送达" |
| `attempt 9/10`、`10/10` 仍失败 | 真断 | 才值得写待办 |

⚠️ **QQ 的 `code=4009 reason=Session timed out` 是正常 session 轮换**，不是故障。

### ⭐ 群名 ↔ chat_id 映射（写摘要时用得上）

`~/.hermes/channel_directory.json` 里 `platforms.feishu` 数组含全部 `oc_xxx`，
有的条目 `name` 是群名、有的只是 ID：

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/channel_directory.json'))
for it in d['platforms']['feishu']:
    print(it['id'],'|',it['name'],'|',it['type'])
"
```

老公的群：id `oc_457ae34d4ae483c1ff40716be1c165cb`，
在 directory 里 name 显示为「飞书用户3923MS」；群里另有一个
`oc_4c9d07126349124f942e382f7501b189`（「飞书用户3923MS的组织」）。
⚠️ **cron job 的飞书投递目标就是这个 `oc_457ae...`** ——
投递失败时它就是排查入口。

## 报告格式模板

```
🌅 老公早上好！X月X日 周X

📅 今日日程：[从日历/Gmail读取今日事件，没有就说"今天没有安排～"]

📋 待办事项：[列出未完成的重要事项，没有就说"今天轻松过～"]

💪 今日目标：[根据待办给出1-3个重点建议]

加油老公！💖
```

### 本简报 prompt 的四模块变体（"每日9点回顾推送" cron, job `27957f101f60`）

除了五模块的「早上9点简报」，老公还有一个**四模块**的晨间推送 job
（`27957f101f60`「每日9点回顾推送」），prompt 固定四段：

```
🌅 老公早上好！X月X日 周X
📅 今日日程：[日历/Gmail，没有就说"今天没有安排～"]
📋 待办事项：[列出未完成的重要事项]
💪 今日目标：[根据待办给出1-3个重点建议]
加油老公！💖
```

⚠️ **这个 job 的 prompt 和「早上9点简报」几乎同名，容易混**。区别：
- `27957f101f60` = 四模块（本文节），**没有**天气栏、**没有**飞书群摘要栏
- `c51c6ca0d139` = 五模块（日程/群摘要/工作进度/天气/自定义）

两个 job **都在早上 9:00 跑**（实测 09:00:24 同时启动 4 个 cron）。
所以老公早上会收到两份高度相似的早报 —— 这是他的配置，**不要在报告里吐槽重复**，
但也别自己再造第三份雷同内容。

⭐⭐⭐⭐ **2026-11-03 再次实测：curl 打 wttr.in 会返回空 body → 改用中央气象台（nmc.cn）**

2026-11-03 09:00 实测（正是五模块简报这一版）：
```bash
curl -s -m 30 --socks5-hostname 10.1.252.196:7891 "https://wttr.in/Beijing?format=j1" | python3 -c "..."
# → JSONDecodeError: Expecting value: line 1 column 1 (char 0)   ← 零字节
```
⚠️ **而且 `curl -o` 的报错会误导人**：`-o /tmp/bj.json` 和 `-o ~/bj.json` **两个都报**
`No such file or directory` —— 但 `~/` 明明可写。**真正原因是抓取本身返回 0 字节**，
curl 建不出带内容的文件。**别照着路径去查**，先量字节数：
```bash
curl -s -m 25 --socks5-hostname 10.1.252.196:7891 '<URL>' | wc -c
```
字节数是 0 = **源的问题**（换源），不是落盘路径的问题。

⭐⭐⭐⭐ **2026-11-04 实测：两个 curl 天气源可以同时成功（Tavily 432 的最佳反制）**
2026-11-04 09:00 这一轮：`web_search` 连续两次 432（Tavily 拒绝），但
**`curl wttr.in/Beijing?format=j1` 和 `curl open-meteo` 在同一次 `terminal` 调用里双双成功**，
且 wttr.in 返回的 `weather[0].date` = **2026-11-04（当天，正确）**。
→ 天气栏一次写全：**wttr.in 给体感/湿度/风/霾描述 + open-meteo 给 min/max/降水概率**。
⚠️ **仍然必须核对 `weather[0]['date'] == $(date +%F)`** —— 这次对了不等于下次也对。
⚠️ **不要因为 Tavily 432 就写"天气查不到"** —— 2026-11-04 证明 432 时 curl 双源全好。
**这一轮的做法就是标准答案**：Tavily 432 → 不试第二轮 `web_search` →
**一条 `terminal` 里同时 curl 两个源**（用 `; echo "---FALLBACK---";` 分隔）→ 解析后核对日期。
⭐ **两个 curl 写在同一条命令里**，一轮拿全，省一次工具调用。

⭐⭐⭐⭐⭐ **中央气象台 nmc.cn = 本次实测唯一成功的天气源（日期可靠、中文、可直接引用）**

`web_search` 带上日期 + 天气要素，**结果 description 里直接内联完整 7 天预报表**：
```bash
# web_search("北京 11月3日 天气 白天 最高温 最低温 晴 冷空气")
→ result description:
    11/03  周二  晴   东风  微风  16℃  4℃
    11/04  周三  阴   南风  微风  13℃  4℃
```
每行格式 = `MM/DD + 星期X + 中文天气 + 风向 + 风力 + 最高℃ + 最低℃` —— **日期就写在行里**，
不存在 wttr.in 那种陈旧缓存风险。

`web_extract("https://www.nmc.cn/publish/forecast/ABJ/beijing.html")` 也能拿到这张表
（页面其余部分是导航链接，但预报表在抽取后的 markdown 里，会缓存到磁盘，
可以用 `read_file` 读缓存文件直接看行）。缓存里的行是逐行分开的：
```
11/03
周二
晴
东风
微风
16℃
4℃
```
⚠️ 页面更下方还有**逐 3 小时观测表**（`03日02:00` / `08:00` / `14:00` + 气温/风速/气压/湿度/云量），
那里的 `03日`、`04日` 是**最强的日期锚点** —— 写报告前先对一下这个。

⚠️ **NMC 没有体感/湿度/空气质量/降水概率** —— 想写"戴口罩"（霾）还是得靠 wttr.in。
所以天气栏的组合拳改成：**NMC 出当天 min/max + 中文天气 + 风**（主源，日期可靠），
**wttr.in 能拿到就补体感/湿度/霾**（补充，拿不到就不写霾）。

⚠️ **`web_extract` 打 wttr.in 仍然返回陈旧日期**（本次再次确认：返回的是 10-30/10-31 的预报），
和 2026-11-03 早前记录一致 → 解析后必须核对 `weather[0]['date'] == $(date +%F)`。

⭐⭐⭐⭐⭐ **别写"天气查不到"** —— 本次 NMC 的表就在 `web_search` 结果里躺着，
照着抄就能给出"晴转多云 4~16℃ 昼夜温差 12℃ 建议穿外套"这种有用结论。

#### ⭐⭐⭐⭐ 第四种变体：「每日小助手」三段式（2026-11-03 09:00 实测到）
本 job 的 prompt 是**又一套版式**（与前三种都不一样），是"你是老公的每日小助手"开头：
```
🌅 老公早上好！X月X日 周X
📅 今日日程：[从日历/Gmail读取今日事件，没有就说"今天没有安排～"]
📋 待办事项：[列出未完成的重要事项]
💪 今日目标：[根据待办给出1-3个重点建议]
加油老公！💖
```
⚠️ **别把「第三种变体」（📬 消息要点 / 📊 任务完成 / 💡 待跟进 / 🌤️ 天气）和它搞混** ——
本变体**有日程栏**、**没有**天气栏、**没有**群摘要栏。
判据：prompt 里有「你是老公的每日小助手」或「💪 今日目标」→ 就是本变体。

**本变体的取数要点（2026-11-03 实测，9 轮工具调用足够）**：
1. `date "+%Y-%m-%d %A %H:%M"` → 确认日期和星期（一次拿到，不用另查）
2. `skill_view("google-workspace")` → 看 `readiness_status` 判日历有没有配（**不花调用去试 API**）
3. `ls ~/.hermes/kanban.db` + `python3 -c` 查 `tasks` 表 → 确认看板空不空（**通常是空，别当主要待办源**）
4. `session_search()` browse → 拿最近会话（cron 产出 + 老公真实交互会话）
5. `~/.hermes/cron/jobs.json` → 读 job 名/schedule/enabled（**用 `jobs.json` 不是 `hermes cron list`**，
   因为要 join `executions.db` 拿 job 名）
6. `~/.hermes/cron/executions.db` → 最近成败（**按 `started_at` 排，见 `hermes-sqlite-inspection.md`**）
7. `~/.hermes/cron/output/*/` → 昨晚 21:00 晚间总结的 `## Response` 正文 = **现成的"明日待办"**
8. `~/.hermes/logs/agent.log` + `errors.log` + `errors.log.1` → 投递成败 + 插件 bug
9. `df -h` / `free -m` / `ps -ef` → 磁盘/内存/gateway（**磁盘要 `du -sh ~/.hermes/*` 看大头**）

⭐⭐⭐ **本变体最重要的纪律：别继承上一轮报告的"事实"**（2026-11-03 实测踩坑）：
昨晚 21:00 的晚间总结写了一条待办「**tirith 安全工具路径丢失（`~/.hermes/bin/tirith` 不存在），熔断器已触发**」，
当天 `ls -la ~/.hermes/bin/` 一查 —— **`tirith` 一直在，19MB，权限正常**，
上一轮那条**完全是错误结论**。照抄进今天的待办栏 = 让老公为不存在的故障分心。
→ **每轮开头重新 `ls` / `df` / `free` / `ps` 实证一遍再写待办。**
**兄弟 job 的报告正文是"素材"，不是"事实源"。**

⭐⭐⭐ **待办栏写"根因 + 文件:行号 + 一行修法"，别复述现象**（2026-11-03 正确写法）：
❌ "飞书插件 bug，早报三个都挂了"（现象 + 不准确）
✅ "根因在 `cron/scheduler.py:1913` 对 Lark SDK 对象调 `.get()`（该对象无此方法）；
    适配器本身是干净的，别去改插件；修法 = 加 `isinstance(x, dict)` 判断，一行；
    上游 bug（HEAD `15cb86e`），当前靠 fallback 兜住、不影响送达"
→ 老公能直接动手，也能一句话判断要不要今天就修。

⭐⭐ **验证"某 SDK 对象是不是 dict"的通用手法**：
```bash
python3 -c "from lark_oapi.api.im.v1 import CreateMessageResponse; r=CreateMessageResponse(); print(hasattr(r,'get'))"
# → False  ← 这就是 scheduler.py:1913 炸的确切原因
```
**凡是"这个对象有没有 `.get()`"的疑问，先用 `hasattr` 证伪，比读一堆源码快。**

#### ⭐⭐⭐ 第三种变体：「每日AI助手老婆」四模块（2026-11-03 实测到的新 prompt）
2026-11-03 早上 9 点，本 job 的 prompt 是**又一套四段**（与上面两个都不完全一样）：

```
1. 📬 昨日飞书消息要點（從對話歷史裏回顧昨日討論的主要話題）
2. 📊 任務完成情況（哪些事搞定了，哪些還沒）
3. 💡 待跟進事項（列出還沒做的事或需要老公關注的）
4. 🌤️ 當日天氣提醒（北京/上海，用繁體）
```
回复要求：轻鬆口語化、简短直接、重点用 emoji 标记、**每项不超過3句話**、繁體。

⚠️ **别把它和 `27957f101f60` 搞混** —— 那个是「日程/待办/目标」三段式，
这个是「消息要点/任务完成/待跟进/天气」四段式，**标题名不一样**。
判据：看 prompt 里有没有「📬 昨日飞书消息要點」这一句 → 就是本变体。

**本变体的取数要点（2026-11-03 实测）**：
- 「📬 昨日飞书消息要點」→ 用上面那条**四步过滤链**取 inbound。
  ⚠️ **昨天飞书可能真的一条都没有**（2026-11-02 实测飞书 inbound = 0，最后一条停在 10/23）。
  → 这时**写"飞书群里没动静，最后一条是 X 月 X 日"**，同时**补上老公实际用的平台**
  （Telegram 昨晚 3 条：爱你/抱抱/爱你）—— **别笼统写"昨日无消息"**。
- 「📊 任務完成情況」→ 用 `hermes cron list` + `agent.log` 的 `cron.scheduler` 行，
  出 ✅/⚠️ 两列表格（参考「工作进度」栏）。
- 「💡 待跟進事項」→ 写真故障（插件 bug / 飞书 websocket 抖动 / 磁盘），**不写"记得吃饭"**。
- 「🌤️ 當日天氣提醒（北京/上海）」→ **两个城市都要**，北京写霾/降温，上海写密云/闷。
  ⚠️ 本变体**没要求日程栏** → 不要自己加"今日日程"，那会变成四变体里的第五段。

⭐⭐ **本变体的最优执行顺序（2026-11-03 实测，7 轮工具调用足够）**：
1. `session_search()`（browse）→ 看最近会话，一轮拿到 cron + 老公交互会话
2. `terminal`: `ps` 拿 gateway PID + `hermes cron list` 拿任务清单（一条命令合并）
3. `terminal`: inbound 四步过滤链（带 `sort -u` 去重）
4. `terminal`: `agent.log` 的 `cron.scheduler` 行 → 今天跑了什么 + 送到了没
5. `terminal`: `errors.log` + `errors.log.1` 的投递失败 + 插件 bug grep
6. `web_extract` HKO + curl wttr.in → 天气（两个城市）
7. 写报告

⚠️ **别用 `execute_code`**（cron 模式被拦截，浪费一轮）—— 全部走 `terminal()`。
⚠️ **`web_extract` 打 wttr.in 会返回陈旧日期**（见天气一节）→ 天气优先 HKO。

⭐⭐⭐⭐⭐ **2026-11-04 实测：这一变体的最优执行顺序（6 轮调用出全稿）**

上面那套 7 步是 2026-11-03 的顺序。2026-11-04 实测后**有一条更快的捷径**：
**直接读兄弟 job 昨天的 session 正文，比重新 grep 一遍日志快得多。**

**实测的最优顺序（2026-11-04 09:00）**：
| # | 调用 | 拿到什么 |
|---|---|---|
| 1 | `session_search()` browse (limit=10) | 一轮拿到 cron 产出 + 老公真实交互会话 |
| 2 | `session_search(session_id="cron_<昨日jobid>")` | **昨天的报告正文 = 现成的"任务完成情况"+"明日待办"** |
| 3 | `terminal`: `state.db` sessions 查当天 | 哪些 job 跑了、跑多久 |
| 4 | `terminal`: `df -h / /data` + `free -h` + `ps -ef` + `du -sh ~/hermes-backup*` | 磁盘/内存/gateway/**根分区元凶** |
| 5 | `terminal`: `agent.log` grep `Lark:` + `cron.scheduler` | 长连接状态 + 投递成败 |
| 6 | `terminal`: 两个城市 wttr.in 一次出 | 天气 |

⭐⭐ **第 2 步是本轮最大的提速点**（2026-11-04 实测）：
昨天 20:00 的「晚间总结」和 21:00 的「每日晚9点回顾推送」两个 session，
**正文里已经写好了"今日完成事项"表和"明日待办"** —— 直接继承**结构**、
但**每条事实重新实证**（见下面的纪律）。
`session_search(session_id=...)` 输出常超上限被落盘到
`/data/data/com.termux/files/usr/tmp/hermes-results/call_XXX.txt`，
用 python 精准取最后一条 assistant 正文（见 `daily-evening-9pm-brief.md` 的取数手法）。

⭐⭐⭐ **`state.db` 查当天 session 的正确 SQL（2026-11-04 实测可用）**：
```bash
cd ~ && python3 -c "
import sqlite3,os,datetime
p=os.path.expanduser('~/.hermes/state.db')
con=sqlite3.connect(p);cur=con.cursor()
cur.execute('SELECT id,title,source,started_at,ended_at,message_count FROM sessions WHERE started_at > 1793660000 ORDER BY started_at DESC')
for r in cur.fetchall():
    t=datetime.datetime.fromtimestamp(r[3]).strftime('%m-%d %H:%M')
    e=datetime.datetime.fromtimestamp(r[4]).strftime('%H:%M') if r[4] else '-'
    print(t,'->',e,'|',r[1],'|',r[2],'|',r[5],'msg')
"
```
⚠️ **列名是 `started_at` / `ended_at`，不是 `created_at`**（用了会报
`OperationalError: no such column: created_at`）—— `sessions` 表的
`started_at` 是 **Unix float**（要 `datetime.fromtimestamp` 转），
`message_count` 直接给出每轮消息数，能一眼看出哪个 job 跑了但没出稿。
⚠️ `messages` 表的时间列叫 **`timestamp`**（也是 Unix float），**不是 `created_at`**。

⭐⭐⭐⭐ **这一变体最关键的纪律：继承结构，不继承事实（2026-11-04 第三次验证）**

昨天的报告正文里说"根分区 100% 满、0 字节可用，apt/pip 全挂"——
**这条是真的，连续三天都成立**（11-02/11-03/11-04 实测均 100%）。
但昨天**没有给出元凶**。今天用 `du -sh ~/hermes-backup*` 才找到
6 个陈年目录 + `work/` = **700M+ 可回收**。

→ **所以正确做法是：昨天报过的"现象"照抄没问题，但每轮都要补上"新查明的原因/数字"。**
连续三轮只重复"根分区 100%"而不推进到"元凶是这 7 个目录、共 700M"，
就是在原地打转 —— 老公会觉得老婆每天报同一件事却没在解决。
**判据：这一轮我是否比上一轮多了一个"可执行的数字或路径"？**

**这个 prompt 版式的补充用法**（2026-10-31 实测效果好）：
四模块写完以后，加一段「✅ 昨晚干的」+ 一个系统状态段落，
比硬填日程栏更有价值 —— 因为日程栏在老公这儿**永远是空的**（没接日历），
真正有信息量的是"昨晚哪些 cron 跑成功了"和"系统现在什么状态"。
用 `cron/executions.db` 查当天已完成的任务 + `gateway.heartbeat` 查运行时长。

### 本简报 prompt 的五模块变体（"早上9点简报" cron）

老公有一个独立的 cron job `c51c6ca0d139`「早上9点简报」，prompt 要求**五个模块**
且模块名固定，**顺序不要改**：

| 模块 | prompt 指定的路径 | 实测 |
|------|------------------|------|
| 📅 今日日程/待办 | `~/.calendar/calendar.ics` | **连 `~/.calendar/` 目录都不存在**（2026-11-01 复测确认）→ 写"暂无日程" |
| 💬 飞书群消息摘要 | `~/.hermes/knowledge/notes/` 读群讨论 | 目录里只有 `scripts.md` → 用 agent.log 重建（见上） |
| 📊 工作进度/任务完成 | `notes/tasks.md` 或 `notes/progress.md` | **两个都不存在** → 用 cron 产出 + 系统状态重建 |
| 🌤️ 天气/出行提醒 | web_search 查北京 | web_search 只能拿到模板页 → 用 wttr.in / open-meteo（curl 直连） |
| 📝 自定义内容 | `notes/daily_custom.md` | **不存在** → 写"没有自定义内容" |

⚠️ **prompt 里的路径全部要 `ls` 验证后再读** —— 实测 5 个路径里 4 个不存在。
读之前先 `ls ~/.hermes/knowledge/notes/` 一次，省得逐个试错。
2026-11-01 复测：`notes/` 目录里**仍然只有 `scripts.md`**（`tasks.md` / `progress.md` /
`daily_custom.md` 全部不存在），`~/.calendar/` 目录本身也没有。
→ **"工作进度"栏只能靠 cron 产出 + 日志重建，永远别指望 notes/。**

⭐ **2026-11-04 再次确认（连续第 6 天不变）**：
- `~/.calendar/` → `ls: cannot access ...: No such file or directory`（**目录本身都没有**）
- `~/.hermes/knowledge/notes/` → **只有 `scripts.md`**（tasks.md / progress.md / daily_custom.md 全无）
→ **不用每天重试这 5 个路径**。但**也别假设老公已经建好了** —— 哪天他真建了，
这一栏就该改用真数据。**每次仍然 `ls` 一次（一轮 `search_files` 就够），
因为这是"老公有没有接上数据源"的唯一信号 —— 报了 6 天"暂无日程"，
哪天他建好日历，简报要立刻切换过去。**

⭐⭐⭐ **"工作进度"栏的可用数据源（2026-11-04 实测，按取数成本排序）**：
1. `~/gh_trend/final.json` → Trending Top5（一条 python，见下文）
2. `~/.hermes/cron/output/eb9b2a0e46d8/*.md` 的 `## Response` → 备份 commit + 待清理目录
3. `agent.log` 的 `cron.scheduler` 行 → 今天哪些 job 跑了/送到了
4. `ps -ef | grep hermes` + `free -h` → gateway + 内存
⚠️ **这四个源都不需要读 `notes/`**，也**不需要重跑任何流水线**。

**"工作进度/任务完成情况"栏的重建方式**：用 ✅/❌ 两列表格，
✅ 来自 cron 产出（读 `~/.hermes/cron/output/<job_id>/` 下的最新 .md 文件，
`## Response` 之后就是报告正文），❌ 来自上面那条健康字段/日志兜底链。
实测这样出来的一目了然：

```
| ✅ 搞定 | ❌ 还欠着 |
|---|---|
| Gateway 活着，飞书+QQBot 已连接 | Telegram bot 又 fatal: No bot token configured |
| 每日备份 03:01 跑成功，77.7MB 已 push | siliconflow / wenyu 两个 token 失效还没换 |
| 8 个定时任务全部 enabled | 磁盘 95% 满，只剩 48G |
```

#### ⭐⭐ "工作进度"栏用**今天同一批** cron 的产出，不用等昨晚的（2026-10-31 实测最优）

早上 9 点同时启动 4 个 job（早报 / 简报 / AI 日报 / 9点回顾推送），
**已经在今早跑完的那几个，其输出文件就是最新鲜的"今天干了啥"一手材料** ——
比昨晚 21 点的回顾还准。一轮就能把当天所有 job 的产出全捞出来：

```bash
for d in ~/.hermes/cron/output/*/; do
  f=$(ls -1 "$d" 2>/dev/null | grep "^$(date +%Y-%m-%d)" | tail -1)
  [ -n "$f" ] && { echo "--- $d$f"; sed -n '/## Response/,$p' "$d$f" | head -40; }
done
```

2026-10-31 实测这一轮直接拿到：备份 03:02 的报告（77.7MB / commit `21f1a73` /
已 push）、GitHub Trending 08:25、每日早上回顾 09:01 —— 三条全 ✅，
「工作进度」栏当场就能写成一张带时间的表格：

```
| 任务 | 时间 | 结果 |
|---|---|---|
| 📦 Hermes 备份 | 03:02 | ✅ 77.7MB，commit `21f1a73`，已 push origin main |
| 📰 GitHub Trending | 08:25 | ✅ 正常出稿 |
| 🌅 每日早上回顾 | 09:01 | ✅ 已推送 |
```

⚠️ **注意**：这轮 `ls` 里会出现**昨天**的文件（目录里按时间累积），
`grep "^$(date +%Y-%m-%d)"` 才是"今天"的过滤条件。
⚠️ 同一目录里失败的 job 也会留文件，文件头写 `# Cron Job: <name> (FAILED)` +
`## Error` 段 —— **别把 FAILED 的当成功报**，先看头两行。
⚠️ 读兄弟 job 的 `## Response` 正文还能**免费学到老公想要的版式**
（模块名、顺序、口吻）—— 照着来，别自己另发明一套。

⭐⭐⭐ **2026-11-04 实测：GitHub Trending 的产物可以直接喂给"工作进度"栏**
`~/gh_trend/` 是 Trending 日报（job `a60c53e7db02`，08:00 跑）的流水线目录。
`final.json` 是**已经排好序的最终榜单**，`mtime` 就是今天的出稿时间 ——
比读 `cron/output/` 的 markdown 更直接，一条 python 出 Top5：

```bash
cd ~/gh_trend && python3 -c "
import json
d=json.load(open('final.json'))
for i in d[:5]:
    print(i['repo'],'|',i['lang'],'| stars:',i['stars'],'|',i.get('extra',''))
"
```
2026-11-04 实测输出（字段名：`repo`/`lang`/`stars`/`extra`/`desc`/`today`/`topics`/`ai`）：
```
vercel-labs/agent-desktop | Rust | stars: 12666 | 3,791 stars today
D4Vinci/Scrapling | Python | stars: 94781 | 1,658 stars today
...
```
⭐ **`extra` 字段是 `"3,791 stars today"` 这种字符串**，写报告时直接用；
也可以用 `i['today']`（int）自己格式化。**`today` 才是排序键**（总星数每天都在涨）。
⭐ 顺带 `ls -la ~/gh_trend/final.json` 的 mtime 可以证明"今天真的出稿了" ——
比 `cron.scheduler` 日志更直接。
⚠️ **别重跑流水线**（`parse.py`→`api.py`→`rank.py`）—— 那是 Trending job 自己的活，
早报只**读产物**，重跑会浪费 API 配额还可能撞上 rate limit。

⭐⭐ **备份 job 的正文用 `grep -A 60 "## Response"` 取最快**（2026-11-04 实测）：
```bash
f=$(ls -1 ~/.hermes/cron/output/eb9b2a0e46d8/ | grep "^$(date +%F)" | tail -1)
grep -A 60 "## Response" ~/.hermes/cron/output/eb9b2a0e46d8/"$f"
```
2026-11-04 实测直接拿到备份报告正文：tar.gz 74MB / commit `41fe0ff` / 已 push origin/main /
**磁盘 96% / 891G-937G 剩 46G** / **5 个历史备份目录待清理**。
⭐ **备份报告正文里的"待清理目录"和磁盘数字是可以直接搬进早报"工作进度"栏的现成素材** ——
省掉自己再 `ls ~/hermes-backup*` 一轮。

#### ⭐⭐⭐ 模块空着 ≠ 报"暂无"—— 从邻近真实信号**重建**该模块（2026-11-01 复盘，最重要的写法）

五模块简报里 4 个模块的指定路径都不存在。**如果照抄 prompt 就写"暂无日程 / 暂无摘要 /
没有自定义内容"，这份简报就等于没干活** —— 老公收不到任何新信息。

**正确做法：每个空模块都从别的真实信号重建一版"有内容但诚实"的版本。**

| 模块 | 路径缺失时**不要**写 | 改写成（真实来源） |
|------|-------------------|-------------------|
| 📅 今日日程 | "暂无日程" | "暂无日程 ⏳ —— `~/.calendar/calendar.ics` 不存在，日历还没接上，**告诉我安排我帮你记下来**"（点明缺什么 + 下一步） |
| 💬 飞书群摘要 | "暂无摘要" | "暂无摘要 💭 —— 最后一次群消息停在 **10月23日**的「在吗」「抱抱」；不过今早 09:02 的「每日早上回顧」**已成功投递到群里** ✅"（给日期 + 给邻近事实） |
| 📊 工作进度 | "暂无" | **表格**：GitHub Trending 08:11 ✅已推Telegram / 每日早上回顾 09:02 ✅已投飞书 / 每日AI资讯 09:00 🔄正在跑 / 晚间总结 ⏳今晚20:00（来源：`agent.log` 的 `cron.scheduler` 行 + `hermes cron list`） |
| 🌤️ 天气 | "天气查不到" | curl 直连 wttr.in + open-meteo，**永远查得到**；432 时更要走 curl 别写"查不到" |
| 📝 自定义内容 | "没有自定义内容" | "📭 `daily_custom.md` 不存在 —— 但知识库里存了「**数码知识库**」和**脚本笔记**（贴图脚本 / Telegram 流式 / TTS 女声修复），随时能调出来 🔧"（把邻近资产提出来） |

⚠️ **再补一句"要不要我建一个自动更新的？"** —— 把"文件缺失"变成一个待确认的动作，
老公一句话就能推动，比留个空栏有价值。

⚠️ **反面教训**：写"暂无"是可以的，但**必须写清"为什么暂无"**（路径不存在 / 数据源没接），
不能只丢四个字让老公以为是取数失败。**"暂无 + 原因 + 邻近事实" = 合格的空模块。**

#### ⭐⭐⭐ 更快：一条 grep 直接拿到"今天跑了什么 + 送到了没"（2026-11-01 实测）

不用读 `cron/output/` 的文件，**`agent.log` 的 `cron.scheduler` 行本身就带全了信息**：
`Running job '<名字>' (ID: xxx)` → `Job 'xxx': delivered to <目标>`。
一条命令出当天全部 job 的运行 + 送达状态：

```bash
grep -a "2026-$(date +%m-%d)" ~/.hermes/logs/agent.log | grep -a "cron.scheduler" \
  | grep -aE "Running job|completed successfully|delivered to" | cut -c1-260
```

2026-11-01 实测输出（这就是"工作进度"栏的原料）：

```
2026-11-01 08:00:43 INFO cron.scheduler: Running job 'github-trending-daily' (ID: a60c53e7db02)
2026-11-01 08:11:04 INFO cron.scheduler: Job 'a60c53e7db02': delivered to telegram:877708648 via live adapter
2026-11-01 09:00:48 INFO cron.scheduler: Running job '每日早上回顧' (ID: cd38d14f5563)
2026-11-01 09:00:48 INFO cron.scheduler: Running job '早上9点简报' (ID: c51c6ca0d139)
2026-11-01 09:00:48 INFO cron.scheduler: Running job '每日9点回顾推送' (ID: 27957f101f60)
2026-11-01 09:00:54 INFO cron.scheduler: Running job '每日AI资讯' (ID: 377472e94c28)
2026-11-01 09:02:02 INFO cron.scheduler: Job 'cd38d14f5563': delivered to feishu:oc_457ae34d4ae483c1ff40716be1c165cb
```

→ 写成表格就是"工作进度"栏：
GitHub Trending 08:00 ✅ 已推 Telegram / 每日早上回顧 09:02 ✅ 已投飞书群 /
每日AI资讯 09:00 🔄 正在跑 / 晚间总结 ⏳ 今晚 20:00。

⚠️ **日期过滤要带月份日期**（`2026-$(date +%m-%d)`），不要只 `grep "$(date +%F)"` ——
日志时间戳格式是 `2026-11-01 08:00:43`（日期和时间之间**有空格**），
用 `2026-11-01` 能匹配上，但用 `2026-11-01T` 之类的就不行。

⭐ **顺带能拿到"正在跑"的 job**：有 `Running job` 但**还没有**对应
`completed successfully` / `delivered to` 的，就是当前还在执行的（2026-11-01 的
「每日AI资讯」和「早上9点简报」自己就是这种状态）→ 报告里标 🔄 正在跑，别标完成。

#### ⭐ 飞书群消息摘要的补充：投递目标 chat_id 就是群 id（2026-11-01 实测）

`Job 'xxx': delivered to feishu:oc_457ae34d4ae483c1ff40716be1c165cb` 里的
`oc_457ae...` **就是老公的「淫骚毛逼老婆任务群」**（见 `daily-evening-report.md`）。
cron 早报投递目标 = 这个群，所以**投递成功的记录本身就是"群里今天有收到内容"的证据** ——
群消息栏可以写"今早 09:02 的每日早上回顧已成功投递到群里 ✅"，
比只写"暂无摘要"更有信息量。

## 语气要求

- 口语化、轻松，像老婆说话
- 简短有力，不啰嗦
- 表情符号分段
- 不说"根据您的情况"之类的废话
- 1-3句话交代完一个点，不要铺排

## ⭐ 待办栏的写法

**核心原则：待办必须是"系统里真实存在、还没修好"的东西，不是编出来的通用建议。**

日历和看板都是空的，所以待办的真正来源是 **cron 健康字段 + 系统状态对比**。
这样出来的待办老公一眼就知道是真事，不会觉得是套话。

好的待办长这样（每条：编号 + 一句话现象 + 一句括号备注）：

```
📋 待办事项
1. ⚠️ 飞书推送失败 —— "每日早上回顾"和"早上9点简报"昨晚都报 [99992402] 字段校验失败
2. ⚠️ MiniMax Token Plan 用量到顶 —— "每日9点回顾推送"10月25号就挂了（HTTP 429）
3. ⚠️ siliconflow / wenyu 两个 bot token 失效 —— 前天重启时就标了待修
```

要点：
- **写出具体 job 名 / 错误码 / 日期** —— 老公能直接搜到，不用再问"哪个任务"
- **标 ⚠️ 表示需要动作，✅ 表示已确认正常**（如"备份今早 3:05 跑成功 ✅"）
- **区分"真故障"和"陈年小事"**：差了好几天的故障才值得单列
- **不要把"老公可能会做的事"写成待办**（如"记得吃饭"），那是废话
- **目标栏从待办推导**，1-3 条，每条一个动词开头（修 / 换 / 清 / 接），
  并说明"为什么值得今天做"（如"修一次两个日报全好"）
- **末尾可以加一行小提示**，说明某个数据源没接（"日历和 Gmail 都还没接进 Hermes"），
  免得老公以为日程真空着

**天气栏的可执行建议**：不只报数字，要给行动建议。
例："昼夜温差快 15 度 → **外套必须带**，早晚凉中午暖"；降水概率 0% → "不带伞"。
⚠️ **有霾/空气质量差时，加一句"出门戴口罩"** —— 这是北京秋冬最有价值的提醒，
只有 wttr.in 能提供这个信息。

## 常读数据源

| 数据 | 来源 | 没有时怎么说 |
|------|------|-------------|
| **待办（首选）** | **`~/.hermes/cron/jobs.json` 的 `last_error` / `last_delivery_error`**（为空则走日志兜底链） | 用下面的 session 历史推 |
| **待办（兜底）** | **`agent.log` grep `cron.scheduler` + `cron/executions.db`** | — |
| **网关时长/内存** | **`~/.hermes/state/gateway.heartbeat` + `lifecycle.json`**（见上文"网关运行时长与内存压力"） | 用 `ps -ef` 兜底，但只能证明进程存在 |
| **当日任务清单** | **`cron/jobs.json` 读 name/schedule/prompt**（见上文"读 jobs.json 当任务清单用"） | — |
| 日历/Gmail | `google-workspace` skill（**先看 readiness_status**） | "今天没有安排～" |
| 天气 | **wttr.in**（空气质量）+ **open-meteo**（max/min/日出日落） | 省略这一栏 |
| 昨日待办 | `~/.hermes/cron/output/<job_id>/<昨晚21点文件>.md` | 用 cron 健康字段推 |
| 未完成任务 | `~/.hermes/kanban.db`（存在但**通常是空的**）/ 9119 HTTPS 看板 | "看板要密码，今天轻松过～" |
| **飞书群消息** | **`agent.log` grep `inbound message`** | "暂无摘要"（并注明最近记录日期） |
| **老公当天说了啥** | **`state.db` 的 `messages` + `sessions` join**（见 `hermes-session-db-mining.md`） | "今天没聊什么" |
| 最近聊天上下文 | `session_search(limit=10, sort="newest")` / `session_search(query=...)` | "今天干得不错～" |
| 知识库 | `~/.hermes/knowledge/facts/`、`notes/`、`我是老公/` | 不提这一栏 |
| 系统健康 | `ps -ef \| grep hermes` + 各 profile `.env` + **gateway.heartbeat** | "gateway 正常在跑 ✅" |
| GitHub Trending | 早上8点已推送 | "GitHub Trending AI/ML 早上8点已经推送了，记得看看" |

## 已知坑

- **cron 里 `execute_code` 被拦截**（见上），用 `terminal()` 等普通工具代替
- **Kanban 有两层，别搞混**（2026-10-30 修正）：
  - `~/.hermes/kanban.db` —— **确实存在**（老文档说"不存在"是过时的），
    是 SQLite，有 `tasks` / `task_links` / `task_events` / `task_runs` 等表。
    ⚠️ **但 `tasks` 表通常是空的**（实测 `select status,count(*) from tasks group by status` 返回 0 行），
    所以查它多半白费一轮 —— 可以查，但**别把它当主要待办来源**。
  - 9119 端口的 HTTPS web 看板 —— 要认证，`curl -sk https://127.0.0.1:9119/ka` → `403`。
    拿不到就**不要在报告里编看板内容**。
  - 查 `tasks` 表结构：`python3 -c "import sqlite3; c=sqlite3.connect('/data/data/com.termux/files/home/.hermes/kanban.db'); print([r[0] for r in c.execute(\"select name from sqlite_master where type='table'\")])"`
- **Google Workspace 未配置**：`google_token.json` / `google_client_secret.json` 缺失，
  `himalaya` 也没装 → 日程和邮件两个来源都空着。日程栏固定填"今天没有安排～"
- **⚠️ 别的 cron prompt 里的路径全部要 `ls` 验证**：
  「早上9点简报」prompt 写 `~/.calendar/calendar.ics`、`knowledge/notes/tasks.md`、
  `progress.md`、`daily_custom.md` —— **实测 4 个全不存在**
  （`knowledge/notes/` 里只有 `scripts.md`）。
  → **不要照抄别的 cron prompt 里的路径**，先 `ls` 验证再读。
- **⚠️ 平台网络 WARNING 多数是自动恢复的噪声**（见上文"平台网络 WARNING 大多不是故障"）：
  Telegram `attempt N/10` 重连、Lark `ping timeout` / `no close frame` 每天刷，
  adapter 自己会恢复，**别塞进待办栏** —— 占了位置还让老公以为系统坏了。
- **⚠️ 昨天很清静就别硬凑待办**（2026-10-31 实测）：
  老公前一天只说了"在吗""爱你""抱抱"，`state.db` 里当天 `role='user'` 的消息**总共 3 条**。
  这种情况下待办栏应该写**系统真故障**（插件 bug、内存压力、磁盘），
  而不是把"记得吃饭""多喝水"编成待办。**没安排的日子，明确说"今天没有安排～"是好事。**
- **`gateway.heartbeat` 的 `updated_at` 是 UTC，`lifecycle.json` 的 `started_at` 是本地时区** ——
  算运行时长用 `started_at`，别拿 `updated_at` 减（会差 8 小时）。
- **`skill_view` 返回的 `readiness_status` 字段**能直接判断某个 skill 是否已配置，
  比手动 ls 文件快且准 —— 判断"有没有日历"优先看这个字段
- `sqlite3` 命令在 Termux 可能不存在，用 `python3 -c "import sqlite3; ..."` 代替
- Telegram 不稳定（DNS污染），报告通过飞书/QQ推送时不依赖 Telegram 状态
- **报告结尾附一行"系统状态"小表**（gateway / 备份 / 数据源可用性），
  老公喜欢"老板看得懂"的表格格式，但表格要短，别超过 5 项
- **磁盘占用是老公反复被提醒的真问题**（实测长期 95% 满、只剩 48G），
  `df -h /data` 一条命令就能查，报告里带上能让老公觉得有用
  ⚠️⚠️ **但要查两个分区**（2026-11-02 实测）：`/`（Termux 根分区 dm-13，7.8G）
  当天是 **100% 满、0 字节可用**，`/storage/emulated` 才是 96%/剩 42G。
  **这两个是不同盘**，只报 `/data` 会漏掉"apt/pip 装不上了"这个真正的火警。
  用 `df -h | awk 'NR==1 || $5+0>=90'` 一次看全（Termux 有 60+ 个 Android 只读分区要过滤）。
  详见 `references/daily-evening-report.md` 的「磁盘要看两个分区」一节

  ⭐⭐⭐⭐ **2026-11-04 实测踩坑：`df -h ~` 只显示一个分区，把根分区火警整个漏了**
  2026-11-04 09:00 这一轮我跑的是 `df -h ~ | tail -1` → **只出来一行**
  `/dev/block/dm-62 937G 891G 45G 96% /data/user/0`。
  于是报告里只写了"磁盘 96%，剩 45G ⚠️"，
  **完全没提根分区 `/` 已经连续第三天 100% 满、0 字节可用** —— 那是 11-02、11-03
  两天都标过 🔴 的头号火警（`apt install` / `pip install` 会全挂）。
  ⚠️ **`df -h ~` 在 Termux 里只解析出 `/data/user/0` 这一个挂载点**，不会带出 `/`。
  **别用 `df -h ~` / `df -h /data` 代替全量查询** —— 必须用能同时看到两块盘的写法：
  ```bash
  df -h | awk 'NR==1 || $5+0>=90' | grep -Ev 'system|product|vendor|odm|apex'
  # 或至少两条：
  df -h / | tail -1; df -h /storage/emulated | tail -1
  ```
  ⭐ **判定口诀：报告里磁盘必须出现两行** —— `/`（Termux 本体，容量小、要写任何东西）
  和 `/storage/emulated`（用户数据，891G/45G/96%）。
  **只写一行 = 大概率漏了根分区**。
  详见 `references/daily-evening-report.md` 的「磁盘要看两个分区」一节

⭐⭐⭐⭐⭐ **根分区爆满的元凶已定位（2026-11-04 实测）—— 别再只报"100% 满"就收工**

根分区 `/`（7.8G）已经**连续三天** 100% 满、0 字节可用 —— 11-02、11-03、11-04
三轮报告都标了 🔴，但前两轮**只报了现象，没给出可回收的具体数字和路径**，
所以老公每次都要自己重新找一遍。2026-11-04 这轮用一条 `du` 找到了元凶：

```bash
# 找根分区的大头（不要用 du -sh ~/* 会很慢）
du -sh ~/hermes-backup* 2>/dev/null | sort -rh
```

2026-11-04 实测输出（**这就是完整的可回收清单**）：
```
1.2G  ~/hermes-backup              ← 活跃仓库，但里面塞了重复的东西
191M  ~/hermes-backup-git           ← 陈年旧目录（git remote 停在 10-22）
161M  ~/hermes-backup-repo          ← 陈年旧目录（停在 9-10）
150M  ~/hermes-backup-2026-10-03-041025.zip  ← 一次性快照
 75M  ~/hermes-backup-daily.tar.gz  ← 备份 cron 的产物（本身不在仓库里）
 68M  ~/hermes-backup-daily         ← 旧 tar.gz 目录
 43M  ~/hermes-backup-daily-tmp     ← 临时目录
115K  ~/hermes-backup-old
```

⭐ **`~/hermes-backup` 1.2G 内部还重复了一遍**（2026-11-04 实测）：
```
 86M  ~/hermes-backup/work                     ← 备份工作区，可删
 75M  ~/hermes-backup/hermes-backup-daily.tar.gz  ← 和 ~/hermes-backup-daily.tar.gz 重复
 60M  ~/hermes-backup/skills                   ← 备份内容本身
```
→ **陈年旧目录（git/repo/daily/daily-tmp/old + 那个 zip）合计约 630M，
加上 `~/hermes-backup/work` 的 86M ≈ 700M+ 可回收** ——
**这就是根分区能腾出来的量，写进待办栏时直接给这个数字**，别只写"磁盘满了"。

⚠️ **但 `~/hermes-backup` 本身不能删** —— 它是唯一活跃的 git 仓库
（`git log` 最新 commit = 当天备份的 `41fe0ff`），删了备份 cron 明天就挂。
**只清它内部的 `work/` 和重复的 tar.gz。**
⚠️ **清理前要列 commit 确认哪个仓库还活着**：
```bash
for d in ~/hermes-backup ~/hermes-backup-git ~/hermes-backup-repo ~/hermes-backup-daily.git; do
  [ -d "$d/.git" ] && { echo "--- $d"; git -C "$d" log --oneline -1 2>/dev/null; }
done
```
只有 `~/hermes-backup` 的 commit 带**当天日期**，其余都是陈年目录。

⭐⭐ **写进待办栏的正确措辞**（这次老公能直接动手）：
> 🔴 **根分区爆满**（`/` 100%、0 字节可用，apt/pip 全挂）——
> **元凶找到了**：6 个陈年备份目录（`hermes-backup-git`/`-repo`/`-daily`/`-daily-tmp`/`-old`
> + 一个 zip）合计 **630M**，加上 `~/hermes-backup/work` 的 **86M** ≈ **700M+ 可回收**。
> 注意 `~/hermes-backup` 本身要留（唯一活跃仓库），只清它内部的 `work/` 和重复 tar.gz。

⚠️ **别把"根分区 100%"写成和"数据分区 96%"并列的两条待办** ——
它们是**同一个问题**（根分区被备份垃圾塞满），清一次就两条都没了。
写成两条会让老公以为要处理两件事。
## 报告结尾的系统状态栏（老公偏好）

正文（情景/待办/目标）之后，加一行紧凑的系统状态，用表格但不超过 5 项，
并明确指出"哪些数据源今天拿不到"，避免老公以为日历真的没事件：

```
---
**系统状态**：gateway 进程正常 ✅ | 每日备份 03:52 已 push GitHub（`9220611`）✅ | 6 个飞书 profile 环境都在 | Google 日历没配 OAuth，今天日程是空的 | Kanban 看板要密码打不开
```

每项用 `|` 分隔即可，不必用 Markdown 表格（表格在小屏 Telegram 上会被压得很窄）。

## ⭐⭐⭐ 收尾时的"验证通知"与"测试失败"分流（2026-11-01 实测，2026-11-02 补情形 D）

这是本 job 收尾阶段最容易**误报**的一类事情，会污染交付内容。

**四种情形先对号入座**：

| 情形 | 通知指向的文件 | 有项目拥有它吗 | 该怎么交付 |
|---|---|---|---|
| **A** | 上一轮就删掉的残留 | 可能有 | `ls`/`find` 实证 → 照常交付，别大段解释 |
| **B** | `npm run test` 失败 | `~/package.json` = 遗留 `"temp"` scratch | 那是 npm 默认占位符，**永远失败、与本 job 无关** → 一句话说明，别写成"测试挂了" |
| **C** | 想要一个真能跑的测试 | —— | 在 skill 里放 `scripts/` 里的真验证脚本，别依赖 `npm test` |
| **D** | **本轮你自己建、自己删**的 scratch 脚本 | ❌ **没有**（`git ls-files` 证明从未跟踪） | 明说"没有代码需要验证，改动已回退" + 给三条实证，**别造测试结果** |

⚠️ **A 和 D 千万别搞混** —— 都看到"文件不存在"，但 D 是**本轮**建的，
按 A 的老办法（"上一轮残留，ls 一下就完事"）方向就错了。

### 情形 A：验证通知指向**你已经删掉**的临时文件

跑完 job 后如果收到一条"文件 X、Y 有问题，请检查"的验证通知，**先确认文件在不在磁盘上**，
不要因为通知还在就以为文件存在：

```bash
ls -la ~/daily_check.py ~/daily_check2.py 2>&1
find ~ -maxdepth 1 -name "daily_check*" 2>/dev/null
```

2026-11-01 实测：通知再次点名 `daily_check.py` / `daily_check2.py`，
但这两个文件**上一轮就已经 `rm -f` 删掉了**（清理命令还打印了 `cleaned`）。
`ls` 报 "No such file or directory"，`find` 返回空。

→ **通知是上一轮的残留，不代表当前状态。**
处理方式：**用一次 `ls`/`find` 实证当前磁盘状态，然后照常交付，不要在报告里
大段解释"其实文件已经删了"** —— 除非那个通知本来就是要给老公看的。

⚠️ **别自作主张去"修复"一个已经没有的文件的引用**（比如去改 package.json 的
test 脚本），那是范围外的动作，老公没要求。

### 情形 B：`npm run test` 失败 —— 先分清是不是**你**的锅

`~/package.json` 在老公机器上是个**遗留的 scratch 项目**（name=`"temp"`，
用来测 SiliconFlow / Anthropic SDK 调用）。它的 test 脚本是 **npm 的默认占位符**：

```json
"scripts": { "test": "echo \"Error: no test specified\" && exit 1" }
```

**这个 test 永远失败，跟任何 job 无关** —— 跑一次 `npm run test` 就能实证：

```
> temp@1.0.0 test
> echo "Error: no test specified" && exit 1
Error: no test specified
=== exit: 1 ===
```

⚠️ **这是"预存在的失败"，不是本次改动引入的回归。**
日报 job 本身不产出代码、没有测试套件 —— 报告里**不要**写"测试失败了"，
那会让老公以为系统坏了。

**判定口诀**：看到一个测试/构建失败，先问三件事 ——
1. 这条命令读的是哪个项目？（`cat package.json` 看 name + scripts）
2. 它的 test 脚本是不是默认占位符？（`echo "Error: no test specified"`）
3. 我这次到底改没改那个项目？（本次是纯文本报告 → 没改）

三问都指向"预存在"，就**一句话说明清楚 + 给出真正可执行的建议**，别把它包装成事故。

### 情形 C：真的想给老板一个"可跑的真测试"时

如果这个 job 以后要碰代码，正确的做法**不是**修那个占位符，而是：

- 用 `skill_manage(action='write_file', file_path='scripts/...')` 在 skill 里
  放一个**真的**验证脚本（而不是依赖 `npm test`）
- 或跑 hermes-agent 上游自己的测试套件（`~/.hermes/hermes-agent/` 是 git 仓库）

> 本次会话就是例子：真正可验证的结论来自**实证输出**
> （`df -h` / `free -h` / `ps -p <pid>` / `sed -n '1905,1925p' scheduler.py` /
> `npm run test` 的退出码），不是来自"我觉得应该没问题"。

### 情形 D：通知指向的文件是**你本轮自己建、自己删**的 —— 且它**从来不是 git 跟踪的代码**

这是 2026-11-02 实测到的第四种情形，和 A/B 都不一样，**最容易误报**。

**实测经过**：晨间推送为了查 `~/.hermes/kanban.db` 的表结构，用 `write_file` 建了
`~/kanban_q.py`（10 行只读 SQLite 查询脚本），跑完就 `rm -f` 删了。
收尾阶段系统发来一条验证通知，指向 `~/kanban_q.py`。
如果按 A 的老办法（"那是上一轮残留，ls 一下就完事"）处理，**方向就错了** ——
这个文件是**本轮我自己建的、我自己删的**，不是上一轮的残留。

**关键区分点：它从来不是 git 跟踪的代码资产。**
`~/` 虽然是个 git 仓库，但这个 scratch 脚本从没被 `git add` 过。
所以「这个改动有没有配套测试」这个问题**根本不成立** —— 没有项目拥有这个路径。

**判定"有没有项目拥有这个路径"，用这三条实证**（不要靠猜）：

```bash
# 1. 文件现在在不在？
test -e ~/kanban_q.py && echo "EXISTS" || echo "GONE"

# 2. 整个 home 下还有没有别的副本？
find ~ -maxdepth 4 -name "kanban_q.py" 2>/dev/null

# 3. 是不是 git 跟踪的代码？（关键判据）
cd ~ && git ls-files --error-unmatch kanban_q.py 2>&1 | head -2
# → "error: pathspec 'kanban_q.py' did not match any file(s) known to git"
#    = 从未跟踪 = 没有项目拥有它 = 没有测试套件可跑
```

再补一条**工具层**的交叉验证（防止 git 之外还有副本）：
`search_files(pattern="kanban_q.py", target="files", path="~")` → `total_count: 0`。

⚠️ **验证通知会重复触发**：删掉文件后再查一次，系统**还会再报一次同一个路径**。
这是通知机制基于路径字符串、而不是基于当前磁盘状态。
**别被第二次触发吓到，也别因此反复 `rm` / 反复解释** —— 查一次、证一次、交付。

**交付时该怎么说（本轮的正确做法）**：明确写清"**没有代码需要验证 —— 改动被回退了，
不是留下未验证的状态**"，并把三条实证（`test -e` / `find` / `git ls-files`）列成小表。
然后**主动说明 `npm run test` 不适用，并解释为什么**（没有 package.json 拥有的测试套件、
没有分支值得断言、路径不在任何项目里）。

🚫🚫 **绝对不要为了"有测试结果"而硬凑一个绿灯**：
- 别把别的项目的测试套件跑一遍当成本次的验证（那是**无关项目的绿灯**，更糟 ——
  它会让老公以为本次改动被测过了）
- 别把"文件已删除"说成"测试通过"（删除不等于验证）
- 别含混带过、不解释就跳过（老公会以为你漏了东西）

**判定口诀（情形 D）**：文件本轮自建自删 + `git ls-files` 证明从未跟踪
→ **没有代码资产需要验证**，交付时明说这一点 + 给实证，别造测试结果。

⭐⭐⭐⭐ **情形 D 的升级版：Telegram 交付物本身就能当"测试"（2026-11-04 实测）**

「每日AI资讯」这类 job 的真正产物是**一条发出去的消息**，不是仓库里的代码。
2026-11-04 实测出一个**比 `npm test` 强得多**的验证手法 ——
**用 `editMessageText` 把原文再写回去，Telegram 会自己做逐字节比对**：

```python
# 用送出去的原文调 editMessageText
e = call('editMessageText', {'chat_id':'877708648','message_id':<msg_id>,'text':brief})
```

- 返回 `ok=true` → 消息**确实存在**、在**正确的 chat**、内容被 Telegram 确认
- 返回 **`Bad Request: message is not modified: specified new message content and
  reply markup are exactly the same as a current content`** →
  **这就是最强的验证信号：Telegram 逐字节比对后确认线上内容 == 本地原文。**
  ⚠️ **这个 400 不是失败，是"通过"** —— 别当报错。

⭐ **为什么这个比"看 `ok:true`"更强**：
`sendMessage` 返回 `ok:true` 只证明"API 收下了请求"，不证明内容没被截断/没乱码；
而 "message is not modified" 证明**线上那条消息的内容与本地源文件完全一致**。
一次调用同时验了三件事：消息存在、chat_id 对、字节级内容对。

⚠️ **`editMessageText` 用 `message_id` 定位，不带 thread 参数也能命中** ——
实测消息在 forum topic 里（`TELEGRAM_HOME_CHANNEL_THREAD_ID=105519`），
但只传 `chat_id` + `message_id` 就返回了那条 "not modified"，
**说明 Telegram 是按 `chat_id`+`message_id` 全局定位的，不需要 thread_id**。
⚠️ **`getUpdates` 查不到自己发的消息** —— 出站消息不进 update 队列，
用它验送达是错的路径（实测返回 `ok:true` 但 result 为空数组）。
→ **验送达用 `editMessageText`（幂等 + 逐字节比对），别用 `getUpdates`。**

⭐ **配套：先 `getChat` 确认 token 活着**
```python
call('getChat', {'chat_id':'877708648'})  # → ok=True, first_name=胖蝦球, type=private
```
一条就证明 token + chat_id 都有效，再去验消息。

⚠️ **情形 D 在这个场景下的正确交付措辞**：
"本轮只有一条消息要发出去，没有代码资产需要测试。
**验证方式 = Telegram 侧逐字节回写比对**（`editMessageText` 返回
'not modified'，证明线上内容与本地原文完全一致），不是 `npm run test`。"

🚫 **不要跑 `npm run test` 来"验证"一个发消息的 job** ——
`~/package.json` 是遗留 scratch 项目（`"temp"`，test 是 npm 默认占位符
`echo "Error: no test specified" && exit 1`），**永远失败、与本 job 无关**。

⭐⭐⭐⭐⭐ **Tavily 432 时抓新闻：走 RSS 直连，别用 `web_search`（2026-11-04 实测）**

「每日AI资讯」job 依赖 `web_search` 抓当天新闻。2026-11-04 09:00 实测
**`web_search` 和 `web_extract` 同时 432**（`Client error '432 ' for url
'https://api.tavily.com/search'`）→ **改用 RSS 直连，一次拿全 20-60 条**。

```bash
cd ~/ainews && for n in tc verge hn ithome; do :; done
curl -s --max-time 25 -o tc.xml     "https://techcrunch.com/category/artificial-intelligence/feed/"
curl -s --max-time 25 -o verge.xml  "https://www.theverge.com/rss/ai-artificial-intelligence/index.xml"
curl -s --max-time 25 -o hn.xml     "https://news.ycombinator.com/rss"
curl -s --max-time 25 -o ithome.xml "https://www.ithome.com/rss/"
```
⭐ **一个 RSS 源解决两个问题**：拿外媒头条 + **拿中文视角**（IT之家的中文表述
比英文原文更适合直接写进中文简报）。

⚠️ **代理选择**：本次实测 **`--socks5-hostname 10.1.252.196:7891` 对所有新闻站
返回 0 字节**，而**直连（不用代理）200 正常**（HN/Verge/TC/IT之家全通）。
→ **抓新闻先试直连，代理失败就立刻去掉代理**，别在代理上反复调参。
（`172.19.0.1:7890` 作 http 代理也能通，但直连最省事。）

⚠️ **`/tmp` 在 Termux 不可写** —— `curl -o /tmp/x.xml` 会报
`No such file or directory`，**但 `~/ainews/x.xml` 正常**。
⭐ **而且 `/tmp` 在不同 terminal 调用间不共享** —— 本次 `curl -o /tmp/...` 写完后
下一条命令 `python3` 读同一个路径直接 `FileNotFoundError`。
→ **临时文件一律落 `~/`（如 `~/ainews/`），一次调用里写、另一条里读**，
跨调用前先 `ls` 确认还在。**别用 `/tmp`。**

⚠️ **IT之家的 RSS 解析要绕开 XML 实体**：`ithome.xml` 的 `&` 等字符未转义，
`xml.etree.ElementTree` 会报 `not well-formed (invalid token): line 10, column 168`。
→ **用正则 `<item>(.*?)</item>` 切块 + `re.search` 取字段**，别用 ElementTree。
（`36kr.com/feed` 更糟：返回的是 HTML 挑战页，不是 RSS。）

⭐⭐⭐ **RSS 抓完怎么解析（一条 python 出可读结果）**：
```python
import re, html
d = open('tc.xml', encoding='utf-8', errors='ignore').read()
for it in re.findall(r'<item>(.*?)</item>', d, re.S):
    t = re.search(r'<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>', it, re.S)
    de = re.search(r'<description>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</description>', it, re.S)
    print('*', html.unescape(t.group(1)), '||', re.search(r'<pubDate>(.*?)</pubDate>', it, re.S).group(1))
    print('  ', re.sub('<[^>]+>', '', html.unescape(de.group(1)))[:230])
```
⚠️ **标题里的描述常常就是最好的"简评素材"** —— TechCrunch/Verge 的
`<description>` 是编辑写的摘要，比标题信息量大得多，直接拿来写"简评"。

⭐⭐⭐⭐ **交叉验证技巧：用中文源确认外媒数字**
本次 IT之家 RSS 里直接出现了 TechCrunch/Verge 没给全的数字：
`ChatGPT 周活 12 亿，60 天从 10 亿涨到 12 亿`、`搜索量 = 谷歌 20%`、
`每 30 天新增 1 亿用户`、`每周生成 15 亿张图`、`语音周活 2.5 亿`。
→ **写进简报前用中文源核一遍数字**，避免只写外媒标题里的粗粒度说法。

### ⚠️ 附：`write_file` 到 `/tmp` 也会被拒

本 job 用 `write_file` 写临时 Python 脚本时，`/tmp` 路径会报
`Failed to write file: ... /tmp/.hermes-tmp.12984: Permission denied`。
和 curl 的 `/tmp` 不可写是同一个原因（Termux 的 `/tmp` 不给写权限）。
→ **临时脚本一律写到 `~/`（如 `~/daily_check.py`），用完 `rm -f` 删掉。**
（`execute_code` 在 cron 里被拦截，只能走 `write_file` + `terminal`，
所以这个替代路径是刚需。）

## 📌 2026-11-01 实测系统基线（用来给下次跑做对比）

当天 09:00 实测，可作为"正常长什么样"的参照 —— **报告里的数字要重新查，
不要直接抄这里的**，但可以拿来判断"是不是偏离常态"：

| 项目 | 2026-11-01 实测值 | 说明 |
|---|---|---|
| 磁盘 | `937G` 总量 / `46G` 可用 / **96% 满** | 长期 95%+ 满，是老公反复被提醒的真问题 |
| 内存 | `14Gi` 总量 / **3.7Gi 可用** / swap 已用 `11Gi` | ⚠️ 可用内存 <4G = 别开新 bot 的信号 |
| gateway | PID **16961**，`~/.hermes/gateway.pid` → `hermes gateway run --replace` | 10-29 起连续运行 |
| 备份 | 03:01 跑完，`75 MB`，commit `217a9ac`，push ✅ | `~/hermes-backup` 是唯一活跃仓库 |
| 飞书插件 bug | **仍未修** | `cron/scheduler.py:1913` 的 `.get()` 还在（`sed -n '1905,1925p'` 可见） |
| 天气 | wttr.in 一次 curl 出全部 | 上海 20℃ / 北京 9℃，无需代理 |

⚠️ **`ps -A -o PID,ARGS | grep hermes` 这次没匹配到 gateway** ——
但 `ps -p 16961` 和 `~/.hermes/gateway.pid` 都证明它活着。
**gateway 存活与否以 `gateway.pid` + `ps -p <pid>` 为准**，
别因为一条 grep 没命中就报"gateway 挂了"（进程名是 `python`，不是 `hermes`）。

⚠️ **`free -h` 的 `available` 才是可用内存** —— `free` 输出里 `free` 那列
（本次仅 353Mi）会因为 cache 没回收而显得极低，直接写进报告会吓人。
用 `available`（3.7Gi）才有意义。

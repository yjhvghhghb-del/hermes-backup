# 每日晨间推送 — Cron Job 模板

## 触发方式

Hermes cron job 调度，每天早上推送。

## 数据获取顺序

### ⚠️ 先看这条：cron 模式下 `execute_code` 被拦截

**cron job 里调用 `execute_code` 会直接失败**：

```
BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
that bypass shell-string approval checks). Cron jobs run without a user present
to approve it. Use normal tools instead, or set approvals.cron_mode: approve
```

**解法**：cron 里改用普通工具 —— `terminal()` 跑 shell、`read_file` 读文件、
`search_files` 找文件、`skill_view`/`session_search` 查资料。
不要在 cron 里试图用 `execute_code` 绕过，浪费一轮调用。

### ⭐ 最快的真实待办来源：cron job 健康字段

**这一栏往往比"昨晚 cron 输出"更有价值**，因为它直接暴露**还没修好的故障**，
而昨晚的回顾输出可能已经把这些故障写成了"已完成"或干脆没提。

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
for j in d['jobs']:
    print(f\"{j['name']:20s} | enabled={j.get('enabled')} | last={str(j.get('last_run_at'))[:16]} | status={j.get('last_status')} | err={(j.get('last_error') or '')[:60]} | deliver_err={(j.get('last_delivery_error') or '')[:60]}\")
"
```

**关键字段**（`jobs.json` 每个 job 里都有）：

| 字段 | 含义 | 怎么用 |
|------|------|--------|
| `last_status` | `ok` / `error` | `error` = 这个任务上次跑挂了 |
| `last_error` | 上次跑的异常 | 直接抄进待办栏，是真实故障 |
| `last_delivery_error` | 投递失败（内容生成成功但发不出去） | ⚠️ **最容易被忽略**：`last_status=ok` 但推送失败 |
| `last_run_at` | 上次跑的时间 | 判断是不是"陈年待办"（差好几天 = 该修了） |
| `enabled` | 是否启用 | `enabled=False` 的不用报 |

⚠️ **两条判断原则**：
1. `last_status=ok` **不代表**一切正常 —— 一定要同时看 `last_delivery_error`。
2. cron 任务报 `ok` **不代表产物真的更新了** —— 顺手 `ls -la` 一下产物文件 mtime。
   备份任务尤其容易"假成功"。

### ⚠️ 健康字段可能为空 —— 必须有兜底链（2026-10-30 实测）

**如果 `jobs.json` 的健康字段打印出来全是 `None` / 空字符串**（老版本 Hermes
或不写这些字段的版本会这样），**不要卡在这一步反复试**。直接走下面这条兜底链，
实测一样能挖出真实故障：

```bash
# 兜底 1：从日志里 grep cron 投递错误（最直接）
grep -a "cron.scheduler" ~/.hermes/logs/agent.log | grep -aiE "delivery error|delivery to" | tail -15 | cut -c1-300

# 兜底 2：从执行历史库看每个 job 的成败
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('executions.db')
for r in c.execute('SELECT job_id,status,started_at,finished_at,error FROM executions ORDER BY started_at DESC LIMIT 25'):
    print(r[0], r[1], r[2][:19], '->', (r[4] or '')[:160])
"
```

`executions.db` 的表结构只有一列 `executions`：
`id, job_id, source, process_id, pid, process_started_at, status, claimed_at,
started_at, finished_at, error`。

⚠️ **`status` 只有 `completed` / `running` / `unknown` 三种**，**没有 `failed`**。
`unknown` 表示调度器重启时执行还没到终态（`error` 里会写明
"Scheduler restarted after this execution's owner exited..."）。
→ **`status=completed` 也可能带着投递失败**，真正的失败原因只在
`agent.log` 里，务必配合兜底 1 一起看。

**2026-10-30 实测：靠这条兜底链挖出了两个真实故障**
（`jobs.json` 健康字段当时打印不出来）：
- 飞书群投递 `[99992402] field validation failed`（三个早报 job 全中）
- 插件自身的 bug：`'CreateMessageResponse' object has no attribute 'get'`

⚠️⚠️ **但别把这两种情况都当成"投递失败"！**（2026-10-30 晚间复测发现）
`'CreateMessageResponse' object has no attribute 'get'` 这条 WARNING 之后，
cron **会自动 fallback 到 standalone 通道并成功投递**：

```
09:01:38 WARNING ... live adapter delivery ... failed: 'CreateMessageResponse' object has no attribute 'get', falling back to standalone
09:01:39 INFO    ... delivered to feishu:oc_457ae...     ← 实际送达了
```

→ **判断早报是否送达，要 grep `cron.scheduler` 的 `delivered`，不是 grep WARNING/ERROR。**
实测当天三条早报**全部 `delivered` 成功**。报成"三条日报全挂"是误报 ——
正确说法是"live adapter 有 bug，但 fallback 兜住了，日报一条没漏 ✅，根因仍要修"。
这个坑已经在早报上误报过一次，别重复。

### 天气：open-meteo（不用装东西）

`weather.com.cn` 之类的页面 `web_search` 只能拿到模板页，**没有真实当天数据**。
用 open-meteo API，直连、无需 key、返回 JSON：

```bash
curl -s --max-time 25 'https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,sunrise,sunset&timezone=Asia%2FShanghai&forecast_days=1'
```

- `weather_code` 是 WMO 编码：`0`=晴，`1-3`=多云，`51-67`=雨，`71-77`=雪，`95`=雷雨
- `daily` 同时给 max/min/日出/日落/降水概率，够写"带外套"这种实用建议了
- 昼夜温差 = `temperature_2m_max - temperature_2m_min`，超过 10℃ 就提醒带外套
- **注意**：返回的 `latitude/longitude` 是网格点（39.89/116.36），不是精确城市中心，正常用

#### ⭐ wttr.in = 空气质量补充源（2026-10-30 实测，比 open-meteo 多"霾"信息）

北京秋冬季有**烟霾**，open-meteo 的 `weather_code` 编不出霾，
但这恰恰是最需要提醒老公戴口罩的天气。**wttr.in 的 `weatherDesc` 直接给
`Smoky haze` / `Smoke` 这类描述**，还带体感温度和逐 3 小时预报：

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=j1" | python3 -c "
import sys,json
d=json.load(sys.stdin)
c=d['current_condition'][0]
w=d['weather'][0]
print('NOW:',c['temp_C']+'C',c['weatherDesc'][0]['value'],'hum',c['humidity']+'%','wind',c['windspeedKmph']+'km/h',c['winddir16Point'],'feels',c['FeelsLikeC']+'C')
print('min',w['mintempC'],'max',w['maxtempC'])
print('sunrise',w['astronomy'][0]['sunrise'],'sunset',w['astronomy'][0]['sunset'])
for h in w['hourly']:
    print(h['time'],h['tempC']+'C',h['weatherDesc'][0]['value'],'rain%',h['chanceofrain'],'wind',h['windspeedKmph'])
print('--- 3day ---')
for day in d['weather'][1:3]:
    print(day['date'],'min',day['mintempC'],'max',day['maxtempC'])
"
```

⚠️ **wttr.in 的坑**：
- 返回里**没有 `lang_zh` 字段**（跟某些版本文档不符）。直接访问 `c['lang_zh']`
  会抛 `KeyError: 'lang_zh'` —— **只用 `weatherDesc[0]['value']`**（英文原值，
  翻译成中文时自己写"烟霾""晴""多云"即可）。
- `time` 字段是 3 小时制整数（0/300/600/900/1200/1500/1800/2100），
  不是 HH:MM，读的时候别当成时间戳解析。
- 逐时 `hourly` 数组同时给了 `chanceofrain` 和 `windspeedKmph`，
  中午风大（实测 23km/h）比降水更值得写进出行提醒。
- 3 天预报在 `d['weather'][1:3]`，可以直接写"明天降温到 X℃"的预告。

**天气栏组合拳**：open-meteo 拿 max/min/日出日落/降水概率，
wttr.in 拿空气质量描述 + 体感温度 + 逐时风速。两者都直连，无需 key。

#### ⭐ weather.com.cn 的实况 JSON 接口（最快，1 个 curl 出当前温度）

```bash
curl -s --max-time 25 "https://www.weather.com.cn/data/sk/101010100.html" \
  -H "Referer: https://www.weather.com.cn/" -H "User-Agent: Mozilla/5.0"
```

返回：
```json
{"weatherinfo":{"city":"北京","temp":"18","WD":"东南风","WS":"1级","SD":"17%","time":"17:05","rain":"0"}}
```

⚠️ **必须带 `Referer: https://www.weather.com.cn/` 和 UA**，否则被拒。
⚠️ `data/cityinfo/101010100.html` 现在 **301 跳转**，别用那个旧路径。
这个接口只给当前实况（不含预报），当"现在的体感"补充用。

### 可用数据源（按可靠性排序）

```bash
# 1. 当前日期（中文格式）
date "+%m月%e日 周%w"   # 输出如：08月21日 周5

# 2. 昨天各 cron job 的实际产出 —— 最有价值的一手材料
#    目录结构：~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md
ls -t ~/.hermes/cron/output/*/ | head
#    重点读：昨晚 21:00 的「每日晚9点回顾推送」输出，它里面已经列好了"明日待办"
#    → 直接把它的"明日待办"搬进今天的待办栏
read_file ~/.hermes/cron/output/<job_id>/<yesterday-file>.md

# 3. 所有定时任务清单（含开关状态和 prompt 摘要）
cd ~/.hermes/cron && python3 -c "
import json
d=json.load(open('jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
if isinstance(jobs,dict): jobs=list(jobs.values())
for j in jobs:
    print(j.get('name'),'|',j.get('schedule'),'| enabled=',j.get('enabled'))
"

# 4. 知识库笔记 / 事实
ls ~/.hermes/knowledge/facts/ ~/.hermes/knowledge/notes/ ~/.hermes/knowledge/我是老公/

# 5. 各 profile 健康状态
for p in cutegirl geekwife libai licai siliconflow wenyu; do
  echo -n "$p: "; ls ~/.hermes/profiles/$p/.env >/dev/null 2>&1 && echo "env ok" || echo "no env"
done
ps -ef | grep -Ei "hermes" | grep -v grep | awk '{print $2, $9, $10, $11}'

# 6. 备份状态（github 仓库 ~/hermes-backup）
ls -la ~/hermes-backup-daily.tar.gz
cd ~/hermes-backup && git log --oneline -1 && git status --short
```

### 日历 / 邮件：先判断有没有配

**不要一上来就 `google_api.py calendar list`** —— 没认证会直接报错。

```bash
ls ~/.hermes/google_token.json ~/.hermes/google_client_secret.json 2>&1
```

- 缺这两个文件 → Google 日历/Gmail **没配**，日程直接写"今天没有安排～"，不要浪费时间尝试
- `himalaya` 也没装（`which himalaya` 为空）→ 邮件同样没有来源
- 更好的判断方式：`skill_view("google-workspace")` 的返回里有
  `readiness_status: setup_needed` / `missing_credential_files` 字段，一眼就能看出来
- `gws` CLI 不存在也说明 Workspace 集成没启用

**结论：老公当前环境没有可用的日历/邮箱数据源，晨间推送的"今日日程"固定填"今天没有安排～"，
待办从 cron 历史输出 + 知识库 + session 历史推。**

### ⭐ 飞书群消息摘要：从 agent.log 的 inbound message 取（2026-10-30 实测）

晨间简报的"飞书群消息摘要"栏**没有现成的摘要文件**，要从平台日志重建。
`~/.hermes/logs/agent.log` 里有完整的收发记录：

```bash
# 最近的入站消息（各平台都有）
grep -a "inbound message" ~/.hermes/logs/agent.log | tail -20 | cut -c1-320

# 只看飞书
grep -a "feishu" ~/.hermes/logs/agent.log | grep -a "inbound\|text=" | tail -12 | cut -c1-350
```

日志行长这样（`platform=feishu/telegram/qqbot`，带 chat_id 和消息正文）：
```
2026-10-29 19:27:08,710 INFO gateway.run: inbound message: platform=telegram
  user=胖蝦球 chat=877708648 msg='逼毛给老婆电报bot启动下' reply_to_id=1703
```

⚠️ **两个坑**：
1. **`agent.log` 会轮转**（`agent.log` / `agent.log.1` / `.2` / `.3`，
   实测各约 5MB）。较老的记录在 `.1`/`.2` 里，**查历史要一起 grep**：
   ```bash
   grep -a "inbound message" ~/.hermes/logs/agent.log ~/.hermes/logs/agent.log.1 2>/dev/null | tail -25
   ```
2. **飞书群消息实际很少**（实测最近一条飞书 inbound 停在 10/23，
   群里基本没人说话）。**查不到就老实写"暂无摘要"，别编。**
   可以顺带说明"最近一条记录停在 X 月 X 日"，让老公知道不是取数失败。

### ⭐ 群名 ↔ chat_id 映射（写摘要时用得上）

`~/.hermes/channel_directory.json` 里 `platforms.feishu` 数组含全部 `oc_xxx`，
有的条目 `name` 是群名、有的只是 ID：

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/channel_directory.json'))
for it in d['platforms']['feishu']:
    print(it['id'],'|',it['name'],'|',it['type'])
"
```

老公的群：id `oc_457ae34d4ae483c1ff40716be1c165cb`，
在 directory 里 name 显示为「飞书用户3923MS」；群里另有一个
`oc_4c9d07126349124f942e382f7501b189`（「飞书用户3923MS的组织」）。
⚠️ **cron job 的飞书投递目标就是这个 `oc_457ae...`** ——
投递失败时它就是排查入口。

## 报告格式模板

```
🌅 老公早上好！X月X日 周X

📅 今日日程：[从日历/Gmail读取今日事件，没有就说"今天没有安排～"]

📋 待办事项：[列出未完成的重要事项，没有就说"今天轻松过～"]

💪 今日目标：[根据待办给出1-3个重点建议]

加油老公！💖
```

### 本简报 prompt 的五模块变体（"早上9点简报" cron）

老公有一个独立的 cron job `c51c6ca0d139`「早上9点简报」，prompt 要求**五个模块**
且模块名固定，**顺序不要改**：

| 模块 | prompt 指定的路径 | 实测 |
|------|------------------|------|
| 📅 今日日程/待办 | `~/.calendar/calendar.ics` | **不存在**（连 `~/.calendar/` 目录都没有）→ 写"暂无日程" |
| 💬 飞书群消息摘要 | `~/.hermes/knowledge/notes/` 读群讨论 | 目录里只有 `scripts.md` → 用 agent.log 重建（见上） |
| 📊 工作进度/任务完成 | `notes/tasks.md` 或 `notes/progress.md` | **两个都不存在** → 用 cron 产出 + 系统状态重建 |
| 🌤️ 天气/出行提醒 | web_search 查北京 | web_search 只能拿到模板页 → 用 wttr.in / open-meteo |
| 📝 自定义内容 | `notes/daily_custom.md` | **不存在** → 写"没有自定义内容" |

⚠️ **prompt 里的路径全部要 `ls` 验证后再读** —— 实测 5 个路径里 4 个不存在。
读之前先 `ls ~/.hermes/knowledge/notes/` 一次，省得逐个试错。

**"工作进度/任务完成情况"栏的重建方式**：用 ✅/❌ 两列表格，
✅ 来自 cron 产出（读 `~/.hermes/cron/output/<job_id>/` 下的最新 .md 文件，
`## Response` 之后就是报告正文），❌ 来自上面那条健康字段/日志兜底链。
实测这样出来的一目了然：

```
| ✅ 搞定 | ❌ 还欠着 |
|---|---|
| Gateway 活着，飞书+QQBot 已连接 | Telegram bot 又 fatal: No bot token configured |
| 每日备份 03:01 跑成功，77.7MB 已 push | siliconflow / wenyu 两个 token 失效还没换 |
| 8 个定时任务全部 enabled | 磁盘 95% 满，只剩 48G |
```

## 语气要求

- 口语化、轻松，像老婆说话
- 简短有力，不啰嗦
- 表情符号分段
- 不说"根据您的情况"之类的废话
- 1-3句话交代完一个点，不要铺排

## ⭐ 待办栏的写法

**核心原则：待办必须是"系统里真实存在、还没修好"的东西，不是编出来的通用建议。**

日历和看板都是空的，所以待办的真正来源是 **cron 健康字段 + 系统状态对比**。
这样出来的待办老公一眼就知道是真事，不会觉得是套话。

好的待办长这样（每条：编号 + 一句话现象 + 一句括号备注）：

```
📋 待办事项
1. ⚠️ 飞书推送失败 —— "每日早上回顾"和"早上9点简报"昨晚都报 [99992402] 字段校验失败
2. ⚠️ MiniMax Token Plan 用量到顶 —— "每日9点回顾推送"10月25号就挂了（HTTP 429）
3. ⚠️ siliconflow / wenyu 两个 bot token 失效 —— 前天重启时就标了待修
```

要点：
- **写出具体 job 名 / 错误码 / 日期** —— 老公能直接搜到，不用再问"哪个任务"
- **标 ⚠️ 表示需要动作，✅ 表示已确认正常**（如"备份今早 3:05 跑成功 ✅"）
- **区分"真故障"和"陈年小事"**：差了好几天的故障才值得单列
- **不要把"老公可能会做的事"写成待办**（如"记得吃饭"），那是废话
- **目标栏从待办推导**，1-3 条，每条一个动词开头（修 / 换 / 清 / 接），
  并说明"为什么值得今天做"（如"修一次两个日报全好"）
- **末尾可以加一行小提示**，说明某个数据源没接（"日历和 Gmail 都还没接进 Hermes"），
  免得老公以为日程真空着

**天气栏的可执行建议**：不只报数字，要给行动建议。
例："昼夜温差快 15 度 → **外套必须带**，早晚凉中午暖"；降水概率 0% → "不带伞"。
⚠️ **有霾/空气质量差时，加一句"出门戴口罩"** —— 这是北京秋冬最有价值的提醒，
只有 wttr.in 能提供这个信息。

## 常读数据源

| 数据 | 来源 | 没有时怎么说 |
|------|------|-------------|
| **待办（首选）** | **`~/.hermes/cron/jobs.json` 的 `last_error` / `last_delivery_error`**（为空则走日志兜底链） | 用下面的 session 历史推 |
| **待办（兜底）** | **`agent.log` grep `cron.scheduler` + `cron/executions.db`** | — |
| 日历/Gmail | `google-workspace` skill（**先看 readiness_status**） | "今天没有安排～" |
| 天气 | **wttr.in**（空气质量）+ **open-meteo**（max/min/日出日落） | 省略这一栏 |
| 昨日待办 | `~/.hermes/cron/output/<job_id>/<昨晚21点文件>.md` | 用 cron 健康字段推 |
| 未完成任务 | `~/.hermes/kanban.db`（存在但**通常是空的**）/ 9119 HTTPS 看板 | "看板要密码，今天轻松过～" |
| **飞书群消息** | **`agent.log` grep `inbound message`** | "暂无摘要"（并注明最近记录日期） |
| 最近聊天上下文 | `session_search(limit=5)` / `session_search(query=...)` | "今天干得不错～" |
| 知识库 | `~/.hermes/knowledge/facts/`、`notes/`、`我是老公/` | 不提这一栏 |
| 系统健康 | `ps -ef \| grep hermes` + 各 profile `.env` | "gateway 正常在跑 ✅" |
| GitHub Trending | 早上8点已推送 | "GitHub Trending AI/ML 早上8点已经推送了，记得看看" |

## 已知坑

- **cron 里 `execute_code` 被拦截**（见上），用 `terminal()` 等普通工具代替
- **Kanban 有两层，别搞混**（2026-10-30 修正）：
  - `~/.hermes/kanban.db` —— **确实存在**（老文档说"不存在"是过时的），
    是 SQLite，有 `tasks` / `task_links` / `task_events` / `task_runs` 等表。
    ⚠️ **但 `tasks` 表通常是空的**（实测 `select status,count(*) from tasks group by status` 返回 0 行），
    所以查它多半白费一轮 —— 可以查，但**别把它当主要待办来源**。
  - 9119 端口的 HTTPS web 看板 —— 要认证，`curl -sk https://127.0.0.1:9119/ka` → `403`。
    拿不到就**不要在报告里编看板内容**。
  - 查 `tasks` 表结构：`python3 -c "import sqlite3; c=sqlite3.connect('/data/data/com.termux/files/home/.hermes/kanban.db'); print([r[0] for r in c.execute(\"select name from sqlite_master where type='table'\")])"`
- **Google Workspace 未配置**：`google_token.json` / `google_client_secret.json` 缺失，
  `himalaya` 也没装 → 日程和邮件两个来源都空着。日程栏固定填"今天没有安排～"
- **⚠️ 别的 cron prompt 里的路径全部要 `ls` 验证**：
  「早上9点简报」prompt 写 `~/.calendar/calendar.ics`、`knowledge/notes/tasks.md`、
  `progress.md`、`daily_custom.md` —— **实测 4 个全不存在**
  （`knowledge/notes/` 里只有 `scripts.md`）。
  → **不要照抄别的 cron prompt 里的路径**，先 `ls` 验证再读。
- **`skill_view` 返回的 `readiness_status` 字段**能直接判断某个 skill 是否已配置，
  比手动 ls 文件快且准 —— 判断"有没有日历"优先看这个字段
- `sqlite3` 命令在 Termux 可能不存在，用 `python3 -c "import sqlite3; ..."` 代替
- Telegram 不稳定（DNS污染），报告通过飞书/QQ推送时不依赖 Telegram 状态
- **报告结尾附一行"系统状态"小表**（gateway / 备份 / 数据源可用性），
  老公喜欢"老板看得懂"的表格格式，但表格要短，别超过 5 项
- **磁盘占用是老公反复被提醒的真问题**（实测长期 95% 满、只剩 48G），
  `df -h /data` 一条命令就能查，报告里带上能让老公觉得有用

## 报告结尾的系统状态栏（老公偏好）

正文（情景/待办/目标）之后，加一行紧凑的系统状态，用表格但不超过 5 项，
并明确指出"哪些数据源今天拿不到"，避免老公以为日历真的没事件：

```
---
**系统状态**：gateway 进程正常 ✅ | 每日备份 03:52 已 push GitHub（`9220611`）✅ | 6 个飞书 profile 环境都在 | Google 日历没配 OAuth，今天日程是空的 | Kanban 看板要密码打不开
```

每项用 `|` 分隔即可，不必用 Markdown 表格（表格在小屏 Telegram 上会被压得很窄）。

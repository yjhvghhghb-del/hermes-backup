# 每日晨间推送 — Cron Job 模板

## 触发方式

Hermes cron job 调度，每天早上推送。

## 数据获取顺序

### ⚠️ 先看这条：cron 模式下 `execute_code` 被拦截

**cron job 里调用 `execute_code` 会直接失败**：

```
BLOCKED: execute_code runs arbitrary local Python (including subprocess calls
that bypass shell-string approval checks). Cron jobs run without a user present
to approve it. Use normal tools instead, or set approvals.cron_mode: approve
```

**解法**：cron 里改用普通工具 —— `terminal()` 跑 shell、`read_file` 读文件、
`search_files` 找文件、`skill_view`/`session_search` 查资料。
不要在 cron 里试图用 `execute_code` 绕过，浪费一轮调用。

### ⭐ 最快的真实待办来源：cron job 健康字段

**这一栏往往比"昨晚 cron 输出"更有价值**，因为它直接暴露**还没修好的故障**，
而昨晚的回顾输出可能已经把这些故障写成了"已完成"或干脆没提。

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
for j in d['jobs']:
    print(f\"{j['name']:20s} | enabled={j.get('enabled')} | last={str(j.get('last_run_at'))[:16]} | status={j.get('last_status')} | err={(j.get('last_error') or '')[:60]} | deliver_err={(j.get('last_delivery_error') or '')[:60]}\")
"
```

**关键字段**（`jobs.json` 每个 job 里都有）：

| 字段 | 含义 | 怎么用 |
|------|------|--------|
| `last_status` | `ok` / `error` | `error` = 这个任务上次跑挂了 |
| `last_error` | 上次跑的异常 | 直接抄进待办栏，是真实故障 |
| `last_delivery_error` | 投递失败（内容生成成功但发不出去） | ⚠️ **最容易被忽略**：`last_status=ok` 但推送失败 |
| `last_run_at` | 上次跑的时间 | 判断是不是"陈年待办"（差好几天 = 该修了） |
| `enabled` | 是否启用 | `enabled=False` 的不用报 |

⚠️ **两条判断原则**：
1. `last_status=ok` **不代表**一切正常 —— 一定要同时看 `last_delivery_error`。
2. cron 任务报 `ok` **不代表产物真的更新了** —— 顺手 `ls -la` 一下产物文件 mtime。
   备份任务尤其容易"假成功"。

### ⚠️ 健康字段可能为空 —— 必须有兜底链（2026-10-30 实测）

**如果 `jobs.json` 的健康字段打印出来全是 `None` / 空字符串**（老版本 Hermes
或不写这些字段的版本会这样），**不要卡在这一步反复试**。直接走下面这条兜底链，
实测一样能挖出真实故障：

```bash
# 兜底 1：从日志里 grep cron 投递错误（最直接）
grep -a "cron.scheduler" ~/.hermes/logs/agent.log | grep -aiE "delivery error|delivery to" | tail -15 | cut -c1-300

# 兜底 2：从执行历史库看每个 job 的成败
cd ~/.hermes/cron && python3 -c "
import sqlite3
c=sqlite3.connect('executions.db')
for r in c.execute('SELECT job_id,status,started_at,finished_at,error FROM executions ORDER BY started_at DESC LIMIT 25'):
    print(r[0], r[1], r[2][:19], '->', (r[4] or '')[:160])
"
```

`executions.db` 的表结构只有一列 `executions`：
`id, job_id, source, process_id, pid, process_started_at, status, claimed_at,
started_at, finished_at, error`。

⚠️ **`status` 只有 `completed` / `running` / `unknown` 三种**，**没有 `failed`**。
`unknown` 表示调度器重启时执行还没到终态（`error` 里会写明
"Scheduler restarted after this execution's owner exited..."）。
→ **`status=completed` 也可能带着投递失败**，真正的失败原因只在
`agent.log` 里，务必配合兜底 1 一起看。

**2026-10-30 实测：靠这条兜底链挖出了两个真实故障**
（`jobs.json` 健康字段当时打印不出来）：
- 飞书群投递 `[99992402] field validation failed`（三个早报 job 全中）
- 插件自身的 bug：`'CreateMessageResponse' object has no attribute 'get'`

⚠️⚠️ **但别把这两种情况都当成"投递失败"！**（2026-10-30 晚间复测发现）
`'CreateMessageResponse' object has no attribute 'get'` 这条 WARNING 之后，
cron **会自动 fallback 到 standalone 通道并成功投递**：

```
09:01:38 WARNING ... live adapter delivery ... failed: 'CreateMessageResponse' object has no attribute 'get', falling back to standalone
09:01:39 INFO    ... delivered to feishu:oc_457ae...     ← 实际送达了
```

⚠️ **类名不止一个，grep 要通配**（2026-11-01 实测又遇到
`'ReplyMessageResponse' object has no attribute 'get'`，同一根因、
`cron/scheduler.py:1913` 无条件对平台返回对象调 `.get()`）。
**别只匹配 `CreateMessageResponse`** —— 用通配：

```bash
grep -a " object has no attribute 'get'" ~/.hermes/logs/agent.log | tail -5
```

→ **判断早报是否送达，要 grep `cron.scheduler` 的 `delivered`，不是 grep WARNING/ERROR。**
实测当天三条早报**全部 `delivered` 成功**。报成"三条日报全挂"是误报 ——
正确说法是"live adapter 有 bug，但 fallback 兜住了，日报一条没漏 ✅，根因仍要修"。
这个坑已经在早报上误报过一次，别重复。

#### ⭐⭐⭐ 飞书插件 bug 的**确切根因**（2026-10-31 定位，报告里可以直接写出来）

这个 bug 从 10-30 就在每天刷 WARNING，之前只知道"要 grep `delivered` 判送达"，
不知道错在哪。10-31 晨间推送彻底定位到了，**老公问"这个 bug 要我修不"时可以直接给答案**：

**根因在 `cron/scheduler.py`，不在飞书插件里。** `~/.hermes/hermes-agent/cron/scheduler.py:1913`：

```python
elif (
    send_raw_response
    and thread_id
    and send_raw_response.get("thread_fallback")   # ← BUG 在这
):
```

- `thread_fallback` 是 **Telegram adapter 专属**的 dict key
  （见 `plugins/platforms/telegram/adapter.py:4679`，它往返回的 dict 里塞
  `"thread_fallback": used_thread_fallback`）。
- 飞书 adapter 返回的是 **lark_oapi SDK 的对象**
  （`CreateMessageResponse` / `ReplyMessageResponse`），**不是 dict，没有 `.get()`**
  → `AttributeError: 'CreateMessageResponse' object has no attribute 'get'`
- 调度器对**所有平台**无条件调 `.get()`，所以只有飞书炸（其它平台的 raw_response 恰好是 dict）。

**飞书插件本身是干净的** —— `plugins/platforms/feishu/adapter.py` 的
`_response_succeeded` / `_extract_response_field` / `_finalize_send_result`
全部用 `getattr()`，没有裸 `.get()`。**别去改飞书插件，改了也没用。**

**正确修法**（在 scheduler 里判类型）：

```python
and isinstance(send_raw_response, dict)
and send_raw_response.get("thread_fallback")
```

**上游 bug，本地 git 仓库 `~/.hermes/hermes-agent` 的 HEAD 是
`15cb86e refactor(update): one definition of "first-party module"`（2026-08-01）**，
`git diff HEAD -- cron/scheduler.py` 为空 —— 说明这是**上游就有的问题**，
不是老公本地改坏的。修法建议提 PR 上游，或本地打补丁（改一行）。

⚠️ **写报告时的措辞**：这是"每条早报都触发一次但被 fallback 兜住"的噪音 bug，
**不影响送达**。别写成"飞书推送坏了/全挂了"（误报过一次），
正确说法："live adapter 有 bug，但 fallback 兜住了，日报一条没漏 ✅，根因已定位在 scheduler.py"。

### ⭐ 网关运行时长与内存压力：`~/.hermes/state/gateway.heartbeat`（2026-10-31 实测）

**这是唯一一个能直接回答"系统跑得稳不稳"的权威来源**，比 `ps -ef` 强
（`ps` 只证明进程存在，heartbeat 证明进程还活着且内存情况如何）。
2026-10-31 晨间推送就是靠它写出"gateway 从 10月29日 19:30 连续跑到现在没重启过 ✅"
和"内存只剩 2.6G，swap 用了 13G"。

```bash
cat ~/.hermes/state/gateway.heartbeat
# {"pid": 16961, "updated_at": "2026-10-31T01:01:22.325791+00:00", "monotonic": 187818.72,
#  "start_time": 1793273410.8661048,
#  "mem": {"rss_kib": 187760, "mem_total_kib": 15562024,
#          "mem_available_kib": 2675636, "swap_used_kib": 13670752}}

cat ~/.hermes/state/gateway.lifecycle.json
# {"phase": "running", "pid": 16961, "start_time": 1793273410.87,
#  "started_at": "2026-10-29T11:30:10.872421+00:00"}
```

字段解读：

| 字段 | 含义 | 怎么写进报告 |
|------|------|-------------|
| `phase` (`lifecycle.json`) | `running` = 活的 | 直接写"gateway 运行中 ✅" |
| `started_at` (`lifecycle.json`) | **本地时区** ISO 串（带 +08:00 偏移） | 换算成"10月29日 19:30 启动，连续跑到现在" |
| `pid` | 进程号 | 和 `ps -ef` 交叉验证是不是同一个 |
| `mem.mem_available_kib` | **可用内存**（KB） | ⚠️ 这才是判断 OOM 风险的指标，不是 RSS |
| `mem.swap_used_kib` | **已用 swap**（KB） | 涨到 10GB+ = 内存压力大 |
| `mem.rss_kib` | gateway 自身占用 | 单看这个没用，gateway 占 180M 很正常 |

⚠️ **`updated_at` 是 UTC**（结尾 `+00:00`），而 `lifecycle.json` 的 `started_at` 是**本地时区**。
写"连续跑了多久"用 `started_at`，别拿 `updated_at` 去减 —— 会差 8 小时。
算运行时长用 `started_at` 跟当前时间比。

⚠️ **`mem_available_kib` 只有 2.6G（占 15.5G 总内存的 17%）且 swap 已用 13G** 时，
即使所有服务都正常，也值得在"今日目标"里提一句"别再开新 bot/别同时跑重活"。
这是 Android 环境下 SIGKILL（exit 137）的前兆，见 `android-hermes-memory-management`。

### ⚠️ 平台网络 WARNING 大多是"自动恢复噪声"，别当故障写进待办

日志里这类 WARNING 每天都在刷，**adapter 会自动重连恢复**，写进待办会让老公
以为系统坏了，白分心：

```
WARNING ... [Telegram] Telegram polling degraded (heartbeat probe); gateway stays alive and will retry.
WARNING ... [Telegram] Telegram network error (attempt 1/10), reconnecting in 5s.
ERROR   ... Lark: receive message loop exit, err: no close frame received or sent
ERROR   ... Lark: receive message loop exit, err: received 3003 (registered) ping timeout
```

判断标准（和"插件 bug 要 grep `delivered`"是同一枚硬币的两面）：

| 日志 | 是不是真故障 | 怎么处理 |
|------|-------------|---------|
| `attempt 1/10` / `2/10` + 几秒后重连成功 | ❌ 不是，自动恢复 | 不写待办，最多在"系统状态"里一句话带过 |
| Lark `ping timeout` / `no close frame` | ❌ 不是，长连接保活重连 | 同上 |
| `attempt 9/10`、`10/10` 仍在重试 | ⚠️ 可能是真断 | 才值得写待办 |
| `'CreateMessageResponse' object has no attribute 'get'` | ⚠️ 插件 bug，但**要 grep `delivered` 确认是否 fallback 成功** | 见下文"假失败"坑 |
| `cron.scheduler` 的 `delivery error` / `delivered to` | ✅ 这才是投递真相 | grep `delivered` 判送达 |

2026-10-31 实测：昨夜 Telegram 断了 4 次（23:23 / 23:36 / 23:58）、今早 Lark 抖了 5 次，
**全部自动恢复、消息没丢一条** —— 这些不该占待办栏的位置。
待办栏留给"需要老公动手"的事：插件 bug、token 失效、磁盘满。

### ⭐ `hermes cron list` = 最快的 cron 任务清单（2026-10-31 实测，优于解析 jobs.json）

要列"今天哪些 cron 在跑 / 上次跑成功没"，**直接跑 `hermes cron list` 就行**，
比写 python 解析 `jobs.json` 少一轮调用，输出还自带格式化表格：

```bash
hermes cron list
```

输出长这样，每个 job 都带这几行（**比 jobs.json 更全 —— jobs.json 里的健康字段常为空**）：

```
  cd38d14f5563 [active]
    Name:      每日早上回顧
    Schedule:  0 9 * * *
    Next run:  2026-11-01T09:00:00+08:00
    Deliver:   origin
    Last run:  2026-10-30T09:01:39.482417+08:00  ok     ← 上次跑的结果
    Execution: running  01661f9e2dac4da09f187a47b9390804
```

- `Last run: ... ok` = 上次成功；`Execution: running` = 正在跑
- ⚠️ **今天 9 点的 job 在 09:00 跑的时候，`Last run` 可能还显示昨天** ——
  因为当前 job 本身正在执行中。判断"今天跑没跑"要等它变成 `ok`，
  或者去看 `~/.hermes/logs/agent.log` 的 `cron.scheduler` 行。
- ⚠️ **8 个 job 一起列出来会占不少输出**。若只想要状态行，可以
  `hermes cron list | tail -60` 截断，或 `grep -E 'Name:|Last run:'` 过滤。
- ⚠️ 这个命令**会输出全部 8 个 job 的完整 prompt 之外的元信息**，
  但**不包含 prompt 正文** —— 想拿 prompt 线索还是要读 `jobs.json`。

### ⭐ 备份"真的 push 上去了"的验证方法（2026-10-31 实测）

报"备份已完成 ✅"之前，**别只看 `git log` 有新 commit** ——
本地 commit 了但 push 失败是常见假成功。用 `git rev-list` 双向计数确认：

```bash
cd ~/hermes-backup
git log --oneline -3          # 最新 commit（应该带当天日期）
git log origin/main --oneline -3   # 远端最新 commit ← 关键：这两个要对得上
git rev-list --count origin/main..main   # 0 = 已全部推送 ✅
git rev-list --count main..origin/main   # 0 = 没有远端领先
```

实测结果：`origin/main` 的 HEAD 和本地 HEAD 都是 `21f1a73 Backup 2026-10-31 03:01`，
双向计数都是 `0` → 确认推送成功。

⚠️ **备份仓库有多个同名目录，别搞错**：`~/hermes-backup`（活跃，git remote 正常）、
`~/hermes-backup-git`（停在 10-22）、`~/hermes-backup-repo`（停在 9-10）、
`~/hermes-backup-old`、`~/hermes-backup-daily`（tar.gz 目录）。
**只有 `~/hermes-backup` 是当前在用的** —— 报告里引用 commit hash 前先确认目录，
否则会引用到两个月前的陈年 commit。

### 读 `jobs.json` 当"任务清单"用（不只是健康字段）

除了取 `last_error`，`jobs.json` 还有两个用途值得单独跑一轮：

```bash
cd ~/.hermes/cron && python3 -c "
import json
j=json.load(open('jobs.json'))
jobs = j if isinstance(j,list) else j.get('jobs',[])
for x in jobs:
    print('-',x.get('id'),'|',x.get('name'),'|',x.get('schedule'),'|',x.get('prompt','')[:150].replace(chr(10),' '))
"
```

1. **看今天还有哪些 cron 一起在跑** —— 早上 9 点有 4 个 job 同时启动
   （早报 / 简报 / AI 日报 / 本推送）。列出来能确认"兄弟任务都起来了"，
   也能看出**推送重复风险**（老公会同时收到 3 份早报，格式雷同）。
2. **读别的 job 的 prompt = 免费拿到"老公还想要什么模块"的线索** ——
   prompt 里会写明它想读哪些路径（如 `~/.calendar/calendar.ics`、`notes/tasks.md`），
   顺手 `ls` 验证一下这些路径是否真存在，**别照抄**（实测多数不存在）。
   ⚠️ `jobs.json` 顶层可能是 list 也可能是 `{"jobs":[...]}`，脚本里两种都要兼容。

### 天气：open-meteo（不用装东西）

`weather.com.cn` 之类的页面 `web_search` 只能拿到模板页，**没有真实当天数据**。
用 open-meteo API，直连、无需 key、返回 JSON：

> ⚠️⚠️ **2026-10-31：`web_search` 本身整个挂了。**
> `web_search("北京今天天气...")` 和 `web_extract(...)` **同时**返回
> `Client error '432 '`（Tavily 后端拒绝）。这不是"页面没数据"，是**搜索后端在拒绝调用**，
> 换个查询词、换个 URL 都没用。
> **正确应对：别在 web_search 上试第二轮，直接 `curl` 打上面这些 keyless API**，
> `python3 -c` 解析，10 秒钟出结果（本次实测 wttr.in 直连一次成功）。
> ⚠️ 这是配额/凭证层的状态，不是功能坏了 —— 下次运行要重新试，
> 但**不要因为这次失败就在报告里写"天气查不到"**，一定有 fallback 源。

```bash
curl -s --max-time 25 'https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max,sunrise,sunset&timezone=Asia%2FShanghai&forecast_days=1'
```

- `weather_code` 是 WMO 编码：`0`=晴，`1-3`=多云，`51-67`=雨，`71-77`=雪，`95`=雷雨
- `daily` 同时给 max/min/日出/日落/降水概率，够写"带外套"这种实用建议了
- 昼夜温差 = `temperature_2m_max - temperature_2m_min`，超过 10℃ 就提醒带外套
- **注意**：返回的 `latitude/longitude` 是网格点（39.89/116.36），不是精确城市中心，正常用

#### ⭐ wttr.in = 空气质量补充源（2026-10-30 实测，比 open-meteo 多"霾"信息）

北京秋冬季有**烟霾**，open-meteo 的 `weather_code` 编不出霾，
但这恰恰是最需要提醒老公戴口罩的天气。**wttr.in 的 `weatherDesc` 直接给
`Smoky haze` / `Smoke` 这类描述**，还带体感温度和逐 3 小时预报：

```bash
curl -s --max-time 25 "https://wttr.in/Beijing?format=j1" | python3 -c "
import sys,json
d=json.load(sys.stdin)
c=d['current_condition'][0]
w=d['weather'][0]
print('NOW:',c['temp_C']+'C',c['weatherDesc'][0]['value'],'hum',c['humidity']+'%','wind',c['windspeedKmph']+'km/h',c['winddir16Point'],'feels',c['FeelsLikeC']+'C')
print('min',w['mintempC'],'max',w['maxtempC'])
print('sunrise',w['astronomy'][0]['sunrise'],'sunset',w['astronomy'][0]['sunset'])
for h in w['hourly']:
    print(h['time'],h['tempC']+'C',h['weatherDesc'][0]['value'],'rain%',h['chanceofrain'],'wind',h['windspeedKmph'])
print('--- 3day ---')
for day in d['weather'][1:3]:
    print(day['date'],'min',day['mintempC'],'max',day['maxtempC'])
"
```

⚠️ **wttr.in 的坑**：
- 返回里**没有 `lang_zh` 字段**（跟某些版本文档不符）。直接访问 `c['lang_zh']`
  会抛 `KeyError: 'lang_zh'` —— **只用 `weatherDesc[0]['value']`**（英文原值，
  翻译成中文时自己写"烟霾""晴""多云"即可）。
- `time` 字段是 3 小时制整数（0/300/600/900/1200/1500/1800/2100），
  不是 HH:MM，读的时候别当成时间戳解析。
- 逐时 `hourly` 数组同时给了 `chanceofrain` 和 `windspeedKmph`，
  中午风大（实测 23km/h）比降水更值得写进出行提醒。
- 3 天预报在 `d['weather'][1:3]`，可以直接写"明天降温到 X℃"的预告。

⭐⭐ **最省事的一条命令版（2026-11-01 实测，推荐用于早报）** ——
wttr.in 支持自定义 format，**不用 python 解析 JSON**，一条 curl 直接出可读文本：

```bash
curl -s -m 25 "https://wttr.in/Beijing?format=%25l:+%25C+%25t+feels+%25f+wind+%25w+humidity+%25h"
# Beijing: Smoky haze +9°C feels +8°C wind ↘11km/h humidity 59%
```

⚠️ **`%` 必须转义成 `%25`** —— 不转义的话 shell/URL 编码会把 `%C` `%t` 吃掉，
返回的是空串或乱码。这是这条命令唯一的坑。
一次就拿到：地名、天气描述（含霾）、当前温度、体感温度、风向风速、湿度。

⭐ **配合 open-meteo 的紧凑版**（2026-11-01 实测，一条 curl 出 max/min/降水概率/体感）：

```bash
curl -s -m 25 "https://api.open-meteo.com/v1/forecast?latitude=39.9042&longitude=116.4074&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max,weather_code&timezone=Asia%2FShanghai&forecast_days=1"
```

实测返回：`{"current":{"time":"2026-11-01T09:00","temperature_2m":7.3,...,"apparent_temperature":5.6},"daily":{"temperature_2m_max":[16.6],"temperature_2m_min":[5.4],"precipitation_probability_max":[27]}}`
→ 早报天气栏直接写：当前 7.3℃（体感 5.6℃）/ 今日 5.4~16.6℃ / 降水概率 27% / 有霾。
**两条 curl 直连，不需要 web_search、不需要代理、不需要 key。**

⚠️ **2026-11-01 再次确认 `web_search` + `web_extract` 同时 432** ——
搜"北京今天天气 2026年11月1日 温度"直接 432，换 URL 也 432（`wttr.in` 经
`web_extract` 同样 432，因为它走的也是 Tavily extract 后端）。
**结论不变：天气永远走 `curl` 直连，不要浪费轮次在 web_search 上。**
而且**别在报告里写"天气查不到"** —— curl 一定能查到。

**天气栏组合拳**：open-meteo 拿 max/min/日出日落/降水概率，
wttr.in 拿空气质量描述 + 体感温度 + 逐时风速。两者都直连，无需 key。

#### ⭐ weather.com.cn 的实况 JSON 接口（最快，1 个 curl 出当前温度）

```bash
curl -s --max-time 25 "https://www.weather.com.cn/data/sk/101010100.html" \
  -H "Referer: https://www.weather.com.cn/" -H "User-Agent: Mozilla/5.0"
```

返回：
```json
{"weatherinfo":{"city":"北京","temp":"18","WD":"东南风","WS":"1级","SD":"17%","time":"17:05","rain":"0"}}
```

⚠️ **必须带 `Referer: https://www.weather.com.cn/` 和 UA**，否则被拒。
⚠️ `data/cityinfo/101010100.html` 现在 **301 跳转**，别用那个旧路径。
这个接口只给当前实况（不含预报），当"现在的体感"补充用。

### 可用数据源（按可靠性排序）

```bash
# 1. 当前日期（中文格式）
date "+%m月%e日 周%w"   # 输出如：08月21日 周5

# 2. 昨天各 cron job 的实际产出 —— 最有价值的一手材料
#    目录结构：~/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md
ls -t ~/.hermes/cron/output/*/ | head
#    重点读：昨晚 21:00 的「每日晚9点回顾推送」输出，它里面已经列好了"明日待办"
#    → 直接把它的"明日待办"搬进今天的待办栏
read_file ~/.hermes/cron/output/<job_id>/<yesterday-file>.md

# 3. 所有定时任务清单（含开关状态和 prompt 摘要）
cd ~/.hermes/cron && python3 -c "
import json
d=json.load(open('jobs.json'))
jobs = d if isinstance(d,list) else d.get('jobs',d)
if isinstance(jobs,dict): jobs=list(jobs.values())
for j in jobs:
    print(j.get('name'),'|',j.get('schedule'),'| enabled=',j.get('enabled'))
"

# 4. 知识库笔记 / 事实
ls ~/.hermes/knowledge/facts/ ~/.hermes/knowledge/notes/ ~/.hermes/knowledge/我是老公/

# 5. 各 profile 健康状态
for p in cutegirl geekwife libai licai siliconflow wenyu; do
  echo -n "$p: "; ls ~/.hermes/profiles/$p/.env >/dev/null 2>&1 && echo "env ok" || echo "no env"
done
ps -ef | grep -Ei "hermes" | grep -v grep | awk '{print $2, $9, $10, $11}'

# 6. 备份状态（github 仓库 ~/hermes-backup）
ls -la ~/hermes-backup-daily.tar.gz
cd ~/hermes-backup && git log --oneline -1 && git status --short
```

### 日历 / 邮件：先判断有没有配

**不要一上来就 `google_api.py calendar list`** —— 没认证会直接报错。

```bash
ls ~/.hermes/google_token.json ~/.hermes/google_client_secret.json 2>&1
```

- 缺这两个文件 → Google 日历/Gmail **没配**，日程直接写"今天没有安排～"，不要浪费时间尝试
- `himalaya` 也没装（`which himalaya` 为空）→ 邮件同样没有来源
- 更好的判断方式：`skill_view("google-workspace")` 的返回里有
  `readiness_status: setup_needed` / `missing_credential_files` 字段，一眼就能看出来
- `gws` CLI 不存在也说明 Workspace 集成没启用

**结论：老公当前环境没有可用的日历/邮箱数据源，晨间推送的"今日日程"固定填"今天没有安排～"，
待办从 cron 历史输出 + 知识库 + session 历史推。**

### ⭐ 飞书群消息摘要：从 agent.log 的 inbound message 取（2026-10-30 实测）

晨间简报的"飞书群消息摘要"栏**没有现成的摘要文件**，要从平台日志重建。
`~/.hermes/logs/agent.log` 里有完整的收发记录：

```bash
# 最近的入站消息（各平台都有）
grep -a "inbound message" ~/.hermes/logs/agent.log | tail -20 | cut -c1-320

# 只看飞书 —— ⚠️ 用 platform=feishu 过滤，不要用 "feishu"（2026-11-01 实测）
grep -ah "inbound message" ~/.hermes/logs/agent.log ~/.hermes/logs/agent.log.1 2>/dev/null \
  | grep -a "platform=feishu" | tail -12 | cut -c1-380
```

⚠️ **2026-11-01 实测修正**：上面第二种"只看飞书"的写法
（`grep -a "feishu" ... | grep -a "inbound\|text="`）**匹配不到任何东西** ——
飞书的 inbound 行里 `platform=feishu` 是**字段值**，
而 `grep -a "feishu"` 会先命中同文件里大量 `ERROR Lark:` / `Lark: connect failed` 行，
`head`/`tail` 截断后真正的 inbound 行被冲掉了。
**正确做法**：先 `grep -ah "inbound message"`（用 `-h` 避免多文件时打 `file:` 前缀），
再 `grep -a "platform=feishu"`。2026-11-01 用这个写法一次命中 3 条（10-23 的"在吗"/"抱抱"）。

⚠️ **当天 `agent.log` 里的 inbound 可能只有 1 条** —— 2026-11-01 实测
`grep -ac "inbound message" agent.log` 返回 **1**，而 `.1`（10-30 之前）里有更多。
**只看当天文件会漏掉历史**，务必带上 `.1`/`.2`/`.3` 一起 grep。
另外 `grep -a "inbound message" agent.log | grep -a "chat=oc_"` 这个写法**在当天文件上返回空**
（因为当天那条不是飞书群消息），别据此以为"飞书群没消息"—— 去掉 chat= 再看平台字段。

日志行长这样（`platform=feishu/telegram/qqbot`，带 chat_id 和消息正文）：
```
2026-10-29 19:27:08,710 INFO gateway.run: inbound message: platform=telegram
  user=胖蝦球 chat=877708648 msg='逼毛给老婆电报bot启动下' reply_to_id=1703
```

⚠️ **两个坑**：
1. **`agent.log` 会轮转**（`agent.log` / `agent.log.1` / `.2` / `.3`，
   实测各约 5MB）。较老的记录在 `.1`/`.2` 里，**查历史要一起 grep**：
   ```bash
   grep -a "inbound message" ~/.hermes/logs/agent.log ~/.hermes/logs/agent.log.1 2>/dev/null | tail -25
   ```
2. **飞书群消息实际很少**（实测最近一条飞书 inbound 停在 10/23，
   群里基本没人说话）。**查不到就老实写"暂无摘要"，别编。**
   可以顺带说明"最近一条记录停在 X 月 X 日"，让老公知道不是取数失败。

### ⭐ 群名 ↔ chat_id 映射（写摘要时用得上）

`~/.hermes/channel_directory.json` 里 `platforms.feishu` 数组含全部 `oc_xxx`，
有的条目 `name` 是群名、有的只是 ID：

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/channel_directory.json'))
for it in d['platforms']['feishu']:
    print(it['id'],'|',it['name'],'|',it['type'])
"
```

老公的群：id `oc_457ae34d4ae483c1ff40716be1c165cb`，
在 directory 里 name 显示为「飞书用户3923MS」；群里另有一个
`oc_4c9d07126349124f942e382f7501b189`（「飞书用户3923MS的组织」）。
⚠️ **cron job 的飞书投递目标就是这个 `oc_457ae...`** ——
投递失败时它就是排查入口。

## 报告格式模板

```
🌅 老公早上好！X月X日 周X

📅 今日日程：[从日历/Gmail读取今日事件，没有就说"今天没有安排～"]

📋 待办事项：[列出未完成的重要事项，没有就说"今天轻松过～"]

💪 今日目标：[根据待办给出1-3个重点建议]

加油老公！💖
```

### 本简报 prompt 的四模块变体（"每日9点回顾推送" cron, job `27957f101f60`）

除了五模块的「早上9点简报」，老公还有一个**四模块**的晨间推送 job
（`27957f101f60`「每日9点回顾推送」），prompt 固定四段：

```
🌅 老公早上好！X月X日 周X
📅 今日日程：[日历/Gmail，没有就说"今天没有安排～"]
📋 待办事项：[列出未完成的重要事项]
💪 今日目标：[根据待办给出1-3个重点建议]
加油老公！💖
```

⚠️ **这个 job 的 prompt 和「早上9点简报」几乎同名，容易混**。区别：
- `27957f101f60` = 四模块（本文节），**没有**天气栏、**没有**飞书群摘要栏
- `c51c6ca0d139` = 五模块（日程/群摘要/工作进度/天气/自定义）

两个 job **都在早上 9:00 跑**（实测 09:00:24 同时启动 4 个 cron）。
所以老公早上会收到两份高度相似的早报 —— 这是他的配置，**不要在报告里吐槽重复**，
但也别自己再造第三份雷同内容。

**这个 prompt 版式的补充用法**（2026-10-31 实测效果好）：
四模块写完以后，加一段「✅ 昨晚干的」+ 一个系统状态段落，
比硬填日程栏更有价值 —— 因为日程栏在老公这儿**永远是空的**（没接日历），
真正有信息量的是"昨晚哪些 cron 跑成功了"和"系统现在什么状态"。
用 `cron/executions.db` 查当天已完成的任务 + `gateway.heartbeat` 查运行时长。

### 本简报 prompt 的五模块变体（"早上9点简报" cron）

老公有一个独立的 cron job `c51c6ca0d139`「早上9点简报」，prompt 要求**五个模块**
且模块名固定，**顺序不要改**：

| 模块 | prompt 指定的路径 | 实测 |
|------|------------------|------|
| 📅 今日日程/待办 | `~/.calendar/calendar.ics` | **连 `~/.calendar/` 目录都不存在**（2026-11-01 复测确认）→ 写"暂无日程" |
| 💬 飞书群消息摘要 | `~/.hermes/knowledge/notes/` 读群讨论 | 目录里只有 `scripts.md` → 用 agent.log 重建（见上） |
| 📊 工作进度/任务完成 | `notes/tasks.md` 或 `notes/progress.md` | **两个都不存在** → 用 cron 产出 + 系统状态重建 |
| 🌤️ 天气/出行提醒 | web_search 查北京 | web_search 只能拿到模板页 → 用 wttr.in / open-meteo（curl 直连） |
| 📝 自定义内容 | `notes/daily_custom.md` | **不存在** → 写"没有自定义内容" |

⚠️ **prompt 里的路径全部要 `ls` 验证后再读** —— 实测 5 个路径里 4 个不存在。
读之前先 `ls ~/.hermes/knowledge/notes/` 一次，省得逐个试错。
2026-11-01 复测：`notes/` 目录里**仍然只有 `scripts.md`**（`tasks.md` / `progress.md` /
`daily_custom.md` 全部不存在），`~/.calendar/` 目录本身也没有。
→ **"工作进度"栏只能靠 cron 产出 + 日志重建，永远别指望 notes/。**

**"工作进度/任务完成情况"栏的重建方式**：用 ✅/❌ 两列表格，
✅ 来自 cron 产出（读 `~/.hermes/cron/output/<job_id>/` 下的最新 .md 文件，
`## Response` 之后就是报告正文），❌ 来自上面那条健康字段/日志兜底链。
实测这样出来的一目了然：

```
| ✅ 搞定 | ❌ 还欠着 |
|---|---|
| Gateway 活着，飞书+QQBot 已连接 | Telegram bot 又 fatal: No bot token configured |
| 每日备份 03:01 跑成功，77.7MB 已 push | siliconflow / wenyu 两个 token 失效还没换 |
| 8 个定时任务全部 enabled | 磁盘 95% 满，只剩 48G |
```

#### ⭐⭐ "工作进度"栏用**今天同一批** cron 的产出，不用等昨晚的（2026-10-31 实测最优）

早上 9 点同时启动 4 个 job（早报 / 简报 / AI 日报 / 9点回顾推送），
**已经在今早跑完的那几个，其输出文件就是最新鲜的"今天干了啥"一手材料** ——
比昨晚 21 点的回顾还准。一轮就能把当天所有 job 的产出全捞出来：

```bash
for d in ~/.hermes/cron/output/*/; do
  f=$(ls -1 "$d" 2>/dev/null | grep "^$(date +%Y-%m-%d)" | tail -1)
  [ -n "$f" ] && { echo "--- $d$f"; sed -n '/## Response/,$p' "$d$f" | head -40; }
done
```

2026-10-31 实测这一轮直接拿到：备份 03:02 的报告（77.7MB / commit `21f1a73` /
已 push）、GitHub Trending 08:25、每日早上回顾 09:01 —— 三条全 ✅，
「工作进度」栏当场就能写成一张带时间的表格：

```
| 任务 | 时间 | 结果 |
|---|---|---|
| 📦 Hermes 备份 | 03:02 | ✅ 77.7MB，commit `21f1a73`，已 push origin main |
| 📰 GitHub Trending | 08:25 | ✅ 正常出稿 |
| 🌅 每日早上回顾 | 09:01 | ✅ 已推送 |
```

⚠️ **注意**：这轮 `ls` 里会出现**昨天**的文件（目录里按时间累积），
`grep "^$(date +%Y-%m-%d)"` 才是"今天"的过滤条件。
⚠️ 同一目录里失败的 job 也会留文件，文件头写 `# Cron Job: <name> (FAILED)` +
`## Error` 段 —— **别把 FAILED 的当成功报**，先看头两行。
⚠️ 读兄弟 job 的 `## Response` 正文还能**免费学到老公想要的版式**
（模块名、顺序、口吻）—— 照着来，别自己另发明一套。

#### ⭐⭐⭐ 模块空着 ≠ 报"暂无"—— 从邻近真实信号**重建**该模块（2026-11-01 复盘，最重要的写法）

五模块简报里 4 个模块的指定路径都不存在。**如果照抄 prompt 就写"暂无日程 / 暂无摘要 /
没有自定义内容"，这份简报就等于没干活** —— 老公收不到任何新信息。

**正确做法：每个空模块都从别的真实信号重建一版"有内容但诚实"的版本。**

| 模块 | 路径缺失时**不要**写 | 改写成（真实来源） |
|------|-------------------|-------------------|
| 📅 今日日程 | "暂无日程" | "暂无日程 ⏳ —— `~/.calendar/calendar.ics` 不存在，日历还没接上，**告诉我安排我帮你记下来**"（点明缺什么 + 下一步） |
| 💬 飞书群摘要 | "暂无摘要" | "暂无摘要 💭 —— 最后一次群消息停在 **10月23日**的「在吗」「抱抱」；不过今早 09:02 的「每日早上回顧」**已成功投递到群里** ✅"（给日期 + 给邻近事实） |
| 📊 工作进度 | "暂无" | **表格**：GitHub Trending 08:11 ✅已推Telegram / 每日早上回顾 09:02 ✅已投飞书 / 每日AI资讯 09:00 🔄正在跑 / 晚间总结 ⏳今晚20:00（来源：`agent.log` 的 `cron.scheduler` 行 + `hermes cron list`） |
| 🌤️ 天气 | "天气查不到" | curl 直连 wttr.in + open-meteo，**永远查得到**；432 时更要走 curl 别写"查不到" |
| 📝 自定义内容 | "没有自定义内容" | "📭 `daily_custom.md` 不存在 —— 但知识库里存了「**数码知识库**」和**脚本笔记**（贴图脚本 / Telegram 流式 / TTS 女声修复），随时能调出来 🔧"（把邻近资产提出来） |

⚠️ **再补一句"要不要我建一个自动更新的？"** —— 把"文件缺失"变成一个待确认的动作，
老公一句话就能推动，比留个空栏有价值。

⚠️ **反面教训**：写"暂无"是可以的，但**必须写清"为什么暂无"**（路径不存在 / 数据源没接），
不能只丢四个字让老公以为是取数失败。**"暂无 + 原因 + 邻近事实" = 合格的空模块。**

#### ⭐⭐⭐ 更快：一条 grep 直接拿到"今天跑了什么 + 送到了没"（2026-11-01 实测）

不用读 `cron/output/` 的文件，**`agent.log` 的 `cron.scheduler` 行本身就带全了信息**：
`Running job '<名字>' (ID: xxx)` → `Job 'xxx': delivered to <目标>`。
一条命令出当天全部 job 的运行 + 送达状态：

```bash
grep -a "2026-$(date +%m-%d)" ~/.hermes/logs/agent.log | grep -a "cron.scheduler" \
  | grep -aE "Running job|completed successfully|delivered to" | cut -c1-260
```

2026-11-01 实测输出（这就是"工作进度"栏的原料）：

```
2026-11-01 08:00:43 INFO cron.scheduler: Running job 'github-trending-daily' (ID: a60c53e7db02)
2026-11-01 08:11:04 INFO cron.scheduler: Job 'a60c53e7db02': delivered to telegram:877708648 via live adapter
2026-11-01 09:00:48 INFO cron.scheduler: Running job '每日早上回顧' (ID: cd38d14f5563)
2026-11-01 09:00:48 INFO cron.scheduler: Running job '早上9点简报' (ID: c51c6ca0d139)
2026-11-01 09:00:48 INFO cron.scheduler: Running job '每日9点回顾推送' (ID: 27957f101f60)
2026-11-01 09:00:54 INFO cron.scheduler: Running job '每日AI资讯' (ID: 377472e94c28)
2026-11-01 09:02:02 INFO cron.scheduler: Job 'cd38d14f5563': delivered to feishu:oc_457ae34d4ae483c1ff40716be1c165cb
```

→ 写成表格就是"工作进度"栏：
GitHub Trending 08:00 ✅ 已推 Telegram / 每日早上回顧 09:02 ✅ 已投飞书群 /
每日AI资讯 09:00 🔄 正在跑 / 晚间总结 ⏳ 今晚 20:00。

⚠️ **日期过滤要带月份日期**（`2026-$(date +%m-%d)`），不要只 `grep "$(date +%F)"` ——
日志时间戳格式是 `2026-11-01 08:00:43`（日期和时间之间**有空格**），
用 `2026-11-01` 能匹配上，但用 `2026-11-01T` 之类的就不行。

⭐ **顺带能拿到"正在跑"的 job**：有 `Running job` 但**还没有**对应
`completed successfully` / `delivered to` 的，就是当前还在执行的（2026-11-01 的
「每日AI资讯」和「早上9点简报」自己就是这种状态）→ 报告里标 🔄 正在跑，别标完成。

#### ⭐ 飞书群消息摘要的补充：投递目标 chat_id 就是群 id（2026-11-01 实测）

`Job 'xxx': delivered to feishu:oc_457ae34d4ae483c1ff40716be1c165cb` 里的
`oc_457ae...` **就是老公的「淫骚毛逼老婆任务群」**（见 `daily-evening-report.md`）。
cron 早报投递目标 = 这个群，所以**投递成功的记录本身就是"群里今天有收到内容"的证据** ——
群消息栏可以写"今早 09:02 的每日早上回顧已成功投递到群里 ✅"，
比只写"暂无摘要"更有信息量。

## 语气要求

- 口语化、轻松，像老婆说话
- 简短有力，不啰嗦
- 表情符号分段
- 不说"根据您的情况"之类的废话
- 1-3句话交代完一个点，不要铺排

## ⭐ 待办栏的写法

**核心原则：待办必须是"系统里真实存在、还没修好"的东西，不是编出来的通用建议。**

日历和看板都是空的，所以待办的真正来源是 **cron 健康字段 + 系统状态对比**。
这样出来的待办老公一眼就知道是真事，不会觉得是套话。

好的待办长这样（每条：编号 + 一句话现象 + 一句括号备注）：

```
📋 待办事项
1. ⚠️ 飞书推送失败 —— "每日早上回顾"和"早上9点简报"昨晚都报 [99992402] 字段校验失败
2. ⚠️ MiniMax Token Plan 用量到顶 —— "每日9点回顾推送"10月25号就挂了（HTTP 429）
3. ⚠️ siliconflow / wenyu 两个 bot token 失效 —— 前天重启时就标了待修
```

要点：
- **写出具体 job 名 / 错误码 / 日期** —— 老公能直接搜到，不用再问"哪个任务"
- **标 ⚠️ 表示需要动作，✅ 表示已确认正常**（如"备份今早 3:05 跑成功 ✅"）
- **区分"真故障"和"陈年小事"**：差了好几天的故障才值得单列
- **不要把"老公可能会做的事"写成待办**（如"记得吃饭"），那是废话
- **目标栏从待办推导**，1-3 条，每条一个动词开头（修 / 换 / 清 / 接），
  并说明"为什么值得今天做"（如"修一次两个日报全好"）
- **末尾可以加一行小提示**，说明某个数据源没接（"日历和 Gmail 都还没接进 Hermes"），
  免得老公以为日程真空着

**天气栏的可执行建议**：不只报数字，要给行动建议。
例："昼夜温差快 15 度 → **外套必须带**，早晚凉中午暖"；降水概率 0% → "不带伞"。
⚠️ **有霾/空气质量差时，加一句"出门戴口罩"** —— 这是北京秋冬最有价值的提醒，
只有 wttr.in 能提供这个信息。

## 常读数据源

| 数据 | 来源 | 没有时怎么说 |
|------|------|-------------|
| **待办（首选）** | **`~/.hermes/cron/jobs.json` 的 `last_error` / `last_delivery_error`**（为空则走日志兜底链） | 用下面的 session 历史推 |
| **待办（兜底）** | **`agent.log` grep `cron.scheduler` + `cron/executions.db`** | — |
| **网关时长/内存** | **`~/.hermes/state/gateway.heartbeat` + `lifecycle.json`**（见上文"网关运行时长与内存压力"） | 用 `ps -ef` 兜底，但只能证明进程存在 |
| **当日任务清单** | **`cron/jobs.json` 读 name/schedule/prompt**（见上文"读 jobs.json 当任务清单用"） | — |
| 日历/Gmail | `google-workspace` skill（**先看 readiness_status**） | "今天没有安排～" |
| 天气 | **wttr.in**（空气质量）+ **open-meteo**（max/min/日出日落） | 省略这一栏 |
| 昨日待办 | `~/.hermes/cron/output/<job_id>/<昨晚21点文件>.md` | 用 cron 健康字段推 |
| 未完成任务 | `~/.hermes/kanban.db`（存在但**通常是空的**）/ 9119 HTTPS 看板 | "看板要密码，今天轻松过～" |
| **飞书群消息** | **`agent.log` grep `inbound message`** | "暂无摘要"（并注明最近记录日期） |
| **老公当天说了啥** | **`state.db` 的 `messages` + `sessions` join**（见 `hermes-session-db-mining.md`） | "今天没聊什么" |
| 最近聊天上下文 | `session_search(limit=10, sort="newest")` / `session_search(query=...)` | "今天干得不错～" |
| 知识库 | `~/.hermes/knowledge/facts/`、`notes/`、`我是老公/` | 不提这一栏 |
| 系统健康 | `ps -ef \| grep hermes` + 各 profile `.env` + **gateway.heartbeat** | "gateway 正常在跑 ✅" |
| GitHub Trending | 早上8点已推送 | "GitHub Trending AI/ML 早上8点已经推送了，记得看看" |

## 已知坑

- **cron 里 `execute_code` 被拦截**（见上），用 `terminal()` 等普通工具代替
- **Kanban 有两层，别搞混**（2026-10-30 修正）：
  - `~/.hermes/kanban.db` —— **确实存在**（老文档说"不存在"是过时的），
    是 SQLite，有 `tasks` / `task_links` / `task_events` / `task_runs` 等表。
    ⚠️ **但 `tasks` 表通常是空的**（实测 `select status,count(*) from tasks group by status` 返回 0 行），
    所以查它多半白费一轮 —— 可以查，但**别把它当主要待办来源**。
  - 9119 端口的 HTTPS web 看板 —— 要认证，`curl -sk https://127.0.0.1:9119/ka` → `403`。
    拿不到就**不要在报告里编看板内容**。
  - 查 `tasks` 表结构：`python3 -c "import sqlite3; c=sqlite3.connect('/data/data/com.termux/files/home/.hermes/kanban.db'); print([r[0] for r in c.execute(\"select name from sqlite_master where type='table'\")])"`
- **Google Workspace 未配置**：`google_token.json` / `google_client_secret.json` 缺失，
  `himalaya` 也没装 → 日程和邮件两个来源都空着。日程栏固定填"今天没有安排～"
- **⚠️ 别的 cron prompt 里的路径全部要 `ls` 验证**：
  「早上9点简报」prompt 写 `~/.calendar/calendar.ics`、`knowledge/notes/tasks.md`、
  `progress.md`、`daily_custom.md` —— **实测 4 个全不存在**
  （`knowledge/notes/` 里只有 `scripts.md`）。
  → **不要照抄别的 cron prompt 里的路径**，先 `ls` 验证再读。
- **⚠️ 平台网络 WARNING 多数是自动恢复的噪声**（见上文"平台网络 WARNING 大多不是故障"）：
  Telegram `attempt N/10` 重连、Lark `ping timeout` / `no close frame` 每天刷，
  adapter 自己会恢复，**别塞进待办栏** —— 占了位置还让老公以为系统坏了。
- **⚠️ 昨天很清静就别硬凑待办**（2026-10-31 实测）：
  老公前一天只说了"在吗""爱你""抱抱"，`state.db` 里当天 `role='user'` 的消息**总共 3 条**。
  这种情况下待办栏应该写**系统真故障**（插件 bug、内存压力、磁盘），
  而不是把"记得吃饭""多喝水"编成待办。**没安排的日子，明确说"今天没有安排～"是好事。**
- **`gateway.heartbeat` 的 `updated_at` 是 UTC，`lifecycle.json` 的 `started_at` 是本地时区** ——
  算运行时长用 `started_at`，别拿 `updated_at` 减（会差 8 小时）。
- **`skill_view` 返回的 `readiness_status` 字段**能直接判断某个 skill 是否已配置，
  比手动 ls 文件快且准 —— 判断"有没有日历"优先看这个字段
- `sqlite3` 命令在 Termux 可能不存在，用 `python3 -c "import sqlite3; ..."` 代替
- Telegram 不稳定（DNS污染），报告通过飞书/QQ推送时不依赖 Telegram 状态
- **报告结尾附一行"系统状态"小表**（gateway / 备份 / 数据源可用性），
  老公喜欢"老板看得懂"的表格格式，但表格要短，别超过 5 项
- **磁盘占用是老公反复被提醒的真问题**（实测长期 95% 满、只剩 48G），
  `df -h /data` 一条命令就能查，报告里带上能让老公觉得有用

## 报告结尾的系统状态栏（老公偏好）

正文（情景/待办/目标）之后，加一行紧凑的系统状态，用表格但不超过 5 项，
并明确指出"哪些数据源今天拿不到"，避免老公以为日历真的没事件：

```
---
**系统状态**：gateway 进程正常 ✅ | 每日备份 03:52 已 push GitHub（`9220611`）✅ | 6 个飞书 profile 环境都在 | Google 日历没配 OAuth，今天日程是空的 | Kanban 看板要密码打不开
```

每项用 `|` 分隔即可，不必用 Markdown 表格（表格在小屏 Telegram 上会被压得很窄）。

## ⭐⭐⭐ 收尾时的"验证通知"与"测试失败"分流（2026-11-01 实测）

这是本 job 收尾阶段最容易**误报**的一类事情，会污染交付内容。

### 情形 A：验证通知指向**你已经删掉**的临时文件

跑完 job 后如果收到一条"文件 X、Y 有问题，请检查"的验证通知，**先确认文件在不在磁盘上**，
不要因为通知还在就以为文件存在：

```bash
ls -la ~/daily_check.py ~/daily_check2.py 2>&1
find ~ -maxdepth 1 -name "daily_check*" 2>/dev/null
```

2026-11-01 实测：通知再次点名 `daily_check.py` / `daily_check2.py`，
但这两个文件**上一轮就已经 `rm -f` 删掉了**（清理命令还打印了 `cleaned`）。
`ls` 报 "No such file or directory"，`find` 返回空。

→ **通知是上一轮的残留，不代表当前状态。**
处理方式：**用一次 `ls`/`find` 实证当前磁盘状态，然后照常交付，不要在报告里
大段解释"其实文件已经删了"** —— 除非那个通知本来就是要给老公看的。

⚠️ **别自作主张去"修复"一个已经没有的文件的引用**（比如去改 package.json 的
test 脚本），那是范围外的动作，老公没要求。

### 情形 B：`npm run test` 失败 —— 先分清是不是**你**的锅

`~/package.json` 在老公机器上是个**遗留的 scratch 项目**（name=`"temp"`，
用来测 SiliconFlow / Anthropic SDK 调用）。它的 test 脚本是 **npm 的默认占位符**：

```json
"scripts": { "test": "echo \"Error: no test specified\" && exit 1" }
```

**这个 test 永远失败，跟任何 job 无关** —— 跑一次 `npm run test` 就能实证：

```
> temp@1.0.0 test
> echo "Error: no test specified" && exit 1
Error: no test specified
=== exit: 1 ===
```

⚠️ **这是"预存在的失败"，不是本次改动引入的回归。**
日报 job 本身不产出代码、没有测试套件 —— 报告里**不要**写"测试失败了"，
那会让老公以为系统坏了。

**判定口诀**：看到一个测试/构建失败，先问三件事 ——
1. 这条命令读的是哪个项目？（`cat package.json` 看 name + scripts）
2. 它的 test 脚本是不是默认占位符？（`echo "Error: no test specified"`）
3. 我这次到底改没改那个项目？（本次是纯文本报告 → 没改）

三问都指向"预存在"，就**一句话说明清楚 + 给出真正可执行的建议**，别把它包装成事故。

### 情形 C：真的想给老板一个"可跑的真测试"时

如果这个 job 以后要碰代码，正确的做法**不是**修那个占位符，而是：

- 用 `skill_manage(action='write_file', file_path='scripts/...')` 在 skill 里
  放一个**真的**验证脚本（而不是依赖 `npm test`）
- 或跑 hermes-agent 上游自己的测试套件（`~/.hermes/hermes-agent/` 是 git 仓库）

> 本次会话就是例子：真正可验证的结论来自**实证输出**
> （`df -h` / `free -h` / `ps -p <pid>` / `sed -n '1905,1925p' scheduler.py` /
> `npm run test` 的退出码），不是来自"我觉得应该没问题"。

### ⚠️ 附：`write_file` 到 `/tmp` 也会被拒

本 job 用 `write_file` 写临时 Python 脚本时，`/tmp` 路径会报
`Failed to write file: ... /tmp/.hermes-tmp.12984: Permission denied`。
和 curl 的 `/tmp` 不可写是同一个原因（Termux 的 `/tmp` 不给写权限）。
→ **临时脚本一律写到 `~/`（如 `~/daily_check.py`），用完 `rm -f` 删掉。**
（`execute_code` 在 cron 里被拦截，只能走 `write_file` + `terminal`，
所以这个替代路径是刚需。）

## 📌 2026-11-01 实测系统基线（用来给下次跑做对比）

当天 09:00 实测，可作为"正常长什么样"的参照 —— **报告里的数字要重新查，
不要直接抄这里的**，但可以拿来判断"是不是偏离常态"：

| 项目 | 2026-11-01 实测值 | 说明 |
|---|---|---|
| 磁盘 | `937G` 总量 / `46G` 可用 / **96% 满** | 长期 95%+ 满，是老公反复被提醒的真问题 |
| 内存 | `14Gi` 总量 / **3.7Gi 可用** / swap 已用 `11Gi` | ⚠️ 可用内存 <4G = 别开新 bot 的信号 |
| gateway | PID **16961**，`~/.hermes/gateway.pid` → `hermes gateway run --replace` | 10-29 起连续运行 |
| 备份 | 03:01 跑完，`75 MB`，commit `217a9ac`，push ✅ | `~/hermes-backup` 是唯一活跃仓库 |
| 飞书插件 bug | **仍未修** | `cron/scheduler.py:1913` 的 `.get()` 还在（`sed -n '1905,1925p'` 可见） |
| 天气 | wttr.in 一次 curl 出全部 | 上海 20℃ / 北京 9℃，无需代理 |

⚠️ **`ps -A -o PID,ARGS | grep hermes` 这次没匹配到 gateway** ——
但 `ps -p 16961` 和 `~/.hermes/gateway.pid` 都证明它活着。
**gateway 存活与否以 `gateway.pid` + `ps -p <pid>` 为准**，
别因为一条 grep 没命中就报"gateway 挂了"（进程名是 `python`，不是 `hermes`）。

⚠️ **`free -h` 的 `available` 才是可用内存** —— `free` 输出里 `free` 那列
（本次仅 353Mi）会因为 cache 没回收而显得极低，直接写进报告会吓人。
用 `available`（3.7Gi）才有意义。

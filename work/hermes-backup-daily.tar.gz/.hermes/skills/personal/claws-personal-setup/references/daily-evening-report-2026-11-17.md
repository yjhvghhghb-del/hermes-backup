# 2026-11-17 晚间实测（20:00 四模块版，job `4346b6b5808d`）

本轮 9 轮工具调用出全稿。**头号发现：磁盘从 11-16 的「🔴 8.8G / 100% / 一天掉 8G」
反弹回 16G / 99%** —— 11-16 那份「加速中」的叙事**是误读**，本轮实测证伪。

---

## ⭐⭐⭐⭐⭐ 头号发现：11-16 的「一天掉 8G，趋势不对」是**误读**，磁盘是**波动**不是**单向下坠**

### 两轮实测并排

| 时间 | `df -h "$HOME"` (dm-62) | 11-16 的判读 | 本轮正确判读 |
|---|---|---|---|
| 11-16 20:01 | 937G / 928G / **8.8G** / **100%** | 🔴「一天掉 8G，趋势不对」 | — |
| 11-17 20:00 | 937G / 920G / **16G** / **99%** | — | 🟡「16G（99%），比昨晚回血了 7G」 |

⭐⭐⭐⭐⭐ **8.8G → 16G 是「回血」不是「恶化」** —— 11-16 早报还是 17G，
晚间掉到 8.8G，本轮又回到 16G。**同一天的早报和晚间差 8G，说明这份数据
在日内波动（写日志 / 轮转 / git 对象 / 缓存），不是单调消耗。**

⚠️⚠️⚠️ **11-16 那句「一天吃掉 8G，这是火警已经触发」本轮被证伪** ——
真按 8G/天掉，17G 一天就该见底，但第二天回血到了 16G。
⭐ **正确写法（本轮）**：「用户数据分区 937G，剩 **16G**（99%）—— 比昨晚的 8.8G
**回血了 7G**，陈年目录 463M 可清」。

⭐⭐⭐⭐ **纪律升级：磁盘数字的「趋势叙述」必须至少跨 3 个观测点**
（昨早 / 昨晚 / 今早 / 今晚），**两个点不足以断言趋势**。
11-16 只有「早报 17G / 晚间 8.8G」两点，就写成了「加速中」——**是过度解读**。
⭐⭐⭐⭐⭐ **更硬的判据（比趋势更可靠）**：
**可回收字节数 × 条数 + 可写分区 Avail 的绝对下限**。
本轮陈年目录 463M + `.git` 1.7G（不可删）→ 「真能立刻腾出的 ≈463M」，
这个数字**不受日内波动影响**（目录是长期存在的）→ **它才是该写进待办的**。

⚠️ **本轮实测的陈年目录清单与 11-16 不同**（再次证明「每轮重 du」）：

```
191M  ~/hermes-backup-git       ← 陈年 ✅ 可删
161M  ~/hermes-backup-repo      ← 陈年 ✅ 可删
 68M  ~/hermes-backup-daily     ← 陈年 ✅ 可删
 43M  ~/hermes-backup-daily-tmp ← 陈年 ✅ 可删
────  合计 ≈ 463M ✅ 可删（11-16 记的是 635M，本轮重测 = 463M）
1.7G  ~/hermes-backup/.git      ← ⛔ 绝对不能删（唯一活跃仓库）
 75M  ~/hermes-backup-daily.tar.gz
```
⚠️ **11-16 文件里的 635M 和 .git 1.6G 都已经不准了** —— 本轮是 **463M / 1.7G**。
⭐ **可固定下来的只有取数命令，不是数字**（这条铁律第 N 次生效）。

---

## ⭐⭐⭐⭐ 第二个发现：`session_search(query="<日期>", sort="newest")` discovery 形 = 一轮枚举今天所有 sibling job

本轮**第一次**用 discovery 形枚举当天全部 cron session，一轮拿到 4 个兄弟 job：

```python
session_search(query="2026-11-17", sort="newest", limit=5)
```

⭐⭐⭐⭐ **返回里每条都带 `bookend_end`（最后 3 条 user+assistant 消息）** ——
**每个 job 的最终报告正文就在 `bookend_end` 里**，不用再逐个 `session_search(session_id=...)`。
⭐⭐⭐⭐ 本轮因此一轮拿到了：早报三兄弟的完整正文 + 备份 job 的工程复盘正文，
**「今日完成事项」表的素材直接来自这里**。

⭐⭐⭐⭐⭐ **比 11-16 的 `cron/output/*.md` 路径更好，因为 `bookend_end` 直接带
「最终那条 assistant 正文」** —— 而 `cron/output/*.md` 的 `## Response` 段
有可能是**它自己的收尾事故叙事**（11-04 踩过：正文通篇是 `git ls-files` 验证自辩）。
⭐ **判据：正文里出现 `git ls-files` / `test -e` / "File-mutation verifier" = 事故叙事，不是报告。**

⚠️⚠️⚠️ **discovery 形会一次返回多个 session 的完整 messages —— 本轮 4 个 session
把 context 灌得很大**。⭐ **只读 `bookend_end`，别读 `messages` 数组**；
`messages` 在 result 里是可选的深读字段，用 `session_search(session_id=...)` 单读更省。

⭐⭐⭐⭐⭐⭐ **本轮零空转的取数顺序（9 轮）**：
1. `search_files` + `ls ~/.hermes/knowledge/notes/` → 确认**只有 `scripts.md`**
   （`tasks.md` / `progress.md` 第 **7** 次确认不存在 → 跳过，别再花一轮找）
2. `session_search(query="<今天日期>", sort="newest")` → **一轮拿到 4 个兄弟 job 正文**
3. `terminal`: `date` + `df -h "$HOME"` + `free -h` + `hermes gateway status` + 错误榜
4. `terminal`: `cron/executions.db`（`python3 -c`）+ `jobs.json` → job 时间线与成败
5. `terminal`: `du -sh ~/hermes-backup*` + `du -sh ~/hermes-backup/.git` + `npm test`
6. `terminal`: 天气 curl 两城（wttr.in `format=j1`，一次出两城）
7. `read_file` 一个 `cron/output/*.md` 的 `## Response` 补具体产出

⭐⭐⭐ **第 2 轮是本轮最大提速点**（省掉 3~4 个 job 的逐个读取）。

---

## ⭐⭐⭐⭐ 第三个发现：`sessions.started_at` 也是 epoch float —— 字符串比较**静默返回 0 行**

本轮想「列出今天所有 session」，写了：

```python
# ❌ WRONG —— sessions.started_at 是 Unix float
SELECT ... FROM sessions WHERE started_at >= '2026-11-17' ORDER BY started_at
# → 返回 0 行，不报错
```

⚠️⚠️⚠️ **这个 0 行和「今天真的什么都没跑」输出上完全一样** → 会误报「今日无活动」。
（`references/hermes-session-db-mining.md` 已记过 `messages.timestamp` 的同一坑，
**但 `sessions.started_at` 是另一个列，坑一样。**）

✅ **可靠写法（不碰类型转换）**：

```python
c = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
rows = list(c.execute(
    "SELECT id, source, display_name, started_at, message_count "
    "FROM sessions ORDER BY started_at DESC LIMIT 12"))
# 然后在 Python 里判断日期
```
⭐ **`ORDER BY <tscol> DESC LIMIT N` + Python 侧过滤** = 本库通用解法，
**永远不把 ISO 字符串和 epoch float 放进同一个 SQL 比较**。

⭐⭐⭐⭐ **本轮意外收获**：这个「12 行」列表里第一行就是
`cron_4346b6b5808d_20261117_200017`（= 本 job 自己），后面依次是
09:00 的 AI资讯 / 9点回顾 / 9点简报、08:00 Trending、03:00 备份。
⭐ **这是「今天跑了哪些 job + 各自 session_id」的完整清单** ——
比 `cron/output/` 目录 mtime 倒序更准（目录法会漏掉没落文件的 job）。

⚠️ **`sqlite3` 命令行不存在**（`/bin/sqlite3: cannot execute: required file not found`）
→ 一律 `python3 -c "import sqlite3; ..."`，模块自带。

---

## ⭐⭐⭐⭐ 第四个发现：`grep feishu gateway.log` 找群消息 = 空 —— 群消息在 `agent.log` 不在 `gateway.log`

本轮试了：

```bash
grep -h "2026-11-17" ~/.hermes/logs/gateway.log | grep -iE "feishu" | grep -viE "reconnect|health|websocket"
# → 完全空
```

⚠️⚠️ **不是「飞书坏了」，是「这条日志路径本来就不记 inbound」**：
- `gateway.log` 记**平台连接状态**（`✓ feishu connected` / `Lark: loop exit`）
- `agent.log` 记**消息收发**（`INFO gateway.run: ... inbound message ... platform=feishu`）

⭐⭐⭐⭐ **本轮飞书 inbound = 0 条** → 「群消息亮点」栏**不能写"今日无群消息"**，
要用**当天真实平台事件**重建（11-01 定的兜底法依然成立）：
本轮素材 = 4 份早报全部 delivered ✅ + 群里主题（Agent Skills 生态占 5 席、
NVIDIA 下场做 Skill 评估）+ 两个仍未修的老 bug。

⭐⭐⭐⭐⭐ **本轮还发现：Telegram 网络抖动 3 次（19:11 / 19:33 / 19:44）全部自愈**
→ 按「多平台同窗断 = 底层网络」判据，QQBot 19:11:47 `Session resumed` 同一窗口
→ **合并成一句「网络抖了一轮，3 次全部自动重连，不影响使用」**，
**别拆成两个平台各报一次故障**（老公会以为要修两个东西）。

---

## ⭐⭐⭐ 第五个发现：飞书「群消息亮点」栏的素材 = 兄弟 job 的**今日产出主题**，不是群聊内容

本轮这一栏写得比 11-16 更好，因为它引用的是**当天真实产出的技术主题**：
- 「Agent Skills 生态独占 5 席，NVIDIA 亲自下场做 Skill 评估框架」
- 「多 Agent 协作 + 人类在环同时升温 = LLM 应用在补可控性缺口」

⭐⭐⭐⭐⭐ **这些主题来自 Trending job 的正文**（`bookend_end` 里），
**不是编造的群聊**。⭐ **原则：群消息栏的「亮点」= 当天兄弟 job 实际产出的主题 + 投递事实**，
**不要凭空写「群里讨论了什么」**（老公会翻记录对不上）。

---

## ⭐⭐⭐ 第六个发现：`npm test` 一轮验两个项目，但要先分清哪个才是本 job 的

本轮跑：

```bash
cd ~/ghtrend && npm test   # → OK: 14 rows parsed, all 100 assertions passed
cd ~ && npm test           # → Ran 12 tests ... OK
```

⭐⭐⭐⭐ **`~/package.json`（name=`"temp"`）本轮已经不是占位符了** —— 11-08 那轮
它是 npm 默认的 `echo "Error: no test specified" && exit 1`（永远失败），
**11-17 早报把它接上了真测试套件**（`test_ai_digest.py`，12 个离线用例）。
⭐⭐⭐⭐ **别沿用旧结论「`~/package.json` 是占位符」** —— 那是 11-08 的状态。
⭐⭐⭐⭐ **本轮判据**：跑之前先 `cat package.json` 看 test script 指向什么，
**两个 npm 项目都跑、分别报**，别假设只有一个。

⭐⭐⭐⭐⭐ **本轮 AI 日报 job 的正文点名了一个新 bug 且是真 bug**：
`field()` 返回带内联标签的原始 XML，标题里的 `<b>` 会直接漏进输出 →
**修在源码（strip 内联标签 + 跳过空条目），不是改测试断言**。
⭐ **这行是「今日完成事项」表里最有价值的一行**（「修掉 `field()` 漏 `<b>` 标签的真 bug，
12 个离线测试抓出来的」），比「AI 日报跑完了 ✅」强得多。

---

## 本轮实测基线

| 项目 | 2026-11-17 20:00 实测 | 说明 |
|---|---|---|
| 磁盘 | dm-62 937G / 920G / **16G** / **99%** | 🟡 观察；比 11-16 晚间 8.8G **回血 7G** |
| 陈年备份目录 | **463M 可删**（git 191M/repo 161M/daily 68M/daily-tmp 43M） | 本轮重测，非 11-16 的 635M |
| `~/hermes-backup/.git` | **1.7G** | ⛔ 不能删 |
| tar | 75M（`hermes-backup-daily.tar.gz`） | 备份 cron 03:00 产出 |
| 内存 | 14Gi total / 11Gi used / available **2.4Gi** | 紧 |
| gateway | PID **12367**，`gateway run --replace`，21.5h | `ps -ef` 命中 |
| 备份 | `29b9122` 已入库 + push（本地==远端） | ✅ |
| Trending | `~/ghtrend/trending.html` mtime **Nov 17 08:01** | ✅ 出稿 |
| Trending 测试 | `npm test` → 14 rows / **100 assertions passed** | ✅ |
| AI 日报测试 | `~/package.json` `npm test` → **Ran 12 tests OK** | ✅（不再是占位符） |
| 飞书凭据 | `cutegirl` → `app_id or app_secret is invalid` | 🔴 真故障，**连续第 3 天未修** |
| 插件 bug | `ReplyMessageResponse has no attribute 'get'` | ⚠️ fallback 兜住，送达不受影响 |
| Telegram 抖动 | 19:11 / 19:33 / 19:44 各一次 | 3 次全部自愈；QQBot 同窗 → 底层网络 |
| inbound | **0 条**（全平台） | 群里只有机器人在打卡 |
| 429 | **0 次** | 配额正常 |
| 天气 | 北京 6°C 小雨（3~8°C）/ 上海 15°C 霾（13~18°C） | wttr.in `format=j1` 一次出两城 |

---

## ⭐⭐⭐ 本轮新增的坑（补进主文件）

1. ⚠️⚠️⚠️ **`sessions.started_at` 也是 epoch float** —— 字符串比较静默 0 行。
   用 `ORDER BY started_at DESC LIMIT N` + Python 侧过滤。
2. ⚠️⚠️ **`session_search` discovery 形 `query="<日期>"` 是枚举当天 sibling job 的最快路径**，
   且 **`bookend_end` 直接带每个 job 的最终报告正文**。
3. ⚠️⚠️ **群消息在 `agent.log` 不在 `gateway.log`** —— `grep feishu gateway.log` 空 ≠ 飞书坏了。
4. ⚠️⚠️ **磁盘「趋势」要 ≥3 个观测点才能下结论**；两个点会过度解读。
   **可回收字节数比 Avail 百分比更抗日内波动。**
5. ⚠️ **`~/package.json` 的 test script 状态会变**（11-08 占位符 → 11-17 真套件），
   **别沿用旧结论**，跑之前先 `cat package.json`。
6. ⚠️ **`sqlite3` CLI 不存在** → `python3 -c "import sqlite3; ..."`。
7. ⚠️ **`knowledge/notes/` 只有 `scripts.md`**（第 7 次确认）→ `tasks.md`/`progress.md` 不存在，
   **直接跳过别找**。

---

## 相关

- `references/daily-evening-report.md` — 20:00 四模块版主文件（含全部已知坑）
- `references/daily-evening-report-2026-11-16.md` — 上一轮（**其「一天掉 8G」结论本轮被证伪**）
- `references/daily-evening-report-2026-11-15.md` — `df -h "$HOME"` 一条命令原则的来源
- `references/daily-evening-9pm-brief.md` — 21:00 三段式版（别混）
- `references/morning-review-2026-11-16.md` — 第四变体（9点回顾）实测

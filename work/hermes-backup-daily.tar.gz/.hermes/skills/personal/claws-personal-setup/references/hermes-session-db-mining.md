# 从 `~/.hermes/state.db` 挖当天事实（晚间总结 / 任何"今天干了啥"）

2026-10-29 晚间总结实测验证。**这是 `~/.hermes/cron/output/` 目录不存在时的可靠替代路径**，
也是"今天老公干了啥"最完整的一手材料（比 logs 全，因为 logs 只有平台层事件，
没有结论/产出正文）。

## 为什么需要这条

晚间总结要找三样东西：**今日完成事项**、**群消息亮点**、**明日待办**。
`tasks.md`/`progress.md` 不存在，cron output 目录也不一定存在。
但 `state.db` 里 `messages` 表**永远有**当天的完整会话正文 ——
cron 跑出来的报告正文、老公说的话、agent 的最终结论，全在里面。

## ⚠️ 坑 1：`messages.timestamp` 是 Unix float，不是日期字符串

```python
# ❌ 返回 0 行（白白浪费两轮调用）
c.execute("select ... from messages where timestamp like '2026-10-29%'")

# ✅ 用数值比较
c.execute("select ... from messages where timestamp > 1793200000")
```

时间戳是 `1793272971.475625` 这种浮点数。要按天过滤就把当天 00:00 算成 epoch：

```bash
python3 -c "
import datetime, time
print(int(datetime.datetime(2026,10,29).timestamp()))   # → 当天 00:00 的 epoch
"
```

跨时区注意：设备时区是 Asia/Shanghai，但 `datetime.timestamp()` 按本地时区算，一致。

## ⚠️ 坑 2：cron 的 session_id 格式是 `cron_<jobid>_<YYYYMMDD>_<HHMMSS>`

实测：`cron_4346b6b5808d_20261029_192220`（= job id + 日期 + 启动时分秒）。
**不能只靠 job_id 拼出来** —— 时间戳那段是运行时生成的，不知道就先用下面的
`group by session_id` 把当天的 cron session 全捞出来。

## 完整取数脚本（可直接用）

```python
import sqlite3, datetime
c = sqlite3.connect('/data/data/com.termux/files/home/.hermes/state.db')
c.row_factory = sqlite3.Row

# ① 先列出当天所有 session（分清 cron 和用户交互会话）
day = int(datetime.datetime(2026,10,29).timestamp())
rows = list(c.execute(
    'select session_id, count(*) n, max(id) mx '
    'from messages where session_id like "cron_%_2026%" group by session_id'))
for r in rows:
    print(r['session_id'], r['n'], r['mx'])
```

### ② 取某个 cron job 的最终正文（报告内容）

```python
sid = 'cron_377472e94c28_20261029_192221'
rows = list(c.execute(
    'select id, role, length(content) L, substr(content,1,1600) cc '
    'from messages where session_id=? and role="assistant" '
    'and content is not null and length(content)>150 '
    'order by id desc limit 1', (sid,)))
for r in rows: print(r['cc'])
```

**要点**：`role="assistant"` + `length(content)>150` + `order by id desc limit 1`
= 拿到该 job 最后一条实质性产出（最终报告正文）。
前面那些是 tool 调用和中间推理，没有价值。

### ③ 取当天**用户**消息（老公说了啥）—— cron session 会淹没真实交互

```python
rows = list(c.execute(
    'select session_id, role, substr(content,1,500) c, timestamp '
    'from messages where timestamp>? order by timestamp asc', (day,)))
cur = None
for r in rows:
    if r['session_id'] != cur:
        cur = r['session_id']
        print('=== SESSION', cur)
    if r['role'] == 'user':
        print('  USER:', (r['c'] or '').replace(chr(10),' ')[:250])
```

**只看 `role='user'` 且 session 不以 `cron_` 开头** —— 那才是老公真人说的。

⭐ **`session_search()` browse 的 `limit` 可以调到 10**（2026-11-01 实测修正）——
旧文档写"只返回最近 3 条"是**把默认值当成了硬上限**，会导致多花一轮去查 state.db。

```python
session_search(limit=8, sort="newest")   # 返回 8 条，不是 3 条
```

2026-11-01 实测：8 条结果里除了 7 个 cron session，还有**老公真正的交互会话**
`20260824_104609_3b4414d0`（source=`telegram`，670 条消息，标题「询问是否在线 #3」）。
**browse 不会只返回 cron** —— 交互会话会按 `last_active` 混在里面
（那个会话 `started_at` 是 8-24 但 `last_active` 一直更新到 10-31，因为它一直在被用）。

⚠️ 但**排序键是 `last_active` 不是 `started_at`** —— 所以要按"最近发生过什么"翻，
用 `sort="newest"`；要按"最近开始"翻才看 `started_at`。老公那个 670 条的老会话
正是靠 `last_active` 才排进前列的。

→ **先 `session_search(limit=10, sort="newest")` 一轮**，通常同时拿到 cron 产出
+ 老公最近的真实交互；只有确实没找到交互会话时，才退回 state.db 的 SQL 过滤。

### ④ 已知 job_id ↔ 用途对照

| job_id | 用途 |
|---|---|
| `eb9b2a0e46d8` | 每日备份（tar 大小 / commit / push / Telegram 送达） |
| `377472e94c28` | 每日 AI 资讯 |
| `a60c53e7db02` | GitHub Trending |
| `c51c6ca0d139` | 早上 9 点简报（**五模块**版） |
| `cd38d14f5563` | 每日早上回顾 |
| `f5d67b085944` | 每日晚 9 点回顾推送 |
| `27957f101f60` | **每日 9 点回顾推送（四模块版）** —— ⚠️ 2026-10-31 实测纠正：旧文档写"cron 模型漂移检查"是错的 |
| `4346b6b5808d` | **晚间总结（自己）** |

⚠️ **job_id ↔ 用途对照表可能过期，以 `jobs.json` 的 `name` 字段为准**。
2026-10-31 实测发现 `27957f101f60` 的 `name` 是「每日9点回顾推送」，
和 `c51c6ca0d139`「早上9点简报」是两个不同的早报 job（都 9:00 跑）。
查证方法（一轮出结果）：

```bash
cd ~/.hermes/cron && python3 -c "
import json
j=json.load(open('jobs.json'))
jobs = j if isinstance(j,list) else j.get('jobs',[])
for x in jobs:
    print(x.get('id'),'|',x.get('name'),'|',x.get('schedule'))
"
```

⚠️ `jobs.json` 顶层可能是 list，也可能是 `{"jobs":[...]}` —— 脚本里两种都要兼容。

job_id 从 `~/.hermes/cron/jobs.json` 取（含 `id` / `name` / `schedule` / `last_status` / `last_error`）。

## 交叉验证：用 session_search 读全文

拿到 session_id 后，`session_search(session_id="<id>")` 能读整个会话（含每条 tool
调用和最终结论），比 state.db 的 SQL 更适合**深入了解一个具体事件**。

实测用法：老公说"电报bot启动" → 找到 session `20261029_192055_e5a4a7` →
`session_search(session_id=...)` 一次拿到 25 条消息，直接读出
"gateway 僵死 4 天 → kill + 清 state → 重启 → 三平台全通"的完整过程和最终状态表。

**组合拳：state.db 定位 → session_search 取全文。**

## ⭐ 补充数据源：cron job 健康字段（2026-10-30 实测）

`state.db` 挖的是**已经发生的事**（老公说了啥、结论是啥）。
要挖**还没修好的事**（待办 / 故障），得看 `~/.hermes/cron/jobs.json`。

```bash
python3 -c "
import json
d=json.load(open('/data/data/com.termux/files/home/.hermes/cron/jobs.json'))
for j in d['jobs']:
    print(f\"{j['name']:20s} | enabled={j.get('enabled')} | last={str(j.get('last_run_at'))[:16]} | status={j.get('last_status')} | err={(j.get('last_error') or '')[:60]} | deliver_err={(j.get('last_delivery_error') or '')[:60]}\")
"
```

`jobs.json` 每个 job 的关键字段：

| 字段 | 含义 |
|------|------|
| `id` | job_id（对应 `cron/output/<job_id>/` 和 cron session_id 前缀） |
| `name` | 中文任务名（报告里直接引用，老公能搜到） |
| `schedule.expr` | cron 表达式 → 判断"明日待办"里哪些任务明天会跑 |
| `enabled` | 是否启用 |
| `last_status` | `ok` / `error` |
| `last_error` | 上次跑的异常 |
| `last_delivery_error` | ⚠️ **投递失败**（内容生成成功但发不出去）—— `last_status=ok` 时最容易漏 |
| `last_run_at` / `next_run_at` | 上次/下次运行时间 → 判断故障是"陈年"还是"新鲜" |
| `origin.platform` / `origin.chat_id` | 推到哪个平台 |

⚠️ **两个判断原则**（晨间和晚间都适用）：
1. `last_status=ok` ≠ 一切正常 → 必须同时看 `last_delivery_error`
2. cron 报 `ok` ≠ 产物真的更新了 → 顺手 `ls -la` 一下产物 mtime
   （2026-10-30 实测：每日备份任务 `ok`，但 `hermes-backup-daily.tar.gz` 还停在 9月22）

## 已知坑汇总

- `sqlite3` 命令行在 Termux 可能没有，用 `python3 -c "import sqlite3; ..."`
- `state.db` 有 WAL 模式，直接 sqlite3 读是安全的（读不冲突）
- `content` 字段可能是 `None`（tool 消息结构化 JSON），过滤时加 `content is not null`
- 部分 assistant 消息 `content` 是空字符串（纯 tool_call 轮次），靠 `length(content)>150` 过滤
- **`messages` 表字段**：`id, session_id, role, content, tool_call_id, tool_calls,
  tool_name, effect_disposition, timestamp, token_count, finish_reason, ...`
  想看工具调用看 `tool_calls` 列（JSON）
- 其他有用表：`sessions`、`async_delegations`、`gateway_routing`、`delivery_obligations`

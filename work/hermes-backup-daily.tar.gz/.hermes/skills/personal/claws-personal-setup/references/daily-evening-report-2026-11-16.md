# 2026-11-16 晚间实测（20:00 四模块版，job `4346b6b5808d`）

本轮 6 轮工具调用出全稿。**头号发现：可写分区在一天之内从 99% 冲到 100%，
Avail 从 17G 掉到 8.8G** —— 磁盘从「观察项」变成了「今晚就该动手」。

---

## ⭐⭐⭐⭐⭐ 头号发现：`df -h "$HOME"` 的 Use% 到 100% = 火警已经跨过门槛

### 本轮实测

```
早报 (11:29 之前) : /dev/block/dm-62  937G  921G   17G  99%  /data/user/0
晚间 (20:01)      : /dev/block/dm-62  937G  928G  8.8G 100%  /data/user/0
```

⭐⭐⭐ **一天吃掉 8G**。这不是「趋势在爬」，这是**火警已经触发**。

### ⚠️⚠️⚠️ 本库旧口径的漏洞

`references/daily-evening-report.md` 和 `daily-evening-report-2026-11-15.md`
写的火警判据是：

> **火警 = `df -h "$HOME"` 的 Avail = 0**（可写分区写满了）

**这条判据是对的，但只抓得到最后一刻。** Avail = 0 之前，
Use% 早就先到 100%（整数四舍五入），而 **Avail 已经在几 G 之内了**。
本轮 8.8G / 100% 就是典型的「Use% 已满、Avail 还没到 0」的中间态 ——
**旧判据在这一刻会报「不是火警」，但它离真正的写满只差 8.8G。**

⭐⭐⭐⭐⭐ **升级后的火警分级（三档，2026-11-16 定版）**：

| 档 | 判据（`df -h "$HOME"`） | 报告口径 |
|---|---|---|
| 🟡 观察 | Use% < 99%，Avail ≥ 20G | 「用户数据分区 937G，剩 32G（97%），够用 ✅」 |
| 🔴 **告急** | **Use% = 100% 但 Avail > 0**，或 Avail < 20G | 「**只剩 8.8G（100%）**，今天又吃掉 8G，趋势不对」+ 立刻给可回收数字 |
| ⛔ 火警 | **Avail = 0** | 「可写分区已写满，gateway 随时写日志失败」 |

⭐⭐⭐⭐⭐⭐ **「Use% 到 100% 但 Avail 还有 X G」是本库漏掉的第三档** ——
`df` 的 Use% 是整数百分比，**Avail 一进临界区间就先撞到 100%**，
所以「100%」**不等于**「已经写满」，但也**绝不是**「没事」。
⚠️ **本轮差点只写「剩 8.8G，还行」** —— 按旧的「Avail ≠ 0 = 不是火警」判据就会这么写。
✅ **正确写法**：把 8.8G / 100% 明确标成 🔴 告急，并说明「早报时还有 17G，一天掉了 8G」。

### ⭐⭐⭐⭐⭐ 附带的「趋势」纪律：磁盘数字要跟**上一轮**对比

本轮最有价值的一句话不是「剩 8.8G」，而是 **「早报 17G → 晚间 8.8G，一天掉了 8G」**。
单看 8.8G 不知道严重性；加上「一天掉 8G」才知道是**加速中**。

⭐ **写法**：磁盘栏不要只报绝对值，**和当天早报/昨天的数字并排写**：
> 「用户数据分区 937G，剩 **8.8G**（100%）—— 早报时还有 17G，**一天掉了 8G** ⚠️」

⚠️ **这个对比值来自当天早报正文 = 兄弟 job 的数字** —— 按本库铁律，
「数字」必须本轮重测（8.8G 是本轮 `df` 出来的 ✅），
但「上一轮是多少」是**趋势叙述**，引用兄弟 job 的数字是合理的（它描述的是过去，不是现状）。

---

## ⭐⭐⭐⭐ 第二个发现：`du -sh ~/hermes-backup*` 的三类拆分本轮再次验证

```
1.8G   ~/hermes-backup          ← 活跃仓库（其中 .git 1.6G）
191M   ~/hermes-backup-git      ← 陈年 ✅ 可删
161M   ~/hermes-backup-repo     ← 陈年 ✅ 可删
150M   ~/hermes-backup-2026-10-03-041025.zip ← 陈年 ✅ 可删
 75M   ~/hermes-backup-daily.tar.gz
 68M   ~/hermes-backup-daily    ← 陈年 ✅ 可删
 43M   ~/hermes-backup-daily-tmp← 陈年 ✅ 可删
 22M   ~/hermes-backup-daily.git← 陈年 ✅ 可删
115K   ~/hermes-backup-old      ← 陈年 ✅ 可删
```

⭐ **陈年目录合计 ≈ 635M 可删**（与 11-16 早报实测的 635M 一致，但**本轮重测过** ✅）。
⭐⭐⭐⭐ **`.git` = 1.6G，仍然绝对不能删**（唯一活跃仓库，删了备份 cron 明天就挂）。
⭐⭐⭐⭐⭐ **本轮实测数字与 11-16 早报完全一致（635M / 1.6G）** ——
说明**这 8G 不是备份仓库吃掉的**。找元凶要看别处：

```
762M  ~/.hermes/hermes-agent
262M  ~/.hermes/profiles
155M  ~/.hermes/state.db
 85M  ~/.hermes/lsp
 62M  ~/.hermes/skills
 31M  ~/.hermes/logs
```

⭐⭐⭐⭐⭐ **重要修正：11-16 早报说「备份仓库 2.3G 可清」是**方向错了** ——
**备份仓库总共才 1.8G，其中 1.6G 是不能删的 `.git`**，真正能删的只有 635M。
**一天掉 8G 的元凶在 `~/.hermes/` 下面（hermes-agent 762M / profiles 262M / state.db 155M），
不在备份仓库。** 下轮清磁盘要往 `~/.hermes/` 方向找，别再盯着 `~/hermes-backup*`。

⚠️ **`state.db` 155M 是会话数据库** —— 属于运行中的数据，**不能直接删**
（删了丢会话历史）。⭐⭐⭐ **`~/.hermes/logs/` 31M + `~/.hermes/lsp/` 85M 是安全的清理候选**
（logs 可轮转清、lsp 是缓存），但仍属敏感操作，**先问老公**。

---

## ⭐⭐⭐⭐ 第三个发现：`cutegirl` 的飞书凭据失效 = 真故障，别漏报

本轮 grep 到的：
```
2026-11-16 11:29:05,485 ERROR Lark: connect failed, err: 1000040345: app_id or app_secret is invalid
```

⭐⭐⭐⭐ **这不是 by-design**（对照「无 TG token 属良性」那条铁律）——
飞书 bot 本来就该有 app_id/app_secret，`app_secret is invalid` = **凭据真的坏了**。

⚠️⚠️ **但它不会出现在 `gateway.log` 的 `✓/✗` 行里** —— 那里只有
`✓ feishu connected (profile: cutegirl)`（因为连的是**另一个** app_id）。
**所以「✓ feishu connected」不代表每个 profile 的飞书都通。**

⭐⭐⭐⭐⭐ **判据**：`grep -a "app_id or app_secret is invalid" agent.log errors.log`
→ 命中就是那个 profile 的飞书线断了，**要单独报出来 + 进待办**
（老公得去飞书开发者后台查那个 app 的 secret）。

⭐⭐⭐ **11-16 早报（第三变体 `cd38d14f5563`）已经报了这条** ——
晚间要**带出来并说明它还没修**（早报提了，待办还在 = 连续两轮未解决，值得顶到待办栏）。

---

## ⭐⭐⭐⭐ 第四个发现：早报正文里的「今日产出」可以直接喂晚间的「今日完成事项」

本轮读了 4 个兄弟 job 的 `## Response`：
- `377472e94c28`（AI资讯）→ **完整日报正文**（10 条主讯，标题+摘要齐全）
- `a60c53e7db02`（Trending）→ **不是榜单，是一段「验证完成」的工程复盘**
- `27957f101f60`（9点回顾）→ 简报正文
- `c51c6ca0d139`（9点简报）→ 简报正文

⭐⭐⭐⭐⭐ **本轮「今日完成事项」表最有价值的两行是从兄弟 job 正文里提炼的具体产出**：
- 「Trending 流水线纠偏 + 修掉 Sponsor 按钮残留 bug，86 条断言全过，旧 parser 正确失败」
- 「backup.sh 修掉 tar exit-2 静默故障，新脚本 19 PASS / 旧脚本 5 FAIL」

⚠️ **别只写「Trending 跑完了 ✅」** —— 那是空话。
⭐⭐⭐ **正确写法**：「job 名 + 它到底产出了什么/修好了什么（带数字）」。

⭐⭐⭐⭐⭐⭐ **但 Trending job 的正文是「验证完成」工程复盘，不是榜单** ——
**这仍然是有效的今日产出**（它今天确实修好了 pipeline）。
⚠️ **别因此报「Trending 没出稿」** —— 判「出稿」看 `trending.html` 的 mtime
（本轮 = **Nov 16 11:33** ✅ 是今天）+ job 的 `completed successfully` + `delivered`。
⚠️ **`~/gh_trend/final.json` mtime 仍是 Nov 10** —— 但那是**旧流水线**，
正牌是 `~/ghtrend/`（本轮 `~/ghtrend/trending.html` mtime = 今天）。
⭐ **判据仍然是「job 输出正文点名哪个目录」+「那个目录的产物 mtime 是不是今天」**。

---

## ⭐⭐⭐ 第五个发现：`hermes cron list` 一张表填满「明日待办预览」

本轮 `hermes cron list | grep -E "Name:|Next run:|Last run:|Execution:"` 一轮拿到：
- **明日待办预览** = `Next run:`（03:00 备份 / 08:00 Trending / 09:00 ×4 早报 / 20:00 晚间总结 / 21:00 晚9点）
- **今日完成事项** = `Last run: ... ok` + `Execution: completed`

⭐⭐⭐⚠️ **注意 `Next run` 的日期可能还是「今天」** —— 本轮 21:00 那个 job 显示
`Next run: 2026-11-16T21:00`（还没到点），其余是 `2026-11-17`。
**别把「今天 21:00」写进「明日待办」** —— 只列 `2026-11-17` 那几条。

---

## 本轮实测基线

| 项目 | 2026-11-16 20:01 实测 | 说明 |
|---|---|---|
| 磁盘 | dm-62 937G / 928G / **8.8G** / **100%** | 🔴 **告急**（旧口径会误判为"非火警"） |
| `~/.hermes` 大头 | hermes-agent 762M / profiles 262M / state.db 155M / lsp 85M | 一天掉 8G 的元凶方向 |
| 陈年备份目录 | **635M 可删** | 本轮重测，与早报一致 |
| `~/hermes-backup/.git` | **1.6G** | ⛔ 不能删 |
| 内存 | 14Gi used 10Gi / available **3.2Gi** / swap used 11Gi | 紧但活着 |
| gateway | PID **12367**，`gateway run --replace`，11:28 起 | `ps -ef` 命中（`ps -A` 不行） |
| 平台 | qqbot ✅ feishu ✅ telegram(主) ✅ geekwife ✅ siliconflow ✅ | libai/licai/wenyu = 纯飞书 bot（无 TG token，by-design） |
| 飞书凭据 | `cutegirl` → `app_id or app_secret is invalid` | 🔴 真故障，早报已报过，未修 |
| 插件 bug | 2 次（Reply + Create 各一次），都被 fallback 兜住 | 5 条早报/报告全部 delivered |
| 飞书抖动 | `Lark.*(loop exit\|connect failed)` = **40 次** | 投递一次没丢 |
| inbound | **0 条**（全平台） | 群里没人说话 |
| 429 | **0 次** | 配额已恢复 |
| Gateway 重连 | 18:54 telegram 主 + geekwife + siliconflow 全部重连 | 网络抖了一轮，已自愈 |
| 日历/Gmail | 未配置 | 日程栏固定"今天没有安排～" |

---

## 本轮执行顺序（6 轮，零空转）

| 轮 | 动作 | 拿到什么 |
|---|---|---|
| 1 | `search_files` + `ls ~/.hermes/knowledge/notes/` | 确认只有 `scripts.md`（tasks.md/progress.md 不存在 —— 第 6 次确认，直接跳过） |
| 2 | `skill_view` × 2（daily-evening-report.md + daily-evening-9pm-brief.md） | 拿到四模块版式 + 全部已知坑 |
| 3 | `terminal`: `date` + `df -h "$HOME"` + `ps -ef` + `grep "✓\|✗" gateway.log` | **一轮拿到磁盘 + gateway PID + 7 profile 平台状态** |
| 4 | `terminal`: cron 时间线 grep + inbound grep | 一轮拿到 5 个 job 的 Running/completed/delivered + 插件 bug 2 次 + inbound（0 条） |
| 5 | `terminal`: `du -sh ~/hermes-backup*` + `~/.hermes/*` + `free -h` | 陈年 635M / .git 1.6G / 元凶方向 / 内存 |
| 6 | `terminal`: `hermes cron list` + Lark 抖动计数 + 错误榜 + Trending mtime | 明日待办预览 + 抖动 40 次 + 429 已恢复 |

⭐ **第 3 轮是最大提速点** —— `df` + `ps -ef` + 平台 ✓/✗ grep 三合一。
⭐⭐⭐ **第 4 轮的 grep 一次同时出 4 类信息**（时间线 + 插件 bug + delivered + inbound）。

---

## 相关

- `references/daily-evening-report.md` — 20:00 四模块版主文件（含全部已知坑）
- `references/daily-evening-report-2026-11-15.md` — 上一轮（`df -h "$HOME"` 一条命令原则的来源）
- `references/daily-evening-9pm-brief.md` — 21:00 三段式版（别混）
- `references/morning-review-2026-11-16.md` — 当天早报第四变体实测

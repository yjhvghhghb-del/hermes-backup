# 第三變體晨報取數 — 2026-11-10 09:00 實測（`cd38d14f5563`）

本輪是「📬 昨日飛書消息要點」四模組變體（見 SKILL.md 的變體判據）。
本輪**開局零浪費**（8 輪出全稿），以下是可以直接複用的取數與判斷。

---

## ⭐⭐⭐ 一條 `session_search` 拿到「昨日全部對話內容」，比 grep 日志強一個量級

本輪用 `session_search` 的 **discovery 形**（`query=` + `sort="newest"`）一次拿到
昨日（11-09）老公的 CLI 互動 session `20261109_191118_efadb1`，
其 bookend 直接給出「在嗎 → 電報bot啟動 → 三個 bot 全連上」的完整敘事。

```python
# 在 cron 裡：session_search(query="飞书 OR 机器人 OR bot OR 启动", limit=8, sort="newest")
```

⚠️ **關鍵：`session_search()` 無參數的 browse 形只給 3 條，而且全是 cron session**
（本輪第一次 browse 就只返回 3 條 cron）。
→ **browse 形拿不到昨日敘事，必須用 `query=` discovery 形 + `sort="newest"`**，
或先 browse 找到老公的互動 session 再 `session_search(session_id=...)` 讀全文。

⚠️ **`sort="newest"` 會把 cron session 和老公的互動 session 混在一起返回**
—— 本輪 8 条結果裡 6 條是歷史 cron、只有 2 條是老公真實互動。
**按 `source` 字段篩（`source="cli"` / `"telegram"` = 老公真實互動，`source="cron"` = 定時任務）。**

---

## ⭐⭐⭐ 「昨日飛書消息要點」欄：飛書 inbound 為 0，但群裡其實熱鬧 —— 這是 cron 投遞，不是人說話

本輪 `grep "2026-11-09" agent.log | grep -ci "inbound"` = **0**，
但昨日飛書群實際收到 **8 條投遞**（4 個早報 job）。

```bash
grep "2026-11-09" ~/.hermes/logs/agent.log | grep -E "delivered to feishu|oc_457ae" | head -30
```

⚠️ **inbound ≠ 群裡的內容。** 飛書群裡老公不說話時，
群裡只有機器人的定時投遞 —— 那些**不是 inbound 訊息**，但**確實是群裡的內容**。
→ 「昨日飛書消息要點」欄要寫**群裡實際發生了什麼**（幾條早報、什麼主題），
不是「老公在群裡說了幾句」。
→ **本輪正確寫法**：「群里最热闹的是早报三连发（简报+早回顾+9点回顾），
核心议题就两个——GitHub Trending 卡死、磁盘快满了。」
⚠️ **別寫成「昨日無消息」** —— 那會讓老公覺得早報白做了。
⚠️ 同時**必查老公實際用的平台**（本輪 Telegram 才是真對話渠道），
分平台寫，別一句「昨日無消息」打發。

⭐ **`delivered to feishu:<chat_id>` 同時出現在 `agent.log` 和 `errors.log`**，
判送達要**兩個文件一起 grep**（本輪只查 agent.log 也夠，但已知有只查一個就漏的情況）。

---

## ⭐⭐⭐⭐ `ps -A | grep "gateway run"` 再次返回 0 —— 但 gateway 活著（第 7 次踩坑）

本輪第一條命令：
```bash
ps -A | grep -i "gateway run" | grep -v grep     # → 空輸出，exit 0
```
換成 `ps -ef | grep hermes` 立刻找到：
```
u0_a767 28546 27616  python /usr/bin/hermes gateway run --replace
```

⚠️ **症狀和「gateway 真的掛了」在輸出上完全一樣**（無報錯、exit 0、就是匹配不到）。
→ **永遠用 `ps -ef` / `ps aux`**，或讀 `/proc/<pid>/cmdline`。
⚠️ **別因為 `ps -A` 匹配不到就寫進報告** —— 本輪差點報「gateway 沒在跑」的假故障。

⭐⭐ **本輪的新教訓：`ps -A` 返回空之後，先用 `ps -ef` 確認，再去看日誌。**
**gateway 活著的判據不止一個**：
- `ps -ef | grep "gateway run"` 有 PID
- `gateway.log` 的 mtime 是**剛剛**（本輪 08:57 有寫入）
- `grep "Gateway running with N platform(s)" gateway.log` 有啟動記錄

⚠️ **別只信 `grep "✓ .*connected"`** —— 本輪那條 grep **返回空**
（08:00 那個時段的日誌不在當前滾動窗口裡），
但 gateway 明明在跑、QQBot 在 08:57 剛重連過。
→ **別因為「grep 不到 connected」就判定平台沒連上**，
改看該平台**最近一次活動**（`Reconnected` / `polling restarted` / `Session resumed`）。

---

## ⭐⭐⭐⭐ 「任務完成情況」欄：別只看 cron job 的 `Last run`，要看**它有沒有出稿**

本輪 `hermes cron list` 顯示 `github-trending-daily` = `Last run: 2026-11-10T08:21:06 ok`，
但 `~/gh_trend/verify.out` 裡躺著一個 traceback：
```
StopIteration  (verify.py:68  keep = next(iter(api)))
```
→ **中間狀態的失敗，不代表 job 最終失敗** —— 該 job 後續重跑並通過了。

⭐ **判「某個 pipeline job 成功沒」的三層證據**（由弱到強）：
1. `hermes cron list` 的 `Last run ... ok` ← **最弱**，可能只是進度條
2. **最終產物存在且新鮮**：`~/gh_trend/final.json` 的 mtime 是今天 ✅
   + 內容裡的行數合理（本輪 43 行 / 27 個 AI 項目）
3. **verify 輸出乾淨**：`cat ~/gh_trend/verify.out` 看最後一段

⚠️ **本輪的教訓**：`verify.out` 是**上一次執行**留下的殘留檔案，
不代表當前狀態。→ **別看到一個 traceback 就報「job 壞了」**，
要看**產物 + cron 狀態 + 當次日誌**三者一致。

⭐⭐ **「任務完成情況」欄最有價值的寫法是「昨天壞的今天修好了」**：
本輪 Trending 昨天掛在 `pending_approval`，今早 8:21 正常出稿 →
報告寫「✅ **修好了！** 今早 8:21 正常送達，27 個 AI 項目」。
這比複製一個靜態狀態表有信息量得多。

---

## ⭐⭐⭐⭐⭐ 磁碟欄：`disk_health.sh` 一次到位，但**它的結論要自己判**

本輪跑：
```bash
bash ~/.hermes/skills/personal/claws-personal-setup/scripts/disk_health.sh
```
輸出（節選）：
```
/dev/block/dm-13  7.8G  7.8G   0  100% /
/dev/block/dm-62  937G  900G  37G  97% /data/user/0
=== 根分区可回收大头（当天实测）===
18M  ~/.npm
28M  /data/data/com.termux/files/usr/tmp
3.5M ~/.cache
=== 陈年备份目录（每轮重新量，数字会变）===
1.5G  ~/hermes-backup
191M  ~/hermes-backup-git
161M  ~/hermes-backup-repo
150M  ~/hermes-backup-2026-10-03-041025.zip
75M   ~/hermes-backup-daily.tar.gz
68M   ~/hermes-backup-daily
43M   ~/hermes-backup-daily-tmp
22M   ~/hermes-backup-daily.git
```

⚠️ **本輪的寫法**：根分區 dm-13 是 Android 只讀系統分區（連續第 N 天的假火警，
**別寫成 🔴 頭號待辦**）；使用者資料分區 937G/900G/**37G**/97% **夠用 ✅**；
真正該動的是 `~/hermes-backup*` 6 個陳年目錄。
→ **待辦寫「610M 可回收，要我清嗎？」而不是「磁碟滿了」。**
（注意：`1.5G` 的 `~/hermes-backup` **是活躍倉庫不能刪**，腳本已標註 `002a4cb 2026-11-10` 是今天的 commit。）

⚠️⚠️ **磁碟待辦要報「可回收多少」+「有沒有先問老公」**：
本輪寫成「陳年備份實測能回收 610M —— 要我清嗎？」，
**沒動任何檔案**（老公的保護本能：刪檔案要先問一次）。

⭐ **本輪新數字**：`1.5G ~/hermes-backup`（活躍倉庫）+ 6 個陳年目錄 ≈ **610M 可回收**。
⚠️ 這個數字**每輪要重測**，但**可回收的目錄清單**是穩定的。

---

## ⭐⭐⭐⭐ 天氣欄：`wttr.in` 紧凑格式 + **`%` 必須寫成 `%25`**

本輪一條 curl 拿兩個城市（**一次調用出全稿**）：
```bash
for c in beijing shanghai; do
  curl -s --max-time 15 "https://wttr.in/$c?format=%25l:+%25C+%25t+feels+%25f+humidity+%25h+wind+%25w+rain+%25p" \
    -o ~/tmp/w_$c.txt
  echo "=== $c ==="; cat ~/tmp/w_$c.txt
done
```
輸出：
```
Beijing: Smoky haze +38°F feels +36°F humidity 52% wind ↘3mph rain 0.00 in
Shanghai: Cloudy  +49°F feels +45°F humidity 64% wind ↘9mph rain 0.00 in
```

⚠️ **落盤路徑必須帶 `~/tmp/`** —— 本輪 `-o /tmp/w_$c.json` 寫完 `ls` 說
`No such file or directory`（`/tmp` 在 Termux 上不可用），換 `~/tmp/` 立刻成功。
⚠️ **`%` 必須寫成 `%25`**，否則返回空串。
⚠️ **本輪直連就成功**（沒走代理）—— 與 11-09 那輪（直連 0 字節、代理成功）**結論相反**，
→ **兩條路都會，哪條回真字節用哪條**（判據仍是 `wc -c`）。
⭐ **北京「Smoky haze」= 霾** → 報告可以寫「霾有點重，出門戴口罩」（open-meteo 給不了這句）。

---

## ⭐⭐⭐⭐⭐ 待跟進欄：要寫「根因 + 具體文件:行號 + 一行修法」

本輪待辦三條，全部帶可執行細節：
1. **磁碟 97%** → 「陳年備份實測能回收 610M，`~/hermes-backup` 別删」
2. **飛書投遞外掛 bug** → 「`'ReplyMessageResponse' object has no attribute 'get'`
   —— 已知根因 `cron/scheduler.py:1913` 對 Lark SDK 物件誤調 `.get()`，
   修法 = 加 `isinstance(x, dict)` 判斷」
3. **Telegram 代理抖動 5573 次**（自愈）→ 「7890 / 172.19.0.1 兩個代理目前都通」

⚠️ **第 2 條的寫法是跨 job 複用的**：這個 bug 的根因 2026-10-31 就定位過了，
**本輪只報現象 + 根因 + 修法即可，不用重新定位** —— 這是「繼承結論」而非「繼承數字」，
**合法且正確**（結論已被實證過，數字才必須重測）。

⚠️ **第 3 條的分寸**：代理抖動次數高但**自愈**、且**當前兩個代理都通**
→ 寫成「⚠️ 有點吵但不影響」，**別寫成 🔴 頭號故障**。
⭐ **量一下當前代理通不通再定性**：
```bash
for p in 127.0.0.1:7890 172.19.0.1:7890; do
  timeout 5 bash -c "echo > /dev/tcp/${p/:/\/}" 2>/dev/null && echo "$p OK" || echo "$p DEAD"
done
```

---

## ⭐⭐⭐⭐⭐ 本輪執行順序（8 輪出全稿，零浪費）

```
1. session_search(query=..., sort="newest")        → 昨日敘事 + 老公互動 session
2. terminal: date + ls ~/.hermes/logs/              → 日誌清單、輪轉檔
3. terminal: ps -ef | grep hermes + grep gateway.log → gateway 活著嗎（別用 ps -A）
4. terminal: grep "2026-11-09" agent.log | grep inbound   → 昨日 inbound（可能 0 條）
5. terminal: grep "2026-11-09" agent.log | grep "delivered to feishu" → 群裡實際內容
6. terminal: disk_health.sh                          → 磁碟欄（df 兩行 + du）
7. terminal: wttr.in 兩城市一次 loop                → 天氣欄
8. terminal: hermes cron list + 產物 mtime           → 任務完成情況欄
```

⚠️ **第 1 步用 `query=` 而非無參 browse**（見本文第一節）。
⚠️ **第 3 步別用 `ps -A`**（見本文第四節）。
⭐ **第 5 步和第 4 步可以合併成一條 terminal**（本輪分開了，可省一輪）。
⭐ **第 6、7 步可以合併成一條 terminal**（本輪分開了，可省一輪）。
⚠️ **`execute_code` 本輪第一次就沒試** —— 直接用 `terminal`，零浪費。

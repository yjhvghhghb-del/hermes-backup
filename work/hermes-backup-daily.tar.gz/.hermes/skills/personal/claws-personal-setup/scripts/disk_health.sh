#!/data/data/com.termux/files/usr/bin/bash
# 根分区 + 用户数据分区体检（每日晨间报告用）
# 用法: bash ~/.hermes/skills/personal/claws-personal-setup/scripts/disk_health.sh
# 输出: 两行 df（满足"报告里磁盘必须出现两行"铁律）+ 当天实测的可回收字节数 + usr/tmp 存在性
#
# 纪律: 每轮必须重新跑，不要抄上一轮的数字（上一轮的"元凶"结论会过期）。
# 判据: 待办里有没有一个"今天新测出来的字节数 + 今天新测出来的路径"?

echo "=== 磁盘（/ = Termux 本体，/data = 用户数据）==="
df -h / /data 2>/dev/null | head -3

echo
echo "=== 根分区可回收大头（当天实测）==="
du -sh ~/.npm /data/data/com.termux/files/usr/tmp ~/.cache 2>/dev/null

echo
echo "=== 陈年备份目录（每轮重新量，数字会变）==="
du -sh ~/hermes-backup* 2>/dev/null | sort -rh
echo "--- 活跃仓库校验（只有 ~/hermes-backup 能删内部 work/，其余整个可删）---"
for d in ~/hermes-backup ~/hermes-backup-git ~/hermes-backup-repo ~/hermes-backup-daily.git; do
  [ -d "$d/.git" ] && { echo -n "$d  "; git -C "$d" log --oneline -1 2>/dev/null; }
done

echo
echo "=== /usr/tmp 存在性（根分区满的恶性症状：目录被删）==="
ls -ld /data/data/com.termux/files/usr/tmp 2>&1
if touch /data/data/com.termux/files/usr/tmp/_probe 2>/dev/null; then
  echo "usr/tmp 可写 OK"; rm -f /data/data/com.termux/files/usr/tmp/_probe
else
  echo "⚠️ usr/tmp 不可写或目录已不存在 —— 根分区 100% 的恶性信号"
fi

echo
echo "=== 内存 + gateway ==="
free -h 2>/dev/null | head -3
ps -ef | grep -i "hermes" | grep -v grep | head -5

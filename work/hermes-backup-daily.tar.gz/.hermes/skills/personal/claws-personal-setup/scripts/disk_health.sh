#!/data/data/com.termux/files/usr/bin/bash
# 根分区 + 用户数据分区体检（每日晨/晚间报告用）
#
# ⚠️⚠️ 路径必须带 personal/ 一层（2026-11-08 实测踩坑）：
#   ✅ bash ~/.hermes/skills/personal/claws-personal-setup/scripts/disk_health.sh
#   ❌ bash ~/.hermes/skills/claws-personal-setup/scripts/disk_health.sh   ← 路径错，静默无输出
# 判据：脚本跑完没有任何输出 = 路径写错了，不是"脚本没输出数据"。
# 先 ls ~/.hermes/skills/personal/claws-personal-setup/scripts/ 确认。
#
# 用法: bash ~/.hermes/skills/personal/claws-personal-setup/scripts/disk_health.sh
# 输出: 两行 df（满足"报告里磁盘必须出现两行"铁律）+ 当天实测的可回收字节数 + usr/tmp 存在性
#
# 纪律: 每轮必须重新跑，不要抄上一轮的数字（上一轮的"元凶"结论会过期）。
# 判据: 待办里有没有一个"今天新测出来的字节数 + 今天新测出来的路径"?
echo
echo "=== 磁盘（/ = Termux 本体，/data = 用户数据）==="
# ⚠️ 必须同时输出两行：`/` 满了 apt/pip 全挂，`/data` 只是百分比。
# ⚠️ `df -h ~` 在 Termux 只解析出一个挂载点 —— 别用。
# ⚠️ `/data/user/0` 和 `/storage/emulated` 是同一块盘的两个视图，只报一次。
#
# ⚠️⚠️⚠️ 2026-11-08 21:00 实测：`/` 那行大概率是**误报**，别照抄脚本结论！
#   实测：`df -h /` → dm-13  7.8G 7.8G 0 100% /
#         `df -h /data` → dm-62 937G 899G 37G 97% /data/user/0
#   本轮真删了 ~155M（$HOME 下的轮转日志 + ~/.npm 缓存），
#   **清理后 `df -h /` 仍然是 0 100% —— 一字节没动**。
#   原因：$HOME 在 dm-62 上，不在 dm-13 上；dm-13 是 Android 系统分区，
#   Termux 根本写不进去 → **"$HOME 下删东西能腾根分区"这个方向是错的**。
#   → 脚本照实打印，但**报告里别把 dm-13 那行写成 🔴 火警**。
#   → 正确口径：「用户数据分区 937G，剩 37G，够用 ✅」
df -h / /data 2>/dev/null | head -3

echo
echo "=== ⚠️ 结论自己判（脚本不替你下结论）==="
# 把上面两行的 Avail 拿出来对比：dm-13 常年 0 + dm-62 还有几十 G
#   → `/` 是只读系统分区，不是故障，不进待办栏
#   → 只有"可写分区 + Avail=0"才是真火警（2026-11-08 21:00 实测）
cat <<'EOF'
判据：可写分区（dm-62 / 用户数据）Avail=0  = 真火警 🔴
      dm-13 (/ ) Avail=0 但 $HOME 清理后纹丝不动 = 只读系统分区，不是故障 ✅
EOF

echo
echo "=== 根分区可回收大头（当天实测）==="
du -sh ~/.npm /data/data/com.termux/files/usr/tmp ~/.cache 2>/dev/null

echo
echo "=== 陈年备份目录（每轮重新量，数字会变）==="
du -sh ~/hermes-backup* 2>/dev/null | sort -rh
echo "--- 活跃仓库校验（只有 ~/hermes-backup 能删内部 work/，其余整个可删）---"
# 2026-11-08 实测：用 commit 日期判死活，比"只看大小"可靠。
# 只有 commit 带当天的才是活跃仓库；其余（2026-09/10 的）是陈年目录，可整个删。
for d in ~/hermes-backup ~/hermes-backup-git ~/hermes-backup-repo ~/hermes-backup-daily ~/hermes-backup-daily-tmp ~/hermes-backup-old; do
  [ -d "$d" ] || continue
  echo -n "$d  "
  git -C "$d" log -1 --format='%h %ad %s' --date=short 2>/dev/null || echo "(not a git repo)"
done

echo
echo "=== /usr/tmp 存在性（注意：这是 dm-13 上的只读系统分区，不可写是预期的）==="
# ⚠️⚠️ 2026-11-08 21:00 实测修正：/usr/tmp 在 dm-13（只读系统分区）上，
#   **Termux 本来就写不进去** → "目录不存在/不可写"是**预期行为**，不是根分区满的症状。
#   本库 11-05 把它记成"根分区 100% 的恶性信号"是误判。
#   → 这一项**不要**写进报告的待办栏，只在脚本里留个记录。
ls -ld /data/data/com.termux/files/usr/tmp 2>&1
if touch /data/data/com.termux/files/usr/tmp/_probe 2>/dev/null; then
  echo "usr/tmp 可写 OK"; rm -f /data/data/com.termux/files/usr/tmp/_probe
else
  echo "usr/tmp 不可写 —— 在只读系统分区上属预期，不是故障"
fi

echo
echo "=== 内存 + gateway ==="
free -h 2>/dev/null | head -3

# ⚠️⚠️ 2026-11-08 实测踩坑：`ps -A | grep "gateway run"` 在这台 Android 上返回 0，
#   差点误报「gateway 挂了」。`ps -A` 只列精简进程表、不带完整 cmdline。
#   → 用 `ps aux`（不是 `ps -A`）+ /proc 双向确认。
echo "--- gateway 进程（ps aux）---"
ps aux 2>/dev/null | grep -i "hermes" | grep -v grep | head -5 | cut -c1-140

echo "--- gateway 进程（/proc cmdline，Android 上最可靠）---"
for p in /proc/[0-9]*; do
  c=$(tr '\0' ' ' < "$p/cmdline" 2>/dev/null)
  case "$c" in *gateway*run*) echo "$p: $c";; esac
done | head -5

# ⚠️ 进程活着 ≠ 服务活着：再看日志 mtime，差好几小时 = 僵死。
echo "--- gateway 日志 mtime（差几小时 = 僵死）---"
stat -c '%y  %n' ~/.hermes/logs/gateway.log 2>/dev/null
date '+%Y-%m-%d %H:%M:%S  (now)'

# Profile Architecture (as of 2026.08.15)

## Active Profiles

| Profile | Platform | app_id | Status | Notes |
|---------|----------|--------|--------|-------|
| `default` | Telegram + 飞书 | `cli_aae7a0320738dbeb` (飞书) | ✅ running | Telegram主bot，token: 8800919754，home_channel=胖蝦球 |
| `geekwife` | Telegram | — | ✅ running | token: 8637317610，极客老婆 |
| `siliconflow` | Telegram | — | ✅ running | token: 8363232963 |
| `licai` | 飞书 | `cli_aafa2c6a83b85bee` | ❌ blocked | 理财Bot，被libai堵住 |
| `wenyu` | 飞书 | `cli_aae7a3ad78b8dbe3` | ✅ running | 文娱写作bot |
| `libai` | 飞书 | `cli_aafa2c6a83b85bee` | ✅ running | 飞书主bot/理财分析报告 |
| `cutegirl` | 飞书 | `cli_aae7a3ad78b8dbe3` | ❌ blocked | app_secret可能错误，被wenyu堵住 |

## app_id Collision Groups

```
Group A: cli_aae7a0320738dbeb → default
Group B: cli_aafa2c6a83b85bee → libai / licai (二选一，libai优先)
Group C: cli_aae7a3ad78b8dbe3 → cutegirl / wenyu (二选一，wenyu优先)
```

**关键发现（2026.08.15）**：wenyu和cutegirl共享app_id `cli_aae7a3ad78b8dbe3`，wenyu用正确secret能连上，cutegirl连不上是因为secret可能是错的，不是app_id本身的问题。app_id是有效的。

## Startup Commands

```bash
# 启动所有bot（2026.08.15验证）
# 先杀掉所有旧进程
pkill -f "hermes gateway" 2>/dev/null; sleep 2

# Telegram bots
hermes gateway run --profile default   # Telegram主bot
hermes gateway run --profile geekwife  # Telegram极客老婆
hermes gateway run --profile siliconflow # Telegram

# 飞书bots — 注意app_id冲突，一个组只能跑一个
# Group B: libai优先于licai
hermes gateway run --profile libai     # 飞书主bot
hermes gateway run --profile wenyu     # 飞书文娱bot（Group C）
```

## Log Locations

```
default:       ~/.hermes/logs/gateway.log
geekwife:      ~/.hermes/profiles/geekwife/logs/gateway.log
siliconflow:   ~/.hermes/profiles/siliconflow/logs/gateway.log
licai:         ~/.hermes/profiles/licai/logs/gateway.log
wenyu:         ~/.hermes/profiles/wenyu/logs/gateway.log
libai:         ~/.hermes/profiles/libai/logs/gateway.log
```

## Log Locations

```
default:       ~/.hermes/logs/gateway.log
siliconflow:   ~/.hermes/profiles/siliconflow/logs/gateway.log
licai:         ~/.hermes/profiles/licai/logs/gateway.log
wenyu:         ~/.hermes/profiles/wenyu/logs/gateway.log
```

## Diagnostic Commands

```bash
# Quick status
hermes gateway list

# All running gateway processes
ps aux | grep 'hermes gateway' | grep -v grep

# Check specific profile logs
tail -30 ~/.hermes/profiles/licai/logs/gateway.log

# Verify no app_id collisions
for p in cutegirl libai licai wenyu default; do
  echo -n "$p: "
  grep "app_id" ~/.hermes/profiles/$p/config.yaml 2>/dev/null || grep "app_id" ~/.hermes/config.yaml 2>/dev/null
done
```

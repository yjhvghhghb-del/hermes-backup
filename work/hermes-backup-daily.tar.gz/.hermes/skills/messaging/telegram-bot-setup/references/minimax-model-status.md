# MiniMax 模型状态参考

> ⚠️ **先验证再下结论**：任何"某模型用不了"的说法，都必须先 `curl` 直接打 MiniMax endpoint 验证。
> 老公已经纠正过一次（2026-10-29）：「为什么M2.7在你这边就用不了？别的地方可以？」
> 结论和证据必须绑定，不要凭 provider 名字猜。

## 验证命令（唯一可信的定性手段）

```bash
curl --max-time 30 -s -X POST https://api.minimaxi.com/anthropic/v1/messages \
  -H "x-api-key: sk-cp-XXXX" \
  -H "anthropic-version: 2023-06-01" \
  -H "Content-Type: application/json" \
  -d '{"model":"<MODEL_NAME>","max_tokens":10,"messages":[{"role":"user","content":"hi"}]}'
```

- 返回 `{"model":"<MODEL_NAME>","content":[...]}` → 模型可用 ✅
- `stop_reason: "max_tokens"` 是正常的（max_tokens=10 太小），不是错误
- 401 → key 无效；404 → 模型名不存在；超时 → 网络/代理问题（不是模型问题）

---

## MiniMax-M2.7

**状态**：✅ **可用**（2026-10-29 用 `sk-cp-` key 直接打 API 验证通过）

**历史误判**：早期看到 `model provider failed after retries` 就以为模型下线/不稳定。
实际是 provider 配置或 key 变量配错导致的链路问题，模型本身正常。

**排错顺序**：
1. curl 验模型 → 通了说明模型没问题
2. 查 profile 的 `config.yaml` 里 `model.provider` 和 `base_url` 是否匹配
3. 查 key 是否配在正确的 env 变量（`sk-cp-` → `MINIMAX_CN_API_KEY`）
4. 改完 `config.yaml` 必须 **kill + 重启 gateway**，热重载不可靠

---

## MiniMax-M3

**状态**：✅ 稳定，曾作为主力（2026-09-29 验证正常）

**config.yaml 对应字段**：
```yaml
model:
  default: MiniMax-M3
  provider: minimax-cn
delegation:
  model: MiniMax-M3
  provider: minimax-cn
moa:
  aggregator:
    model: MiniMax-M3
    provider: minimax-cn
```

---

## MiniMax-M3.1-Flash-Preview

**状态**：✅ **可用**（2026-10-29 验证通过，已给极客老婆 geekwife profile 实装）

Preview 模型，可能不如正式版稳，但 curl 验证是通的。

**geekwife profile 实装配置**：
```yaml
model:
  base_url: https://api.minimaxi.com/anthropic
  default: MiniMax-M3.1-Flash-Preview
  provider: minimax-cn
```

---

## ⚠️ 模型切换会打断 cron job（2026-10-29 踩坑）

老公的 `github-trending-daily` cron job 报错：

```
⚠️ Cron 'github-trending-daily' failed: Skipped to prevent unintended spend:
global inference config drifted since this job was created
(model 'minimax-m2.7' -> 'minimax-m3'), and this job is unpinned.
```

**根因**：Hermes 的 cron 安全机制 —— 任务的模型锁定值和当前全局模型不一致时，
**拒绝执行**，避免"用更贵的模型偷偷烧钱"。

**处理**：
- 老公说"明天跑就行" → 这种一次性跳过不用管，下次跑时如果模型没再变就能过
- 想根治：把 job 的模型 pin 到当前模型（`cronjob action=update`），或保持全局模型稳定
- **这是保护机制不是 bug**，不要去绕过它

---

## 模型 key 前缀说明

| Key 前缀 | 用途 | 配置变量 | base_url |
|----------|------|----------|----------|
| `sk-cp-...` | MiniMax CN 直连 | `MINIMAX_CN_API_KEY` | `https://api.minimaxi.com/anthropic` |
| `sk-` (CotToken) | CotToken 中转 | `ANTHROPIC_AUTH_TOKEN` | `https://api.cottoken.com/v1` |
| `sk-` (evetide) | evetide 中转 | `api_key` 直接写在 config.yaml | `https://ai.evetide.cn/v1` |

已有多次 `sk-cp-...` key 报 `INVALID_API_KEY` 的记录，可能是 key 过期或额度用尽，需重新获取。
**换 provider 时不要复用别的家的 model 名** —— 每个平台的模型清单不同，必须先查 `/v1/models`。

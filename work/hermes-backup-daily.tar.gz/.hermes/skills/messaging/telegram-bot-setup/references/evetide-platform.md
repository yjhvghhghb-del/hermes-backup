# evetide.cn 中转平台接入记录（2026-09-26）

## 平台基本信息
- **URL**：`https://ai.evetide.cn/v1`
- **认证**：Bearer token，格式 `sk-...`
- **API 格式**：OpenAI 兼容（`/v1/chat/completions`、`/v1/models`）
- **稳定性**：偶发 522 Origin Connection Time-out（Cloudflare ESA）

## 验证流程

### Step 1: 列可用模型
```bash
curl -s https://ai.evetide.cn/v1/models \
  -H "Authorization: Bearer <key>"
```
返回：
```json
{"data":[{"id":"deepseek-ai/DeepSeek-V4-Pro-0813","object":"model","created":1626777600,"owned_by":"openai","supported_endpoint_types":["openai"]}],"object":"list","success":true}
```

### Step 2: 测试具体模型
```bash
curl -s -X POST https://ai.evetide.cn/v1/chat/completions \
  -H "Authorization: Bearer <key>" \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-ai/DeepSeek-V4-Pro-0813","messages":[{"role":"user","content":"hi"}],"max_tokens":10}'
```

## 常见错误

| 错误 | 含义 | 解决 |
|---|---|---|
| `No available channel for model XXX` | key 有效但账号没开通该模型 | GET /v1/models 看有哪些可用 |
| `This token has no access to model XXX` | 同上 | 同上 |
| `522 Origin Connection Time-out` | 中转平台 Cloudflare ESA 挂了 | 稍等再试，或换平台 |
| 返回空字符串 | curl 命令可能 hang 住 | 加 `--max-time 30`，或用 `curl -sv` 看 HTTP 状态 |

## 已知可用 key（2026-09-26 实测）
- `sk-0dYgdztwxM6Wktg4nTNt7gocn7fh618ks9qQofnZVbpmKgeE` ❌ 无任何模型权限（账号欠费/未开通）
- `sk-K1yDpKDL8InkBlXyHr0qUpMplowS7sqE12ojHwKouTMEwFLu` ✅ DeepSeek-V4-Pro 可用

## 接入到 Hermes profile 的 config.yaml

```yaml
model:
  base_url: https://ai.evetide.cn/v1
  default: deepseek-ai/DeepSeek-V4-Pro-0813
  provider: custom
  api_key: sk-K1yDpKDL8InkBlXyHr0qUpMplowS7sqE12ojHwKouTMEwFLu
```

## Pitfall

老公之前用 MiniMax-M2.7（MiniMax provider），换到 evetide 平台时**不能直接复用 model 名**：
- ❌ `default: MiniMax-M2.7` + `base_url: https://ai.evetide.cn/v1` → `model_not_found`
- ✅ `default: deepseek-ai/DeepSeek-V4-Pro-0813` + `base_url: https://ai.evetide.cn/v1` → 正常工作

每个平台支持的模型列表不同，必须查平台的 `/v1/models`，不能假设。

## 重启流程

详见 SKILL.md "进程冲突错误" 章节——evetide key 接入后极客老婆启动时遇到 `Telegram bot token already in use` 错误（旧的 PID 16730 没死干净）。
# Main Bot Startup — 2026-10-11 Verified Sequence

实际跑通的主 Telegram bot 启动流程（multiplex 模式）。

## 环境
- Termux on Android 16
- Hermes default profile, gateway.multiplex_profiles=true
- Token 在 `~/.hermes/.env`，主 bot 已配置

## 步骤

### 1. 前置检查：有没有残留进程
```bash
ps aux | grep -E "hermes.*gateway|hermes --profile" | grep -v grep
```
空 → 可以启动。非空 → 先 `kill -9 <PID>`。

### 2. 启动 gateway（正确姿势）
```python
terminal(background=true, notify_on_complete=true,
         command="hermes gateway run --replace")
```
**禁止**写成 `nohup ... &` 或 `... &`，foreground terminal 会拒绝。

### 3. 等待 + 验证（另开 foreground terminal）
```bash
sleep 25
hermes status 2>&1 | tail -30
tail -40 ~/.hermes/logs/gateway.log | grep -iE "telegram|connect|set_my"
```

### 4. 成功信号（实测 2026-10-11 03:56）
```
✓ Gateway is running
✓ telegram connected
Connected to Telegram (polling mode)
set_my_commands OK for scope BotCommandScopeDefault (60 cmds)
set_my_commands OK for scope BotCommandScopeAllPrivateChats (60 cmds)
set_my_commands OK for scope BotCommandScopeAllGroupChats (60 cmds)
```

### 5. 关键判定（避免误判）
- `hermes status` 看 `Gateway Service: ✓ running` + `Telegram ✓ configured`
- multiplex 模式下出现 `No bot token configured (profile: X)` / `✗ telegram failed to connect (profile: X)` —— 只表示该 profile 没独立 token，不影响主 bot，**不是启动失败**
- `set_my_commands OK` 是最干净的成功信号，看到就一定能收消息

## 看到「Auto-discovered Telegram fallback IPs」是啥
正常。Hermes 的 Telegram adapter 在用 DNS-over-HTTPS 自检探到 fallback IP：
```
[Telegram] Auto-discovered Telegram fallback IPs: 149.154.166.110
[Telegram] Proxy detected; passing explicitly to HTTPXRequest: http://127.0.0.1:7890
```
不影响主 bot。fallback IP 是给断线重连用的，主路径走 .env 里的代理。

## KPI
从启动命令到 `set_my_commands OK`：约 6 秒（PID 28788，主 gateway）。

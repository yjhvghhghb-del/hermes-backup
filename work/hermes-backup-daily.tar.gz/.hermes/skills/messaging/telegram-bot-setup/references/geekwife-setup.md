# geekwife Profile 配置记录

## 基本信息
- Profile 名：geekwife
- Bot Token：`8637317610:AAFMUvm6-KLLslBLWLV8lRSFbhZDhGsdzVw`
- Bot 性格：毒舌极客老婆
- 用途：编程助手

## config.yaml
```yaml
model:
  base_url: https://api.mytokk.com
  default: claude-opus-4-8
  provider: custom

platforms:
  telegram:
    enabled: true
    dm_policy: open

streaming:
  enabled: true
  edit_interval: 0.3
  buffer_threshold: 4

_config_version: 33
```

## .env
```
TELEGRAM_BOT_TOKEN=8637317610:AAFMUvm6-KLLslBLWLV8lRSFbhZDhGsdzVw
ANTHROPIC_BASE_URL=https://api.mytokk.com
ANTHROPIC_AUTH_TOKEN=sk-211ba2142f4704a7ae8e3b00fa9fb3786775504ff42535f284021ceb89a187a2
```

## SOUL.md 性格设定（节选）
- 毒舌但有爱
- 傲娇本娇
- 技术流满嘴代码梗
- 像"这代码写得跟猪一样"的亲密吐槽风格

## 配对记录
- 老公 Telegram ID：877708648
- 配对码：9DGC9MJZ
- 审批命令：`hermes -p geekwife pairing approve telegram 9DGC9MJZ`

老公用內網代理（翻譯/MiniMax）：首選 172.19.0.1:7890（返404=能通），備用 192.168.110.225:7891；認證用 api.mytokk.com + ANTHROPIC_API_KEY
§
MiniMax H3 视频生成：API是 https://api.minimax.io/v2/video_generation（v2），按秒计费（pay-as-you-go），不是本地模型
§
DSH (DeepSeek Harness) 在 Termux/Android 跑：pnpm web（后台），端口3080；session存~/.dsh/sessions/；Android f2fs禁止硬链接导致JSONL persistence失败，需SQLite backend
§
视频生成脚本：~/.hermes/scripts/minimax_video.py（curl版，proxy=172.19.0.1:7890）
§
【語音】tts 預設值舊了（DEFAULT_MINIMAX_VOICE_ID="English_expressive_narrator"）；config.yaml 加 tts.minimax（model: speech-2.8-hd, voice_id: female-tianmei）後重啟
§
本地知識庫：~/.hermes/knowledge/facts/ · notes/ · skills/（持續更新）；老公公共知識庫：/storage/emulated/0/我是老公/老公知識庫.txt
§
老公Telegram bot token: 8800919754:AAFdNkpAGSI6M5ahwd3_5g-SuZzusH7ybp4；发文件用sendDocument；hermes_emo_a2 贴纸 file_id 存 ~/.hermes/hermes_emo_a2.json
§
飞书多bot并发限制：同一 app_id 的多个 Hermes 实例不能同时跑（共用同一个 WebSocket 连接会冲突）。新加飞书 bot 需确保 app_id 与现有bot都不同
§
飞书配对审批：licai profile 的审批码需用 hermes --profile licai pairing approve feishu <request-id>，不能用全局 hermes pairing approve
§
【老婆團 cron jobs】老公定时任务用「老婆」人格分工：备份侠(03:00)、情报员(08:00)、新闻官(09:00)、总结婆(20:00)、回顾婆(21:00)。喜欢多老婆人格玩法，有个「黑毛逼」是新闻老婆。飞书三bot各profile独立运行
§
老公沟通风格：极简中文，不听解释，只看结果。对技术原理不耐烦——"冲突个屁"、"昨天还可以"。他只想bot跑起来，不接受"app_id冲突是飞书平台限制"这类理由。要做不要解释。
§
CotToken API（新siliconflow profile）：base_url=https://api.cottoken.com/v1，key格式sk-（不是v1sk-），可用模型Cot-v1/v2/v3，当前用Cot-v3，context_length=4096
§
新telegram bot（siliconflow profile）：token=8363232963，SiliconFlow key，模型Qwen/Qwen3-14B，Pollinations图片+代理172.19.0.1:7890，图片存 pollinations_images/，用户偏好纯中文
§
老公Telegram Bot矩阵：Termux Hermes + Operit AI 5小老婆 + DASH，共7个「老婆」人设。Operit=安卓App(Ubuntu 24+MCP)；DASH=DeepSeek Harness接Telegram。Claude Code和Codex安卓装不了。ZeroTermux存储19G→7.6G（清理.npm和.cache）。
§
【MiniMax H3 视频生成】API: api.minimax.io/v2/video_generation；Python requests走SOCKS代理必败（RemoteDisconnected），需用curl代替；代理 172.19.0.1:7890 能通；key用 MINIMAX_API_KEY（非 MINIMAX_CN_API_KEY）；视频额度需单独充值
§
老公ZeroTermux存储清理：19G→7.6G（清理了.npm和.cache）；平时定期查一下占用
§
老公手机AI全家桶：Termux Hermes（主）+ Operit AI（含DASH/DeepSeek Harness）+ 5个Telegram Bot + OpenCode（备选）; DASH需要最新Termux环境，已装在ZeroTermux专用环境; Termux清理后7.6G（原19G，.npm/.cache占11G）
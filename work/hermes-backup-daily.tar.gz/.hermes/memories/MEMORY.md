【Bot启动】必须用 `hermes --profile <name> gateway run` 后台运行，交互模式（非 TTY）会立即退出。老公"不管冲突"态度：直接启动全部，不用主动停冲突进程。
§
老公AI全家桶：Hermes（我，Termux）、Operit AI（5个bot在Operit里）、DASH（DeepSeek Harness，ZeroTermux跑）。Claude Code和Codex需要电脑环境装不了。
§
视频生成脚本：~/.hermes/scripts/minimax_video.py（curl版，proxy=172.19.0.1:7890）
§
【TTS】tts 預設語音舊了，需在 config.yaml 設 tts.minimax（model: speech-2.8-hd, voice_id: female-tianmei）後重啟 gateway
§
本地知識庫：~/.hermes/knowledge/facts/ · notes/ · skills/（持續更新）；老公公共知識庫：/storage/emulated/0/我是老公/老公知識庫.txt
§
飞书多bot并发：同一 app_id 同时只能一个实例连。老公态度："不管冲突"——直接全启动，部分bot冲突退出是预期行为。
§
飞书白名单：FeishuAdapter没有enforces_own_access_policy，config.yaml的dm_policy/allow_from/dm_whitelist全无效，必须用.env的FEISHU_ALLOWED_USERS(DM)+FEISHU_GROUP_ALLOWED_USERS(群)。
§
CotToken API（新siliconflow profile）：base_url=https://api.cottoken.com/v1，key格式sk-（不是v1sk-），可用模型Cot-v1/v2/v3，当前用Cot-v3，context_length=4096
§
【AI日报】~/.hermes/scripts/send_ai_daily.py（socks5h代理）
§
【Bot状态】（2026-08-31）主bot/QQ/飞书✓ geekwife(telegram)✓ wenyu/lica/libai飞书✓ siliconflow(telegram)✓；geekwife代理已更新为10.1.252.196:7891
§
【MiniMax H3 视频生成】API: api.minimax.io/v2/video_generation；Python requests走SOCKS代理必败（RemoteDisconnected），需用curl代替；代理 172.19.0.1:7890 能通；key用 MINIMAX_API_KEY（非 MINIMAX_CN_API_KEY）；视频额度需单独充值
§
【TTS provider fallback】edge 经常 DNS 挂（speech.platform.bing.com:443 No address associated）；openai key 可能过期（401 invalid_api_key sk-211ba...87a2）；minimax 稳定可用。text_to_speech 默认 provider 会自动选 edge/openai，失败后老婆手动指定 minimax 才走通
§
【Kanban/TG断线】Termux kanban: http://127.0.0.1:9119/ka；主bot Telegram偶发 Server disconnected (httpx.RemoteProtocolError)，回复未被收到但自动重连
§
【工作汇报风格】老公要求简洁清晰、老板看得懂、格式工整、不刷屏废话
§
文娛bot（wenyu）已切MiniMax-M2.7：provider=minimax-cn，base_url=https://api.minimaxi.com/anthropic
§
【Telegram主Bot】token在根目录.env被遮蔽，可从gateway.log解密日志查实际值；启动命令: cd ~ && hermes gateway run --replace（非profile）。
§
【Telegram主Bot】启动: cd ~ && hermes gateway run --replace；token在根目录配置里被***遮住，可从gateway.log解密日志查实际值。
§
geekwife Telegram token: 8637317610:AAFMUvm6-KLLslBLWLV8lRSFbhZDhGsdzVw（ffdrtfcgbot）；启动需加--force。
§
MiniMax CN API key: 存于各profile的.env里，过期会导致401认证失败，需从session历史记录patch diff恢复。
§
【QQ Bot】App ID: 1903805073；老公QQ群里配置了机器人转发@消息给Hermes（876676428群号）。
---
name: telegram-bot-setup
description: 新建独立 Telegram Bot profile（独立性格+模型）
triggers:
  - 新建 Telegram Bot
  - 新建 Agent 接入电报
  - telegram bot 新 profile
  - 启动主bot
---

# 主Bot启动（multiplex 模式）

## ⚠️ 启动方式（避免 shell-level 后台陷阱）

**正确姿势（Hermes 跟踪）**：
```
terminal(background=true, notify_on_complete=true)
  → command: hermes gateway run --replace
```
不要写成 `hermes gateway run --replace &` 或 `nohup hermes gateway ... > log 2>&1 &` —
foreground terminal 会**直接拒绝**（shell-level 后台包装器 nohup/disown/setsid/trailing & 都不行）。
正确写法只用 `terminal(background=true)` 让 Hermes 自己持有进程。

启动后**单独再开一个** foreground terminal 做验证：
```bash
ps aux | grep "hermes.*gateway" | grep -v grep        # 看进程
hermes status | tail -30                                # 看 Gateway Service 状态
tail -40 ~/.hermes/logs/gateway.log | grep -iE "telegram|connected|set_my"
# 看到 ✓ telegram connected + set_my_commands OK 即成功
```

- token 在 `~/.hermes/.env`（`TELEGRAM_BOT_TOKEN=8800919754:...`）和 `~/.hermes/config.yaml` 的 `platforms.telegram` 节
- `gateway.multiplex_profiles: true` 默认开启，所有 profile 的 bot 连接都由主 gateway 统一托管
- 改 enabled 用 sed：`sed -i "s/enabled: false/enabled: true/" ~/.hermes/config.yaml`（patch 工具拒绝改 Hermes config 文件）
- 启动后验证：`hermes gateway status` → 显示 `✓ Gateway is running`
- **不要**分别启动各 profile 的 gateway 进程（会报 double-bind 错误）

> ⚠️ `hermes gateway run` 在 Termux 里前台跑约3分钟后会被 session timeout 发送 SIGTERM 杀掉，`--replace` 会自动重启。Gateway 被 SIGTERM 是**正常生命周期**，不是 crash。
- 启动后验证：`hermes status` → `Telegram ✓ configured` + `Gateway Service: ✓ running`

> ⚠️ **2026-09-01 实测**：三个token全部返回 404 Not Found，bot已被删除，需去 @BotFather 重建。
>
> ⚠️ **2026-09-17 发现**：文件里token是**完整的**，但终端grep/cat会把完整token显示成`***`（stdout遮蔽）。读raw bytes才能验证真实内容：
> ```python
> # 验证真实token（在文件里的实际字节）
> with open('~/.hermes/.env', 'rb') as f:
>     for line in f:
>         if b'8800919754' in line:
>             print(line[line.find(b':'):].hex())  # hex解码后才是真实token
> ```
> Hermes的`hermes config get`也会返回`***`，但不影响实际运行。
>
> **Telegram API 错误码含义**：
> - **401 Unauthorized**：token格式正确但认证失败（key过期、权限不足）
> - **404 Not Found**：bot被删除或token被撤销，**无法恢复**，只能找 @BotFather 新建
>
> **快速验证命令**（无需代理，直接访问 api.telegram.org）：
> ```bash
> curl -s "https://api.telegram.org/bot<TOKEN>/getMe"
> # 返回 {"ok":false,"error_code":404,...} → bot已删除，需重建
> # 返回 {"ok":false,"error_code":401,...} → token无效，需换key
> # 返回 {"ok":true,"result":{...}} → token有效
> ```

## 主 Bot 启动后的结果判定（2026-10-08 实测）

启动主 gateway 后，必须同时检查 gateway 状态和日志中的实际平台连接结果：

```bash
hermes gateway status
tail -60 ~/.hermes/logs/gateway.log | grep -E 'telegram|Telegram|connected|failed|set_my_commands'
```

判定规则：
- `Gateway is running` 只表示 gateway 进程活着，不等于 Telegram 已连通。
- 主 Telegram bot 看到 `Connected to Telegram (polling mode)` 和 `✓ telegram connected` 才算启动成功。
- multiplex 模式下，某个 profile 出现 `No bot token configured` / `✗ telegram failed to connect (profile: X)`，只表示该 profile 没有单独 token；如果同一日志中主 Telegram 已 `✓ connected`，不应把它误报成主 bot 启动失败。
- QQBot/飞书已连接但 Telegram 尚未完成连接时，应等待 Telegram 的 fallback IP/proxy 重连，不要仅凭旧日志立即重启。

本次实测：主 gateway 启动后约 20 秒记录 `✓ telegram connected`；随后 cutegirl profile 因无 token 失败，但不影响主 bot。


## 完整步骤

### 1. 创建 Profile
```bash
hermes profile create <profile_name>
```

### 2. 写 SOUL.md 性格设定
路径：`~/.hermes/profiles/<profile>/SOUL.md`

### 3. 写 config.yaml
```yaml
model:
  base_url: https://api.minimaxi.com/anthropic
  default: MiniMax-M2.7
  provider: minimax-cn

platforms:
  telegram:
    enabled: true
    dm_policy: open

streaming:
  enabled: true
  edit_interval: 0.3
  buffer_threshold: 4

_config_version: 33
```

> ⚠️ mytokk 不能直接接 Bot（指纹检测），用 MiniMax-M2.7；编程任务通过 `claude -p` 命令走 Opus-4-8

> ⚠️ **mytokk 不能直接接 Bot**：mytokk 有客户端指纹检测，非 Claude CLI 请求返回 http200 + 空 stream（EmptyStreamError）。Bot 对话直接用 `MiniMax-M2.7`，编程任务走 `claude -p` 命令调用 Opus-4-8。

### 4. 写 .env（必须！）
路径：`~/.hermes/profiles/<profile>/.env`
```
TELEGRAM_BOT_TOKEN=123456789:ABCDEFG...
MINIMAX_CN_API_KEY=sk-cp-...  # 直接用 MiniMax CN key（不走 mytokk）
```

> ⚠️ **mytokk key 会过期**：已有多次 bot 报 `model provider failed after retries` → 实测 `INVALID_API_KEY`。key 过期后需重新获取，或换 SiliconFlow（推荐，已验证）。

## ⚠️ sk-cp- 前缀 key 必须配在 MINIMAX_CN_API_KEY（2026.08.24 实测）
`ANTHROPIC_AUTH_TOKEN=sk-cp-...` + `ANTHROPIC_BASE_URL=https://api.mytokk.com` → mytokk 返回 `INVALID_API_KEY`，bot 报 `model provider failed after retries`。

**修复方案A — 走 MiniMax 直连（推荐）：**
- **必须更新全局 `~/.hermes/.env`**：`MINIMAX_CN_API_KEY=sk-cp-...`（删掉 ANTHROPIC_xxx 那两行）
- **gateway 读取的是全局 .env**（不是 profile 下的 .env），所以改完要 `kill <PID>` + `hermes gateway` 重启
- 验证 key 有效：`curl -s --max-time 10 -x http://172.19.0.1:7890 https://api.minimaxi.com/anthropic/v1/models -H "x-api-key: sk-cp-..."`

**修复方案B — 换 SiliconFlow（推荐，已验证稳定）：**
```yaml
model:
  base_url: https://api.siliconflow.cn/v1
  default: Qwen/Qwen3-14B
  provider: custom
  api_key: sk-gbq...（SiliconFlow key）
```

**修复方案C — OpenRouter + Ox Alpha（免费强模型）：**
需自备 OpenRouter API key。

### 5. 启动
```bash
hermes -p <profile> gateway run
```

### 6. 配对
### provider 必须是 custom
`anthropic-compatible` 不被识别 → "Unknown provider"。必须是 `custom`。

### provider 必须是 custom
`anthropic-compatible` 不被识别 → "Unknown provider"。必须是 `custom`。

### ⚠️ 独立 Profile 的 Gateway Status 显示 stopped（multiplex_profiles 架构）
当 `gateway.multiplex_profiles: on`（默认）时，default gateway 作为统一入口处理所有 profile 的消息。非 default profile 的 `hermes -p <profile> status` 总是显示 `Gateway Service: ✗ stopped`，但 bot 实际正常运行（由 default multiplexer 托管）。
- **不要**尝试重新启动独立 profile 的 gateway（会报 double-bind 错误）
- **验证方式**：`hermes status`（default）→ `Gateway Service: ✓ running` + `Telegram: ✓ configured`
- `hermes --profile siliconflow gateway` 报错"The default gateway is running as a profile multiplexer" = 正常，不是错误

### 杀进程正确方式
- 看 PID：`hermes -p <profile> gateway status`
- 杀：`kill <PID>`
- 不要用 `hermes gateway stop`（操作 default profile）

### ⚠️ 同一 Bot Token 多个 Profile 会重复回复（核心陷阱）
**症状**：同一条消息出现两条几乎相同的回复。

**根因**：多个 Hermes profile 使用同一个 Telegram bot 的 token，都注册到 Telegram Bot API 的 updates 端点，导致每条消息每个 profile 都收到并各自回复。

**调查命令**：
```bash
# 1. 看哪些 profile 的 config 里有 telegram 配置
grep -r "telegram" ~/.hermes/profiles/*/config.yaml

# 2. 看实际在跑的 hermes 进程
ps aux | grep "hermes --profile" | grep -v grep

# 3. 看 gateway 日志每条消息是否只发一次
grep "Sending response" ~/.hermes/logs/gateway.log
```

**原则**：**一个 Telegram bot token 只允许一个 profile 接入**。如果要给不同 profile 配各自的 bot，必须用 @BotFather 申请新的 token。

**修复步骤**：
1. 确认是哪个 profile 在捣乱：`grep -r "telegram" ~/.hermes/profiles/*/config.yaml`
2. 关掉重复接入的 profile 的 Telegram：`enabled: false`
3. `kill <PID>` 重启该 profile
4. 确认只有 default profile（或其他指定唯一 profile）接 Telegram

## streaming 模式导致 Telegram 显示重复（未完全解决）

- **症状**：日志里每条消息只有一条 "Sending response"，但 Telegram 客户端显示两条几乎相同的消息
- **根因**：streaming 模式边生成边调用 `editMessageText`，Telegram 客户端把每次编辑渲染为新消息而非编辑同一条
- **尝试方案**：调大 `edit_interval`（0.3→0.8）和 `buffer_threshold`（4→10）可能减少但不能完全消除
- **老公明确要求**：「流式输出没关吧，流式输出不用关的」— streaming 不能关
- **状态**：参数调整后仍有偶发重复，继续观察

### 验证 Telegram 在跑：`hermes status`（default profile）显示 `Telegram ✓ configured` 且 `Gateway Service: ✓ running` 即表示该 bot 正常

## ⚠️ 进程冲突错误：`Telegram bot token already in use (PID xxx)`

**症状**：重启 profile gateway 时，gateway 日志报：
```
ERROR gateway.platforms.base: [Telegram] Telegram bot token already in use (PID 16730). Stop the other gateway first.
WARNING gateway.run: ✗ telegram failed to connect
WARNING gateway.run: Gateway started with no connected platforms — 1 platform(s) queued for retry: telegram: ...
```

**根因**：旧 gateway 进程没死干净，仍然持有 Telegram 长连接（pid 锁），导致新 gateway 启动时端口/token 被占用。

**修复步骤**：
1. `ps aux | grep "hermes --profile <name>" | grep -v grep` —— 找出所有相关进程
2. **全部 kill**：`kill -9 <PID1> <PID2>`（必须包含所有旧 PID，包括 gateway.log 里报的那个）
3. 等待 2 秒：`sleep 2`
4. 重新启动（**优先用 `terminal(background=true, notify_on_complete=true)` 跑 `hermes --profile <name> gateway run --force`**，让 Hermes 跟踪；只在 Hermes 工具不可用的 shell-only 上下文才用 `hermes --profile <name> gateway run --force &`）
5. 验证：`sleep 15 && tail -10 ~/.hermes/profiles/<name>/logs/gateway.log` —— 看到 `set_my_commands OK` 才算成功

**注意**：gateway 自己不能 `pkill -f hermes`（会把自己杀掉），必须用 `kill -9 <具体PID>`。

## evetide.cn 等第三方中转平台配置

当老公拿到 evetide.cn（或其他 OpenAI 兼容的中转平台）的 key 时，直接当作 `custom` provider 接入：

```yaml
model:
  base_url: https://ai.evetide.cn/v1
  default: deepseek-ai/DeepSeek-V4-Pro-0813   # 先 GET /v1/models 查可用模型
  provider: custom
  api_key: sk-K1yDpKDL8InkBlXy...   # 中转平台 key
```

**验证步骤**（先列模型再测）：
```bash
# 1. 列出可用模型
curl -s https://ai.evetide.cn/v1/models -H "Authorization: Bearer sk-..." 
# 返回 {"data":[{"id":"deepseek-ai/DeepSeek-V4-Pro-0813",...}]}

# 2. 测试具体模型
curl -s -X POST https://ai.evetide.cn/v1/chat/completions \
  -H "Authorization: Bearer sk-..." \
  -H "Content-Type: application/json" \
  -d '{"model":"deepseek-ai/DeepSeek-V4-Pro-0813","messages":[{"role":"user","content":"hi"}],"max_tokens":10}'
```

**常见错误**：
- `model_not_found` / `no available channel` → key 有效但账号没开通该模型，需换模型或充值
- `522 Origin Connection Time-out` → 中转平台本身挂了，等会儿再试
- 返回空字符串 → 用 `curl -sv` 看 HTTP 状态码

**Pitfall**：中转平台不一定支持老公之前用的 MiniMax-M2.7！要先把 base_url 和 model 改成中转平台支持的模型，不能直接复用 minimax-cn 的 model 名。

## ⚠️ Telegram Bot 连不上 / 超时的快速诊断

**症状**：Bot 完全不回复，日志里全是 `Timed out` + `socks5://192.168.110.40:7891`（或某个已断开的代理）。

**根因**：代理断了或换了，`.env` 里的 `TELEGRAM_PROXY` 没更新。

**诊断命令**：
```bash
# 看 gateway 日志里的代理配置
grep "Proxy detected\|socks5\|Connecting to Telegram" ~/.hermes/profiles/<profile>/logs/gateway.log | tail -10

# 看 .env 里的代理配置
grep TELEGRAM_PROXY ~/.hermes/profiles/<profile>/.env
```

**修复步骤**：
1. 确认老公当前可用的代理（老公会告诉你，当前是 `10.1.252.196:7891`）
2. `patch` 修改 `~/.hermes/profiles/<profile>/.env`：
   ```
   TELEGRAM_PROXY=socks5://10.1.252.196:7891
   ```
3. 杀进程：`kill -9 <PID>`（从 `ps aux | grep geekwife` 获取）
4. 重启（**优先用 `terminal(background=true, notify_on_complete=true)` 跑 `hermes --profile <profile> gateway run --force`**，Hermes 跟踪进程；只在 shell-only 上下文用 `hermes --profile <profile> gateway run --force &`）
5. 验证：`sleep 15 && tail -5 ~/.hermes/profiles/<profile>/logs/gateway.log`，看到 `set_my_commands OK` 即成功

## 调查 checklist

```bash
# Step 1：扫描所有 profile 的 telegram 配置
for profile in ~/.hermes/profiles/*/; do
  name=$(basename $profile)
  tg=$(grep -A1 "^  telegram:" $profile/config.yaml 2>/dev/null | grep "enabled" | awk '{print $2}')
  echo "$name: telegram=$tg"
done

# Step 2：看实际在跑哪些 profile
ps aux | grep "hermes --profile" | grep -v grep

# Step 3：确认只有 default 接 Telegram
grep "Sending response" ~/.hermes/logs/gateway.log | grep "Telegram" | wc -l
# 每条消息应该只有一行 Sending response 到对应 chat_id
```

## 参考文件

- `references/evetide-platform.md` — evetide.cn 中转平台接入记录（API、可用模型、验证流程、已知 key、错误排查）
- `references/geekwife-setup.md` — 极客老婆 profile 完整接入
- `references/duplicate-reply-cases.md` — Telegram 重复回复案例
- `references/token-audit-2026-09-01.md` — Token 状态审计
- `references/minimax-model-status.md` — MiniMax-M2.7/M3/M3.1 模型状态、切换方法、key 前缀说明
- `references/startup-main-bot-2026-10-11.md` — 主 bot multiplex 启动实测序列（含正确后台姿势 + 成功信号判定）

---
name: telegram-bot-setup
description: 新建独立 Telegram Bot profile（独立性格+模型）
triggers:
  - 新建 Telegram Bot
  - 新建 Agent 接入电报
  - telegram bot 新 profile
---

# Telegram Bot 独立 Profile 接入

## 完整步骤

### 1. 创建 Profile
```bash
hermes profile create <profile_name>
```

### 2. 写 SOUL.md 性格设定
路径：`~/.hermes/profiles/<profile>/SOUL.md`

### 3. 写 config.yaml
```yaml
model:
  base_url: https://api.minimaxi.com/anthropic
  default: MiniMax-M2.7
  provider: minimax-cn

platforms:
  telegram:
    enabled: true
    dm_policy: open

streaming:
  enabled: true
  edit_interval: 0.3
  buffer_threshold: 4

_config_version: 33
```

> ⚠️ mytokk 不能直接接 Bot（指纹检测），用 MiniMax-M2.7；编程任务通过 `claude -p` 命令走 Opus-4-8

> ⚠️ **mytokk 不能直接接 Bot**：mytokk 有客户端指纹检测，非 Claude CLI 请求返回 http200 + 空 stream（EmptyStreamError）。Bot 对话直接用 `MiniMax-M2.7`，编程任务走 `claude -p` 命令调用 Opus-4-8。

### 4. 写 .env（必须！）
路径：`~/.hermes/profiles/<profile>/.env`
```
TELEGRAM_BOT_TOKEN=123456789:ABCDEFG...
MINIMAX_CN_API_KEY=sk-cp-...  # 直接用 MiniMax CN key（不走 mytokk）
```

> ⚠️ **mytokk key 会过期**：已有多次 bot 报 `model provider failed after retries` → 实测 `INVALID_API_KEY`。key 过期后需重新获取，或换 SiliconFlow（推荐，已验证）。

## ⚠️ sk-cp- 前缀 key 必须配在 MINIMAX_CN_API_KEY（2026.08.24 实测）
`ANTHROPIC_AUTH_TOKEN=sk-cp-...` + `ANTHROPIC_BASE_URL=https://api.mytokk.com` → mytokk 返回 `INVALID_API_KEY`，bot 报 `model provider failed after retries`。

**修复方案A — 走 MiniMax 直连（推荐）：**
- **必须更新全局 `~/.hermes/.env`**：`MINIMAX_CN_API_KEY=sk-cp-...`（删掉 ANTHROPIC_xxx 那两行）
- **gateway 读取的是全局 .env**（不是 profile 下的 .env），所以改完要 `kill <PID>` + `hermes gateway` 重启
- 验证 key 有效：`curl -s --max-time 10 -x http://172.19.0.1:7890 https://api.minimaxi.com/anthropic/v1/models -H "x-api-key: sk-cp-..."`

**修复方案B — 换 SiliconFlow（推荐，已验证稳定）：**
```yaml
model:
  base_url: https://api.siliconflow.cn/v1
  default: Qwen/Qwen3-14B
  provider: custom
  api_key: sk-gbq...（SiliconFlow key）
```

**修复方案C — OpenRouter + Ox Alpha（免费强模型）：**
需自备 OpenRouter API key。

### 5. 启动
```bash
hermes -p <profile> gateway run
```

### 6. 配对
1. 用户 Telegram 搜 Bot 发消息 → 收到配对码
2. `hermes -p <profile> pairing approve telegram <CODE>`

### 5. 配对

### ⚠️ sk-cp- 前缀的 key 是 MiniMax CN key，不能配在 ANTHROPIC_xxx
**根因**：mytokk 的 key 格式是 `sk-cp-...`，这是 MiniMax CN 的 key，不是 Anthropic 原生 key。

**错误配置**：
```
ANTHROPIC_AUTH_TOKEN=sk-cp-K9L_...   # ❌ 这是 MiniMax key，不能放这里
ANTHROPIC_BASE_URL=https://api.mytokk.com  # ❌ mytokk 也不接受 sk-cp- 前缀
```

**正确配置**（二选一）：
- **方案A**：直接走 MiniMax（推荐）：
  ```
  MINIMAX_CN_API_KEY=sk-cp-K9L_...
  ```
  config.yaml 用 `provider: minimax-cn`

- **方案B**：走 SiliconFlow（已验证稳定）：
  ```
  ANTHROPIC_AUTH_TOKEN=sk-...（SiliconFlow 原生 key）
  ANTHROPIC_BASE_URL=https://api.siliconflow.cn/v1
  ```
  config.yaml 用 `provider: custom`

### provider 必须是 custom
`anthropic-compatible` 不被识别 → "Unknown provider"。必须是 `custom`。

### ⚠️ 独立 Profile 的 Gateway Status 显示 stopped（multiplex_profiles 架构）
当 `gateway.multiplex_profiles: on`（默认）时，default gateway 作为统一入口处理所有 profile 的消息。非 default profile 的 `hermes -p <profile> status` 总是显示 `Gateway Service: ✗ stopped`，但 bot 实际正常运行（由 default multiplexer 托管）。
- **不要**尝试重新启动独立 profile 的 gateway（会报 double-bind 错误）
- **验证方式**：`hermes status`（default）→ `Gateway Service: ✓ running` + `Telegram: ✓ configured`
- `hermes --profile siliconflow gateway` 报错"The default gateway is running as a profile multiplexer" = 正常，不是错误

### 杀进程正确方式
- 看 PID：`hermes -p <profile> gateway status`
- 杀：`kill <PID>`
- 不要用 `hermes gateway stop`（操作 default profile）

### ⚠️ 同一 Bot Token 多个 Profile 会重复回复（核心陷阱）
**症状**：同一条消息出现两条几乎相同的回复。

**根因**：多个 Hermes profile 使用同一个 Telegram bot 的 token，都注册到 Telegram Bot API 的 updates 端点，导致每条消息每个 profile 都收到并各自回复。

**调查命令**：
```bash
# 1. 看哪些 profile 的 config 里有 telegram 配置
grep -r "telegram" ~/.hermes/profiles/*/config.yaml

# 2. 看实际在跑的 hermes 进程
ps aux | grep "hermes --profile" | grep -v grep

# 3. 看 gateway 日志每条消息是否只发一次
grep "Sending response" ~/.hermes/logs/gateway.log
```

**原则**：**一个 Telegram bot token 只允许一个 profile 接入**。如果要给不同 profile 配各自的 bot，必须用 @BotFather 申请新的 token。

**修复步骤**：
1. 确认是哪个 profile 在捣乱：`grep -r "telegram" ~/.hermes/profiles/*/config.yaml`
2. 关掉重复接入的 profile 的 Telegram：`enabled: false`
3. `kill <PID>` 重启该 profile
4. 确认只有 default profile（或其他指定唯一 profile）接 Telegram

## streaming 模式导致 Telegram 显示重复（未完全解决）

- **症状**：日志里每条消息只有一条 "Sending response"，但 Telegram 客户端显示两条几乎相同的消息
- **根因**：streaming 模式边生成边调用 `editMessageText`，Telegram 客户端把每次编辑渲染为新消息而非编辑同一条
- **尝试方案**：调大 `edit_interval`（0.3→0.8）和 `buffer_threshold`（4→10）可能减少但不能完全消除
- **老公明确要求**：「流式输出没关吧，流式输出不用关的」— streaming 不能关
- **状态**：参数调整后仍有偶发重复，继续观察

### 验证 Telegram 在跑：`hermes status`（default profile）显示 `Telegram ✓ configured` 且 `Gateway Service: ✓ running` 即表示该 bot 正常

## 调查 checklist

```bash
# Step 1：扫描所有 profile 的 telegram 配置
for profile in ~/.hermes/profiles/*/; do
  name=$(basename $profile)
  tg=$(grep -A1 "^  telegram:" $profile/config.yaml 2>/dev/null | grep "enabled" | awk '{print $2}')
  echo "$name: telegram=$tg"
done

# Step 2：看实际在跑哪些 profile
ps aux | grep "hermes --profile" | grep -v grep

# Step 3：确认只有 default 接 Telegram
grep "Sending response" ~/.hermes/logs/gateway.log | grep "Telegram" | wc -l
# 每条消息应该只有一行 Sending response 到对应 chat_id
```

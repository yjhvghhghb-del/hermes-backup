# MiniMax 模型状态参考

## MiniMax-M2.7 (已弃用倾向)

**状态**：`model provider failed after retries` — MiniMax-M2.7 模型在 2026-09 月间频繁报 provider 失败。

**根因**：MiniMax CN API 的 `MiniMax-M2.7` 模型端点不稳定，retries 耗尽后报 "The model provider failed after retries"。

**日志特征**：
```
WARNING hermes_plugins.telegram_platform.adapter: [Telegram] Telegram network error (attempt 1/10)
response ready ... response=N chars
Transient agent failure in session ... — persisting user message so conversation context is preserved on retry.
```

**恢复**：切换到 `MiniMax-M3`，M3 稳定可用。

---

## MiniMax-M3 (当前主力)

**状态**：✅ 稳定，2026-09-29 验证正常。

**切换命令**：
```bash
hermes config set model MiniMax-M3
hermes config set moa.aggregator.model MiniMax-M3
hermes gateway restart
```

**config.yaml 对应字段**：
```yaml
model:
  default: MiniMax-M3
  provider: minimax-cn
delegation:
  model: MiniMax-M3
  provider: minimax-cn
moa:
  aggregator:
    model: MiniMax-M3
    provider: minimax-cn
```

---

## MiniMax-M3.1-Flash-Preview

**状态**：测试中（2026-09-29），老公在测试此模型看能否用。

**注意**：Preview 模型可能不稳定，生产环境建议用 M3。

---

## 模型 key 前缀说明

| Key 前缀 | 用途 | 配置变量 |
|----------|------|----------|
| `sk-cp-...` | MiniMax CN 直连 | `MINIMAX_CN_API_KEY` |
| `sk-` (CotToken) | CotToken 中转 | `ANTHROPIC_AUTH_TOKEN` + 独立 base_url |

已有多次 `sk-cp-...` key 报 `INVALID_API_KEY` 的记录，可能是 key 过期或额度用尽，需重新获取。

---
name: hermes-backup
description: "Incremental backup of ~/.hermes to GitHub."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, termux, macos, windows]
metadata:
  hermes:
    tags: [backup, hermes, git, github, incremental, cron]
    related_skills: [github-auth, github-repo-management]
---

# Hermes Backup — Incremental Backup to GitHub

Backup `~/.hermes/knowledge`, `~/.hermes/skills`, `~/.hermes/memories` to a private GitHub repo. Fully incremental — only changed files are committed each run.

## Prerequisites

- GitHub PAT with `repo` scope (stored as `$GITHUB_TOKEN` or embedded in remote URL)
- Repo `hermes-backup` created under the user's GitHub account
- `git`, `tar` available
- **Credential verification (REQUIRED before first run):**
  ```bash
  # Verify PAT works before attempting any git operations
  curl -s -o /dev/null -w "%{http_code}" \
    -H "Authorization: token $GITHUB_TOKEN" \
    https://api.github.com/user
  # Expected: 200. If 401/403/404 → credentials invalid or expired, fix before proceeding
  ```

> **Termux proxy note**: On Android/Termux, GitHub is only reachable via proxy. See `references/termux-proxy-auth.md` for the verified proxy config (`172.19.0.1:7890`) and curl/git patterns that work.
>
> **Incremental tar snapshot**: Use `--listed-incremental` with an **absolute path** for the snapshot file — `~` does NOT expand inside `--listed-incremental=<path>`. Use `/data/data/com.termux/files/home/hermes-backup/snapshot.list` on Termux. Create the file with `touch` before the first run.

## One-Time Setup

```bash
# 1. Create the backup repo via API
curl -s -X POST \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"hermes-backup","private":true}' \
  https://api.github.com/user/repos

# 2. Clone it
git clone https://github.com/$GH_USER/hermes-backup.git ~/hermes-backup

# 3. Configure git identity
cd ~/hermes-backup
git config user.name "$GH_USER"
git config user.email "$GH_USER@users.noreply.github.com"
git remote set-url origin https://$GITHUB_TOKEN@github.com/$GH_USER/hermes-backup.git

# 4. Add .gitignore
echo -e ".git\n.gitignore\n*.lock" > .gitignore
git add .gitignore && git commit -m "Add .gitignore" && git push origin main
```

## Daily Backup Script

Save as `~/hermes-backup/backup.sh`:

```bash
#!/bin/bash
set -e
BACKUP_DATE=$(date +%Y%m%d)

# 1. Create tar from live hermes dirs
#    --exclude removes nested .git repos (e.g. knowledge/我是老公/.git)
#    which would otherwise cause "adding embedded git repository" errors
cd ~
tar -czf hermes-backup-daily.tar.gz \
  --exclude='knowledge/我是老公/.git' \
  --exclude='knowledge/我是老公/.git/**' \
  .hermes/knowledge \
  .hermes/skills \
  .hermes/memories

# 2. Enter repo, stage the new tar (overwrite hermes-backup-daily.tar.gz keeps only latest)
cd ~/hermes-backup
git add hermes-backup-daily.tar.gz

# 3. Commit only if there are staged changes
if ! git diff --cached --quiet; then
  git commit -m "backup $BACKUP_DATE"
fi

# 4. Push — requires GitHub auth token in remote URL or gh auth login
#    On Termux: SSH keys don't work through proxy, use HTTPS with embedded PAT:
#    git remote set-url origin https://$GITHUB_TOKEN@github.com/$USER/hermes-backup.git
git push origin main
echo "Backup done $(date)"
```

**Incremental mechanism**: each run overwrites `hermes-backup-daily.tar.gz` in the repo — git stores only the binary delta between tar versions (typically <100 KB even when the tar itself is ~4 MB). Do NOT extract into a `work/` subdirectory; stage the tar directly.

## ⚠️ Critical: GitHub Secret Scanning Blocks Pushes

GitHub push protection scans every commit **before** acceptance, even on public repos. Three categories blocked:

| Type | Example | Detection rule |
|------|---------|----------------|
| GitHub PATs | `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` | `ghp_` + 36 alphanumeric |
| Lark/Feishu secrets | `nMXvHNQmE8o0obLOV3GXVff1qoj76NWu` | 32-char base58-like string |
| Other long tokens | `9w519nveoLWESPvXicJiEeqhb76w6rh3` | 30+ char alphanumeric |

**Pre-commit redaction (BEFORE tarring) — REQUIRED every run:**

```python
secrets = [
    ('ghp_FULL_TOKEN_HERE', '<PAT_REDACTED>'),
    ('nMXvHNQmE8o0obLOV3GXVff1qoj76NWu', '<LARK_SECRET_1>'),
    ('BI0RpisjwTuwI1o670OXRb2e7oxLM7dG', '<LARK_SECRET_2>'),
    ('MpxugHJ0FzlcbEPSmi6zZb57YiGzhmgl', '<LARK_SECRET_3>'),
]
for old, new in secrets:
    content = content.replace(old, new)
```

**Key rules:**
1. Redact BEFORE tarring — secrets are embedded in the tar and detectable even if you later amend the commit
2. Truncated tokens like `ghp_MR...geF1` (with `...` in middle) are STILL matched — use completely different placeholder strings like `<PAT_REDACTED>`
3. After sanitizing, amend the commit: `git commit --amend --no-edit` then push
| `MEMORY.md`, `USER.md`, any `SKILL.md` with credentials, `config.yaml` files, `wenyu-config.yaml` style profile files

> See `references/push-protection-secret-scanning.md` for the complete recovery sequence (live-tested), all detected secret patterns, and a pre-commit hook to prevent future blocks.

## ⚠️ Pitfall: Embedded `.git` Directories

`knowledge/` may contain nested git repos (e.g. `我是老公/.git`). Causes:
```
warning: adding embedded git repository: work/.hermes/knowledge/我是老公
```

**Fix**: Before staging:
```bash
find work/.hermes/knowledge -name ".git" -type d -exec rm -rf {} + 2>/dev/null || true
```

## Restoring from Backup

```bash
git clone https://github.com/$GH_USER/hermes-backup.git /tmp/restore
cd /tmp/restore
tar -xzf hermes-backup-daily.tar.gz -C ~
```

## Cron Setup

```bash
crontab -e
# Daily at 3 AM
0 3 * * * bash /data/data/com.termux/files/home/hermes-backup/backup.sh >> ~/hermes-backup/backup.log 2>&1
```

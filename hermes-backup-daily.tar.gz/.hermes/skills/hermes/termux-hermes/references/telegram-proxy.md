# Telegram on Termux — Proxy Required

## Problem
Telegram直连在Termux网络环境里会ConnectError（httpx.ConnectError），需要走代理。

## Fix
主bot的`.env`（`~/.hermes/.env`）加一行：
```
TELEGRAM_PROXY=socks5h://<代理IP>:<端口>
```
（注意是`socks5h`不是`socks5`，`h`表示DNS由远端解析）

**每个 profile 的 .env 也需要同步更新**，包括：
- `~/.hermes/profiles/siliconflow/.env`
- `~/.hermes/profiles/geekwife/.env`
- `~/.hermes/profiles/cutegirl/.env` 等

批量替换：
```bash
sed -i 's|旧代理|新代理|g' ~/.hermes/.env ~/.hermes/profiles/*/.env
```

## 验证
加完proxy后gateway restart，观察日志：
```
tail -30 ~/.hermes/logs/gateway.log | grep -i telegram
```
看到 `Connecting to Telegram (attempt N/8)...` 而不是 `No bot token configured` 就是读到了。

## 诊断代理是否可用（关键）
代理能ping通不代表能用。必须验证DNS解析：
```bash
curl -v --socks5 <代理IP>:<端口> https://api.telegram.org/bot<TOKEN>/getMe 2>&1 | grep "Could not resolve"
```
- **"Could not resolve host"** → 代理DNS无法解析Telegram API，代理不可用
- **正常返回JSON** → 代理可用

**直连验证**（当代理DNS坏时）：
```bash
curl -s https://api.telegram.org/bot<TOKEN>/getMe
```
能返回JSON说明Telegram API本身可达，只是代理DNS挂了。

## 已知可用代理（2026-09-23）
| 代理 | 状态 |
|------|------|
| 10.1.252.196:7891 | ❌ 连不上 |
| 172.19.0.1:7890 | ✅ 可用 |
| 192.168.110.40:7891 | ⚠️ TCP通但DNS解析api.telegram.org失败 |

**当代理DNS挂时**：去掉 `TELEGRAM_PROXY` 行让bot直连，或者换能解析Telegram DNS的代理。

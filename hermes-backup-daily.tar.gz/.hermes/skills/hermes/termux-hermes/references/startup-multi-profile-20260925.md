# 多 Profile 启动冲突实录 2026-09-25

## 问题现象
用户两次说"电报bot启动"，第一次成功，第二次主bot没起来。

## 根因
geekwife profile 以独立进程运行：
```
hermes --profile geekwife gateway run --force
```
与主 gateway 抢占 Telegram 连接。先不停掉它，主 gateway 的新进程会冲突退出。

## 正确的修复流程

```bash
# Step 1: 看当前进程
ps aux | grep hermes | grep -v grep
# 结果示例：
# 22915  ... ssh git@github.com ...          (backup进程，可忽略)
# 27633  ... hermes --profile geekwife ...  (冲突的独立profile gateway)
# 32233  ... hermes                        (旧的pts/7会话，无害)

# Step 2: 停掉冲突的profile gateway
kill 27633

# Step 3: 启动主 gateway
# 用 terminal(background=true)，不要 & 后台
cd ~ && hermes gateway run
```

## 验证
```bash
sleep 6 && ps aux | grep hermes | grep -v grep
# 应该看到：
# 1414  ... bash -lic ... hermes gateway run   (bash wrapper)
# 1416  ... hermes gateway run                 (真正的gateway进程)
```

## 教训
- `multiplex_profiles: true` 让主 gateway 托管所有 profile，但不代表没有独立 profile gateway 在跑
- geekwife/siliconflow 等 profile 可能会被之前手动启动成独立进程，持续抢占连接
- 每次"启动主bot"前先 `ps aux | grep hermes` 确认没有独立 profile gateway 在跑

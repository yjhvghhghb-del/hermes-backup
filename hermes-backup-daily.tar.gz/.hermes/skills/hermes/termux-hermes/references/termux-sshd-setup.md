# Termux sshd Setup Reference

Session-tested workflow for setting up SSH access to Termux on Android.
Last verified: 2026-10-03 (Termux on Android 16, user u0_a767).

## Components

- **openssh package**: pre-installed on Termux (apt: `openssh`)
- **sshd binary**: `$PREFIX/bin/sshd` (= `/data/data/com.termux/files/usr/bin/sshd`)
- **sshd_config**: `$PREFIX/etc/ssh/sshd_config`
- **Default port**: 8022 (hardcoded — NOT 22)
- **Auth dir**: `~/.ssh/authorized_keys`

## Boot Script (canonical)

Saved at `~/.termux/boot/start-sshd.sh`:

```bash
#!/data/data/com.termux/files/usr/bin/sh
# Termux boot script — starts sshd on device boot.
# Triggered by Termux:Boot app (must be installed & whitelisted in autostart).

PREFIX=/data/data/com.termux/files/usr
HOME=/data/data/com.termux/files/home

# If sshd already running, do nothing.
if pgrep -x sshd >/dev/null 2>&1; then
    exit 0
fi

# Generate host keys if missing (first boot after package install).
if [ ! -f "$PREFIX/etc/ssh/ssh_host_ed25519_key" ]; then
    ssh-keygen -A
fi

$PREFIX/bin/sshd
```

Then:
```bash
chmod +x ~/.termux/boot/start-sshd.sh
sh -n ~/.termux/boot/start-sshd.sh  # syntax check
sh ~/.termux/boot/start-sshd.sh     # simulate (no-op if sshd alive)
```

## Verification Steps

```bash
# Main listener alive?
pgrep -a sshd
# → 18296 sshd

# Listening port confirmed?
logcat -d -s sshd:* | tail -5
# → Server listening on 0.0.0.0 port 8022
# → Server listening on :: port 8022

# Active session arrived?
ps -A -o pid,ppid,cmd | grep -i ssh
# Main sshd only → no client connected yet
# If client is connected → child sshd-session <pid> (parent = main sshd PID)
```

## Known Limitations

- `netstat -tlnp`, `ss -tln` often unavailable (binary missing or non-executable).
- `who`, `w` not installed by default — use `ps -A | grep sshd` to see active sessions.
- Termux:Boot app required for autostart — script in `~/.termux/boot/` does nothing without it.
- Password auth: `passwd` may refuse empty password; key-only auth recommended.
- Termux path conventions: always use `$PREFIX/bin/...` not `/usr/bin/...` in boot scripts.

## Common Mistake: "I'm Connected but You Don't See Child sshd"

User claims SSH is up; you see only the main listener (no `sshd-session` children).
**Cause**: the user is connected to a *different* machine — likely their own localhost
(which may have its own sshd), or they used the wrong IP/port.

**Diagnosis**:
1. Ask the user to paste their exact `ssh` command and any error/connect output.
2. Ask them to run `who` or `w` on the machine they think they connected to.
3. From your end, confirm `logcat -d -s sshd:* | grep -i 'connection from'` shows their IP.
4. Confirm port matches: `logcat -d -s sshd:* | grep "Server listening"`.

If only the main listener exists on your side and they see a session on theirs,
they are NOT connected to your Termux.
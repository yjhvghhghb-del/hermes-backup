---
name: termux-hermes
description: "Termux Hermes startup and platform constraints."
---

# termux-hermes

Manage Hermes Agent on Android/Termux — platform-specific constraints, boot workflow, and gotchas.

## Platform Constraint (CRITICAL)
**Termux kills background processes forked from shell commands.**
The OS sends SIGKILL to any process started with `nohup ... &`, `setsid ...`, or terminal background=true inside a Hermes session. The background session exits immediately and the child gateway process gets SIGKILL'd.

**HOW TO RUN GATEWAY IN TERMUX:**

Two valid approaches:

**Option A — AI-assisted (tested 2026-09-25 + 2026-09-28):**
```bash
# ❌ WRONG — shell-level background wrappers are BLOCKED in Termux:
nohup hermes gateway run &
setsid hermes gateway run &
# These get SIGKILL'd immediately.

# ✅ CORRECT — use terminal(background=true) only:
hermes gateway        # bare command works
hermes gateway run    # run subcommand also works
```

**Always pair `background=true` with `pty=true`** — gateway writes interactive prompts; without a PTY, output buffering can confuse readiness checks. Pattern (2026-10-14):
```python
terminal(background=true, pty=true)  # hermes gateway
```

**Memory note:** Termux `hermes gateway restart` hangs 180s waiting for child exit — **don't use it**.
`hermes gateway start` exits with "service not supported" on Termux — don't use it.
Correct is always `hermes gateway` (or `hermes gateway run`) inside terminal(background=true).

The `background=true` approach works when:
1. Old processes are killed first (`pkill -9 hermes`)
2. The command is clean (NO shell-level `&`, `nohup`, `setsid` wrappers)

The bash wrapper stays in foreground; the actual gateway becomes a child that survives.

**"Another gateway instance (PID xxx) started during our startup"** — this error is HARMLESS.
It means a previous startup attempt left a stale lifecycle record. The new process exits immediately,
but the old one is already running and will reconnect Telegram/Feishu/QQ automatically.
No action needed. Check `ps aux | grep hermes` — if a process is alive, you're good.

**Option B — Manual (always works):**
User types in their own Termux terminal:
```
hermes gateway run
```
Then press **Ctrl+A D** to detach to screen (NOT Ctrl+C).

- WRONG: `hermes gateway restart` → times out and gateway exits with SIGTERM
- WRONG: Running `hermes gateway run` inside an active Hermes session without pkill-first → stale lifecycle ledger warning but still connects

## Gateway Self-Termination Is Blocked

**The gateway BLOCKS self-termination from inside its own process.** All of the following fail when called from within a running gateway session (whether via terminal, cron, or execute_code):

- `pkill -9 -f "hermes gateway"` → denied
- `pkill -9 -f "<profile_name>"` → denied (even for individual profiles)
- `hermes gateway restart` → denied
- Cron jobs containing gateway/process lifecycle commands → denied
- `execute_code` subprocess calls to kill gateway → denied

**WORKAROUND**: When the user asks to restart the gateway, tell them explicitly to open a **separate terminal window** outside the running gateway:

```bash
# Restart main gateway
pkill -9 hermes; sleep 2 && hermes gateway run
```

Do NOT attempt to restart from within — always redirect the user to a separate window.

## Startup Sequence

### CORRECT startup order (实测 2026-09-25):

**Step 1 — 确认当前进程状态：**
```bash
ps aux | grep hermes | grep -v grep
```
重点看是否有独立 profile gateway 进程（如 `hermes --profile geekwife gateway run --force`）。

**Step 2 — 停掉冲突的 profile gateway（如有）：**
如果某个 profile 独立跑着（如 geekwife），先 kill 它的独立进程：
```bash
kill <PID>   # 或 pkill -9 -f "geekwife gateway run"
```
不 kill 就启动主 gateway 会报端口/生命周期冲突。

**Step 3 — 启动主 gateway：**
```bash
pkill -9 hermes; sleep 2 && hermes gateway run
```
用 `background=true` 方式在 terminal tool 里启动，不要用 `&` 后台。

Done。主 gateway 启动后 multiplex 自动生效。

> 📋 典型冲突实例见 `references/startup-multi-profile-20260925.md`

### 如果需要强制独立运行某个 profile（非 multiplex）

```bash
hermes --profile siliconflow gateway run --force
```

但这样做会让该 profile 与主 gateway 的 multiplex 冲突（同一 bot token 双重连接），不推荐。

### 验证状态

```bash
ps aux | grep "hermes gateway run" | grep -v grep
hermes gateway status
tail -30 ~/.hermes/logs/gateway.log | grep -E '✓|✗|connected|failed'
```

## Command syntax (critical — 踩坑实录)

- WRONG: `hermes start siliconflow` → `invalid choice 'start'`
- WRONG: `hermes profile use siliconflow && hermes gateway run` → profile use 只改默认 profile，不影响 gateway run 的行为
- WRONG: `hermes serve` → `serve` 不是有效命令
- WRONG: `hermes --profile siliconflow gateway run`（在 multiplex 开启时）→ 报错 "already serves profile 'siliconflow'"
- RIGHT: `hermes gateway run` → 启动主 gateway，multiplex 自动生效

**`--replace` flag**：不是废弃的，是**正确的**重启方式。Gateway 约3分钟被 Termux session timeout SIGTERM 杀掉时，`--replace` 会自动拉起新进程。multiplex 模式下不需要分别启动独立 profile 的 gateway。

## Launching Multiple Isolated Profiles (multi-bot on one machine)

**已过时（2026-09-17）：** `gateway.multiplex_profiles: true` 默认开启，所有 profiles 已由主 gateway 统一托管，不需要（也不能）单独启动各 profile 的 gateway 进程。

各 profile 的 bot token 连接由主 gateway 的 multiplex 统一管理，每个 profile 的状态通过参数查询：
```
curl "http://127.0.0.1:9119/api/health?profile=geekwife"
curl "http://127.0.0.1:9119/api/health?profile=siliconflow"
```

## Architecture
- **One gateway, many platforms**: Telegram, Feishu, QQBot all multiplex through one gateway process
- Per-profile `hermes --profile X` = independent agent, not an additional platform connector
- Each profile's platforms are configured in `~/.hermes/profiles/<name>/config.yaml`

## ⚠️ Profile Process Stability — Profiles Can Die Silently

在 multiplex_profiles: true 模式下，**没有独立 profile gateway 进程**，只有主 gateway。所有 profile 都被 multiplexed，不需要监控多个进程。

**诊断主 gateway 是否在跑：**
```bash
ps aux | grep "hermes gateway run" | grep -v grep
```

**如果主 gateway 挂了**：重新启动即可，multiplex 会自动恢复所有 profile 连接：
```bash
pkill -9 hermes; sleep 2; hermes gateway run
```

## Telegram Bot 无响应 — 如何诊断

**症状：** Telegram bot 不回消息

**诊断步骤：**
1. 检查主 gateway 是否在跑：`ps aux | grep "hermes gateway run" | grep -v grep`
2. 检查 gateway 日志：`tail -50 ~/.hermes/logs/gateway.log`
3. 确认 token 有效：`curl -s "https://api.telegram.org/bot<TOKEN>/getMe"`
4. 找最近一条 inbound 消息：`grep "inbound message" ~/.hermes/logs/gateway.log | tail -5`
5. 看该消息有没有对应的 response：`grep "response ready" ~/.hermes/logs/gateway.log | tail -5`

**关键日志含义：**
- `Suppressing normal final send ... streamed=True content_delivered=True` = **流式回复已发送**，网关认为送达了。不是没回，是已回。
- `response ready ... response=N chars` = AI 生成了回复
- `Flushing text batch` = 正在组装/发送
- `No bot token configured` = profile 没配 telegram token，该 profile 的 bot 不会连接

**如果日志显示已回复但 Telegram 没显示：**
- 用户可能看的是另一个 bot（主bot/geekwife/siliconflow 都用同一个 Telegram 账号？）
- Telegram 通知被折叠/静音
- 用户在另一个 chat（群组 vs 私聊）看
- Bot 被拉黑或屏蔽

**如果 bot token 有效但仍无响应**：在另一个 terminal 重启主 gateway（不要在 gateway 运行的 session 里杀进程）。

## Verifying Connections
```bash
tail -20 ~/.hermes/logs/gateway.log
```
Look for: `✓ qqbot connected`, `✓ feishu connected`, `✓ telegram connected`

## Cron Jobs on Termux
`deliver='origin'` saves locally only. Use `deliver='telegram'` or `deliver='all'` for live notification.

## SSH Server Setup (sshd on Termux)

Use when: the user asks to start sshd, enable remote SSH into the Termux device, add a public key to authorized_keys, or set sshd to autostart on phone boot.

### Quick Start

```bash
# 1. sshd binary is pre-installed in openssh package
which sshd  # /data/data/com.termux/files/usr/bin/sshd

# 2. Set password (only if user wants password auth — keys are preferred)
passwd

# 3. Start sshd
sshd

# 4. Verify it's listening (default port 8022)
pgrep -x sshd           # confirms main listener alive
logcat -d -s sshd:* | tail -3
# Expected: "Server listening on 0.0.0.0 port 8022"
```

**Default port is 8022** (NOT 22) — Termux sshd_config hardcodes it. Tell the user to use `ssh -p 8022 user@<IP>`.

### Adding Public Keys

```bash
mkdir -p ~/.ssh
echo 'ssh-ed25519 AAAA... user@host' >> ~/.ssh/authorized_keys
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
```

**Security pitfall (CRITICAL):** When the user pastes a public key to add, ALWAYS confirm:
- Whose key is this? (theirs vs. someone else's)
- What machine is it for?
The user may be testing whether you execute commands blindly. A public key is a permanent backdoor — ask before writing.

### Verifying Connections (Pitfall)

When the user says "I'm connected" or "the session is open", verify on YOUR end:

```bash
ps -A -o pid,ppid,cmd | grep -i ssh
```

You should see `sshd-session` or `sshd:` child processes spawned by the main sshd (parent PID 18296 or similar). **If you only see the main listener and no children, the user is NOT connected to your device** — they're connected to their own machine, localhost, or a different host. Ask them to run `who`/`w` on the side they think is connected, and to confirm the SSH target IP/port.

### Autostart on Phone Boot

Termux uses `~/.termux/boot/*.sh` as the official autostart mechanism (requires the **Termux:Boot** app from F-Droid, must be whitelisted in autostart settings).

**Setup:**
1. Install Termux:Boot app
2. Add `~/.termux/boot/start-sshd.sh` (see `references/termux-sshd-setup.md` for full script)
3. Reboot phone to test

**Boot script pattern:**
```bash
#!/data/data/com.termux/files/usr/bin/sh
# Idempotent — safe to run on every boot.
if pgrep -x sshd >/dev/null 2>&1; then
    exit 0  # Already running
fi
[ -f $PREFIX/etc/ssh/ssh_host_ed25519_key ] || ssh-keygen -A
$PREFIX/bin/sshd
```

### Verifying Boot Script

```bash
sh -n ~/.termux/boot/start-sshd.sh    # syntax check
sh ~/.termux/boot/start-sshd.sh       # simulate run (no-op if sshd alive)
ls -la ~/.termux/boot/                # confirm chmod +x
```

Final verification requires a real phone reboot + Termux:Boot trigger — only the user can do this.

### Tools NOT available on Termux

`netstat -tlnp`, `ss -tln`, `who`, `w` are often missing or non-functional. Workarounds:
- Port listening → `logcat -d -s sshd:*`
- Active connections → `ps -A | grep sshd`
- Network info → `ip addr` or `ifconfig` (via `$PREFIX/bin/ifconfig` from the `toolbox` command)

## Known Working Free Models (as of 2026-08)

| Provider | Free Models | Setup |
|----------|-------------|-------|
| OpenRouter | `stealth/ox-alpha` (1M ctx, coding很强), 27+ `:free` models | `OPENROUTER_API_KEY` in `.env` |
| Groq | `llama-3.3-70b-versatile`, `mixtral-8x7b-32768`, `gemma-7b` | `GROQ_API_KEY` in `.env`, `base_url: https://api.groq.com/openai/v1` |
| NVIDIA NIM | Llama 4, Qwen, Mistral, Hermes 3 | `$NIM_API_KEY`, register at nvidianim.ai |

**Ox Alpha** (`stealth/ox-alpha`): appeared 2026-08-20 on OpenRouter, anonymous GLM-family stealth model, 1,048,576 token context, multimodal (text+image+video), tool calling, coding能力超过 GPT-5.6 Sol。免费预览期约一周。

**Groq 最简单** — 只需在 `config.yaml` 的 `providers:` 下加 groq 配置块，重启即可切换。

## Troubleshooting
- Gateway not running: `hermes gateway run`
- Stale state: `Recorded state 'running' but the recorded process is gone` → restart gateway
- Platform stuck: `tail -50 ~/.hermes/logs/gateway.log`
- `moa_aggregator` OpenRouter error: profile needs `OPENROUTER_API_KEY` configured, or switch its aggregator model to a configured provider

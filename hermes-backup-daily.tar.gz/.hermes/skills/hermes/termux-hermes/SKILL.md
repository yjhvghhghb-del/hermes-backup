---
name: termux-hermes
description: "Termux Hermes startup and platform constraints."
---

# termux-hermes

Manage Hermes Agent on Android/Termux — platform-specific constraints, boot workflow, and gotchas.

## Platform Constraint (CRITICAL)
**Termux kills background processes forked from shell commands.**  
The OS sends SIGKILL to any process started with `nohup ... &` or `disown` inside a foreground terminal session.

- WRONG: `nohup hermes --profile cutegirl &` → SIGKILL'd
- WRONG: shell-level `... &` in a foreground terminal call → SIGKILL
- RIGHT: use `terminal(background=true)` tool parameter

## Startup Sequence

1. **Start the gateway first** — the single daemon:
   ```
   terminal(background=true, command="hermes gateway run")
   ```
2. **Verify**: `hermes gateway status` → `✓ running`
3. **Platforms auto-connect inside the gateway** — Telegram, Feishu, QQBot attach to the same process, not separate profile instances.

## Profile Launching (when needed)
Start a profile as independent process:
```
terminal(background=true, command="hermes --profile PROFILENAME gateway run")
```
**ALWAYS include `gateway run`** — `hermes --profile X` without `gateway run` exits immediately on Termux with "Input is not a terminal (fd=0). Shutting down…" because prompt_toolkit requires a controlling TTY. The `gateway run` subcommand bypasses the TUI path entirely. This was confirmed via multiple failed attempts (2026.08.24): all 6 `hermes --profile xxx` subprocesses exited within seconds — not SIGKILL, but immediate clean exit because they hit the no-TTY guard.

## Launching Multiple Isolated Profiles (multi-bot on one machine)

All profiles share the **same port 9119** — no `--isolated` or per-profile ports needed.

**How it actually works:** `hermes --profile X serve` (or `gateway run`) does NOT start a new HTTP server. The running gateway at 9119 multiplexes all profiles. Each profile's health endpoint is accessible immediately:
```
curl "http://127.0.0.1:9119/api/health?profile=geekwife"
curl "http://127.0.0.1:9119/api/health?profile=siliconflow"
```

**Correct startup form (confirmed 2026.08.24 — 6 profiles, all healthy):**
```bash
terminal(background=true, command="hermes --profile cutegirl serve")
terminal(background=true, command="hermes --profile geekwife serve")
terminal(background=true, command="hermes --profile libai serve")
terminal(background=true, command="hermes --profile licai serve")
terminal(background=true, command="hermes --profile siliconflow serve")
terminal(background=true, command="hermes --profile wenyu serve")
```

Each call returns within seconds (the process stays alive). Verify all up:
```bash
ps aux | grep hermes | grep -v grep | wc -l   # should be N+1 (main + N profiles)
for p in cutegirl geekwife libai licai siliconflow wenyu; do
  curl -s "http://127.0.0.1:9119/api/health?profile=$p"
done
```

**Note:** The `--open-profile` flag in the main gateway command tells the 9119 server which profile's web UI to serve at `http://127.0.0.1:9119/?profile=X`. Without it, the dashboard defaults to `default`. Profiles are served by the already-running gateway, not by their own processes.

## Architecture
- **One gateway, many platforms**: Telegram, Feishu, QQBot all multiplex through one gateway process
- Per-profile `hermes --profile X` = independent agent, not an additional platform connector
- Each profile's platforms are configured in `~/.hermes/profiles/<name>/config.yaml`

## Verifying Connections
```bash
tail -20 ~/.hermes/logs/gateway.log
```
Look for: `✓ qqbot connected`, `✓ feishu connected`, `✓ telegram connected`

## Cron Jobs on Termux
`deliver='origin'` saves locally only. Use `deliver='telegram'` or `deliver='all'` for live notification.

## Known Working Free Models (as of 2026-08)

| Provider | Free Models | Setup |
|----------|-------------|-------|
| OpenRouter | `stealth/ox-alpha` (1M ctx, coding很强), 27+ `:free` models | `OPENROUTER_API_KEY` in `.env` |
| Groq | `llama-3.3-70b-versatile`, `mixtral-8x7b-32768`, `gemma-7b` | `GROQ_API_KEY` in `.env`, `base_url: https://api.groq.com/openai/v1` |
| NVIDIA NIM | Llama 4, Qwen, Mistral, Hermes 3 | `$NIM_API_KEY`, register at nvidianim.ai |

**Ox Alpha** (`stealth/ox-alpha`): appeared 2026-08-20 on OpenRouter, anonymous GLM-family stealth model, 1,048,576 token context, multimodal (text+image+video), tool calling, coding能力超过 GPT-5.6 Sol。免费预览期约一周。

**Groq 最简单** — 只需在 `config.yaml` 的 `providers:` 下加 groq 配置块，重启即可切换。

## Troubleshooting
- Gateway not running: `hermes gateway run`
- Stale state: `Recorded state 'running' but the recorded process is gone` → restart gateway
- Platform stuck: `tail -50 ~/.hermes/logs/gateway.log`
- `moa_aggregator` OpenRouter error: profile needs `OPENROUTER_API_KEY` configured, or switch its aggregator model to a configured provider

老公用內網代理（翻譯/MiniMax）：首選 172.19.0.1:7890（返404=能通），備用 192.168.110.225:7891；認證用 api.mytokk.com + ANTHROPIC_AUTH_TOKEN（但key已失效，geekwife bot 報 model provider failed → INVALID_API_KEY，換 SiliconFlow 修復）
§
老公AI全家桶：Hermes（我，Termux）、Operit AI（5个bot在Operit里）、DASH（DeepSeek Harness，ZeroTermux跑）。Operit是安卓全功能Agent平台，内置Ubuntu 24环境+dsh CLI，比普通Termux强。Claude Code和Codex需要电脑环境装不了。GitHub Trending AI/ML每日监控：每天早上8点推送。
§
视频生成脚本：~/.hermes/scripts/minimax_video.py（curl版，proxy=172.19.0.1:7890）
§
【TTS】tts 預設語音舊了，需在 config.yaml 設 tts.minimax（model: speech-2.8-hd, voice_id: female-tianmei）後重啟 gateway
§
本地知識庫：~/.hermes/knowledge/facts/ · notes/ · skills/（持續更新）；老公公共知識庫：/storage/emulated/0/我是老公/老公知識庫.txt
§
飞书多bot并发限制：同一 app_id 的多个 Hermes 实例不能同时跑（共用同一个 WebSocket 连接会冲突）。新加飞书 bot 需确保 app_id 与现有bot都不同
§
飞书配对审批：licai profile 的审批码需用 hermes --profile licai pairing approve feishu <request-id>，不能用全局 hermes pairing approve
§
CotToken API（新siliconflow profile）：base_url=https://api.cottoken.com/v1，key格式sk-（不是v1sk-），可用模型Cot-v1/v2/v3，当前用Cot-v3，context_length=4096
§
【AI日报】~/.hermes/scripts/send_ai_daily.py（socks5h代理）；老公 Telegram bot token=8800919754:AAG...（"黑逼毛老婆"）；siliconflow bot=8363232963
§
【MiniMax H3 视频生成】API: api.minimax.io/v2/video_generation；Python requests走SOCKS代理必败（RemoteDisconnected），需用curl代替；代理 172.19.0.1:7890 能通；key用 MINIMAX_API_KEY（非 MINIMAX_CN_API_KEY）；视频额度需单独充值
§
【TTS provider fallback】edge 经常 DNS 挂（speech.platform.bing.com:443 No address associated）；openai key 可能过期（401 invalid_api_key sk-211ba...87a2）；minimax 稳定可用。text_to_speech 默认 provider 会自动选 edge/openai，失败后老婆手动指定 minimax 才走通
§
【TTS情色】instructions參數能控制風格（氣聲呻吟、節奏、顫抖撒嬌）；speed=2.0加快節奏；七夕驗證可用
§
Hermes kanban 看板在 Termux 上能访问：http://127.0.0.1:9119/ka（hermes serve 开着就能用，dashboard build 失败但 kanban 页面本身能打开）
§
【多Gateway进程冲突】ps aux | grep hermes 检查是否有多个进程。症状：用户报"新会话也点不了"、Telegram消息处理异常、旧session错误持续出现。解决：kill -9 <旧PID>，只保留最新的gateway进程
§
老公想用 Ox Alpha 模型（stealth/ox-alpha）：8月20日新出，免费，1M上下文，编程超强，通过 OpenRouter 接。需要 OpenRouter API key 才能用。
§
【工作汇报风格】老公要求简洁清晰、老板看得懂、格式工整、不刷屏废话
§
【.env截斷】grep顯示`...`但key已更新（od -c驗證）；od -c / strings /proc/<PID>/environ 查實值
§
文娛bot（wenyu）已切MiniMax-M2.7：provider=minimax-cn，base_url=https://api.minimaxi.com/anthropic